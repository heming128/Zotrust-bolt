-- Location: supabase/migrations/20250902234000_add_city_column_to_users.sql
-- Schema Analysis: Adding city column to existing users table for city-based onboarding
-- Integration Type: modification/extension to existing users table
-- Dependencies: users table (already exists)

-- Add city column to existing users table for city-based functionality
ALTER TABLE public.users
ADD COLUMN IF NOT EXISTS city TEXT;

-- Add index for city column for efficient filtering
CREATE INDEX IF NOT EXISTS idx_users_city ON public.users(city);

-- Add created_city timestamp to track when city was first set
ALTER TABLE public.users
ADD COLUMN IF NOT EXISTS city_set_at TIMESTAMPTZ;

-- Mock data update: Set city for existing users
DO $$
DECLARE
    existing_user_count INTEGER;
BEGIN
    -- Get count of existing users
    SELECT COUNT(*) INTO existing_user_count FROM public.users;
    
    IF existing_user_count > 0 THEN
        -- Update existing users with sample cities for testing
        UPDATE public.users 
        SET city = CASE 
            WHEN username = 'buyer_user' THEN 'Mumbai'
            WHEN username = 'seller_user' THEN 'Delhi'
            ELSE 'Bangalore'
        END,
        city_set_at = NOW()
        WHERE city IS NULL;
        
        RAISE NOTICE 'Updated % existing users with city information', existing_user_count;
    ELSE
        RAISE NOTICE 'No existing users found to update';
    END IF;
EXCEPTION
    WHEN OTHERS THEN
        RAISE NOTICE 'Error updating users: %', SQLERRM;
END $$;