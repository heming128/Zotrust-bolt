-- Location: supabase/migrations/20250827050352_call_signaling_system.sql
-- Schema Analysis: Fresh P2P call signaling implementation 
-- Integration Type: Addition - Call signaling with WebRTC support
-- Dependencies: user_profiles table (assumes existing from P2P system)

-- Create call status enum
CREATE TYPE public.call_status AS ENUM (
    'initiating',
    'ringing', 
    'active',
    'ended',
    'declined',
    'failed',
    'missed'
);

-- Create call type enum
CREATE TYPE public.call_type AS ENUM (
    'voice',
    'video'
);

-- Create calls table for call management
CREATE TABLE public.calls (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    caller_id UUID REFERENCES public.user_profiles(id) ON DELETE CASCADE,
    callee_id UUID REFERENCES public.user_profiles(id) ON DELETE CASCADE,
    call_type public.call_type NOT NULL DEFAULT 'voice'::public.call_type,
    call_status public.call_status NOT NULL DEFAULT 'initiating'::public.call_status,
    room_id TEXT NOT NULL UNIQUE,
    sdp_offer TEXT,
    sdp_answer TEXT,
    started_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    answered_at TIMESTAMPTZ,
    ended_at TIMESTAMPTZ,
    duration_seconds INTEGER DEFAULT 0,
    ended_by_id UUID REFERENCES public.user_profiles(id) ON DELETE SET NULL,
    failure_reason TEXT,
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);

-- Create call_signaling table for WebRTC signaling
CREATE TABLE public.call_signaling (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    call_id UUID REFERENCES public.calls(id) ON DELETE CASCADE,
    sender_id UUID REFERENCES public.user_profiles(id) ON DELETE CASCADE,
    signal_type TEXT NOT NULL CHECK (signal_type IN ('offer', 'answer', 'ice-candidate', 'end-call')),
    signal_data JSONB NOT NULL,
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);

-- Create indexes for efficient querying
CREATE INDEX idx_calls_caller_id ON public.calls(caller_id);
CREATE INDEX idx_calls_callee_id ON public.calls(callee_id);
CREATE INDEX idx_calls_room_id ON public.calls(room_id);
CREATE INDEX idx_calls_status ON public.calls(call_status);
CREATE INDEX idx_calls_started_at ON public.calls(started_at);
CREATE INDEX idx_call_signaling_call_id ON public.call_signaling(call_id);
CREATE INDEX idx_call_signaling_created_at ON public.call_signaling(created_at);

-- Enable RLS for call tables
ALTER TABLE public.calls ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.call_signaling ENABLE ROW LEVEL SECURITY;

-- RLS Policies for calls table
-- Users can manage calls they are part of (caller or callee)
CREATE POLICY "users_manage_own_calls"
ON public.calls
FOR ALL
TO authenticated
USING (caller_id = auth.uid() OR callee_id = auth.uid())
WITH CHECK (caller_id = auth.uid() OR callee_id = auth.uid());

-- RLS Policies for call_signaling table
-- Users can manage signaling for calls they are part of
CREATE POLICY "users_manage_call_signaling"
ON public.call_signaling
FOR ALL
TO authenticated
USING (
    EXISTS (
        SELECT 1 FROM public.calls c 
        WHERE c.id = call_id 
        AND (c.caller_id = auth.uid() OR c.callee_id = auth.uid())
    )
)
WITH CHECK (
    EXISTS (
        SELECT 1 FROM public.calls c 
        WHERE c.id = call_id 
        AND (c.caller_id = auth.uid() OR c.callee_id = auth.uid())
    )
);

-- Function to initiate a call
CREATE OR REPLACE FUNCTION public.initiate_call(
    p_callee_id UUID,
    p_call_type public.call_type DEFAULT 'voice'::public.call_type
)
RETURNS UUID
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    v_room_id TEXT;
    v_call_id UUID;
BEGIN
    -- Generate unique room ID
    v_room_id := 'room_' || gen_random_uuid()::TEXT;
    
    -- Create the call record
    INSERT INTO public.calls (
        caller_id,
        callee_id,
        call_type,
        room_id,
        call_status
    ) VALUES (
        auth.uid(),
        p_callee_id,
        p_call_type,
        v_room_id,
        'initiating'::public.call_status
    ) RETURNING id INTO v_call_id;
    
    RETURN v_call_id;
END;
$$;

-- Function to update call status
CREATE OR REPLACE FUNCTION public.update_call_status(
    p_call_id UUID,
    p_status public.call_status,
    p_failure_reason TEXT DEFAULT NULL
)
RETURNS BOOLEAN
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    v_current_status public.call_status;
    v_duration INTEGER;
BEGIN
    -- Get current status
    SELECT call_status INTO v_current_status
    FROM public.calls
    WHERE id = p_call_id
    AND (caller_id = auth.uid() OR callee_id = auth.uid());
    
    IF v_current_status IS NULL THEN
        RETURN FALSE;
    END IF;
    
    -- Calculate duration if ending call
    IF p_status = 'ended'::public.call_status AND v_current_status = 'active'::public.call_status THEN
        SELECT EXTRACT(EPOCH FROM (CURRENT_TIMESTAMP - answered_at))::INTEGER 
        INTO v_duration
        FROM public.calls
        WHERE id = p_call_id;
        
        UPDATE public.calls
        SET 
            call_status = p_status,
            ended_at = CURRENT_TIMESTAMP,
            duration_seconds = COALESCE(v_duration, 0),
            ended_by_id = auth.uid(),
            failure_reason = p_failure_reason,
            updated_at = CURRENT_TIMESTAMP
        WHERE id = p_call_id;
    ELSIF p_status = 'active'::public.call_status THEN
        UPDATE public.calls
        SET 
            call_status = p_status,
            answered_at = CURRENT_TIMESTAMP,
            updated_at = CURRENT_TIMESTAMP
        WHERE id = p_call_id;
    ELSE
        UPDATE public.calls
        SET 
            call_status = p_status,
            failure_reason = p_failure_reason,
            updated_at = CURRENT_TIMESTAMP
        WHERE id = p_call_id;
    END IF;
    
    RETURN TRUE;
END;
$$;

-- Function to add signaling data
CREATE OR REPLACE FUNCTION public.add_signaling_data(
    p_call_id UUID,
    p_signal_type TEXT,
    p_signal_data JSONB
)
RETURNS UUID
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    v_signaling_id UUID;
BEGIN
    INSERT INTO public.call_signaling (
        call_id,
        sender_id,
        signal_type,
        signal_data
    ) VALUES (
        p_call_id,
        auth.uid(),
        p_signal_type,
        p_signal_data
    ) RETURNING id INTO v_signaling_id;
    
    RETURN v_signaling_id;
END;
$$;

-- Function to get active calls for a user
CREATE OR REPLACE FUNCTION public.get_user_active_calls(p_user_id UUID DEFAULT NULL)
RETURNS TABLE(
    call_id UUID,
    caller_name TEXT,
    callee_name TEXT,
    call_type public.call_type,
    call_status public.call_status,
    room_id TEXT,
    started_at TIMESTAMPTZ,
    is_caller BOOLEAN
)
LANGUAGE sql
STABLE
SECURITY DEFINER
AS $$
SELECT 
    c.id as call_id,
    caller.display_name as caller_name,
    callee.display_name as callee_name,
    c.call_type,
    c.call_status,
    c.room_id,
    c.started_at,
    (c.caller_id = COALESCE(p_user_id, auth.uid())) as is_caller
FROM public.calls c
JOIN public.user_profiles caller ON c.caller_id = caller.id
JOIN public.user_profiles callee ON c.callee_id = callee.id
WHERE (c.caller_id = COALESCE(p_user_id, auth.uid()) OR c.callee_id = COALESCE(p_user_id, auth.uid()))
AND c.call_status IN ('initiating', 'ringing', 'active')
ORDER BY c.started_at DESC;
$$;

-- Mock data for call signaling
DO $$
DECLARE
    existing_user1_id UUID;
    existing_user2_id UUID;
    test_call_id UUID := gen_random_uuid();
    test_room_id TEXT := 'room_' || gen_random_uuid()::TEXT;
BEGIN
    -- Get existing user IDs from user_profiles
    SELECT id INTO existing_user1_id FROM public.user_profiles LIMIT 1;
    SELECT id INTO existing_user2_id FROM public.user_profiles OFFSET 1 LIMIT 1;
    
    -- If we don't have enough users, use the same user for both (for demo)
    IF existing_user2_id IS NULL THEN
        existing_user2_id := existing_user1_id;
    END IF;
    
    IF existing_user1_id IS NOT NULL THEN
        -- Create sample call
        INSERT INTO public.calls (
            id, caller_id, callee_id, call_type, call_status, room_id,
            started_at, duration_seconds
        ) VALUES (
            test_call_id, existing_user1_id, existing_user2_id, 'voice'::public.call_type,
            'ended'::public.call_status, test_room_id,
            CURRENT_TIMESTAMP - INTERVAL '5 minutes', 300
        );
        
        -- Create sample signaling data
        INSERT INTO public.call_signaling (
            call_id, sender_id, signal_type, signal_data
        ) VALUES (
            test_call_id, existing_user1_id, 'offer',
            '{"type": "offer", "sdp": "v=0\\r\\no=- 123456789 2 IN IP4 127.0.0.1\\r\\n..."}'::jsonb
        );
        
        RAISE NOTICE 'Call signaling mock data created successfully for users: % and %', existing_user1_id, existing_user2_id;
    ELSE
        RAISE NOTICE 'No existing users found. Please create user profiles first.';
    END IF;

EXCEPTION
    WHEN OTHERS THEN
        RAISE NOTICE 'Error creating call signaling mock data: %', SQLERRM;
END $$;

-- Add helpful comments
COMMENT ON TABLE public.calls IS 'Call management table storing call sessions and metadata';
COMMENT ON TABLE public.call_signaling IS 'WebRTC signaling data for call establishment';
COMMENT ON FUNCTION public.initiate_call(UUID, public.call_type) IS 'Creates a new call session between two users';
COMMENT ON FUNCTION public.update_call_status(UUID, public.call_status, TEXT) IS 'Updates call status and calculates duration';
COMMENT ON FUNCTION public.add_signaling_data(UUID, TEXT, JSONB) IS 'Stores WebRTC signaling data for call negotiation';
COMMENT ON FUNCTION public.get_user_active_calls(UUID) IS 'Retrieves active calls for a user';