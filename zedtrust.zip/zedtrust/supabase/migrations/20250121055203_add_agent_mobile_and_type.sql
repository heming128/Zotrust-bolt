-- Migration to add mobile number and agent type fields to the agents table
-- Location: supabase/migrations/20250121055203_add_agent_mobile_and_type.sql
-- Adding mobile number and agent type fields to support hawala agent management

-- Step 1: Add new columns to agents table
ALTER TABLE public.agents ADD COLUMN mobile_number TEXT;
ALTER TABLE public.agents ADD COLUMN agent_type TEXT DEFAULT 'hawala';

-- Step 2: Add check constraint for agent type
ALTER TABLE public.agents ADD CONSTRAINT check_agent_type 
CHECK (agent_type IN ('hawala', 'financial', 'exchange', 'general'));

-- Step 3: Create index for mobile number searches
CREATE INDEX idx_agents_mobile_number ON public.agents(mobile_number) WHERE mobile_number IS NOT NULL;
CREATE INDEX idx_agents_type ON public.agents(agent_type);

-- Step 4: Update existing agents to have hawala type
UPDATE public.agents SET agent_type = 'hawala' WHERE agent_type IS NULL;

-- Step 5: Add comments for documentation
COMMENT ON COLUMN public.agents.mobile_number IS 'Agent contact mobile number for verification and communication';
COMMENT ON COLUMN public.agents.agent_type IS 'Type of agent service: hawala, financial, exchange, or general';