-- Location: supabase/migrations/20250822035000_platform_settings_admin.sql
-- Schema Analysis: Building upon existing ZedTrust P2P trading platform
-- Integration Type: Addition - Admin platform configuration
-- Dependencies: No existing table dependencies required

-- Create platform settings table for admin configurations
CREATE TABLE public.platform_settings (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    setting_key TEXT NOT NULL UNIQUE,
    setting_value TEXT NOT NULL,
    setting_type TEXT NOT NULL DEFAULT 'string',
    description TEXT,
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);

-- Create index for efficient settings lookups
CREATE INDEX idx_platform_settings_key ON public.platform_settings(setting_key);
CREATE INDEX idx_platform_settings_active ON public.platform_settings(is_active);

-- Enable RLS
ALTER TABLE public.platform_settings ENABLE ROW LEVEL SECURITY;

-- Helper function to check admin role from auth metadata
CREATE OR REPLACE FUNCTION public.is_admin_from_auth()
RETURNS BOOLEAN
LANGUAGE sql
STABLE
SECURITY DEFINER
AS $$
SELECT EXISTS (
    SELECT 1 FROM auth.users au
    WHERE au.id = auth.uid() 
    AND (au.raw_user_meta_data->>'role' = 'admin' 
         OR au.raw_app_meta_data->>'role' = 'admin')
)
$$;

-- RLS Policy: Only admins can manage platform settings
CREATE POLICY "admin_manage_platform_settings"
ON public.platform_settings
FOR ALL
TO authenticated
USING (public.is_admin_from_auth())
WITH CHECK (public.is_admin_from_auth());

-- Create function to get platform setting value
CREATE OR REPLACE FUNCTION public.get_platform_setting(key_name TEXT)
RETURNS TEXT
LANGUAGE sql
STABLE
SECURITY DEFINER
AS $$
SELECT setting_value 
FROM public.platform_settings 
WHERE setting_key = key_name 
AND is_active = true
LIMIT 1
$$;

-- Create function to update platform setting
CREATE OR REPLACE FUNCTION public.update_platform_setting(
    key_name TEXT, 
    new_value TEXT, 
    setting_description TEXT DEFAULT NULL
)
RETURNS BOOLEAN
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
    -- Check admin permission
    IF NOT public.is_admin_from_auth() THEN
        RAISE EXCEPTION 'Unauthorized: Admin access required';
    END IF;
    
    -- Insert or update setting
    INSERT INTO public.platform_settings (setting_key, setting_value, description, updated_at)
    VALUES (key_name, new_value, setting_description, CURRENT_TIMESTAMP)
    ON CONFLICT (setting_key) 
    DO UPDATE SET 
        setting_value = EXCLUDED.setting_value,
        description = COALESCE(EXCLUDED.description, platform_settings.description),
        updated_at = CURRENT_TIMESTAMP;
    
    RETURN TRUE;
EXCEPTION
    WHEN OTHERS THEN
        RAISE NOTICE 'Error updating platform setting: %', SQLERRM;
        RETURN FALSE;
END;
$$;

-- Insert initial platform settings
DO $$
BEGIN
    -- Platform fees wallet address
    INSERT INTO public.platform_settings (setting_key, setting_value, setting_type, description) VALUES
        ('platform_fees_wallet_address', '', 'wallet_address', 'Wallet address where 1% platform fees from both buyers and sellers are collected'),
        ('platform_fee_percentage', '1.0', 'decimal', 'Platform fee percentage (default 1%)'),
        ('platform_fees_enabled', 'true', 'boolean', 'Enable or disable platform fee collection'),
        ('min_trade_amount', '10.00', 'decimal', 'Minimum trade amount in USD to apply platform fees'),
        ('max_daily_fee_collection', '10000.00', 'decimal', 'Maximum daily fee collection limit in USD')
    ON CONFLICT (setting_key) DO NOTHING;
    
    RAISE NOTICE 'Platform settings initialized successfully';
EXCEPTION
    WHEN OTHERS THEN
        RAISE NOTICE 'Error initializing platform settings: %', SQLERRM;
END $$;