-- Location: supabase/migrations/20250830020000_complete_zedtrust_backend_setup.sql
-- Schema Analysis: Building upon existing ZedTrust schema with complete backend setup
-- Integration Type: Extension - Adding missing OTP logs and enhancing existing functionality
-- Dependencies: agents, agent_locations, user_profiles, trades, calls (existing tables)

-- Step 1: Create OTP logs table for trade verification
CREATE TABLE IF NOT EXISTS public.otp_logs (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    trade_id UUID REFERENCES public.trades(id) ON DELETE CASCADE,
    otp_code TEXT NOT NULL,
    otp_color TEXT NOT NULL,
    is_verified BOOLEAN DEFAULT false,
    verified_at TIMESTAMPTZ,
    verified_by_id UUID REFERENCES public.user_profiles(id) ON DELETE SET NULL,
    expires_at TIMESTAMPTZ NOT NULL DEFAULT (CURRENT_TIMESTAMP + INTERVAL '15 minutes'),
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);

-- Step 2: Create indexes for OTP logs
CREATE INDEX idx_otp_logs_trade_id ON public.otp_logs(trade_id);
CREATE INDEX idx_otp_logs_otp_code ON public.otp_logs(otp_code);
CREATE INDEX idx_otp_logs_expires_at ON public.otp_logs(expires_at);
CREATE INDEX idx_otp_logs_is_verified ON public.otp_logs(is_verified);

-- Step 3: Enable RLS for OTP logs
ALTER TABLE public.otp_logs ENABLE ROW LEVEL SECURITY;

-- Step 4: Create RLS policies for OTP logs
-- Users can view OTP logs for their own trades
CREATE POLICY "users_view_own_trade_otps"
ON public.otp_logs
FOR SELECT
TO authenticated
USING (
    EXISTS (
        SELECT 1 FROM public.trades t
        WHERE t.id = trade_id
        AND (t.buyer_id = auth.uid() OR t.seller_id = auth.uid())
    )
);

-- Users can create OTP logs for their own trades
CREATE POLICY "users_create_trade_otps"
ON public.otp_logs
FOR INSERT
TO authenticated
WITH CHECK (
    EXISTS (
        SELECT 1 FROM public.trades t
        WHERE t.id = trade_id
        AND (t.buyer_id = auth.uid() OR t.seller_id = auth.uid())
    )
);

-- Users can verify OTP logs for their own trades
CREATE POLICY "users_verify_trade_otps"
ON public.otp_logs
FOR UPDATE
TO authenticated
USING (
    EXISTS (
        SELECT 1 FROM public.trades t
        WHERE t.id = trade_id
        AND (t.buyer_id = auth.uid() OR t.seller_id = auth.uid())
    )
)
WITH CHECK (
    EXISTS (
        SELECT 1 FROM public.trades t
        WHERE t.id = trade_id
        AND (t.buyer_id = auth.uid() OR t.seller_id = auth.uid())
    )
);

-- Step 5: Create comprehensive trade management functions

-- Function to create a new trade with automatic agent matching
CREATE OR REPLACE FUNCTION public.create_trade(
    p_seller_id UUID,
    p_buyer_city TEXT,
    p_seller_city TEXT,
    p_agent_id UUID DEFAULT NULL
)
RETURNS UUID
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    v_trade_id UUID;
    v_selected_agent_id UUID;
    v_buyer_location_id UUID;
    v_seller_location_id UUID;
BEGIN
    -- Auto-select agent if not provided
    IF p_agent_id IS NULL THEN
        SELECT a.id INTO v_selected_agent_id
        FROM public.agents a
        JOIN public.agent_locations al ON a.id = al.agent_id
        WHERE a.is_verified = true
        AND al.is_active = true
        AND (al.city = p_buyer_city OR al.city = p_seller_city)
        ORDER BY a.rating DESC
        LIMIT 1;
    ELSE
        v_selected_agent_id := p_agent_id;
    END IF;
    
    -- Find suitable agent locations
    SELECT id INTO v_buyer_location_id
    FROM public.agent_locations
    WHERE agent_id = v_selected_agent_id
    AND city = p_buyer_city
    AND is_active = true
    ORDER BY created_at DESC
    LIMIT 1;
    
    SELECT id INTO v_seller_location_id
    FROM public.agent_locations
    WHERE agent_id = v_selected_agent_id
    AND city = p_seller_city
    AND is_active = true
    ORDER BY created_at DESC
    LIMIT 1;
    
    -- Create the trade
    INSERT INTO public.trades (
        buyer_id,
        seller_id,
        agent_id,
        buyer_location_id,
        seller_location_id,
        buyer_city,
        seller_city,
        status
    ) VALUES (
        auth.uid(),
        p_seller_id,
        v_selected_agent_id,
        v_buyer_location_id,
        v_seller_location_id,
        p_buyer_city,
        p_seller_city,
        'CREATED'::public.trade_status
    ) RETURNING id INTO v_trade_id;
    
    RETURN v_trade_id;
END;
$$;

-- Function to generate OTP for trade verification
CREATE OR REPLACE FUNCTION public.generate_trade_otp(p_trade_id UUID)
RETURNS TABLE(
    otp_id UUID,
    otp_code TEXT,
    otp_color TEXT,
    expires_at TIMESTAMPTZ
)
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    v_otp_code TEXT;
    v_otp_color TEXT;
    v_otp_id UUID;
    v_expires_at TIMESTAMPTZ;
    colors TEXT[] := ARRAY['red', 'blue', 'green', 'yellow', 'purple', 'orange'];
BEGIN
    -- Generate 6-digit OTP code
    v_otp_code := LPAD((RANDOM() * 999999)::INTEGER::TEXT, 6, '0');
    
    -- Select random color
    v_otp_color := colors[1 + (RANDOM() * array_length(colors, 1))::INTEGER];
    
    -- Set expiration time (15 minutes from now)
    v_expires_at := CURRENT_TIMESTAMP + INTERVAL '15 minutes';
    
    -- Insert OTP record
    INSERT INTO public.otp_logs (
        trade_id,
        otp_code,
        otp_color,
        expires_at
    ) VALUES (
        p_trade_id,
        v_otp_code,
        v_otp_color,
        v_expires_at
    ) RETURNING id INTO v_otp_id;
    
    -- Return OTP details
    RETURN QUERY
    SELECT v_otp_id, v_otp_code, v_otp_color, v_expires_at;
END;
$$;

-- Function to verify OTP
CREATE OR REPLACE FUNCTION public.verify_trade_otp(
    p_trade_id UUID,
    p_otp_code TEXT,
    p_otp_color TEXT
)
RETURNS BOOLEAN
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    v_otp_record RECORD;
    v_trade_status public.trade_status;
BEGIN
    -- Find matching OTP record
    SELECT * INTO v_otp_record
    FROM public.otp_logs
    WHERE trade_id = p_trade_id
    AND otp_code = p_otp_code
    AND otp_color = p_otp_color
    AND expires_at > CURRENT_TIMESTAMP
    AND is_verified = false
    ORDER BY created_at DESC
    LIMIT 1;
    
    -- Check if OTP was found
    IF v_otp_record.id IS NULL THEN
        RETURN FALSE;
    END IF;
    
    -- Mark OTP as verified
    UPDATE public.otp_logs
    SET 
        is_verified = true,
        verified_at = CURRENT_TIMESTAMP,
        verified_by_id = auth.uid()
    WHERE id = v_otp_record.id;
    
    -- Update trade status to RELEASED
    UPDATE public.trades
    SET 
        status = 'RELEASED'::public.trade_status,
        updated_at = CURRENT_TIMESTAMP
    WHERE id = p_trade_id;
    
    RETURN TRUE;
END;
$$;

-- Function to get verified agents with locations
CREATE OR REPLACE FUNCTION public.get_verified_agents(p_city TEXT DEFAULT NULL)
RETURNS TABLE(
    agent_id UUID,
    agent_name TEXT,
    agent_alias TEXT,
    agent_rating DECIMAL,
    location_id UUID,
    location_city TEXT,
    location_area TEXT,
    location_alias TEXT,
    location_address TEXT
)
LANGUAGE sql
STABLE
SECURITY DEFINER
AS $$
SELECT 
    a.id as agent_id,
    a.name as agent_name,
    a.alias as agent_alias,
    a.rating as agent_rating,
    al.id as location_id,
    al.city as location_city,
    al.area as location_area,
    al.display_alias as location_alias,
    al.address_line as location_address
FROM public.agents a
JOIN public.agent_locations al ON a.id = al.agent_id
WHERE a.is_verified = true
AND al.is_active = true
AND (p_city IS NULL OR al.city = p_city)
ORDER BY a.rating DESC, al.city, al.area;
$$;

-- Function to get active agent locations by city
CREATE OR REPLACE FUNCTION public.get_agent_locations_by_city(
    p_agent_id UUID,
    p_city TEXT
)
RETURNS TABLE(
    location_id UUID,
    area TEXT,
    display_alias TEXT,
    address_line TEXT,
    geo_lat DECIMAL,
    geo_lng DECIMAL
)
LANGUAGE sql
STABLE
SECURITY DEFINER
AS $$
SELECT 
    al.id as location_id,
    al.area,
    al.display_alias,
    al.address_line,
    al.geo_lat,
    al.geo_lng
FROM public.agent_locations al
WHERE al.agent_id = p_agent_id
AND al.city = p_city
AND al.is_active = true
ORDER BY al.area;
$$;

-- Function to get trade details with all related information
CREATE OR REPLACE FUNCTION public.get_trade_details(p_trade_id UUID)
RETURNS TABLE(
    trade_id UUID,
    buyer_name TEXT,
    seller_name TEXT,
    agent_name TEXT,
    buyer_location TEXT,
    seller_location TEXT,
    trade_status public.trade_status,
    created_at TIMESTAMPTZ,
    updated_at TIMESTAMPTZ,
    latest_otp_code TEXT,
    latest_otp_color TEXT,
    otp_expires_at TIMESTAMPTZ,
    is_otp_verified BOOLEAN
)
LANGUAGE sql
STABLE
SECURITY DEFINER
AS $$
SELECT 
    t.id as trade_id,
    buyer.display_name as buyer_name,
    seller.display_name as seller_name,
    a.name as agent_name,
    bl.display_alias || ', ' || bl.area as buyer_location,
    sl.display_alias || ', ' || sl.area as seller_location,
    t.status as trade_status,
    t.created_at,
    t.updated_at,
    ol.otp_code as latest_otp_code,
    ol.otp_color as latest_otp_color,
    ol.expires_at as otp_expires_at,
    ol.is_verified as is_otp_verified
FROM public.trades t
LEFT JOIN public.user_profiles buyer ON t.buyer_id = buyer.id
LEFT JOIN public.user_profiles seller ON t.seller_id = seller.id
LEFT JOIN public.agents a ON t.agent_id = a.id
LEFT JOIN public.agent_locations bl ON t.buyer_location_id = bl.id
LEFT JOIN public.agent_locations sl ON t.seller_location_id = sl.id
LEFT JOIN LATERAL (
    SELECT otp_code, otp_color, expires_at, is_verified
    FROM public.otp_logs
    WHERE trade_id = t.id
    ORDER BY created_at DESC
    LIMIT 1
) ol ON true
WHERE t.id = p_trade_id
AND (t.buyer_id = auth.uid() OR t.seller_id = auth.uid());
$$;

-- Step 6: Create comprehensive mock data
DO $$
DECLARE
    existing_user1_id UUID;
    existing_user2_id UUID;
    existing_agent_id UUID;
    test_trade_id UUID := gen_random_uuid();
    test_otp_id UUID := gen_random_uuid();
BEGIN
    -- Get existing users and agent
    SELECT id INTO existing_user1_id FROM public.user_profiles LIMIT 1;
    SELECT id INTO existing_user2_id FROM public.user_profiles OFFSET 1 LIMIT 1;
    SELECT id INTO existing_agent_id FROM public.agents WHERE is_verified = true LIMIT 1;
    
    -- Use same user for both if only one exists
    IF existing_user2_id IS NULL THEN
        existing_user2_id := existing_user1_id;
    END IF;
    
    IF existing_user1_id IS NOT NULL AND existing_agent_id IS NOT NULL THEN
        -- Create comprehensive mock trade
        INSERT INTO public.trades (
            id, buyer_id, seller_id, agent_id,
            buyer_city, seller_city, status
        ) VALUES (
            test_trade_id, existing_user1_id, existing_user2_id, existing_agent_id,
            'Mumbai', 'Surat', 'OTP_PENDING'::public.trade_status
        );
        
        -- Create mock OTP log
        INSERT INTO public.otp_logs (
            id, trade_id, otp_code, otp_color, expires_at
        ) VALUES (
            test_otp_id, test_trade_id, '123456', 'blue',
            CURRENT_TIMESTAMP + INTERVAL '15 minutes'
        );
        
        RAISE NOTICE 'Complete ZedTrust backend mock data created successfully';
        RAISE NOTICE 'Trade ID: %, OTP: 123456 (blue)', test_trade_id;
    ELSE
        RAISE NOTICE 'Missing required data. Ensure users and agents exist first.';
    END IF;

EXCEPTION
    WHEN OTHERS THEN
        RAISE NOTICE 'Error creating comprehensive mock data: %', SQLERRM;
END $$;

-- Step 7: Create views for easy API access

-- View for active trades
CREATE OR REPLACE VIEW public.active_trades AS
SELECT 
    t.id,
    t.buyer_id,
    t.seller_id,
    t.agent_id,
    t.buyer_city,
    t.seller_city,
    t.status,
    t.created_at,
    buyer.display_name as buyer_name,
    seller.display_name as seller_name,
    a.name as agent_name,
    a.alias as agent_alias
FROM public.trades t
LEFT JOIN public.user_profiles buyer ON t.buyer_id = buyer.id
LEFT JOIN public.user_profiles seller ON t.seller_id = seller.id
LEFT JOIN public.agents a ON t.agent_id = a.id
WHERE t.status NOT IN ('CANCELLED', 'RELEASED');

-- View for user trade history
CREATE OR REPLACE VIEW public.user_trade_history AS
SELECT 
    t.id,
    t.buyer_id,
    t.seller_id,
    t.status,
    t.created_at,
    t.updated_at,
    CASE 
        WHEN t.buyer_id = auth.uid() THEN 'buyer'
        WHEN t.seller_id = auth.uid() THEN 'seller'
        ELSE 'unknown'
    END as user_role,
    CASE 
        WHEN t.buyer_id = auth.uid() THEN seller.display_name
        WHEN t.seller_id = auth.uid() THEN buyer.display_name
        ELSE 'Unknown'
    END as counterparty_name,
    a.name as agent_name
FROM public.trades t
LEFT JOIN public.user_profiles buyer ON t.buyer_id = buyer.id
LEFT JOIN public.user_profiles seller ON t.seller_id = seller.id
LEFT JOIN public.agents a ON t.agent_id = a.id
WHERE t.buyer_id = auth.uid() OR t.seller_id = auth.uid();

-- Add helpful comments
COMMENT ON TABLE public.otp_logs IS 'OTP verification logs for trade security';
COMMENT ON FUNCTION public.create_trade(UUID, TEXT, TEXT, UUID) IS 'Creates new trade with automatic agent matching';
COMMENT ON FUNCTION public.generate_trade_otp(UUID) IS 'Generates secure OTP for trade verification';
COMMENT ON FUNCTION public.verify_trade_otp(UUID, TEXT, TEXT) IS 'Verifies OTP and releases trade';
COMMENT ON FUNCTION public.get_verified_agents(TEXT) IS 'Returns verified agents with location details';
COMMENT ON FUNCTION public.get_agent_locations_by_city(UUID, TEXT) IS 'Returns agent locations filtered by city';
COMMENT ON FUNCTION public.get_trade_details(UUID) IS 'Returns comprehensive trade information';
COMMENT ON VIEW public.active_trades IS 'View of all active (non-completed) trades';
COMMENT ON VIEW public.user_trade_history IS 'User-specific trade history with role context';