-- Location: supabase/migrations/20250121055202_admin_controlled_agents_system.sql
-- Schema Analysis: Creating new admin-controlled agent system with city-wise locations
-- Integration Type: Addition - Complete new agent management system
-- Dependencies: auth.users (for user relationships)

-- Step 1: Create custom types for the agent system
CREATE TYPE public.trade_status AS ENUM ('CREATED', 'AGENT_MATCHED', 'OTP_PENDING', 'RELEASED', 'CANCELLED', 'DISPUTED');

-- Step 2: Create core tables (no foreign keys yet)

-- Agents table - Core agent entities that admins can create and verify
CREATE TABLE public.agents (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name TEXT NOT NULL,
    alias TEXT NOT NULL,
    rating DECIMAL(3,2) DEFAULT 0.0 CHECK (rating >= 0.0 AND rating <= 5.0),
    is_verified BOOLEAN DEFAULT false,
    notes TEXT,
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);

-- User profiles intermediary table (required for PostgREST compatibility)
CREATE TABLE public.user_profiles (
    id UUID PRIMARY KEY REFERENCES auth.users(id),
    email TEXT NOT NULL UNIQUE,
    full_name TEXT NOT NULL,
    role TEXT DEFAULT 'user',
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);

-- Step 3: Create dependent tables (with foreign keys to existing tables only)

-- Agent locations - City-wise locations for each agent
CREATE TABLE public.agent_locations (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    agent_id UUID REFERENCES public.agents(id) ON DELETE CASCADE,
    city TEXT NOT NULL,
    area TEXT NOT NULL,
    display_alias TEXT NOT NULL,
    address_line TEXT NOT NULL,
    geo_lat DECIMAL(10, 8),
    geo_lng DECIMAL(11, 8),
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);

-- Seller policies - Define which agents a seller can use
CREATE TABLE public.seller_policies (
    seller_id UUID REFERENCES public.user_profiles(id) ON DELETE CASCADE,
    allowed_agent_ids UUID[],
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (seller_id)
);

-- Trades table - Stores trade information with agent assignments
CREATE TABLE public.trades (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    buyer_id UUID REFERENCES public.user_profiles(id) ON DELETE SET NULL,
    seller_id UUID REFERENCES public.user_profiles(id) ON DELETE SET NULL,
    agent_id UUID REFERENCES public.agents(id) ON DELETE SET NULL,
    buyer_location_id UUID REFERENCES public.agent_locations(id) ON DELETE SET NULL,
    seller_location_id UUID REFERENCES public.agent_locations(id) ON DELETE SET NULL,
    buyer_city TEXT NOT NULL,
    seller_city TEXT NOT NULL,
    status public.trade_status DEFAULT 'CREATED'::public.trade_status,
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);

-- Step 4: Create indexes for performance
CREATE INDEX idx_agents_name ON public.agents(name);
CREATE INDEX idx_agents_is_verified ON public.agents(is_verified);
CREATE INDEX idx_agents_rating ON public.agents(rating);

CREATE INDEX idx_agent_locations_agent_id ON public.agent_locations(agent_id);
CREATE INDEX idx_agent_locations_city ON public.agent_locations(city);
CREATE INDEX idx_agent_locations_is_active ON public.agent_locations(is_active);
CREATE INDEX idx_agent_locations_city_active ON public.agent_locations(city, is_active) WHERE is_active = true;

CREATE INDEX idx_user_profiles_email ON public.user_profiles(email);
CREATE INDEX idx_user_profiles_role ON public.user_profiles(role);

CREATE INDEX idx_seller_policies_seller_id ON public.seller_policies(seller_id);

CREATE INDEX idx_trades_buyer_id ON public.trades(buyer_id);
CREATE INDEX idx_trades_seller_id ON public.trades(seller_id);
CREATE INDEX idx_trades_agent_id ON public.trades(agent_id);
CREATE INDEX idx_trades_status ON public.trades(status);

-- Step 5: Create helper functions (MUST BE BEFORE RLS POLICIES)

-- Function for automatic profile creation
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER
SECURITY DEFINER
LANGUAGE plpgsql
AS $$
BEGIN
  INSERT INTO public.user_profiles (id, email, full_name, role)
  VALUES (
    NEW.id, 
    NEW.email, 
    COALESCE(NEW.raw_user_meta_data->>'full_name', split_part(NEW.email, '@', 1)),
    COALESCE(NEW.raw_user_meta_data->>'role', 'user')
  );
  RETURN NEW;
END;
$$;

-- Function to check if user is admin (uses auth.users metadata)
CREATE OR REPLACE FUNCTION public.is_admin_from_auth()
RETURNS BOOLEAN
LANGUAGE sql
STABLE
SECURITY DEFINER
AS $$
SELECT EXISTS (
    SELECT 1 FROM auth.users au
    WHERE au.id = auth.uid() 
    AND (au.raw_user_meta_data->>'role' = 'admin' 
         OR au.raw_app_meta_data->>'role' = 'admin')
)
$$;

-- Step 6: Enable RLS on all tables
ALTER TABLE public.agents ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.agent_locations ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.user_profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.seller_policies ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.trades ENABLE ROW LEVEL SECURITY;

-- Step 7: Create RLS policies following the approved patterns

-- Pattern 1: Core user table (user_profiles) - Simple only, no functions
CREATE POLICY "users_manage_own_user_profiles"
ON public.user_profiles
FOR ALL
TO authenticated
USING (id = auth.uid())
WITH CHECK (id = auth.uid());

-- Pattern 6: Role-based access for agents (admin-only management)
CREATE POLICY "admin_full_access_agents"
ON public.agents
FOR ALL
TO authenticated
USING (public.is_admin_from_auth())
WITH CHECK (public.is_admin_from_auth());

-- Public read access for verified agents (users can see them for selection)
CREATE POLICY "public_read_verified_agents"
ON public.agents
FOR SELECT
TO authenticated
USING (is_verified = true);

-- Pattern 6: Role-based access for agent locations (admin-only management)
CREATE POLICY "admin_full_access_agent_locations"
ON public.agent_locations
FOR ALL
TO authenticated
USING (public.is_admin_from_auth())
WITH CHECK (public.is_admin_from_auth());

-- Public read access for active agent locations (users can see them)
CREATE POLICY "public_read_active_agent_locations"
ON public.agent_locations
FOR SELECT
TO authenticated
USING (is_active = true);

-- Pattern 2: Simple user ownership for seller policies
CREATE POLICY "users_manage_own_seller_policies"
ON public.seller_policies
FOR ALL
TO authenticated
USING (seller_id = auth.uid())
WITH CHECK (seller_id = auth.uid());

-- Pattern 2: Users can manage their own trades
CREATE POLICY "users_manage_own_trades_as_buyer"
ON public.trades
FOR ALL
TO authenticated
USING (buyer_id = auth.uid())
WITH CHECK (buyer_id = auth.uid());

CREATE POLICY "users_manage_own_trades_as_seller"
ON public.trades
FOR ALL
TO authenticated
USING (seller_id = auth.uid())
WITH CHECK (seller_id = auth.uid());

-- Admin can access all trades
CREATE POLICY "admin_full_access_trades"
ON public.trades
FOR ALL
TO authenticated
USING (public.is_admin_from_auth())
WITH CHECK (public.is_admin_from_auth());

-- Step 8: Create trigger for automatic profile creation
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

-- Step 9: Create mock data with proper structure
DO $$
DECLARE
    admin_uuid UUID := gen_random_uuid();
    user_uuid UUID := gen_random_uuid();
    agent1_uuid UUID := gen_random_uuid();
    agent2_uuid UUID := gen_random_uuid();
    location1_uuid UUID := gen_random_uuid();
    location2_uuid UUID := gen_random_uuid();
    location3_uuid UUID := gen_random_uuid();
    location4_uuid UUID := gen_random_uuid();
BEGIN
    -- Create auth users with required fields
    INSERT INTO auth.users (
        id, instance_id, aud, role, email, encrypted_password, email_confirmed_at,
        created_at, updated_at, raw_user_meta_data, raw_app_meta_data,
        is_sso_user, is_anonymous, confirmation_token, confirmation_sent_at,
        recovery_token, recovery_sent_at, email_change_token_new, email_change,
        email_change_sent_at, email_change_token_current, email_change_confirm_status,
        reauthentication_token, reauthentication_sent_at, phone, phone_change,
        phone_change_token, phone_change_sent_at
    ) VALUES
        (admin_uuid, '00000000-0000-0000-0000-000000000000', 'authenticated', 'authenticated',
         'admin@zedtrust.com', crypt('admin123', gen_salt('bf', 10)), now(), now(), now(),
         '{"full_name": "Admin User", "role": "admin"}'::jsonb, '{"provider": "email", "providers": ["email"]}'::jsonb,
         false, false, '', null, '', null, '', '', null, '', 0, '', null, null, '', '', null),
        (user_uuid, '00000000-0000-0000-0000-000000000000', 'authenticated', 'authenticated',
         'user@zedtrust.com', crypt('user123', gen_salt('bf', 10)), now(), now(), now(),
         '{"full_name": "Test User"}'::jsonb, '{"provider": "email", "providers": ["email"]}'::jsonb,
         false, false, '', null, '', null, '', '', null, '', 0, '', null, null, '', '', null);

    -- Create sample agents
    INSERT INTO public.agents (id, name, alias, rating, is_verified, notes) VALUES
        (agent1_uuid, 'Rajnikant Aagnya Hawala', 'Rajni Network', 4.9, true, 'Premium hawala service with multiple city presence'),
        (agent2_uuid, 'Mumbai Express Financial', 'Mumbai Express', 4.7, true, 'Fast and reliable financial services across western India');

    -- Create agent locations (city-wise)
    INSERT INTO public.agent_locations (id, agent_id, city, area, display_alias, address_line, geo_lat, geo_lng, is_active) VALUES
        -- Rajni Network locations
        (location1_uuid, agent1_uuid, 'Surat', 'Ring Road', 'Ring Road Branch', 'Shop 12, Textile Market, Ring Road', 21.1702, 72.8311, true),
        (location2_uuid, agent1_uuid, 'Mumbai', 'Fort', 'Fort Branch', '2nd Floor, Mehta Building, Fort', 18.9335, 72.8351, true),
        -- Mumbai Express locations  
        (location3_uuid, agent2_uuid, 'Mumbai', 'Andheri', 'Andheri West Branch', 'Office 501, Business Plaza, Andheri West', 19.1136, 72.8697, true),
        (location4_uuid, agent2_uuid, 'Pune', 'Koregaon Park', 'Koregaon Park Branch', 'Ground Floor, Tech Center, Koregaon Park', 18.5362, 73.8958, true);

    -- Create sample trade
    INSERT INTO public.trades (
        buyer_id, seller_id, agent_id, 
        buyer_location_id, seller_location_id,
        buyer_city, seller_city, status
    ) VALUES (
        user_uuid, admin_uuid, agent1_uuid,
        location2_uuid, location1_uuid,
        'Mumbai', 'Surat', 'CREATED'::public.trade_status
    );

EXCEPTION
    WHEN foreign_key_violation THEN
        RAISE NOTICE 'Foreign key error: %', SQLERRM;
    WHEN unique_violation THEN
        RAISE NOTICE 'Unique constraint error: %', SQLERRM;
    WHEN OTHERS THEN
        RAISE NOTICE 'Unexpected error: %', SQLERRM;
END $$;

-- Step 10: Create cleanup function for testing
CREATE OR REPLACE FUNCTION public.cleanup_agent_test_data()
RETURNS VOID
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    test_user_ids UUID[];
BEGIN
    -- Get test user IDs
    SELECT ARRAY_AGG(id) INTO test_user_ids
    FROM auth.users
    WHERE email LIKE '%@zedtrust.com';

    -- Delete in dependency order (children first)
    DELETE FROM public.trades WHERE buyer_id = ANY(test_user_ids) OR seller_id = ANY(test_user_ids);
    DELETE FROM public.agent_locations WHERE agent_id IN (SELECT id FROM public.agents);
    DELETE FROM public.agents;
    DELETE FROM public.seller_policies WHERE seller_id = ANY(test_user_ids);
    DELETE FROM public.user_profiles WHERE id = ANY(test_user_ids);

    -- Delete auth.users last (after all references are removed)
    DELETE FROM auth.users WHERE id = ANY(test_user_ids);

EXCEPTION
    WHEN foreign_key_violation THEN
        RAISE NOTICE 'Foreign key constraint prevents deletion: %', SQLERRM;
    WHEN OTHERS THEN
        RAISE NOTICE 'Cleanup failed: %', SQLERRM;
END;
$$;

-- Add helpful comments
COMMENT ON TABLE public.agents IS 'Admin-controlled agent entities with verification status';
COMMENT ON TABLE public.agent_locations IS 'City-wise locations for each agent to enable privacy-preserving assignment';
COMMENT ON TABLE public.seller_policies IS 'Optional whitelist of allowed agents per seller';
COMMENT ON TABLE public.trades IS 'Trade records with automatic city-based agent location assignment';
COMMENT ON FUNCTION public.handle_new_user() IS 'Automatically creates user profile when new auth user is created';
COMMENT ON FUNCTION public.is_admin_from_auth() IS 'Checks if current user has admin role from auth metadata';
COMMENT ON FUNCTION public.cleanup_agent_test_data() IS 'Removes all test data for clean testing environment';