import 'package:flutter/material.dart';

import '../presentation/admin_agent_management/admin_agent_management.dart';
import '../presentation/admin_authentication_portal/admin_authentication_portal.dart';
import '../presentation/admin_control_center/admin_control_center.dart';
import '../presentation/admin_dashboard/admin_dashboard.dart';
import '../presentation/admin_platform_settings/admin_platform_settings.dart';
import '../presentation/admin_security_gateway/admin_security_gateway.dart';
import '../presentation/agent_location_assignment/agent_location_assignment.dart';
import '../presentation/agent_network_management/agent_network_management.dart';
import '../presentation/agent_selection/agent_selection.dart';
import '../presentation/agent_verification_center/agent_verification_center.dart';
import '../presentation/agent_visibility_control_center/agent_visibility_control_center.dart';
import '../presentation/create_profile/create_profile.dart';
import '../presentation/create_trade/create_trade.dart';
import '../presentation/dashboard/dashboard.dart';
import '../presentation/in_app_chat/in_app_chat.dart';
import '../presentation/location_management_hub/location_management_hub.dart';
import '../presentation/otp_verification/otp_verification.dart';
import '../presentation/p2p_ad_messaging_interface/p2p_ad_messaging_interface.dart';
import '../presentation/p2p_trading/p2p_trading.dart';
import '../presentation/p2p_user_profile_view/p2p_user_profile_view.dart';
import '../presentation/seller_agent_selection/seller_agent_selection.dart';
import '../presentation/set_amount_method/set_amount_method.dart';
import '../presentation/set_type_price/set_type_price.dart';
import '../presentation/splash_screen/splash_screen.dart';
import '../presentation/trade_details/trade_details.dart';
import '../presentation/trade_history/trade_history.dart';
import '../presentation/unified_agent_registration/unified_agent_registration.dart';
import '../presentation/wallet_connection/wallet_connection.dart';
import '../presentation/web_rtc_voice_call_interface/web_rtc_voice_call_interface.dart';
import '../presentation/zo_trust_d_app_dashboard/zo_trust_d_app_dashboard.dart';
import '../presentation/city_based_onboarding_modal/city_based_onboarding_modal.dart';
import '../presentation/web3_wallet_integration_hub/web3_wallet_integration_hub.dart';

class AppRoutes {
  // Standard app routes
  static const String initial = '/';
  static const String createTrade = '/create-trade';
  static const String createProfile = '/create-profile';
  static const String tradeDetails = '/trade-details';
  static const String splash = '/splash-screen';
  static const String walletConnection = '/wallet-connection';
  static const String web3WalletIntegrationHub = '/web3-wallet-integration-hub';
  static const String dashboard = '/dashboard';
  static const String agentSelection = '/agent-selection';
  static const String sellerAgentSelection = '/seller-agent-selection';
  static const String otpVerification = '/otp-verification';
  static const String tradeHistory = '/trade-history';
  static const String inAppChat = '/in-app-chat';
  static const String p2pTrading = '/p2p-trading';
  static const String p2pUserProfileView = '/p2p-user-profile-view';
  static const String setTypePrice = '/set-type-price';
  static const String setAmountMethod = '/set-amount-method';
  static const String adminAgentManagement = '/admin-agent-management';
  static const String agentLocationAssignment = '/agent-location-assignment';
  static const String agentVerificationCenter = '/agent-verification-center';
  static const String locationManagementHub = '/location-management-hub';
  static const String unifiedAgentRegistration = '/unified-agent-registration';
  static const String agentNetworkManagement = '/agent-network-management';

  // P2P Messaging and Calling routes
  static const String p2pAdMessagingInterface = '/p2p-ad-messaging-interface';
  static const String webRtcVoiceCallInterface =
      '/web-rtc-voice-call-interface';

  // Admin routes - optimized for web URL handling
  static const String admin = '/admin';
  static const String adminAuthenticationPortal =
      '/admin-authentication-portal';
  static const String adminDashboard = '/admin-dashboard';
  static const String adminSecurityGateway = '/admin-security-gateway';
  static const String adminControlCenter = '/admin-control-center';
  static const String adminPlatformSettings = '/admin-platform-settings';
  static const String agentVisibilityControlCenter =
      '/agent-visibility-control-center';

  // ZoTrust DApp specific routes
  static const String zoTrustDAppDashboard = '/zo-trust-d-app-dashboard';
  static const String cityBasedOnboardingModal = '/city-based-onboarding-modal';

  // Routes map - optimized for direct URL access
  static Map<String, WidgetBuilder> routes = {
    initial: (context) => const SplashScreen(),
    createTrade: (context) => const CreateTrade(),
    createProfile: (context) => const CreateProfile(),
    tradeDetails: (context) => const TradeDetails(),
    splash: (context) => const SplashScreen(),
    walletConnection: (context) => const WalletConnection(),
    web3WalletIntegrationHub: (context) => const Web3WalletIntegrationHub(),
    dashboard: (context) => const DashboardScreen(),
    agentSelection: (context) => const AgentSelection(),
    sellerAgentSelection: (context) => const SellerAgentSelection(),
    otpVerification: (context) => const OtpVerification(),
    tradeHistory: (context) => const TradeHistory(),
    inAppChat: (context) => const InAppChat(),
    p2pTrading: (context) => const P2PTrading(),
    p2pUserProfileView: (context) => const P2PUserProfileView(),
    setTypePrice: (context) => const SetTypePrice(),
    setAmountMethod: (context) => const SetAmountMethod(),
    adminAgentManagement: (context) => const AdminAgentManagement(),
    agentLocationAssignment: (context) => const AgentLocationAssignment(),
    agentVerificationCenter: (context) => const AgentVerificationCenter(),
    locationManagementHub: (context) => const LocationManagementHub(),
    unifiedAgentRegistration: (context) => const UnifiedAgentRegistration(),
    agentNetworkManagement: (context) => const AgentNetworkManagement(),

    // P2P Messaging and Calling routes,
    p2pAdMessagingInterface: (context) => const P2PAdMessagingInterface(),
    webRtcVoiceCallInterface: (context) {
      final args =
          ModalRoute.of(context)?.settings.arguments as Map<String, dynamic>?;
      return WebRTCVoiceCallInterface(
        counterparty: args?['counterparty'] ?? 'Unknown',
        isVerified: args?['isVerified'] ?? false,
        conversationId: args?['conversationId'] ?? '',
      );
    },

    // Admin routes - direct mapping for web URL support,
    admin: (context) => const AdminSecurityGateway(),
    adminAuthenticationPortal: (context) => const AdminAuthenticationPortal(),
    adminDashboard: (context) => const AdminDashboard(),
    adminSecurityGateway: (context) => const AdminSecurityGateway(),
    adminControlCenter: (context) => const AdminControlCenter(),
    adminPlatformSettings: (context) => const AdminPlatformSettings(),
    agentVisibilityControlCenter: (context) =>
        const AgentVisibilityControlCenter(),

    // ZoTrust DApp routes
    zoTrustDAppDashboard: (context) => const ZoTrustDAppDashboard(),
    cityBasedOnboardingModal: (context) => const CityBasedOnboardingModal(),
  };

  // Utility method to validate admin routes
  static bool isAdminRoute(String route) {
    return route.startsWith('/admin');
  }

  // Get the appropriate admin screen based on route
  static Widget getAdminScreen(String route) {
    switch (route) {
      case AppRoutes.admin:
      case AppRoutes.adminSecurityGateway:
        return const AdminSecurityGateway();
      case AppRoutes.adminControlCenter:
        return const AdminControlCenter();
      case AppRoutes.adminDashboard:
        return const AdminDashboard();
      case AppRoutes.adminAuthenticationPortal:
        return const AdminAuthenticationPortal();
      case AppRoutes.adminPlatformSettings:
        return const AdminPlatformSettings();
      default:
        return const AdminSecurityGateway();
    }
  }
}
