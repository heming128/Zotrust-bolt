class OTPModel {
  final String id;
  final String tradeId;
  final String otpCode;
  final String otpColor;
  final bool isVerified;
  final DateTime? verifiedAt;
  final String? verifiedById;
  final DateTime expiresAt;
  final DateTime createdAt;

  OTPModel({
    required this.id,
    required this.tradeId,
    required this.otpCode,
    required this.otpColor,
    required this.isVerified,
    this.verifiedAt,
    this.verifiedById,
    required this.expiresAt,
    required this.createdAt,
  });

  factory OTPModel.fromJson(Map<String, dynamic> json) {
    return OTPModel(
      id: json['id'] ?? json['otp_id'] ?? '',
      tradeId: json['trade_id'] ?? '',
      otpCode: json['otp_code'] ?? '',
      otpColor: json['otp_color'] ?? '',
      isVerified: json['is_verified'] ?? false,
      verifiedAt: json['verified_at'] != null
          ? DateTime.parse(json['verified_at'])
          : null,
      verifiedById: json['verified_by_id'],
      expiresAt: DateTime.parse(
        json['expires_at'] ??
            DateTime.now().add(const Duration(minutes: 15)).toIso8601String(),
      ),
      createdAt: DateTime.parse(
        json['created_at'] ?? DateTime.now().toIso8601String(),
      ),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'trade_id': tradeId,
      'otp_code': otpCode,
      'otp_color': otpColor,
      'is_verified': isVerified,
      'verified_at': verifiedAt?.toIso8601String(),
      'verified_by_id': verifiedById,
      'expires_at': expiresAt.toIso8601String(),
      'created_at': createdAt.toIso8601String(),
    };
  }

  OTPModel copyWith({
    String? id,
    String? tradeId,
    String? otpCode,
    String? otpColor,
    bool? isVerified,
    DateTime? verifiedAt,
    String? verifiedById,
    DateTime? expiresAt,
    DateTime? createdAt,
  }) {
    return OTPModel(
      id: id ?? this.id,
      tradeId: tradeId ?? this.tradeId,
      otpCode: otpCode ?? this.otpCode,
      otpColor: otpColor ?? this.otpColor,
      isVerified: isVerified ?? this.isVerified,
      verifiedAt: verifiedAt ?? this.verifiedAt,
      verifiedById: verifiedById ?? this.verifiedById,
      expiresAt: expiresAt ?? this.expiresAt,
      createdAt: createdAt ?? this.createdAt,
    );
  }

  // Helper methods
  bool get isExpired => DateTime.now().isAfter(expiresAt);

  Duration get timeUntilExpiry => expiresAt.difference(DateTime.now());

  bool get isActive => !isExpired && !isVerified;

  String get formattedExpiryTime {
    if (isExpired) return 'Expired';

    final remaining = timeUntilExpiry;
    if (remaining.inMinutes > 0) {
      return '${remaining.inMinutes}m ${remaining.inSeconds % 60}s';
    } else {
      return '${remaining.inSeconds}s';
    }
  }

  String get colorDisplayName {
    switch (otpColor.toLowerCase()) {
      case 'red':
        return '🔴 Red';
      case 'blue':
        return '🔵 Blue';
      case 'green':
        return '🟢 Green';
      case 'yellow':
        return '🟡 Yellow';
      case 'purple':
        return '🟣 Purple';
      case 'orange':
        return '🟠 Orange';
      default:
        return '⚪ ${otpColor.toUpperCase()}';
    }
  }

  @override
  String toString() {
    return 'OTPModel{id: $id, tradeId: $tradeId, otpCode: $otpCode, otpColor: $otpColor, isVerified: $isVerified, expiresAt: $expiresAt}';
  }

  @override
  bool operator ==(Object other) {
    if (identical(this, other)) return true;

    return other is OTPModel &&
        other.id == id &&
        other.tradeId == tradeId &&
        other.otpCode == otpCode &&
        other.otpColor == otpColor;
  }

  @override
  int get hashCode {
    return id.hashCode ^
        tradeId.hashCode ^
        otpCode.hashCode ^
        otpColor.hashCode;
  }
}

enum OTPStatus {
  active,
  verified,
  expired,
  invalid;

  static OTPStatus fromOTPModel(OTPModel otp) {
    if (otp.isVerified) return OTPStatus.verified;
    if (otp.isExpired) return OTPStatus.expired;
    if (otp.isActive) return OTPStatus.active;
    return OTPStatus.invalid;
  }
}

extension OTPStatusExtension on OTPStatus {
  String get displayName {
    switch (this) {
      case OTPStatus.active:
        return 'Active';
      case OTPStatus.verified:
        return 'Verified';
      case OTPStatus.expired:
        return 'Expired';
      case OTPStatus.invalid:
        return 'Invalid';
    }
  }

  String get description {
    switch (this) {
      case OTPStatus.active:
        return 'OTP is active and can be verified';
      case OTPStatus.verified:
        return 'OTP has been successfully verified';
      case OTPStatus.expired:
        return 'OTP has expired and cannot be used';
      case OTPStatus.invalid:
        return 'OTP is invalid or corrupted';
    }
  }
}
