import 'package:flutter/foundation.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:geolocator/geolocator.dart';
import 'package:crypto/crypto.dart';
import 'dart:convert';
import '../../services/supabase_service.dart';

/// Enhanced Agent Management Service with CRUD operations and Google Maps integration
class EnhancedAgentService {
  static EnhancedAgentService? _instance;
  static EnhancedAgentService get instance =>
      _instance ??= EnhancedAgentService._();

  EnhancedAgentService._();

  SupabaseClient get _client => SupabaseService.instance.client;

  /// Create new agent (Admin only)
  Future<Map<String, dynamic>> createAgent({
    required String name,
    required String alias,
    required String mobileNumber,
    required String agentType,
    required List<Map<String, dynamic>> locations,
    double rating = 5.0,
    bool isVerified = false,
    String? notes,
    Map<String, dynamic>? additionalData,
  }) async {
    try {
      // Create agent
      final agentData = {
        'name': name,
        'alias': alias,
        'mobile': mobileNumber,
        'agent_type': agentType,
        'rating': rating,
        'is_verified': isVerified,
        'notes': notes,
        'created_at': DateTime.now().toIso8601String(),
        ...?additionalData,
      };

      final agentResponse =
          await _client.from('agents').insert(agentData).select().single();

      final agentId = agentResponse['id'] as String;

      // Create agent locations with Google Maps validation
      List<Map<String, dynamic>> createdLocations = [];
      for (final location in locations) {
        final locationResult = await _createAgentLocation(
          agentId: agentId,
          locationData: location,
        );
        if (locationResult['success'] == true) {
          createdLocations.add(locationResult['location']);
        }
      }

      if (kDebugMode) {
        print(
            '✅ Agent created: $name with ${createdLocations.length} locations');
      }

      return {
        'success': true,
        'message': 'Agent created successfully',
        'agent': agentResponse,
        'locations': createdLocations,
      };
    } catch (e) {
      if (kDebugMode) {
        print('❌ Agent creation failed: $e');
      }
      return {
        'success': false,
        'message': 'Failed to create agent: $e',
      };
    }
  }

  /// Update agent information (Admin only)
  Future<Map<String, dynamic>> updateAgent({
    required String agentId,
    String? name,
    String? alias,
    String? mobileNumber,
    String? agentType,
    double? rating,
    bool? isVerified,
    String? notes,
    Map<String, dynamic>? additionalData,
  }) async {
    try {
      final updateData = <String, dynamic>{
        'updated_at': DateTime.now().toIso8601String(),
      };

      if (name != null) updateData['name'] = name;
      if (alias != null) updateData['alias'] = alias;
      if (mobileNumber != null) updateData['mobile'] = mobileNumber;
      if (agentType != null) updateData['agent_type'] = agentType;
      if (rating != null) updateData['rating'] = rating;
      if (isVerified != null) updateData['is_verified'] = isVerified;
      if (notes != null) updateData['notes'] = notes;
      if (additionalData != null) updateData.addAll(additionalData);

      final response = await _client
          .from('agents')
          .update(updateData)
          .eq('id', agentId)
          .select()
          .single();

      if (kDebugMode) {
        print('✅ Agent updated: $agentId');
      }

      return {
        'success': true,
        'message': 'Agent updated successfully',
        'agent': response,
      };
    } catch (e) {
      if (kDebugMode) {
        print('❌ Agent update failed: $e');
      }
      return {
        'success': false,
        'message': 'Failed to update agent: $e',
      };
    }
  }

  /// Delete agent and all associated data (Admin only)
  Future<Map<String, dynamic>> deleteAgent(String agentId) async {
    try {
      // Delete agent locations first
      await _client.from('agent_locations').delete().eq('agent_id', agentId);

      // Delete the agent
      await _client.from('agents').delete().eq('id', agentId);

      if (kDebugMode) {
        print('✅ Agent deleted: $agentId');
      }

      return {
        'success': true,
        'message': 'Agent deleted successfully',
      };
    } catch (e) {
      if (kDebugMode) {
        print('❌ Agent deletion failed: $e');
      }
      return {
        'success': false,
        'message': 'Failed to delete agent: $e',
      };
    }
  }

  /// Get all verified agents for user selection
  Future<List<Map<String, dynamic>>> getVerifiedAgents({
    String? city,
    String? agentType,
  }) async {
    try {
      var query = _client.from('agents').select('''
            *,
            agent_locations!inner(
              id,
              city,
              area,
              display_alias,
              address_line,
              geo_lat,
              geo_lng,
              is_active
            )
          ''').eq('is_verified', true);

      if (city != null) {
        query = query.eq('agent_locations.city', city);
      }

      if (agentType != null) {
        query = query.eq('agent_type', agentType);
      }

      final response = await query.order('rating', ascending: false);

      return List<Map<String, dynamic>>.from(response);
    } catch (e) {
      if (kDebugMode) {
        print('❌ Error fetching verified agents: $e');
      }
      return [];
    }
  }

  /// Get all agents for admin management
  Future<List<Map<String, dynamic>>> getAllAgentsForAdmin() async {
    try {
      final response = await _client.from('agents').select('''
            *,
            agent_locations(
              id,
              city,
              area,
              display_alias,
              address_line,
              is_active,
              geo_lat,
              geo_lng
            )
          ''').order('created_at', ascending: false);

      return List<Map<String, dynamic>>.from(response);
    } catch (e) {
      if (kDebugMode) {
        print('❌ Error fetching agents for admin: $e');
      }
      return [];
    }
  }

  /// Validate agent city coverage using Google Maps
  Future<Map<String, dynamic>> validateCityCoverage({
    required String agentId,
    required List<String> cities,
  }) async {
    try {
      final coverage = <String, bool>{};
      final missingCities = <String>[];

      for (final city in cities) {
        final locations = await _client
            .from('agent_locations')
            .select()
            .eq('agent_id', agentId)
            .eq('city', city)
            .eq('is_active', true);

        final hasLocationInCity = locations.isNotEmpty;
        coverage[city] = hasLocationInCity;

        if (!hasLocationInCity) {
          missingCities.add(city);
        }
      }

      return {
        'coverage': coverage,
        'missing_cities': missingCities,
        'full_coverage': missingCities.isEmpty,
      };
    } catch (e) {
      if (kDebugMode) {
        print('❌ Error validating city coverage: $e');
      }
      return {
        'coverage': {},
        'missing_cities': cities,
        'full_coverage': false,
      };
    }
  }

  /// Auto-match agents for buyer and seller cities
  Future<List<Map<String, dynamic>>> getMatchedAgents({
    required String buyerCity,
    required String sellerCity,
  }) async {
    try {
      // Find agents that have active locations in both cities
      final response = await _client.rpc(
        'get_verified_agents_with_city_coverage',
        params: {
          'p_buyer_city': buyerCity,
          'p_seller_city': sellerCity,
        },
      );

      return List<Map<String, dynamic>>.from(response);
    } catch (e) {
      if (kDebugMode) {
        print('❌ Error matching agents: $e');
      }
      return [];
    }
  }

  /// Create agent location with Google Maps validation
  Future<Map<String, dynamic>> _createAgentLocation({
    required String agentId,
    required Map<String, dynamic> locationData,
  }) async {
    try {
      final city = locationData['city'] as String;
      final area = locationData['area'] as String;
      final addressLine = locationData['address_line'] as String;

      // Validate and get coordinates using Google Maps (if available)
      Map<String, double>? coordinates;
      try {
        coordinates = await _validateAddressWithGoogleMaps(
          city: city,
          area: area,
          addressLine: addressLine,
        );
      } catch (e) {
        if (kDebugMode) {
          print('⚠️ Google Maps validation skipped: $e');
        }
        // Continue without coordinates if Google Maps fails
      }

      final locationCreateData = {
        'agent_id': agentId,
        'city': city,
        'area': area,
        'display_alias': locationData['display_alias'] ?? '$area, $city',
        'address_line': addressLine,
        'geo_lat': coordinates?['latitude'],
        'geo_lng': coordinates?['longitude'],
        'is_active': locationData['is_active'] ?? true,
        'enable_buyer_matching': locationData['enable_buyer_matching'] ?? true,
        'enable_seller_matching':
            locationData['enable_seller_matching'] ?? true,
        'city_wide_coverage': locationData['city_wide_coverage'] ?? true,
        'cross_region_access': locationData['cross_region_access'] ?? false,
      };

      final response = await _client
          .from('agent_locations')
          .insert(locationCreateData)
          .select()
          .single();

      return {
        'success': true,
        'location': response,
      };
    } catch (e) {
      if (kDebugMode) {
        print('❌ Agent location creation failed: $e');
      }
      return {
        'success': false,
        'message': 'Failed to create location: $e',
      };
    }
  }

  /// Validate address using Google Maps API (placeholder for actual implementation)
  Future<Map<String, double>> _validateAddressWithGoogleMaps({
    required String city,
    required String area,
    required String addressLine,
  }) async {
    // This is a placeholder - actual implementation would use Google Maps Geocoding API
    // For now, return sample coordinates
    final fullAddress = '$addressLine, $area, $city';

    // Generate deterministic coordinates based on address hash
    final bytes = utf8.encode(fullAddress);
    final digest = sha256.convert(bytes);
    final hashValue = digest.bytes.fold(0, (prev, element) => prev + element);

    // Map to realistic coordinates for major Indian cities
    final cityCoordinates = {
      'Mumbai': {'lat': 19.0760, 'lng': 72.8777},
      'Surat': {'lat': 21.1702, 'lng': 72.8311},
      'Delhi': {'lat': 28.7041, 'lng': 77.1025},
      'Pune': {'lat': 18.5204, 'lng': 73.8567},
      'Bangalore': {'lat': 12.9716, 'lng': 77.5946},
      'Chennai': {'lat': 13.0827, 'lng': 80.2707},
    };

    final baseCoords =
        cityCoordinates[city] ?? {'lat': 20.5937, 'lng': 78.9629};

    // Add small random offset based on hash
    final latOffset = ((hashValue % 1000) - 500) / 10000.0; // ±0.05 degrees
    final lngOffset = ((hashValue % 1500) - 750) / 10000.0; // ±0.075 degrees

    return {
      'latitude': baseCoords['lat']! + latOffset,
      'longitude': baseCoords['lng']! + lngOffset,
    };
  }

  /// Get agent performance analytics (Admin only)
  Future<Map<String, dynamic>> getAgentAnalytics(String agentId) async {
    try {
      final results = await Future.wait([
        _client
            .from('trades')
            .select()
            .eq('agent_id', agentId)
            .count(CountOption.exact),
        _client
            .from('trades')
            .select()
            .eq('agent_id', agentId)
            .eq('status', 'RELEASED')
            .count(CountOption.exact),
        _client
            .from('trades')
            .select()
            .eq('agent_id', agentId)
            .eq('status', 'CANCELLED')
            .count(CountOption.exact),
        _client
            .from('agent_locations')
            .select()
            .eq('agent_id', agentId)
            .eq('is_active', true)
            .count(CountOption.exact),
      ]);

      final totalTrades = results[0].count ?? 0;
      final completedTrades = results[1].count ?? 0;
      final cancelledTrades = results[2].count ?? 0;
      final activeLocations = results[3].count ?? 0;

      return {
        'total_trades': totalTrades,
        'completed_trades': completedTrades,
        'cancelled_trades': cancelledTrades,
        'active_locations': activeLocations,
        'success_rate': totalTrades > 0
            ? ((completedTrades / totalTrades) * 100).toStringAsFixed(1)
            : '0.0',
        'cancellation_rate': totalTrades > 0
            ? ((cancelledTrades / totalTrades) * 100).toStringAsFixed(1)
            : '0.0',
      };
    } catch (e) {
      if (kDebugMode) {
        print('❌ Error fetching agent analytics: $e');
      }
      return {};
    }
  }

  /// Get nearby agents using geolocation
  Future<List<Map<String, dynamic>>> getNearbyAgents({
    double? latitude,
    double? longitude,
    double radiusKm = 10.0,
  }) async {
    try {
      // Get current position if not provided
      Position? position;
      if (latitude == null || longitude == null) {
        try {
          position = await Geolocator.getCurrentPosition();
          latitude = position.latitude;
          longitude = position.longitude;
        } catch (e) {
          if (kDebugMode) {
            print('⚠️ Could not get current location: $e');
          }
          // Return all verified agents if location is unavailable
          return await getVerifiedAgents();
        }
      }

      // Query agents with locations within radius using PostGIS functions
      final response = await _client.rpc(
        'get_nearby_agents',
        params: {
          'p_latitude': latitude,
          'p_longitude': longitude,
          'p_radius_km': radiusKm,
        },
      );

      return List<Map<String, dynamic>>.from(response);
    } catch (e) {
      if (kDebugMode) {
        print('❌ Error fetching nearby agents: $e');
      }
      return await getVerifiedAgents();
    }
  }

  /// Bulk update agent verification status (Admin only)
  Future<Map<String, dynamic>> bulkUpdateVerification({
    required List<String> agentIds,
    required bool isVerified,
  }) async {
    try {
      await _client
          .from('agents')
          .update({'is_verified': isVerified}).inFilter('id', agentIds);

      if (kDebugMode) {
        print('✅ Bulk verification updated for ${agentIds.length} agents');
      }

      return {
        'success': true,
        'message': '${agentIds.length} agents updated successfully',
      };
    } catch (e) {
      if (kDebugMode) {
        print('❌ Bulk update failed: $e');
      }
      return {
        'success': false,
        'message': 'Failed to update agents: $e',
      };
    }
  }

  /// Get available cities from agent locations
  Future<List<String>> getAvailableCities() async {
    try {
      final response = await _client
          .from('agent_locations')
          .select('city')
          .eq('is_active', true);

      final cities =
          response.map((item) => item['city'].toString()).toSet().toList();

      cities.sort();
      return cities;
    } catch (e) {
      if (kDebugMode) {
        print('❌ Error fetching available cities: $e');
      }
      return ['Mumbai', 'Surat', 'Delhi', 'Pune', 'Bangalore', 'Chennai'];
    }
  }

  /// Export agent data for reporting (Admin only)
  Future<Map<String, dynamic>> exportAgentData() async {
    try {
      final agents = await getAllAgentsForAdmin();
      final exportData = {
        'export_timestamp': DateTime.now().toIso8601String(),
        'total_agents': agents.length,
        'verified_agents':
            agents.where((agent) => agent['is_verified'] == true).length,
        'agents': agents.map((agent) {
          return {
            'id': agent['id'],
            'name': agent['name'],
            'alias': agent['alias'],
            'mobile': agent['mobile'],
            'agent_type': agent['agent_type'],
            'rating': agent['rating'],
            'is_verified': agent['is_verified'],
            'location_count': (agent['agent_locations'] as List).length,
            'active_locations': (agent['agent_locations'] as List)
                .where((loc) => loc['is_active'] == true)
                .length,
          };
        }).toList(),
      };

      return {
        'success': true,
        'export_data': exportData,
      };
    } catch (e) {
      if (kDebugMode) {
        print('❌ Error exporting agent data: $e');
      }
      return {
        'success': false,
        'message': 'Failed to export data: $e',
      };
    }
  }
}
