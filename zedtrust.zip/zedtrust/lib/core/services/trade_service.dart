import 'package:flutter/foundation.dart';

import './enhanced_supabase_service.dart';

/// Trade service for handling trade operations with Supabase
class TradeService {
  static TradeService? _instance;
  static TradeService get instance => _instance ??= TradeService._();

  TradeService._();

  final _supabase = EnhancedSupabaseService.instance;

  /// Create a new trade with validation
  Future<Map<String, dynamic>> createTrade({
    required String buyerId,
    required String sellerId,
    required String agentId,
    required double amountUsdc,
    String? buyerWalletAddress,
    String? sellerWalletAddress,
  }) async {
    try {
      // Validate agent exists and is verified
      final agents = await _supabase.getVerifiedAgents();
      final agent = agents.firstWhere(
        (a) => a['id'] == agentId,
        orElse: () => throw Exception('Agent not found or not verified'),
      );

      // Create the trade
      final trade = await _supabase.createTrade(
        buyerId: buyerId,
        sellerId: sellerId,
        agentId: agentId,
        amountUsdc: amountUsdc,
        buyerWalletAddress: buyerWalletAddress,
        sellerWalletAddress: sellerWalletAddress,
        status: 'CREATED',
      );

      if (trade != null) {
        if (kDebugMode) {
          print('✅ Trade created successfully: ${trade['id']}');
        }
        return {'success': true, 'trade': trade};
      } else {
        throw Exception('Failed to create trade');
      }
    } catch (e) {
      if (kDebugMode) {
        print('❌ Error creating trade: $e');
      }
      return {'success': false, 'error': e.toString()};
    }
  }

  /// Get trades for current user with filtering
  Future<List<Map<String, dynamic>>> getUserTrades({
    String? status,
    String? role, // 'buyer' or 'seller'
  }) async {
    try {
      final trades = await _supabase.getUserTrades();

      var filteredTrades = trades;

      // Filter by status
      if (status != null) {
        filteredTrades =
            filteredTrades
                .where(
                  (trade) =>
                      trade['status']?.toString().toLowerCase() ==
                      status.toLowerCase(),
                )
                .toList();
      }

      // Filter by role
      if (role != null && _supabase.currentUser != null) {
        final userId = _supabase.currentUser!.id;
        filteredTrades =
            filteredTrades.where((trade) {
              if (role.toLowerCase() == 'buyer') {
                return trade['buyer_id'] == userId;
              } else if (role.toLowerCase() == 'seller') {
                return trade['seller_id'] == userId;
              }
              return true;
            }).toList();
      }

      return filteredTrades;
    } catch (e) {
      if (kDebugMode) {
        print('❌ Error fetching user trades: $e');
      }
      return [];
    }
  }

  /// Update trade status with validation
  Future<Map<String, dynamic>> updateTradeStatus({
    required String tradeId,
    required String newStatus,
  }) async {
    try {
      final trade = await _supabase.updateTradeStatus(
        tradeId: tradeId,
        status: newStatus,
      );

      if (trade != null) {
        if (kDebugMode) {
          print('✅ Trade status updated: ${trade['id']} -> $newStatus');
        }
        return {'success': true, 'trade': trade};
      } else {
        throw Exception('Failed to update trade status');
      }
    } catch (e) {
      if (kDebugMode) {
        print('❌ Error updating trade status: $e');
      }
      return {'success': false, 'error': e.toString()};
    }
  }

  /// Get trade details with all related data
  Future<Map<String, dynamic>?> getTradeDetails(String tradeId) async {
    try {
      final trade = await _supabase.getTradeDetails(tradeId);

      if (trade != null && kDebugMode) {
        print('✅ Trade details fetched: ${trade['id']}');
      }

      return trade;
    } catch (e) {
      if (kDebugMode) {
        print('❌ Error fetching trade details: $e');
      }
      return null;
    }
  }

  /// Check if current user can access trade
  bool canAccessTrade(Map<String, dynamic> trade) {
    final currentUser = _supabase.currentUser;
    if (currentUser == null) return false;

    return trade['buyer_id'] == currentUser.id ||
        trade['seller_id'] == currentUser.id;
  }

  /// Get user's role in trade
  String? getUserRoleInTrade(Map<String, dynamic> trade) {
    final currentUser = _supabase.currentUser;
    if (currentUser == null) return null;

    if (trade['buyer_id'] == currentUser.id) return 'buyer';
    if (trade['seller_id'] == currentUser.id) return 'seller';
    return null;
  }

  /// Cancel trade with validation
  Future<Map<String, dynamic>> cancelTrade({
    required String tradeId,
    required String reason,
  }) async {
    try {
      final trade = await _supabase.getTradeDetails(tradeId);

      if (trade == null) {
        throw Exception('Trade not found');
      }

      if (!canAccessTrade(trade)) {
        throw Exception('Not authorized to cancel this trade');
      }

      // Check if trade can be cancelled
      final currentStatus = trade['status']?.toString().toLowerCase();
      if (currentStatus == 'completed' || currentStatus == 'cancelled') {
        throw Exception('Trade cannot be cancelled in current status');
      }

      final updatedTrade = await _supabase.updateTradeStatus(
        tradeId: tradeId,
        status: 'CANCELLED',
      );

      if (updatedTrade != null) {
        if (kDebugMode) {
          print('✅ Trade cancelled: $tradeId');
        }
        return {'success': true, 'trade': updatedTrade};
      } else {
        throw Exception('Failed to cancel trade');
      }
    } catch (e) {
      if (kDebugMode) {
        print('❌ Error cancelling trade: $e');
      }
      return {'success': false, 'error': e.toString()};
    }
  }

  /// Get trade statistics for current user
  Future<Map<String, dynamic>> getUserTradeStatistics() async {
    try {
      final currentUser = _supabase.currentUser;
      if (currentUser == null) {
        throw Exception('User not authenticated');
      }

      final stats = await _supabase.getUserTradeStats(currentUser.id);

      return stats;
    } catch (e) {
      if (kDebugMode) {
        print('❌ Error fetching trade statistics: $e');
      }
      return {};
    }
  }

  /// Subscribe to trade updates for real-time notifications
  void subscribeToTradeUpdates({
    required Function(Map<String, dynamic>) onTradeCreated,
    required Function(Map<String, dynamic>) onTradeUpdated,
    required Function(Map<String, dynamic>) onTradeDeleted,
  }) {
    _supabase.subscribeToTrades(
      onInsert: (trade) {
        if (kDebugMode) {
          print('📱 New trade created: ${trade['id']}');
        }
        onTradeCreated(trade);
      },
      onUpdate: (trade) {
        if (kDebugMode) {
          print('📱 Trade updated: ${trade['id']} -> ${trade['status']}');
        }
        onTradeUpdated(trade);
      },
      onDelete: (trade) {
        if (kDebugMode) {
          print('📱 Trade deleted: ${trade['id']}');
        }
        onTradeDeleted(trade);
      },
    );
  }
}
