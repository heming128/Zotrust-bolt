import 'package:flutter/foundation.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:flutter_webrtc/flutter_webrtc.dart';
import 'package:web_socket_channel/web_socket_channel.dart';
import '../../services/supabase_service.dart';

/// Service for in-app chat and WebRTC voice calling
class ChatCallingService {
  static ChatCallingService? _instance;
  static ChatCallingService get instance =>
      _instance ??= ChatCallingService._();

  ChatCallingService._();

  SupabaseClient get _client => SupabaseService.instance.client;

  // WebRTC components
  RTCPeerConnection? _peerConnection;
  MediaStream? _localStream;
  WebSocketChannel? _signalingChannel;

  // Call state
  String? _currentCallId;
  bool _isCallActive = false;
  String? _remoteUserId;

  /// Send message in trade chat
  Future<Map<String, dynamic>> sendTradeMessage({
    required String tradeId,
    required String messageContent,
    String messageType = 'text',
    Map<String, dynamic>? metadata,
  }) async {
    try {
      final currentUser = _client.auth.currentUser;
      if (currentUser == null) {
        throw Exception('User not authenticated');
      }

      final messageData = {
        'trade_id': tradeId,
        'sender_id': currentUser.id,
        'message_content': messageContent,
        'message_type': messageType,
        'metadata': metadata,
        'created_at': DateTime.now().toIso8601String(),
      };

      final response =
          await _client.from('chat_messages').insert(messageData).select('''
            *,
            sender:user_profiles!sender_id(
              profile_name,
              full_name
            )
          ''').single();

      if (kDebugMode) {
        print(
            '✅ Message sent: ${messageContent.substring(0, messageContent.length > 50 ? 50 : messageContent.length)}...');
      }

      return {
        'success': true,
        'message': response,
      };
    } catch (e) {
      if (kDebugMode) {
        print('❌ Failed to send message: $e');
      }
      return {
        'success': false,
        'message': 'Failed to send message: $e',
      };
    }
  }

  /// Get chat messages for a trade
  Future<List<Map<String, dynamic>>> getTradeMessages({
    required String tradeId,
    int limit = 50,
    int offset = 0,
  }) async {
    try {
      final response = await _client
          .from('chat_messages')
          .select('''
            *,
            sender:user_profiles!sender_id(
              profile_name,
              full_name
            )
          ''')
          .eq('trade_id', tradeId)
          .order('created_at', ascending: false)
          .range(offset, offset + limit - 1);

      return List<Map<String, dynamic>>.from(response);
    } catch (e) {
      if (kDebugMode) {
        print('❌ Error fetching messages: $e');
      }
      return [];
    }
  }

  /// Subscribe to real-time chat messages
  RealtimeChannel subscribeToTradeChat({
    required String tradeId,
    required Function(Map<String, dynamic>) onNewMessage,
  }) {
    return _client
        .channel('trade_chat_$tradeId')
        .onPostgresChanges(
          event: PostgresChangeEvent.insert,
          schema: 'public',
          table: 'chat_messages',
          filter: PostgresChangeFilter(
            type: PostgresChangeFilterType.eq,
            column: 'trade_id',
            value: tradeId,
          ),
          callback: (payload) {
            onNewMessage(payload.newRecord);
          },
        )
        .subscribe();
  }

  /// Initiate voice call with WebRTC
  Future<Map<String, dynamic>> initiateVoiceCall({
    required String calleeId,
    String? tradeId,
    String callType = 'voice',
  }) async {
    try {
      final currentUser = _client.auth.currentUser;
      if (currentUser == null) {
        throw Exception('User not authenticated');
      }

      // Create call record in database
      final callData = {
        'caller_id': currentUser.id,
        'callee_id': calleeId,
        'trade_id': tradeId,
        'call_type': callType,
        'status': 'INITIATED',
        'started_at': DateTime.now().toIso8601String(),
      };

      final response =
          await _client.from('calls').insert(callData).select().single();

      _currentCallId = response['id'];
      _remoteUserId = calleeId;

      // Initialize WebRTC
      await _initializeWebRTC();

      // Start signaling
      await _connectSignaling();

      if (kDebugMode) {
        print('✅ Voice call initiated: $_currentCallId');
      }

      return {
        'success': true,
        'call_id': _currentCallId,
        'message': 'Call initiated successfully',
      };
    } catch (e) {
      if (kDebugMode) {
        print('❌ Failed to initiate call: $e');
      }
      return {
        'success': false,
        'message': 'Failed to initiate call: $e',
      };
    }
  }

  /// Answer incoming call
  Future<Map<String, dynamic>> answerCall(String callId) async {
    try {
      // Update call status
      await _client.from('calls').update({
        'status': 'ACTIVE',
        'answered_at': DateTime.now().toIso8601String(),
      }).eq('id', callId);

      _currentCallId = callId;
      _isCallActive = true;

      // Initialize WebRTC for answering
      await _initializeWebRTC();
      await _connectSignaling();

      if (kDebugMode) {
        print('✅ Call answered: $callId');
      }

      return {
        'success': true,
        'message': 'Call answered successfully',
      };
    } catch (e) {
      if (kDebugMode) {
        print('❌ Failed to answer call: $e');
      }
      return {
        'success': false,
        'message': 'Failed to answer call: $e',
      };
    }
  }

  /// End active call
  Future<Map<String, dynamic>> endCall([String? callId]) async {
    try {
      final endCallId = callId ?? _currentCallId;
      if (endCallId == null) {
        return {
          'success': false,
          'message': 'No active call to end',
        };
      }

      // Update call status in database
      await _client.from('calls').update({
        'status': 'ENDED',
        'ended_at': DateTime.now().toIso8601String(),
      }).eq('id', endCallId);

      // Cleanup WebRTC resources
      await _cleanupWebRTC();

      if (kDebugMode) {
        print('✅ Call ended: $endCallId');
      }

      return {
        'success': true,
        'message': 'Call ended successfully',
      };
    } catch (e) {
      if (kDebugMode) {
        print('❌ Failed to end call: $e');
      }
      return {
        'success': false,
        'message': 'Failed to end call: $e',
      };
    }
  }

  /// Initialize WebRTC peer connection
  Future<void> _initializeWebRTC() async {
    try {
      // Create peer connection with STUN servers
      final configuration = <String, dynamic>{
        'iceServers': [
          {'urls': 'stun:stun.l.google.com:19302'},
          {'urls': 'stun:stun1.l.google.com:19302'},
        ]
      };

      _peerConnection = await createPeerConnection(configuration);

      // Get user media (audio only for voice calls)
      final constraints = <String, dynamic>{
        'audio': true,
        'video': false,
      };

      _localStream = await navigator.mediaDevices.getUserMedia(constraints);

      // Add local stream to peer connection
      for (final track in _localStream!.getTracks()) {
        await _peerConnection!.addTrack(track, _localStream!);
      }

      // Handle remote stream
      _peerConnection!.onAddStream = (MediaStream stream) {
        if (kDebugMode) {
          print('📞 Remote stream added');
        }
        // Handle remote audio stream
      };

      // Handle ICE candidates
      _peerConnection!.onIceCandidate = (RTCIceCandidate candidate) {
        if (kDebugMode) {
          print('🧊 ICE candidate: ${candidate.candidate}');
        }
        // Send candidate through signaling
        _sendSignalingMessage({
          'type': 'ice_candidate',
          'candidate': candidate.toMap(),
        });
      };

      if (kDebugMode) {
        print('✅ WebRTC initialized');
      }
    } catch (e) {
      if (kDebugMode) {
        print('❌ WebRTC initialization failed: $e');
      }
      throw e;
    }
  }

  /// Connect to signaling server via Supabase realtime
  Future<void> _connectSignaling() async {
    try {
      final currentUser = _client.auth.currentUser;
      if (currentUser == null || _currentCallId == null) return;

      // Subscribe to call signaling updates
      _client
          .channel('call_signaling_$_currentCallId')
          .onPostgresChanges(
            event: PostgresChangeEvent.update,
            schema: 'public',
            table: 'call_signaling',
            filter: PostgresChangeFilter(
              type: PostgresChangeFilterType.eq,
              column: 'call_id',
              value: _currentCallId!,
            ),
            callback: (payload) {
              _handleSignalingMessage(payload.newRecord);
            },
          )
          .subscribe();

      if (kDebugMode) {
        print('✅ Signaling connected for call: $_currentCallId');
      }
    } catch (e) {
      if (kDebugMode) {
        print('❌ Signaling connection failed: $e');
      }
    }
  }

  /// Send signaling message through Supabase
  Future<void> _sendSignalingMessage(Map<String, dynamic> message) async {
    try {
      if (_currentCallId == null) return;

      final currentUser = _client.auth.currentUser;
      if (currentUser == null) return;

      await _client.from('call_signaling').upsert({
        'call_id': _currentCallId,
        'sender_id': currentUser.id,
        'message_type': message['type'],
        'message_data': message,
        'created_at': DateTime.now().toIso8601String(),
      });
    } catch (e) {
      if (kDebugMode) {
        print('❌ Failed to send signaling message: $e');
      }
    }
  }

  /// Handle incoming signaling messages
  Future<void> _handleSignalingMessage(Map<String, dynamic> data) async {
    try {
      final messageData = data['message_data'] as Map<String, dynamic>;
      final messageType = messageData['type'] as String;

      switch (messageType) {
        case 'offer':
          await _handleOffer(messageData);
          break;
        case 'answer':
          await _handleAnswer(messageData);
          break;
        case 'ice_candidate':
          await _handleIceCandidate(messageData);
          break;
      }
    } catch (e) {
      if (kDebugMode) {
        print('❌ Error handling signaling message: $e');
      }
    }
  }

  /// Handle WebRTC offer
  Future<void> _handleOffer(Map<String, dynamic> offer) async {
    try {
      if (_peerConnection == null) return;

      await _peerConnection!.setRemoteDescription(
        RTCSessionDescription(offer['sdp'], offer['type']),
      );

      final answer = await _peerConnection!.createAnswer();
      await _peerConnection!.setLocalDescription(answer);

      _sendSignalingMessage({
        'type': 'answer',
        'sdp': answer.sdp,
      });
    } catch (e) {
      if (kDebugMode) {
        print('❌ Error handling offer: $e');
      }
    }
  }

  /// Handle WebRTC answer
  Future<void> _handleAnswer(Map<String, dynamic> answer) async {
    try {
      if (_peerConnection == null) return;

      await _peerConnection!.setRemoteDescription(
        RTCSessionDescription(answer['sdp'], answer['type']),
      );
    } catch (e) {
      if (kDebugMode) {
        print('❌ Error handling answer: $e');
      }
    }
  }

  /// Handle ICE candidate
  Future<void> _handleIceCandidate(Map<String, dynamic> candidateData) async {
    try {
      if (_peerConnection == null) return;

      final candidate = RTCIceCandidate(
        candidateData['candidate']['candidate'],
        candidateData['candidate']['sdpMid'],
        candidateData['candidate']['sdpMLineIndex'],
      );

      await _peerConnection!.addCandidate(candidate);
    } catch (e) {
      if (kDebugMode) {
        print('❌ Error handling ICE candidate: $e');
      }
    }
  }

  /// Cleanup WebRTC resources
  Future<void> _cleanupWebRTC() async {
    try {
      // Stop local stream tracks
      if (_localStream != null) {
        for (final track in _localStream!.getTracks()) {
          await track.stop();
        }
        await _localStream!.dispose();
        _localStream = null;
      }

      // Close peer connection
      if (_peerConnection != null) {
        await _peerConnection!.close();
        _peerConnection = null;
      }

      // Close signaling channel
      if (_signalingChannel != null) {
        await _signalingChannel!.sink.close();
        _signalingChannel = null;
      }

      _currentCallId = null;
      _isCallActive = false;
      _remoteUserId = null;

      if (kDebugMode) {
        print('✅ WebRTC resources cleaned up');
      }
    } catch (e) {
      if (kDebugMode) {
        print('❌ Error cleaning up WebRTC: $e');
      }
    }
  }

  /// Get active calls for user
  Future<List<Map<String, dynamic>>> getActiveCalls() async {
    try {
      final currentUser = _client.auth.currentUser;
      if (currentUser == null) return [];

      final response = await _client
          .from('calls')
          .select('''
            *,
            caller:user_profiles!caller_id(profile_name, full_name),
            callee:user_profiles!callee_id(profile_name, full_name),
            trade:trades(id, buyer_city, seller_city)
          ''')
          .or('caller_id.eq.${currentUser.id},callee_id.eq.${currentUser.id}')
          .inFilter('status', ['INITIATED', 'ACTIVE'])
          .order('started_at', ascending: false);

      return List<Map<String, dynamic>>.from(response);
    } catch (e) {
      if (kDebugMode) {
        print('❌ Error fetching active calls: $e');
      }
      return [];
    }
  }

  /// Get call history for user
  Future<List<Map<String, dynamic>>> getCallHistory({
    int limit = 20,
  }) async {
    try {
      final currentUser = _client.auth.currentUser;
      if (currentUser == null) return [];

      final response = await _client
          .from('calls')
          .select('''
            *,
            caller:user_profiles!caller_id(profile_name, full_name),
            callee:user_profiles!callee_id(profile_name, full_name),
            trade:trades(id, buyer_city, seller_city)
          ''')
          .or('caller_id.eq.${currentUser.id},callee_id.eq.${currentUser.id}')
          .order('started_at', ascending: false)
          .limit(limit);

      return List<Map<String, dynamic>>.from(response);
    } catch (e) {
      if (kDebugMode) {
        print('❌ Error fetching call history: $e');
      }
      return [];
    }
  }

  /// Subscribe to call notifications
  RealtimeChannel subscribeToCallNotifications({
    required Function(Map<String, dynamic>) onCallReceived,
    required Function(Map<String, dynamic>) onCallStatusUpdate,
  }) {
    final currentUser = _client.auth.currentUser;
    if (currentUser == null) {
      throw Exception('User not authenticated');
    }

    return _client
        .channel('user_calls_${currentUser.id}')
        .onPostgresChanges(
          event: PostgresChangeEvent.insert,
          schema: 'public',
          table: 'calls',
          filter: PostgresChangeFilter(
            type: PostgresChangeFilterType.eq,
            column: 'callee_id',
            value: currentUser.id,
          ),
          callback: (payload) {
            onCallReceived(payload.newRecord);
          },
        )
        .onPostgresChanges(
          event: PostgresChangeEvent.update,
          schema: 'public',
          table: 'calls',
          filter: PostgresChangeFilter(
            type: PostgresChangeFilterType.eq,
            column: 'caller_id',
            value: currentUser.id,
          ),
          callback: (payload) {
            onCallStatusUpdate(payload.newRecord);
          },
        )
        .onPostgresChanges(
          event: PostgresChangeEvent.update,
          schema: 'public',
          table: 'calls',
          filter: PostgresChangeFilter(
            type: PostgresChangeFilterType.eq,
            column: 'callee_id',
            value: currentUser.id,
          ),
          callback: (payload) {
            onCallStatusUpdate(payload.newRecord);
          },
        )
        .subscribe();
  }

  /// Mark messages as read
  Future<void> markMessagesAsRead({
    required String tradeId,
    required List<String> messageIds,
  }) async {
    try {
      await _client
          .from('chat_messages')
          .update({'is_read': true})
          .inFilter('id', messageIds)
          .eq('trade_id', tradeId);

      if (kDebugMode) {
        print('✅ Marked ${messageIds.length} messages as read');
      }
    } catch (e) {
      if (kDebugMode) {
        print('❌ Error marking messages as read: $e');
      }
    }
  }

  /// Get unread message count
  Future<int> getUnreadMessageCount(String tradeId) async {
    try {
      final currentUser = _client.auth.currentUser;
      if (currentUser == null) return 0;

      final response = await _client
          .from('chat_messages')
          .select()
          .eq('trade_id', tradeId)
          .neq('sender_id', currentUser.id)
          .eq('is_read', false)
          .count(CountOption.exact);

      return response.count ?? 0;
    } catch (e) {
      if (kDebugMode) {
        print('❌ Error fetching unread count: $e');
      }
      return 0;
    }
  }

  // Getters for current call state
  bool get isCallActive => _isCallActive;
  String? get currentCallId => _currentCallId;
  String? get remoteUserId => _remoteUserId;

  /// Dispose resources
  void dispose() async {
    await _cleanupWebRTC();
  }
}