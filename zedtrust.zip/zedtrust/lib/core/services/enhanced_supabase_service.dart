import 'package:flutter/foundation.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import '../../services/supabase_service.dart';

/// Enhanced Supabase service for ZedTrust DApp with complete integration
class EnhancedSupabaseService {
  static EnhancedSupabaseService? _instance;
  static EnhancedSupabaseService get instance {
    _instance ??= EnhancedSupabaseService._();
    return _instance!;
  }

  EnhancedSupabaseService._();

  SupabaseClient get client => SupabaseService.instance.client;

  /// Initialize enhanced services
  Future<void> initialize() async {
    try {
      await SupabaseService.initialize();
      if (kDebugMode) {
        print('✅ Enhanced Supabase service initialized');
      }
    } catch (e) {
      if (kDebugMode) {
        print('❌ Enhanced Supabase service initialization failed: $e');
      }
      rethrow;
    }
  }

  // ===== USER MANAGEMENT =====

  /// Get current user profile with complete data
  Future<Map<String, dynamic>?> getCurrentUserProfile() async {
    try {
      final user = client.auth.currentUser;
      if (user == null) return null;

      final response = await client
          .from('users')
          .select('*')
          .eq('id', user.id)
          .maybeSingle();

      return response;
    } catch (e) {
      if (kDebugMode) {
        print('❌ Error fetching user profile: $e');
      }
      return null;
    }
  }

  /// Create new user in database
  Future<Map<String, dynamic>?> createUser({
    required String id,
    required String username,
    String role = 'user',
  }) async {
    try {
      final response = await client
          .from('users')
          .insert({'id': id, 'username': username, 'role': role})
          .select()
          .single();

      return response;
    } catch (e) {
      if (kDebugMode) {
        print('❌ Error creating user: $e');
      }
      rethrow;
    }
  }

  /// Update user profile
  Future<Map<String, dynamic>?> updateUser({
    required String id,
    String? username,
    String? role,
  }) async {
    try {
      final updateData = <String, dynamic>{};
      if (username != null) updateData['username'] = username;
      if (role != null) updateData['role'] = role;

      final response = await client
          .from('users')
          .update(updateData)
          .eq('id', id)
          .select()
          .single();

      return response;
    } catch (e) {
      if (kDebugMode) {
        print('❌ Error updating user: $e');
      }
      rethrow;
    }
  }

  // ===== AGENT MANAGEMENT =====

  /// Get all agents with location counts
  Future<List<Map<String, dynamic>>> getAllAgents() async {
    try {
      final response = await client.from('agents').select('''
            *,
            agent_locations!inner(count)
          ''').order('created_at', ascending: false);

      return List<Map<String, dynamic>>.from(response);
    } catch (e) {
      if (kDebugMode) {
        print('❌ Error fetching agents: $e');
      }
      return [];
    }
  }

  /// Get verified agents only
  Future<List<Map<String, dynamic>>> getVerifiedAgents() async {
    try {
      final response = await client
          .from('agents')
          .select('*')
          .eq('verified', true)
          .order('name', ascending: true);

      return List<Map<String, dynamic>>.from(response);
    } catch (e) {
      if (kDebugMode) {
        print('❌ Error fetching verified agents: $e');
      }
      return [];
    }
  }

  /// Create new agent
  Future<Map<String, dynamic>?> createAgent({
    required String name,
    bool verified = false,
  }) async {
    try {
      final response = await client
          .from('agents')
          .insert({'name': name, 'verified': verified})
          .select()
          .single();

      return response;
    } catch (e) {
      if (kDebugMode) {
        print('❌ Error creating agent: $e');
      }
      rethrow;
    }
  }

  /// Update agent verification status
  Future<Map<String, dynamic>?> updateAgentVerification({
    required String agentId,
    required bool verified,
  }) async {
    try {
      final response = await client
          .from('agents')
          .update({'verified': verified})
          .eq('id', agentId)
          .select()
          .single();

      return response;
    } catch (e) {
      if (kDebugMode) {
        print('❌ Error updating agent verification: $e');
      }
      rethrow;
    }
  }

  // ===== AGENT LOCATIONS =====

  /// Get agent locations for specific agent
  Future<List<Map<String, dynamic>>> getAgentLocations(String agentId) async {
    try {
      final response = await client
          .from('agent_locations')
          .select('*')
          .eq('agent_id', agentId)
          .eq('is_active', true)
          .order('city', ascending: true);

      return List<Map<String, dynamic>>.from(response);
    } catch (e) {
      if (kDebugMode) {
        print('❌ Error fetching agent locations: $e');
      }
      return [];
    }
  }

  /// Get agent locations by city
  Future<List<Map<String, dynamic>>> getAgentLocationsByCity({
    required String city,
  }) async {
    try {
      final response = await client
          .from('agent_locations')
          .select('''
            *,
            agents!inner(name, verified)
          ''')
          .eq('city', city)
          .eq('is_active', true)
          .order('area', ascending: true);

      return List<Map<String, dynamic>>.from(response);
    } catch (e) {
      if (kDebugMode) {
        print('❌ Error fetching agent locations by city: $e');
      }
      return [];
    }
  }

  /// Create agent location
  Future<Map<String, dynamic>?> createAgentLocation({
    required String agentId,
    required String city,
    String? area,
    String? addressLine,
    double? geoLat,
    double? geoLng,
    bool isActive = true,
  }) async {
    try {
      final response = await client
          .from('agent_locations')
          .insert({
            'agent_id': agentId,
            'city': city,
            'area': area,
            'address_line': addressLine,
            'geo_lat': geoLat,
            'geo_lng': geoLng,
            'is_active': isActive,
          })
          .select()
          .single();

      return response;
    } catch (e) {
      if (kDebugMode) {
        print('❌ Error creating agent location: $e');
      }
      rethrow;
    }
  }

  // ===== TRADES MANAGEMENT =====

  /// Get all trades for current user
  Future<List<Map<String, dynamic>>> getUserTrades() async {
    try {
      final user = client.auth.currentUser;
      if (user == null) return [];

      final response = await client
          .from('trades')
          .select('''
            *,
            agents(name),
            buyer_location:agent_locations!buyer_location_id(city, area),
            seller_location:agent_locations!seller_location_id(city, area)
          ''')
          .or('buyer_id.eq.${user.id},seller_id.eq.${user.id}')
          .order('created_at', ascending: false);

      return List<Map<String, dynamic>>.from(response);
    } catch (e) {
      if (kDebugMode) {
        print('❌ Error fetching user trades: $e');
      }
      return [];
    }
  }

  /// Create new trade
  Future<Map<String, dynamic>?> createTrade({
    required String buyerId,
    required String sellerId,
    String? agentId,
    String? buyerLocationId,
    String? sellerLocationId,
    String? buyerWalletAddress,
    String? sellerWalletAddress,
    double? amountUsdc,
    String status = 'PENDING',
  }) async {
    try {
      final response = await client
          .from('trades')
          .insert({
            'buyer_id': buyerId,
            'seller_id': sellerId,
            'agent_id': agentId,
            'buyer_location_id': buyerLocationId,
            'seller_location_id': sellerLocationId,
            'buyer_wallet_address': buyerWalletAddress,
            'seller_wallet_address': sellerWalletAddress,
            'amount_usdc': amountUsdc,
            'status': status,
          })
          .select()
          .single();

      return response;
    } catch (e) {
      if (kDebugMode) {
        print('❌ Error creating trade: $e');
      }
      rethrow;
    }
  }

  /// Get trade by ID with complete details
  Future<Map<String, dynamic>?> getTradeDetails(String tradeId) async {
    try {
      final response = await client.from('trades').select('''
            *,
            agents(name, verified),
            buyer_location:agent_locations!buyer_location_id(*),
            seller_location:agent_locations!seller_location_id(*),
            escrow(*),
            otps(*)
          ''').eq('id', tradeId).single();

      return response;
    } catch (e) {
      if (kDebugMode) {
        print('❌ Error fetching trade details: $e');
      }
      return null;
    }
  }

  /// Update trade status
  Future<Map<String, dynamic>?> updateTradeStatus({
    required String tradeId,
    required String status,
  }) async {
    try {
      final response = await client
          .from('trades')
          .update({'status': status})
          .eq('id', tradeId)
          .select()
          .single();

      return response;
    } catch (e) {
      if (kDebugMode) {
        print('❌ Error updating trade status: $e');
      }
      rethrow;
    }
  }

  // ===== ESCROW MANAGEMENT =====

  /// Get escrow details for trade
  Future<Map<String, dynamic>?> getEscrowDetails(String tradeId) async {
    try {
      final response = await client
          .from('escrow')
          .select('*')
          .eq('trade_id', tradeId)
          .maybeSingle();

      return response;
    } catch (e) {
      if (kDebugMode) {
        print('❌ Error fetching escrow details: $e');
      }
      return null;
    }
  }

  /// Create escrow for trade
  Future<Map<String, dynamic>?> createEscrow({
    required String tradeId,
    required double lockedAmount,
    String? smartContractAddress,
    double buyerFee = 0.0,
    double sellerFee = 0.0,
    double platformFeeTotal = 0.0,
  }) async {
    try {
      final response = await client
          .from('escrow')
          .insert({
            'trade_id': tradeId,
            'locked_amount': lockedAmount,
            'smart_contract_address': smartContractAddress,
            'buyer_fee': buyerFee,
            'seller_fee': sellerFee,
            'platform_fee_total': platformFeeTotal,
          })
          .select()
          .single();

      return response;
    } catch (e) {
      if (kDebugMode) {
        print('❌ Error creating escrow: $e');
      }
      rethrow;
    }
  }

  /// Release escrow
  Future<Map<String, dynamic>?> releaseEscrow({
    required String escrowId,
    String? releaseTransactionHash,
  }) async {
    try {
      final response = await client
          .from('escrow')
          .update({
            'released': true,
            'released_at': DateTime.now().toIso8601String(),
            'release_transaction_hash': releaseTransactionHash,
          })
          .eq('id', escrowId)
          .select()
          .single();

      return response;
    } catch (e) {
      if (kDebugMode) {
        print('❌ Error releasing escrow: $e');
      }
      rethrow;
    }
  }

  // ===== OTP MANAGEMENT =====

  /// Generate OTP for trade
  Future<Map<String, dynamic>?> generateOTP({
    required String tradeId,
    required String otpCode,
    required String colorCode,
  }) async {
    try {
      final response = await client
          .from('otps')
          .insert({
            'trade_id': tradeId,
            'otp_code': otpCode,
            'color_code': colorCode,
          })
          .select()
          .single();

      return response;
    } catch (e) {
      if (kDebugMode) {
        print('❌ Error generating OTP: $e');
      }
      rethrow;
    }
  }

  /// Verify OTP
  Future<Map<String, dynamic>?> verifyOTP({
    required String tradeId,
    required String otpCode,
  }) async {
    try {
      final otp = await client
          .from('otps')
          .select('*')
          .eq('trade_id', tradeId)
          .eq('otp_code', otpCode)
          .eq('is_verified', false)
          .gt('expires_at', DateTime.now().toIso8601String())
          .maybeSingle();

      if (otp == null) {
        throw Exception('Invalid or expired OTP');
      }

      final response = await client
          .from('otps')
          .update({
            'is_verified': true,
            'verified_at': DateTime.now().toIso8601String(),
          })
          .eq('id', otp['id'])
          .select()
          .single();

      return response;
    } catch (e) {
      if (kDebugMode) {
        print('❌ Error verifying OTP: $e');
      }
      rethrow;
    }
  }

  /// Get OTP for trade
  Future<Map<String, dynamic>?> getTradeOTP(String tradeId) async {
    try {
      final response = await client
          .from('otps')
          .select('*')
          .eq('trade_id', tradeId)
          .gt('expires_at', DateTime.now().toIso8601String())
          .order('created_at', ascending: false)
          .maybeSingle();

      return response;
    } catch (e) {
      if (kDebugMode) {
        print('❌ Error fetching trade OTP: $e');
      }
      return null;
    }
  }

  // ===== REAL-TIME SUBSCRIPTIONS =====

  /// Subscribe to trades updates
  RealtimeChannel subscribeToTrades({
    required Function(Map<String, dynamic>) onInsert,
    required Function(Map<String, dynamic>) onUpdate,
    required Function(Map<String, dynamic>) onDelete,
  }) {
    return client
        .channel('trades_channel')
        .onPostgresChanges(
          event: PostgresChangeEvent.insert,
          schema: 'public',
          table: 'trades',
          callback: (payload) => onInsert(payload.newRecord),
        )
        .onPostgresChanges(
          event: PostgresChangeEvent.update,
          schema: 'public',
          table: 'trades',
          callback: (payload) => onUpdate(payload.newRecord),
        )
        .onPostgresChanges(
          event: PostgresChangeEvent.delete,
          schema: 'public',
          table: 'trades',
          callback: (payload) => onDelete(payload.oldRecord),
        )
        .subscribe();
  }

  /// Subscribe to escrow updates
  RealtimeChannel subscribeToEscrow({
    required Function(Map<String, dynamic>) onUpdate,
  }) {
    return client
        .channel('escrow_channel')
        .onPostgresChanges(
          event: PostgresChangeEvent.update,
          schema: 'public',
          table: 'escrow',
          callback: (payload) => onUpdate(payload.newRecord),
        )
        .subscribe();
  }

  // ===== STATISTICS & ANALYTICS =====

  /// Get platform statistics
  Future<Map<String, dynamic>> getPlatformStats() async {
    try {
      final results = await Future.wait([
        client.from('users').select().count(CountOption.exact),
        client.from('agents').select().count(CountOption.exact),
        client.from('trades').select().count(CountOption.exact),
        client
            .from('escrow')
            .select()
            .eq('released', true)
            .count(CountOption.exact),
      ]);

      return {
        'total_users': results[0].count,
        'total_agents': results[1].count,
        'total_trades': results[2].count,
        'completed_escrows': results[3].count,
      };
    } catch (e) {
      if (kDebugMode) {
        print('❌ Error fetching platform stats: $e');
      }
      return {};
    }
  }

  /// Get user trade statistics
  Future<Map<String, dynamic>> getUserTradeStats(String userId) async {
    try {
      final results = await Future.wait([
        client
            .from('trades')
            .select()
            .or('buyer_id.eq.$userId,seller_id.eq.$userId')
            .count(CountOption.exact),
        client
            .from('trades')
            .select()
            .or('buyer_id.eq.$userId,seller_id.eq.$userId')
            .eq('status', 'COMPLETED')
            .count(CountOption.exact),
      ]);

      return {
        'total_trades': results[0].count,
        'completed_trades': results[1].count,
        'success_rate': results[0].count > 0
            ? (results[1].count / results[0].count * 100).toStringAsFixed(1)
            : '0.0',
      };
    } catch (e) {
      if (kDebugMode) {
        print('❌ Error fetching user trade stats: $e');
      }
      return {};
    }
  }

  // ===== UTILITY FUNCTIONS =====

  /// Check if user is authenticated
  bool get isAuthenticated => client.auth.currentUser != null;

  /// Get current user
  User? get currentUser => client.auth.currentUser;

  /// Get current session
  Session? get currentSession => client.auth.currentSession;

  /// Listen to auth state changes
  Stream<AuthState> get authStateChanges => client.auth.onAuthStateChange;

  /// Dispose resources
  void dispose() {
    // Cleanup if needed
  }
}
