import 'dart:math';

import 'package:flutter/foundation.dart';

import './enhanced_supabase_service.dart';

/// OTP service for handling OTP operations with Supabase
class OTPService {
  static OTPService? _instance;
  static OTPService get instance => _instance ??= OTPService._();

  OTPService._();

  final _supabase = EnhancedSupabaseService.instance;
  final _random = Random();

  // Color codes for OTP verification
  static const List<String> _colorCodes = [
    'red',
    'blue',
    'green',
    'yellow',
    'purple',
    'orange',
    'pink',
    'cyan',
    'indigo',
    'teal',
  ];

  /// Generate a new OTP for trade
  Future<Map<String, dynamic>> generateOTP({required String tradeId}) async {
    try {
      // Verify trade exists and user has access
      final trade = await _supabase.getTradeDetails(tradeId);
      if (trade == null) {
        throw Exception('Trade not found');
      }

      final currentUser = _supabase.currentUser;
      if (currentUser == null) {
        throw Exception('User not authenticated');
      }

      // Check if user is buyer or seller
      final isBuyer = trade['buyer_id'] == currentUser.id;
      final isSeller = trade['seller_id'] == currentUser.id;

      if (!isBuyer && !isSeller) {
        throw Exception('Not authorized to generate OTP for this trade');
      }

      // Generate 6-digit OTP
      final otpCode = _generateOTPCode();
      final colorCode = _generateColorCode();

      final otp = await _supabase.generateOTP(
        tradeId: tradeId,
        otpCode: otpCode,
        colorCode: colorCode,
      );

      if (otp != null) {
        if (kDebugMode) {
          print('✅ OTP generated successfully: ${otp['id']}');
          print('🔢 OTP Code: $otpCode');
          print('🎨 Color: $colorCode');
        }
        return {
          'success': true,
          'otp': otp,
          'otp_code': otpCode,
          'color_code': colorCode,
        };
      } else {
        throw Exception('Failed to generate OTP');
      }
    } catch (e) {
      if (kDebugMode) {
        print('❌ Error generating OTP: $e');
      }
      return {'success': false, 'error': e.toString()};
    }
  }

  /// Verify OTP for trade
  Future<Map<String, dynamic>> verifyOTP({
    required String tradeId,
    required String otpCode,
  }) async {
    try {
      final verifiedOTP = await _supabase.verifyOTP(
        tradeId: tradeId,
        otpCode: otpCode,
      );

      if (verifiedOTP != null) {
        if (kDebugMode) {
          print('✅ OTP verified successfully: ${verifiedOTP['id']}');
        }
        return {'success': true, 'otp': verifiedOTP};
      } else {
        throw Exception('Invalid or expired OTP');
      }
    } catch (e) {
      if (kDebugMode) {
        print('❌ Error verifying OTP: $e');
      }
      return {'success': false, 'error': e.toString()};
    }
  }

  /// Get current valid OTP for trade
  Future<Map<String, dynamic>?> getCurrentOTP(String tradeId) async {
    try {
      final otp = await _supabase.getTradeOTP(tradeId);

      if (otp != null && kDebugMode) {
        print('✅ Current OTP fetched: ${otp['id']}');
      }

      return otp;
    } catch (e) {
      if (kDebugMode) {
        print('❌ Error fetching current OTP: $e');
      }
      return null;
    }
  }

  /// Check if OTP is valid (not expired and not verified)
  bool isOTPValid(Map<String, dynamic>? otp) {
    if (otp == null) return false;

    final now = DateTime.now();
    final expiresAt = DateTime.parse(otp['expires_at']);
    final isVerified = otp['is_verified'] == true;

    return !isVerified && now.isBefore(expiresAt);
  }

  /// Get OTP expiration time remaining in minutes
  int getOTPExpiryMinutes(Map<String, dynamic>? otp) {
    if (otp == null) return 0;

    final now = DateTime.now();
    final expiresAt = DateTime.parse(otp['expires_at']);

    if (now.isAfter(expiresAt)) return 0;

    return expiresAt.difference(now).inMinutes;
  }

  /// Get formatted expiry time string
  String getFormattedExpiryTime(Map<String, dynamic>? otp) {
    final minutes = getOTPExpiryMinutes(otp);

    if (minutes <= 0) return 'Expired';
    if (minutes == 1) return '1 minute remaining';
    return '$minutes minutes remaining';
  }

  /// Generate a random 6-digit OTP code
  String _generateOTPCode() {
    return (_random.nextInt(900000) + 100000).toString();
  }

  /// Generate a random color code
  String _generateColorCode() {
    return _colorCodes[_random.nextInt(_colorCodes.length)];
  }

  /// Get color hex code from color name
  String getColorHex(String colorName) {
    switch (colorName.toLowerCase()) {
      case 'red':
        return '#FF0000';
      case 'blue':
        return '#0000FF';
      case 'green':
        return '#00FF00';
      case 'yellow':
        return '#FFFF00';
      case 'purple':
        return '#800080';
      case 'orange':
        return '#FFA500';
      case 'pink':
        return '#FFC0CB';
      case 'cyan':
        return '#00FFFF';
      case 'indigo':
        return '#4B0082';
      case 'teal':
        return '#008080';
      default:
        return '#000000';
    }
  }

  /// Get all available color codes
  List<String> getAvailableColors() {
    return List.from(_colorCodes);
  }

  /// Validate OTP format
  bool isValidOTPFormat(String otpCode) {
    return otpCode.length == 6 && RegExp(r'^\d{6}$').hasMatch(otpCode);
  }

  /// Get OTP status message
  String getOTPStatusMessage(Map<String, dynamic>? otp) {
    if (otp == null) return 'No OTP found';

    if (otp['is_verified'] == true) return 'OTP verified successfully';

    final expiryMinutes = getOTPExpiryMinutes(otp);
    if (expiryMinutes <= 0) return 'OTP has expired';

    return 'OTP is active ($expiryMinutes min remaining)';
  }

  /// Check if user can generate new OTP
  Future<bool> canGenerateNewOTP(String tradeId) async {
    try {
      final currentOTP = await getCurrentOTP(tradeId);

      // Can generate if no OTP exists or current OTP is expired/verified
      return currentOTP == null || !isOTPValid(currentOTP);
    } catch (e) {
      if (kDebugMode) {
        print('❌ Error checking OTP generation eligibility: $e');
      }
      return false;
    }
  }

  /// Get OTP statistics for trade
  Future<Map<String, int>> getOTPStats(String tradeId) async {
    try {
      final allOTPs = await _supabase.client
          .from('otps')
          .select('*')
          .eq('trade_id', tradeId)
          .order('created_at', ascending: false);

      final totalGenerated = allOTPs.length;
      final verified =
          allOTPs.where((otp) => otp['is_verified'] == true).length;
      final expired =
          allOTPs.where((otp) {
            final expiresAt = DateTime.parse(otp['expires_at']);
            return DateTime.now().isAfter(expiresAt) &&
                otp['is_verified'] != true;
          }).length;

      return {
        'total_generated': totalGenerated,
        'verified': verified,
        'expired': expired,
        'active': totalGenerated - verified - expired,
      };
    } catch (e) {
      if (kDebugMode) {
        print('❌ Error fetching OTP stats: $e');
      }
      return {'total_generated': 0, 'verified': 0, 'expired': 0, 'active': 0};
    }
  }
}
