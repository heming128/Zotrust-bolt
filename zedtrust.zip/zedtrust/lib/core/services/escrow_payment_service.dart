import 'package:flutter/foundation.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import '../../services/supabase_service.dart';

/// Service for handling USDC escrow payments and fee management
class EscrowPaymentService {
  static EscrowPaymentService? _instance;
  static EscrowPaymentService get instance =>
      _instance ??= EscrowPaymentService._();

  EscrowPaymentService._();

  SupabaseClient get _client => SupabaseService.instance.client;

  // Platform fee percentages
  static const double buyerFeePercent = 1.0; // 1% from buyer
  static const double sellerFeePercent = 1.0; // 1% from seller
  static const double totalFeePercent = buyerFeePercent + sellerFeePercent;

  /// Create escrow trade with buyer fund locking
  Future<Map<String, dynamic>> createEscrowTrade({
    required String sellerId,
    required String buyerCity,
    required String sellerCity,
    required double usdcAmount,
    String? agentId,
    Map<String, dynamic>? additionalData,
  }) async {
    try {
      final buyerFee = (usdcAmount * buyerFeePercent) / 100;
      final sellerFee = (usdcAmount * sellerFeePercent) / 100;
      final totalAmount =
          usdcAmount + buyerFee; // Buyer pays amount + buyer fee

      // Calculate escrow details
      final escrowData = {
        'usdc_amount': usdcAmount,
        'buyer_fee': buyerFee,
        'seller_fee': sellerFee,
        'total_escrow_amount': totalAmount,
        'platform_fee_total': buyerFee + sellerFee,
        'escrow_status': 'LOCKED',
        ...?additionalData,
      };

      // Create trade with escrow information
      final response = await _client.rpc(
        'create_escrow_trade',
        params: {
          'p_seller_id': sellerId,
          'p_buyer_city': buyerCity,
          'p_seller_city': sellerCity,
          'p_agent_id': agentId,
          'p_escrow_data': escrowData,
        },
      );

      if (response != null) {
        if (kDebugMode) {
          print('✅ Escrow trade created: $response');
          print('💰 USDC Amount: $usdcAmount');
          print('💰 Buyer Fee (1%): $buyerFee');
          print('💰 Seller Fee (1%): $sellerFee');
          print('💰 Total Locked: $totalAmount');
        }

        return {
          'success': true,
          'trade_id': response,
          'escrow_details': {
            'usdc_amount': usdcAmount,
            'buyer_fee': buyerFee,
            'seller_fee': sellerFee,
            'total_locked': totalAmount,
            'platform_fee': buyerFee + sellerFee,
          },
        };
      }

      throw Exception('Failed to create escrow trade');
    } catch (e) {
      if (kDebugMode) {
        print('❌ Escrow trade creation failed: $e');
      }
      return {
        'success': false,
        'message': 'Failed to create escrow trade: $e',
      };
    }
  }

  /// Lock buyer funds in escrow with smart contract integration
  Future<Map<String, dynamic>> lockBuyerFunds({
    required String tradeId,
    required double usdcAmount,
    required String walletAddress,
    required String transactionHash,
  }) async {
    try {
      final buyerFee = (usdcAmount * buyerFeePercent) / 100;
      final totalAmount = usdcAmount + buyerFee;

      // Update trade with locked funds information
      final response = await _client
          .from('trades')
          .update({
            'escrow_status': 'LOCKED',
            'escrow_amount': totalAmount,
            'buyer_wallet_address': walletAddress,
            'lock_transaction_hash': transactionHash,
            'locked_at': DateTime.now().toIso8601String(),
            'status': 'OTP_PENDING',
          })
          .eq('id', tradeId)
          .select()
          .single();

      if (kDebugMode) {
        print('✅ Buyer funds locked: $totalAmount USDC');
        print('🔒 Transaction Hash: $transactionHash');
      }

      return {
        'success': true,
        'message': 'Funds locked successfully',
        'locked_amount': totalAmount,
        'transaction_hash': transactionHash,
      };
    } catch (e) {
      if (kDebugMode) {
        print('❌ Fund locking failed: $e');
      }
      return {
        'success': false,
        'message': 'Failed to lock funds: $e',
      };
    }
  }

  /// Release escrow funds after OTP verification with smart contract execution
  Future<Map<String, dynamic>> releaseEscrowFunds({
    required String tradeId,
    required String otpCode,
    required String otpColor,
  }) async {
    try {
      // Verify OTP first
      final otpValid = await _client.rpc(
        'verify_trade_otp',
        params: {
          'p_trade_id': tradeId,
          'p_otp_code': otpCode,
          'p_otp_color': otpColor,
        },
      );

      if (otpValid != true) {
        return {
          'success': false,
          'message': 'Invalid OTP. Please check the code and color.',
        };
      }

      // Process escrow release with fee distribution
      final releaseResult = await _client.rpc(
        'process_escrow_release',
        params: {
          'p_trade_id': tradeId,
          'p_release_transaction_hash':
              null, // Will be updated by smart contract
        },
      );

      if (releaseResult['success'] == true) {
        if (kDebugMode) {
          print('✅ Escrow funds released successfully');
          print('💰 Seller Receives: ${releaseResult['seller_receives']} USDC');
          print(
              '💰 Platform Fee: ${releaseResult['platform_fee_collected']} USDC');
          print(
              '📊 Fee Breakdown: Buyer(1%) + Seller(1%) = ${totalFeePercent}%');
        }

        return {
          'success': true,
          'message': 'Funds released successfully',
          'distribution': {
            'seller_receives': releaseResult['seller_receives'],
            'platform_fee': releaseResult['platform_fee_collected'],
            'buyer_fee': releaseResult['buyer_fee'],
            'seller_fee': releaseResult['seller_fee'],
          },
          'release_transaction_hash': releaseResult['release_transaction_hash'],
        };
      } else {
        throw Exception(
            releaseResult['message'] ?? 'Unknown error during release');
      }
    } catch (e) {
      if (kDebugMode) {
        print('❌ Fund release failed: $e');
      }
      return {
        'success': false,
        'message': 'Failed to release funds: $e',
      };
    }
  }

  /// Get escrow trade details with comprehensive fee breakdown
  Future<Map<String, dynamic>?> getEscrowTradeDetails(String tradeId) async {
    try {
      final response = await _client.from('trades').select('''
            *,
            agents(name, verified),
            buyer:users!buyer_id(username),
            seller:users!seller_id(username),
            escrow(*),
            otps(*)
          ''').eq('id', tradeId).single();

      // Calculate fee breakdown if not stored
      if (response['amount_usdc'] != null) {
        final usdcAmount = response['amount_usdc'] as double;
        final buyerFee = (usdcAmount * buyerFeePercent) / 100;
        final sellerFee = (usdcAmount * sellerFeePercent) / 100;

        response['fee_breakdown'] = {
          'buyer_fee_percent': buyerFeePercent,
          'seller_fee_percent': sellerFeePercent,
          'buyer_fee_amount': buyerFee,
          'seller_fee_amount': sellerFee,
          'total_platform_fee': buyerFee + sellerFee,
        };
      }

      return response;
    } catch (e) {
      if (kDebugMode) {
        print('❌ Error fetching escrow trade details: $e');
      }
      return null;
    }
  }

  /// Cancel escrow and refund buyer with smart contract execution
  Future<Map<String, dynamic>> cancelEscrow({
    required String tradeId,
    required String cancellationReason,
  }) async {
    try {
      // Use the database function for proper cancellation
      final result = await _client.rpc(
        'cancel_escrow_trade',
        params: {
          'p_trade_id': tradeId,
          'p_cancellation_reason': cancellationReason,
          'p_refund_transaction_hash':
              null, // Will be updated by smart contract
        },
      );

      if (result['success'] == true) {
        if (kDebugMode) {
          print('✅ Escrow cancelled and refund initiated');
          print('💰 Refund Amount: ${result['refund_amount']} USDC');
        }

        return {
          'success': true,
          'message': 'Trade cancelled. Refund initiated.',
          'refund_amount': result['refund_amount'],
          'refund_transaction_hash': result['refund_transaction_hash'],
        };
      } else {
        throw Exception(
            result['message'] ?? 'Unknown error during cancellation');
      }
    } catch (e) {
      if (kDebugMode) {
        print('❌ Escrow cancellation failed: $e');
      }
      return {
        'success': false,
        'message': 'Failed to cancel escrow: $e',
      };
    }
  }

  /// Get comprehensive platform fee statistics (Admin only)
  Future<Map<String, dynamic>> getPlatformFeeStats() async {
    try {
      final results = await Future.wait([
        _client
            .from('trades')
            .select('platform_fee_collected')
            .eq('status', 'RELEASED'),
        _client.rpc('get_total_platform_fees'),
        _client.rpc('get_monthly_platform_fees'),
      ]);

      return {
        'total_completed_trades': results[0].count ?? 0,
        'total_fees_collected': results[1] ?? 0.0,
        'monthly_fees': results[2] ?? [],
      };
    } catch (e) {
      if (kDebugMode) {
        print('❌ Error fetching platform fee stats: $e');
      }
      return {};
    }
  }

  /// Get comprehensive escrow system statistics
  Future<Map<String, dynamic>> getEscrowStatistics() async {
    try {
      final stats = await _client.rpc('get_escrow_statistics');

      if (kDebugMode) {
        print('📊 Escrow Statistics:');
        print('💰 Total Locked: ${stats['total_locked_usdc']} USDC');
        print('💰 Total Released: ${stats['total_released_usdc']} USDC');
        print('💰 Platform Fees: ${stats['total_platform_fees']} USDC');
        print('📈 Active Trades: ${stats['active_trades']}');
        print('✅ Completed Trades: ${stats['completed_trades']}');
        print('❌ Cancelled Trades: ${stats['cancelled_trades']}');
      }

      return stats ?? {};
    } catch (e) {
      if (kDebugMode) {
        print('❌ Error fetching escrow statistics: $e');
      }
      return {};
    }
  }

  /// Calculate fee breakdown for amount
  Map<String, double> calculateFees(double usdcAmount) {
    final buyerFee = (usdcAmount * buyerFeePercent) / 100;
    final sellerFee = (usdcAmount * sellerFeePercent) / 100;

    return {
      'usdc_amount': usdcAmount,
      'buyer_fee': buyerFee,
      'seller_fee': sellerFee,
      'buyer_total': usdcAmount + buyerFee,
      'seller_receives': usdcAmount - sellerFee,
      'platform_fee_total': buyerFee + sellerFee,
    };
  }

  /// Get escrow status for trade
  Future<String?> getEscrowStatus(String tradeId) async {
    try {
      final response = await _client
          .from('trades')
          .select('escrow_status')
          .eq('id', tradeId)
          .maybeSingle();

      return response?['escrow_status'] as String?;
    } catch (e) {
      if (kDebugMode) {
        print('❌ Error fetching escrow status: $e');
      }
      return null;
    }
  }

  /// Get audit trail for trade
  Future<List<Map<String, dynamic>>> getTradeAuditLog(String tradeId) async {
    try {
      final response = await _client
          .from('escrow_audit_log')
          .select('*')
          .eq('trade_id', tradeId)
          .order('performed_at', ascending: false);

      return List<Map<String, dynamic>>.from(response);
    } catch (e) {
      if (kDebugMode) {
        print('❌ Error fetching audit log: $e');
      }
      return [];
    }
  }

  /// Listen for escrow status changes with enhanced real-time updates
  RealtimeChannel subscribeToEscrowUpdates({
    required String tradeId,
    required Function(Map<String, dynamic>) onStatusUpdate,
  }) {
    return _client
        .channel('escrow_updates_$tradeId')
        .onPostgresChanges(
          event: PostgresChangeEvent.update,
          schema: 'public',
          table: 'trades',
          filter: PostgresChangeFilter(
            type: PostgresChangeFilterType.eq,
            column: 'id',
            value: tradeId,
          ),
          callback: (payload) {
            if (kDebugMode) {
              print('🔄 Escrow update received: ${payload.newRecord}');
            }
            onStatusUpdate(payload.newRecord);
          },
        )
        .subscribe();
  }

  /// Listen for OTP verification status changes
  RealtimeChannel subscribeToOtpUpdates({
    required String tradeId,
    required Function(Map<String, dynamic>) onOtpUpdate,
  }) {
    return _client
        .channel('otp_updates_$tradeId')
        .onPostgresChanges(
          event: PostgresChangeEvent.update,
          schema: 'public',
          table: 'otps',
          filter: PostgresChangeFilter(
            type: PostgresChangeFilterType.eq,
            column: 'trade_id',
            value: tradeId,
          ),
          callback: (payload) {
            if (kDebugMode) {
              print('🔐 OTP update received: ${payload.newRecord}');
            }
            onOtpUpdate(payload.newRecord);
          },
        )
        .subscribe();
  }

  /// Validate trade parameters for escrow creation
  Map<String, dynamic> validateTradeParameters({
    required double usdcAmount,
    required String buyerAddress,
    required String sellerAddress,
    String? agentId,
  }) {
    final errors = <String>[];

    // Validate USDC amount
    if (usdcAmount <= 0) {
      errors.add('USDC amount must be greater than 0');
    }
    if (usdcAmount < 1) {
      errors.add('Minimum trade amount is 1 USDC');
    }
    if (usdcAmount > 100000) {
      errors.add('Maximum trade amount is 100,000 USDC');
    }

    // Validate wallet addresses
    final addressRegex = RegExp(r'^0x[a-fA-F0-9]{40}$');
    if (!addressRegex.hasMatch(buyerAddress)) {
      errors.add('Invalid buyer wallet address format');
    }
    if (!addressRegex.hasMatch(sellerAddress)) {
      errors.add('Invalid seller wallet address format');
    }
    if (buyerAddress.toLowerCase() == sellerAddress.toLowerCase()) {
      errors.add('Buyer and seller addresses cannot be the same');
    }

    // Calculate fees
    final feeBreakdown = calculateFees(usdcAmount);

    return {
      'isValid': errors.isEmpty,
      'errors': errors,
      'feeBreakdown': feeBreakdown,
    };
  }
}