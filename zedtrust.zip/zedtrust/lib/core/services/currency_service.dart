import 'package:dio/dio.dart';

class CurrencyService {
  static final CurrencyService _instance = CurrencyService._internal();
  factory CurrencyService() => _instance;
  CurrencyService._internal();

  final Dio _dio = Dio();
  double? _usdToInrRate;
  DateTime? _lastUpdated;
  
  // Cache exchange rate for 5 minutes
  static const Duration _cacheExpiry = Duration(minutes: 5);

  Future<double> getUSDToINRRate() async {
    // Return cached rate if still valid
    if (_usdToInrRate != null && 
        _lastUpdated != null && 
        DateTime.now().difference(_lastUpdated!) < _cacheExpiry) {
      return _usdToInrRate!;
    }

    try {
      // Using free exchange rate API
      final response = await _dio.get(
        'https://api.exchangerate-api.com/v4/latest/USD',
        options: Options(
          
          receiveTimeout: const Duration(seconds: 10)));

      if (response.statusCode == 200) {
        final data = response.data;
        _usdToInrRate = (data['rates']['INR'] as num).toDouble();
        _lastUpdated = DateTime.now();
        return _usdToInrRate!;
      }
    } catch (e) {
      print('Error fetching exchange rate: $e');
    }

    // Fallback to approximate rate if API fails
    _usdToInrRate = 83.50; // Approximate USD to INR rate
    _lastUpdated = DateTime.now();
    return _usdToInrRate!;
  }

  Future<double> convertUSDToINR(double usdAmount) async {
    final rate = await getUSDToINRRate();
    return usdAmount * rate;
  }

  String formatINRPrice(double inrAmount) {
    if (inrAmount >= 10000000) { // 1 crore
      return '₹${(inrAmount / 10000000).toStringAsFixed(2)}Cr';
    } else if (inrAmount >= 100000) { // 1 lakh
      return '₹${(inrAmount / 100000).toStringAsFixed(2)}L';
    } else if (inrAmount >= 1000) {
      return '₹${(inrAmount / 1000).toStringAsFixed(2)}K';
    } else {
      return '₹${inrAmount.toStringAsFixed(2)}';
    }
  }

  String formatFullINRPrice(double inrAmount) {
    return '₹${inrAmount.toStringAsFixed(2).replaceAllMapped(
      RegExp(r'(\d+?)(?=(\d\d)+(\d)(?!\d))(\.\d+)?'),
      (Match m) => '${m[1]},')})';
  }
}