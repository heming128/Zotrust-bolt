import 'dart:math';
import 'package:flutter/foundation.dart';
import './platform_settings_service.dart';

/// TradeFeeLogic: Implements exact platform fee calculations for USDC trades
/// with Polygon chain escrow settlement logic.
///
/// Requirements:
/// - Buyer pays 1% fee (receives 0.99*G USDC)
/// - Seller pays 1% fee (locks 1.01*G USDC)
/// - Platform collects 0.02*G total fees on successful trade
/// - All calculations in 6-decimal USDC format
class TradeFeeLogicService {
  static final TradeFeeLogicService _instance =
      TradeFeeLogicService._internal();
  static TradeFeeLogicService get instance => _instance;
  TradeFeeLogicService._internal();

  // Fee constants as per requirements
  static const double _buyerFeePct = 0.01; // 1% for buyer
  static const double _sellerFeePct = 0.01; // 1% for seller
  static const int _usdcDecimals = 6; // USDC standard decimals

  /// Calculate all fee components for a trade amount
  ///
  /// Returns a comprehensive fee breakdown including:
  /// - Required lock from seller (G * (1 + fS))
  /// - Net amount to buyer (G * (1 - fB))
  /// - Platform fees from each party
  /// - Total platform fee collected
  Map<String, dynamic> calculateTradeFees({
    required double grossTradeAmount,
    bool useIntegerFormat = false,
  }) {
    if (grossTradeAmount <= 0) {
      throw ArgumentError('Trade amount must be greater than 0');
    }

    final G = grossTradeAmount; // Gross trade amount (G)

    // Calculate exact fees as per formula
    final requiredLockFromSeller = G * (1 + _sellerFeePct); // G * (1 + fS)
    final netToBuyer = G * (1 - _buyerFeePct); // G * (1 - fB)
    final platformFeeBuyer = G * _buyerFeePct; // G * fB
    final platformFeeSeller = G * _sellerFeePct; // G * fS
    final platformFeeTotal = platformFeeBuyer + platformFeeSeller; // 0.02 * G

    // Convert to 6-decimal integers if requested (for smart contracts)
    final Map<String, dynamic> result = {
      'grossTradeAmount':
          useIntegerFormat ? _toUsdcInteger(G) : _roundToUsdcDecimals(G),
      'requiredLockFromSeller':
          useIntegerFormat
              ? _toUsdcInteger(requiredLockFromSeller)
              : _roundToUsdcDecimals(requiredLockFromSeller),
      'netToBuyer':
          useIntegerFormat
              ? _toUsdcInteger(netToBuyer)
              : _roundToUsdcDecimals(netToBuyer),
      'platformFeeBuyer':
          useIntegerFormat
              ? _toUsdcInteger(platformFeeBuyer)
              : _roundToUsdcDecimals(platformFeeBuyer),
      'platformFeeSeller':
          useIntegerFormat
              ? _toUsdcInteger(platformFeeSeller)
              : _roundToUsdcDecimals(platformFeeSeller),
      'platformFeeTotal':
          useIntegerFormat
              ? _toUsdcInteger(platformFeeTotal)
              : _roundToUsdcDecimals(platformFeeTotal),
      'buyerFeePct': _buyerFeePct,
      'sellerFeePct': _sellerFeePct,
      'usdcDecimals': _usdcDecimals,
      'isIntegerFormat': useIntegerFormat,
    };

    return result;
  }

  /// Calculate what buyer needs to pay (for UI display)
  double calculateBuyerTotalPayment(double grossTradeAmount) {
    final fees = calculateTradeFees(grossTradeAmount: grossTradeAmount);
    return fees['grossTradeAmount'] + fees['platformFeeBuyer'];
  }

  /// Calculate what seller will receive after fees (for UI display)
  double calculateSellerNetReceived(double grossTradeAmount) {
    final fees = calculateTradeFees(grossTradeAmount: grossTradeAmount);
    return fees['netToBuyer'];
  }

  /// Calculate what seller must lock in escrow
  double calculateSellerEscrowLock(double grossTradeAmount) {
    final fees = calculateTradeFees(grossTradeAmount: grossTradeAmount);
    return fees['requiredLockFromSeller'];
  }

  /// Generate escrow settlement parameters for smart contract
  Map<String, dynamic> generateEscrowSettlementParams({
    required double grossTradeAmount,
    required String buyerAddress,
    required String sellerAddress,
    required String feeWalletAddress,
  }) {
    final fees = calculateTradeFees(
      grossTradeAmount: grossTradeAmount,
      useIntegerFormat: true,
    );

    return {
      'grossTradeAmountWei': fees['grossTradeAmount'],
      'sellerLockAmountWei': fees['requiredLockFromSeller'],
      'buyerReceiveAmountWei': fees['netToBuyer'],
      'platformFeeAmountWei': fees['platformFeeTotal'],
      'buyerAddress': buyerAddress,
      'sellerAddress': sellerAddress,
      'feeWalletAddress': feeWalletAddress,
      'tokenDecimals': _usdcDecimals,
      'settlement': {
        'onRelease': {
          'toBuyer': fees['netToBuyer'],
          'toPlatform': fees['platformFeeTotal'],
          'description':
              'On successful OTP/release: Buyer receives ${_formatFromInteger(fees['netToBuyer'])} USDC, Platform receives ${_formatFromInteger(fees['platformFeeTotal'])} USDC',
        },
        'onRefund': {
          'toSeller': fees['requiredLockFromSeller'],
          'toPlatform': 0,
          'description':
              'On cancel/refund: Seller receives full locked amount ${_formatFromInteger(fees['requiredLockFromSeller'])} USDC, no fees deducted',
        },
      },
    };
  }

  /// Validate trade parameters against acceptance criteria
  Map<String, dynamic> validateTradeParameters({
    required double grossTradeAmount,
    required String userRole, // 'buyer' or 'seller'
  }) {
    final List<String> validationErrors = [];
    final List<String> validationWarnings = [];

    // Basic validation
    if (grossTradeAmount <= 0) {
      validationErrors.add('Trade amount must be greater than 0');
    }

    if (!['buyer', 'seller'].contains(userRole.toLowerCase())) {
      validationErrors.add('User role must be either "buyer" or "seller"');
    }

    if (grossTradeAmount < 1) {
      validationWarnings.add(
        'Trade amount below \$1 may have rounding precision issues',
      );
    }

    if (grossTradeAmount > 1000000) {
      validationWarnings.add(
        'Large trade amounts may require special handling',
      );
    }

    final fees = calculateTradeFees(grossTradeAmount: grossTradeAmount);

    // Acceptance criteria validation
    final bool buyerReceivesCorrectAmount =
        _roundToUsdcDecimals(fees['netToBuyer']) ==
        _roundToUsdcDecimals(grossTradeAmount * 0.99);

    final bool platformCollectsCorrectFee =
        _roundToUsdcDecimals(fees['platformFeeTotal']) ==
        _roundToUsdcDecimals(grossTradeAmount * 0.02);

    if (!buyerReceivesCorrectAmount) {
      validationErrors.add(
        'Buyer amount calculation does not match 0.99*G requirement',
      );
    }

    if (!platformCollectsCorrectFee) {
      validationErrors.add(
        'Platform fee calculation does not match 0.02*G requirement',
      );
    }

    return {
      'isValid': validationErrors.isEmpty,
      'errors': validationErrors,
      'warnings': validationWarnings,
      'acceptanceCriteria': {
        'buyerReceives99Percent': buyerReceivesCorrectAmount,
        'platformCollects2Percent': platformCollectsCorrectFee,
        'bothPartiesCharged1Percent':
            fees['buyerFeePct'] == 0.01 && fees['sellerFeePct'] == 0.01,
        'refundReturns100Percent': true, // Always true by design
        'uses6DecimalIntegers': fees['usdcDecimals'] == 6,
      },
      'calculatedFees': fees,
    };
  }

  /// Generate example calculation for documentation/UI
  Map<String, dynamic> generateExampleCalculation(double exampleAmount) {
    final fees = calculateTradeFees(grossTradeAmount: exampleAmount);

    return {
      'example': 'If G = \$${exampleAmount.toStringAsFixed(2)}:',
      'steps': [
        'Seller locks = \$${fees['requiredLockFromSeller'].toStringAsFixed(2)} (${exampleAmount.toStringAsFixed(2)} * 1.01)',
        'Buyer receives = \$${fees['netToBuyer'].toStringAsFixed(2)} (${exampleAmount.toStringAsFixed(2)} * 0.99)',
        'Platform keeps = \$${fees['platformFeeTotal'].toStringAsFixed(2)} (${fees['platformFeeBuyer'].toStringAsFixed(2)} from Buyer + ${fees['platformFeeSeller'].toStringAsFixed(2)} from Seller)',
      ],
      'formulas': {
        'RequiredLockFromSeller':
            'G * (1 + fS) = ${exampleAmount} * 1.01 = ${fees['requiredLockFromSeller'].toStringAsFixed(2)}',
        'NetToBuyer':
            'G * (1 - fB) = ${exampleAmount} * 0.99 = ${fees['netToBuyer'].toStringAsFixed(2)}',
        'PlatformFeeBuyer':
            'G * fB = ${exampleAmount} * 0.01 = ${fees['platformFeeBuyer'].toStringAsFixed(2)}',
        'PlatformFeeSeller':
            'G * fS = ${exampleAmount} * 0.01 = ${fees['platformFeeSeller'].toStringAsFixed(2)}',
        'PlatformFeeTotal':
            'PlatformFeeBuyer + PlatformFeeSeller = ${fees['platformFeeTotal'].toStringAsFixed(2)}',
      },
    };
  }

  /// Convert USDC amount to 6-decimal integer (for smart contracts)
  int _toUsdcInteger(double amount) {
    return (amount * pow(10, _usdcDecimals)).round();
  }

  /// Convert 6-decimal integer back to USDC amount
  double _formatFromInteger(int amountWei) {
    return amountWei / pow(10, _usdcDecimals);
  }

  /// Round to USDC precision (6 decimals)
  double _roundToUsdcDecimals(double amount) {
    return double.parse(amount.toStringAsFixed(_usdcDecimals));
  }

  /// Get fee wallet address from platform settings
  Future<String?> getFeeWalletAddress() async {
    return await PlatformSettingsService.instance
        .getPlatformFeesWalletAddress();
  }

  /// Check if platform fees are enabled
  Future<bool> areFeesEnabled() async {
    return await PlatformSettingsService.instance.arePlatformFeesEnabled();
  }

  /// Get minimum trade amount for fee application
  Future<double> getMinTradeAmount() async {
    return await PlatformSettingsService.instance.getMinTradeAmount();
  }

  /// Validate platform configuration for trade fees
  Future<Map<String, dynamic>> validatePlatformConfiguration() async {
    final config =
        await PlatformSettingsService.instance.validatePlatformConfiguration();
    final feeWallet = await getFeeWalletAddress();

    return {
      ...config,
      'tradeFeeLogicReady': config['isValid'] && feeWallet != null,
      'recommendedFeeWallet': feeWallet,
      'feePercentages': {
        'buyer': _buyerFeePct * 100,
        'seller': _sellerFeePct * 100,
        'total': (_buyerFeePct + _sellerFeePct) * 100,
      },
    };
  }

  /// Debug method to verify calculations match requirements exactly
  Map<String, dynamic> debugCalculations(double grossTradeAmount) {
    if (kDebugMode) {
      final fees = calculateTradeFees(grossTradeAmount: grossTradeAmount);
      final validation = validateTradeParameters(
        grossTradeAmount: grossTradeAmount,
        userRole: 'buyer',
      );
      final example = generateExampleCalculation(grossTradeAmount);

      return {
        'input': grossTradeAmount,
        'fees': fees,
        'validation': validation,
        'example': example,
        'escrowParams': generateEscrowSettlementParams(
          grossTradeAmount: grossTradeAmount,
          buyerAddress: '0xBuyer123...',
          sellerAddress: '0xSeller456...',
          feeWalletAddress: '0xPlatform789...',
        ),
      };
    }

    return {'debug': 'Only available in debug mode'};
  }
}
