import 'package:flutter/foundation.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import '../../services/supabase_service.dart';

/// Enhanced Authentication service with complete Supabase Auth integration
class AuthService {
  static AuthService? _instance;
  static AuthService get instance => _instance ??= AuthService._();

  AuthService._();

  SupabaseClient get _client => SupabaseService.instance.client;

  /// Sign up user with auto-generated UUID and comprehensive profile creation
  Future<Map<String, dynamic>> signUp({
    required String email,
    required String password,
    required String fullName,
    String? profileName,
    Map<String, dynamic>? metadata,
  }) async {
    try {
      // Sign up with Supabase Auth
      final response = await _client.auth.signUp(
        email: email,
        password: password,
        data: {
          'full_name': fullName,
          'profile_name': profileName ?? fullName,
          'display_name': profileName ?? fullName,
          ...?metadata,
        },
      );

      if (response.user != null) {
        // Wait for user profile creation (handled by database trigger)
        await Future.delayed(const Duration(milliseconds: 500));

        if (kDebugMode) {
          print('✅ User signed up successfully: ${response.user!.id}');
          print('📧 Email: ${response.user!.email}');
        }

        return {
          'success': true,
          'user_id': response.user!.id,
          'email': response.user!.email,
          'requires_verification': response.user!.emailConfirmedAt == null,
          'message': response.user!.emailConfirmedAt != null
              ? 'Account created successfully'
              : 'Please check your email to verify your account',
          'user': response.user,
          'session': response.session,
        };
      } else {
        throw Exception('Sign up failed: User creation returned null');
      }
    } catch (e) {
      if (kDebugMode) {
        print('❌ Auth sign up failed: $e');
      }
      return {
        'success': false,
        'error_code': _getErrorCode(e.toString()),
        'message': _parseAuthError(e.toString()),
      };
    }
  }

  /// Sign in user with email and password
  Future<Map<String, dynamic>> signIn({
    required String email,
    required String password,
  }) async {
    try {
      final response = await _client.auth.signInWithPassword(
        email: email,
        password: password,
      );

      if (response.user != null && response.session != null) {
        // Get user profile after sign in
        final profile = await getCurrentUserProfile();

        if (kDebugMode) {
          print('✅ User signed in successfully: ${response.user!.id}');
          print('👤 Profile: ${profile?['display_name'] ?? 'No profile'}');
        }

        return {
          'success': true,
          'user_id': response.user!.id,
          'email': response.user!.email,
          'message': 'Signed in successfully',
          'user': response.user,
          'session': response.session,
          'profile': profile,
        };
      } else {
        throw Exception('Sign in failed: Invalid credentials');
      }
    } catch (e) {
      if (kDebugMode) {
        print('❌ Auth sign in failed: $e');
      }
      return {
        'success': false,
        'error_code': _getErrorCode(e.toString()),
        'message': _parseAuthError(e.toString()),
      };
    }
  }

  /// Sign in with OAuth providers (Google, Apple, etc.)
  Future<Map<String, dynamic>> signInWithOAuth({
    required OAuthProvider provider,
    String? redirectTo,
  }) async {
    try {
      final result = await _client.auth.signInWithOAuth(
        provider,
        redirectTo: redirectTo,
      );

      return {
        'success': result,
        'message': result ? 'OAuth sign-in initiated' : 'OAuth sign-in failed',
      };
    } catch (e) {
      if (kDebugMode) {
        print('❌ OAuth sign in failed: $e');
      }
      return {
        'success': false,
        'error_code': _getErrorCode(e.toString()),
        'message': _parseAuthError(e.toString()),
      };
    }
  }

  /// Sign out current user with cleanup
  Future<Map<String, dynamic>> signOut() async {
    try {
      await _client.auth.signOut();

      if (kDebugMode) {
        print('✅ User signed out successfully');
      }

      return {'success': true, 'message': 'Signed out successfully'};
    } catch (e) {
      if (kDebugMode) {
        print('❌ Auth sign out failed: $e');
      }
      return {
        'success': false,
        'error_code': _getErrorCode(e.toString()),
        'message': 'Sign out failed: $e',
      };
    }
  }

  /// Get current authenticated user
  User? get currentUser => _client.auth.currentUser;

  /// Check if user is authenticated
  bool get isAuthenticated => _client.auth.currentUser != null;

  /// Get current session
  Session? get currentSession => _client.auth.currentSession;

  /// Get current user's profile from database with comprehensive data
  Future<Map<String, dynamic>?> getCurrentUserProfile() async {
    try {
      final user = currentUser;
      if (user == null) return null;

      final response = await _client
          .from('users')
          .select('*')
          .eq('id', user.id)
          .maybeSingle();

      if (response != null && kDebugMode) {
        print('✅ User profile fetched: ${response['username']}');
      }

      return response;
    } catch (e) {
      if (kDebugMode) {
        print('❌ Error fetching user profile: $e');
      }
      return null;
    }
  }

  /// Update user profile with comprehensive data handling
  Future<Map<String, dynamic>> updateProfile({
    String? username,
    String? role,
    Map<String, dynamic>? additionalData,
  }) async {
    try {
      final user = currentUser;
      if (user == null) {
        throw Exception('User not authenticated');
      }

      // Prepare update data
      final profileData = <String, dynamic>{};

      if (username != null) profileData['username'] = username;
      if (role != null) profileData['role'] = role;
      if (additionalData != null) profileData.addAll(additionalData);

      // Update users table
      final response = await _client
          .from('users')
          .update(profileData)
          .eq('id', user.id)
          .select()
          .single();

      if (kDebugMode) {
        print('✅ User profile updated successfully');
      }

      return {
        'success': true,
        'message': 'Profile updated successfully',
        'profile': response,
      };
    } catch (e) {
      if (kDebugMode) {
        print('❌ Error updating user profile: $e');
      }
      return {
        'success': false,
        'error_code': _getErrorCode(e.toString()),
        'message': 'Failed to update profile: ${_parseAuthError(e.toString())}',
      };
    }
  }

  /// Reset password via email
  Future<Map<String, dynamic>> resetPassword({
    required String email,
    String? redirectTo,
  }) async {
    try {
      await _client.auth.resetPasswordForEmail(email, redirectTo: redirectTo);

      return {
        'success': true,
        'message': 'Password reset email sent successfully',
      };
    } catch (e) {
      if (kDebugMode) {
        print('❌ Password reset failed: $e');
      }
      return {
        'success': false,
        'error_code': _getErrorCode(e.toString()),
        'message': _parseAuthError(e.toString()),
      };
    }
  }

  /// Update password for authenticated user
  Future<Map<String, dynamic>> updatePassword({
    required String newPassword,
  }) async {
    try {
      await _client.auth.updateUser(UserAttributes(password: newPassword));

      return {'success': true, 'message': 'Password updated successfully'};
    } catch (e) {
      if (kDebugMode) {
        print('❌ Password update failed: $e');
      }
      return {
        'success': false,
        'error_code': _getErrorCode(e.toString()),
        'message': _parseAuthError(e.toString()),
      };
    }
  }

  /// Resend email confirmation
  Future<Map<String, dynamic>> resendConfirmation({
    required String email,
  }) async {
    try {
      await _client.auth.resend(type: OtpType.signup, email: email);

      return {'success': true, 'message': 'Confirmation email sent'};
    } catch (e) {
      if (kDebugMode) {
        print('❌ Resend confirmation failed: $e');
      }
      return {
        'success': false,
        'error_code': _getErrorCode(e.toString()),
        'message': _parseAuthError(e.toString()),
      };
    }
  }

  /// Listen for auth state changes
  Stream<AuthState> get authStateChanges => _client.auth.onAuthStateChange;

  /// Check if current user has specific role
  Future<bool> hasRole(String role) async {
    try {
      final profile = await getCurrentUserProfile();
      return profile?['role']?.toString().toLowerCase() == role.toLowerCase();
    } catch (e) {
      if (kDebugMode) {
        print('❌ Error checking user role: $e');
      }
      return false;
    }
  }

  /// Check if current user is admin
  Future<bool> isCurrentUserAdmin() async {
    return await hasRole('admin');
  }

  /// Check if current user is verified
  Future<bool> isCurrentUserVerified() async {
    try {
      final profile = await getCurrentUserProfile();
      // Since the users table doesn't have is_verified, return true for now
      return profile != null;
    } catch (e) {
      if (kDebugMode) {
        print('❌ Error checking verification status: $e');
      }
      return false;
    }
  }

  /// Get user display name
  Future<String> getUserDisplayName(String userId) async {
    try {
      final response = await _client
          .from('users')
          .select('username')
          .eq('id', userId)
          .maybeSingle();

      return response?['username'] ?? 'Unknown User';
    } catch (e) {
      if (kDebugMode) {
        print('❌ Error fetching user display name: $e');
      }
      return 'Unknown User';
    }
  }

  /// Get UUID-to-profile name mapping for multiple users
  Future<Map<String, String>> getUserNameMapping(List<String> userIds) async {
    try {
      final response = await _client
          .from('users')
          .select('id, username')
          .inFilter('id', userIds);

      final mapping = <String, String>{};
      for (final profile in response) {
        mapping[profile['id']] = profile['username'] ?? 'Unknown User';
      }

      return mapping;
    } catch (e) {
      if (kDebugMode) {
        print('❌ Error fetching user name mapping: $e');
      }
      return {};
    }
  }

  /// Update last seen timestamp
  Future<void> updateLastSeen() async {
    try {
      final user = currentUser;
      if (user == null) return;

      // Since users table doesn't have last_seen_at, we'll skip this for now
      if (kDebugMode) {
        print(
            'ℹ️ Last seen update skipped - column not available in users table');
      }
    } catch (e) {
      if (kDebugMode) {
        print('❌ Error updating last seen: $e');
      }
    }
  }

  /// Parse and format auth error messages
  String _parseAuthError(String error) {
    if (error.contains('Invalid login credentials')) {
      return 'Invalid email or password';
    } else if (error.contains('Email not confirmed')) {
      return 'Please verify your email address';
    } else if (error.contains('User already registered')) {
      return 'An account with this email already exists';
    } else if (error.contains('Password should be at least')) {
      return 'Password should be at least 6 characters';
    } else if (error.contains('Unable to validate email address')) {
      return 'Invalid email address format';
    } else if (error.contains('Password is too weak')) {
      return 'Password is too weak. Please choose a stronger password';
    } else if (error.contains('Network error') ||
        error.contains('Failed host lookup')) {
      return 'Network error. Please check your connection';
    } else if (error.contains('signup_disabled')) {
      return 'Account registration is currently disabled';
    } else if (error.contains('email_address_invalid')) {
      return 'Please enter a valid email address';
    } else if (error.contains('password_too_short')) {
      return 'Password must be at least 6 characters long';
    }
    return 'Authentication failed. Please try again';
  }

  /// Get error code for programmatic handling
  String _getErrorCode(String error) {
    if (error.contains('Invalid login credentials'))
      return 'invalid_credentials';
    if (error.contains('Email not confirmed')) return 'email_not_confirmed';
    if (error.contains('User already registered')) return 'user_exists';
    if (error.contains('Network error')) return 'network_error';
    if (error.contains('signup_disabled')) return 'signup_disabled';
    if (error.contains('email_address_invalid')) return 'invalid_email';
    if (error.contains('password_too_short')) return 'password_too_short';
    return 'unknown_error';
  }

  /// Dispose resources
  void dispose() {
    // Cleanup if needed
  }
}
