import 'dart:async';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:flutter_webrtc/flutter_webrtc.dart';
import 'package:permission_handler/permission_handler.dart';

enum CallState {
  idle,
  calling,
  receiving,
  connecting,
  connected,
  ended,
  failed,
}

class CallService {
  static final CallService _instance = CallService._internal();
  factory CallService() => _instance;
  CallService._internal();

  final SupabaseClient _supabase = Supabase.instance.client;

  // WebRTC components
  RTCPeerConnection? _peerConnection;
  MediaStream? _localStream;
  MediaStream? _remoteStream;

  // Call state management
  CallState _callState = CallState.idle;
  String? _currentCallId;
  String? _currentRoomId;
  String? _remoteUserId;
  bool _isCaller = false;

  // Real-time subscription
  RealtimeChannel? _signalingChannel;

  // Stream controllers
  final StreamController<CallState> _callStateController =
      StreamController<CallState>.broadcast();
  final StreamController<MediaStream?> _remoteStreamController =
      StreamController<MediaStream?>.broadcast();
  final StreamController<MediaStream?> _localStreamController =
      StreamController<MediaStream?>.broadcast();

  // Getters
  CallState get callState => _callState;
  String? get currentCallId => _currentCallId;
  String? get currentRoomId => _currentRoomId;
  bool get isCaller => _isCaller;

  // Streams
  Stream<CallState> get callStateStream => _callStateController.stream;
  Stream<MediaStream?> get remoteStream => _remoteStreamController.stream;
  Stream<MediaStream?> get localStream => _localStreamController.stream;

  // WebRTC configuration
  final Map<String, dynamic> _rtcConfiguration = {
    'iceServers': [
      {'urls': 'stun:stun.l.google.com:19302'},
      {'urls': 'stun:stun1.l.google.com:19302'},
    ],
    'sdpSemantics': 'unified-plan',
  };

  // Initialize call service
  Future<void> initialize() async {
    await _requestPermissions();
    await _setupWebRTC();
  }

  // Request necessary permissions
  Future<void> _requestPermissions() async {
    final permissions = [Permission.microphone, Permission.camera];

    Map<Permission, PermissionStatus> statuses = await permissions.request();

    for (Permission permission in permissions) {
      if (statuses[permission] != PermissionStatus.granted) {
        print('Permission ${permission.toString()} not granted');
      }
    }
  }

  // Setup WebRTC peer connection
  Future<void> _setupWebRTC() async {
    try {
      _peerConnection = await createPeerConnection(_rtcConfiguration);

      _peerConnection!.onIceCandidate = (RTCIceCandidate candidate) {
        _sendSignalingData('ice-candidate', {
          'candidate': candidate.candidate,
          'sdpMLineIndex': candidate.sdpMLineIndex,
          'sdpMid': candidate.sdpMid,
        });
      };

      _peerConnection!.onAddStream = (MediaStream stream) {
        _remoteStream = stream;
        _remoteStreamController.add(stream);
      };

      _peerConnection!.onConnectionState = (RTCPeerConnectionState state) {
        print('Connection state: $state');
        if (state == RTCPeerConnectionState.RTCPeerConnectionStateConnected) {
          _updateCallState(CallState.connected);
          _updateCallStatus('active');
        } else if (state ==
            RTCPeerConnectionState.RTCPeerConnectionStateFailed) {
          _handleCallFailure('Connection failed');
        }
      };
    } catch (e) {
      print('Error setting up WebRTC: $e');
      _handleCallFailure('WebRTC setup failed');
    }
  }

  // Initiate a call
  Future<bool> initiateCall(String calleeId, {bool isVideo = false}) async {
    try {
      if (_callState != CallState.idle) {
        throw Exception('Already in a call');
      }

      _updateCallState(CallState.calling);
      _isCaller = true;
      _remoteUserId = calleeId;

      // Create call in database
      final response = await _supabase.rpc('initiate_call', {
        'p_callee_id': calleeId,
        'p_call_type': isVideo ? 'video' : 'voice',
      });

      _currentCallId = response as String?;

      if (_currentCallId == null) {
        throw Exception('Failed to create call');
      }

      // Get room ID
      final callData =
          await _supabase
              .from('calls')
              .select('room_id')
              .eq('id', _currentCallId!)
              .single();

      _currentRoomId = callData['room_id'];

      // Setup local stream
      await _setupLocalStream(isVideo);

      // Setup signaling channel
      await _setupSignalingChannel();

      // Create offer
      await _createOffer();

      return true;
    } catch (e) {
      print('Error initiating call: $e');
      _handleCallFailure('Failed to initiate call');
      return false;
    }
  }

  // Answer an incoming call
  Future<bool> answerCall(String callId, {bool withVideo = false}) async {
    try {
      _currentCallId = callId;
      _isCaller = false;
      _updateCallState(CallState.connecting);

      // Get call details
      final callData =
          await _supabase
              .from('calls')
              .select('room_id, caller_id')
              .eq('id', callId)
              .single();

      _currentRoomId = callData['room_id'];
      _remoteUserId = callData['caller_id'];

      // Setup local stream
      await _setupLocalStream(withVideo);

      // Setup signaling channel
      await _setupSignalingChannel();

      // Update call status to active
      await _updateCallStatus('active');

      return true;
    } catch (e) {
      print('Error answering call: $e');
      _handleCallFailure('Failed to answer call');
      return false;
    }
  }

  // End current call
  Future<void> endCall() async {
    try {
      if (_currentCallId != null) {
        await _updateCallStatus('ended');
        await _sendSignalingData('end-call', {});
      }

      await _cleanup();
    } catch (e) {
      print('Error ending call: $e');
    }
  }

  // Decline incoming call
  Future<void> declineCall(String callId) async {
    try {
      await _supabase.rpc('update_call_status', {
        'p_call_id': callId,
        'p_status': 'declined',
      });
    } catch (e) {
      print('Error declining call: $e');
    }
  }

  // Setup local media stream
  Future<void> _setupLocalStream(bool withVideo) async {
    try {
      _localStream = await navigator.mediaDevices.getUserMedia({
        'audio': true,
        'video': withVideo,
      });

      if (_peerConnection != null && _localStream != null) {
        await _peerConnection!.addStream(_localStream!);
        _localStreamController.add(_localStream);
      }
    } catch (e) {
      print('Error setting up local stream: $e');
      _handleCallFailure('Media access failed');
    }
  }

  // Create WebRTC offer
  Future<void> _createOffer() async {
    try {
      RTCSessionDescription offer = await _peerConnection!.createOffer();
      await _peerConnection!.setLocalDescription(offer);

      await _sendSignalingData('offer', {'type': offer.type, 'sdp': offer.sdp});

      await _updateCallStatus('ringing');
    } catch (e) {
      print('Error creating offer: $e');
      _handleCallFailure('Failed to create offer');
    }
  }

  // Create WebRTC answer
  Future<void> _createAnswer(Map<String, dynamic> offer) async {
    try {
      await _peerConnection!.setRemoteDescription(
        RTCSessionDescription(offer['sdp'], offer['type']),
      );

      RTCSessionDescription answer = await _peerConnection!.createAnswer();
      await _peerConnection!.setLocalDescription(answer);

      await _sendSignalingData('answer', {
        'type': answer.type,
        'sdp': answer.sdp,
      });
    } catch (e) {
      print('Error creating answer: $e');
      _handleCallFailure('Failed to create answer');
    }
  }

  // Handle received answer
  Future<void> _handleAnswer(Map<String, dynamic> answer) async {
    try {
      await _peerConnection!.setRemoteDescription(
        RTCSessionDescription(answer['sdp'], answer['type']),
      );
    } catch (e) {
      print('Error handling answer: $e');
      _handleCallFailure('Failed to handle answer');
    }
  }

  // Handle ICE candidate
  Future<void> _handleIceCandidate(Map<String, dynamic> candidate) async {
    try {
      await _peerConnection!.addCandidate(
        RTCIceCandidate(
          candidate['candidate'],
          candidate['sdpMid'],
          candidate['sdpMLineIndex'],
        ),
      );
    } catch (e) {
      print('Error handling ICE candidate: $e');
    }
  }

  // Send signaling data
  Future<void> _sendSignalingData(
    String type,
    Map<String, dynamic> data,
  ) async {
    if (_currentCallId == null) return;

    try {
      await _supabase.rpc('add_signaling_data', {
        'p_call_id': _currentCallId,
        'p_signal_type': type,
        'p_signal_data': data,
      });
    } catch (e) {
      print('Error sending signaling data: $e');
    }
  }

  // Setup real-time signaling channel
  Future<void> _setupSignalingChannel() async {
    if (_currentRoomId == null) return;

    _signalingChannel =
        _supabase
            .channel('call_signaling:$_currentRoomId')
            .onPostgresChanges(
              event: PostgresChangeEvent.insert,
              schema: 'public',
              table: 'call_signaling',
              callback: (payload) async {
                final data = payload.newRecord;
                final signalType = data['signal_type'];
                final signalData = data['signal_data'] as Map<String, dynamic>;
                final senderId = data['sender_id'];

                // Don't process our own signals
                if (senderId == _supabase.auth.currentUser?.id) return;

                switch (signalType) {
                  case 'offer':
                    await _createAnswer(signalData);
                    break;
                  case 'answer':
                    await _handleAnswer(signalData);
                    break;
                  case 'ice-candidate':
                    await _handleIceCandidate(signalData);
                    break;
                  case 'end-call':
                    await _cleanup();
                    break;
                }
              },
            )
            .subscribe();
  }

  // Update call status in database
  Future<void> _updateCallStatus(String status) async {
    if (_currentCallId == null) return;

    try {
      await _supabase.rpc('update_call_status', {
        'p_call_id': _currentCallId,
        'p_status': status,
      });
    } catch (e) {
      print('Error updating call status: $e');
    }
  }

  // Update call state
  void _updateCallState(CallState newState) {
    _callState = newState;
    _callStateController.add(newState);
  }

  // Handle call failure
  Future<void> _handleCallFailure(String reason) async {
    print('Call failed: $reason');

    if (_currentCallId != null) {
      await _supabase.rpc('update_call_status', {
        'p_call_id': _currentCallId,
        'p_status': 'failed',
        'p_failure_reason': reason,
      });
    }

    _updateCallState(CallState.failed);
    await _cleanup();
  }

  // Get active calls for current user
  Future<List<Map<String, dynamic>>> getActiveCalls() async {
    try {
      final response = await _supabase.rpc('get_user_active_calls');
      return List<Map<String, dynamic>>.from(response);
    } catch (e) {
      print('Error getting active calls: $e');
      return [];
    }
  }

  // Listen for incoming calls
  Stream<Map<String, dynamic>> listenForIncomingCalls() {
    final controller = StreamController<Map<String, dynamic>>();

    final subscription =
        _supabase
            .channel('incoming_calls')
            .onPostgresChanges(
              event: PostgresChangeEvent.insert,
              schema: 'public',
              table: 'calls',
              filter: PostgresChangeFilter(
                type: PostgresChangeFilterType.eq,
                column: 'callee_id',
                value: _supabase.auth.currentUser?.id,
              ),
              callback: (payload) {
                final callData = payload.newRecord;
                if (callData['call_status'] == 'initiating') {
                  _updateCallState(CallState.receiving);
                  controller.add(callData);
                }
              },
            )
            .subscribe();

    controller.onCancel = () {
      subscription.unsubscribe();
    };

    return controller.stream;
  }

  // Toggle mute
  Future<void> toggleMute() async {
    if (_localStream != null) {
      final audioTracks = _localStream!.getAudioTracks();
      if (audioTracks.isNotEmpty) {
        audioTracks.first.enabled = !audioTracks.first.enabled;
      }
    }
  }

  // Toggle video
  Future<void> toggleVideo() async {
    if (_localStream != null) {
      final videoTracks = _localStream!.getVideoTracks();
      if (videoTracks.isNotEmpty) {
        videoTracks.first.enabled = !videoTracks.first.enabled;
      }
    }
  }

  // Switch camera
  Future<void> switchCamera() async {
    if (_localStream != null) {
      final videoTracks = _localStream!.getVideoTracks();
      if (videoTracks.isNotEmpty) {
        await Helper.switchCamera(videoTracks.first);
      }
    }
  }

  // Cleanup resources
  Future<void> _cleanup() async {
    _updateCallState(CallState.ended);

    // Close peer connection
    await _peerConnection?.close();
    _peerConnection = null;

    // Stop local stream
    _localStream?.getTracks().forEach((track) => track.stop());
    _localStream = null;

    // Clear remote stream
    _remoteStream = null;
    _remoteStreamController.add(null);
    _localStreamController.add(null);

    // Unsubscribe from signaling channel
    await _signalingChannel?.unsubscribe();
    _signalingChannel = null;

    // Reset state
    _currentCallId = null;
    _currentRoomId = null;
    _remoteUserId = null;
    _isCaller = false;

    // Reinitialize WebRTC for next call
    await _setupWebRTC();

    Future.delayed(const Duration(seconds: 2), () {
      _updateCallState(CallState.idle);
    });
  }

  // Dispose service
  void dispose() {
    _cleanup();
    _callStateController.close();
    _remoteStreamController.close();
    _localStreamController.close();
  }
}
