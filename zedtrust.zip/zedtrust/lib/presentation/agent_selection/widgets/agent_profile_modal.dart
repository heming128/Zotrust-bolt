import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';

class AgentProfileModal extends StatelessWidget {
  final Map<String, dynamic> agent;
  final VoidCallback onSelectAgent;
  final VoidCallback onMessageAgent;

  const AgentProfileModal({
    Key? key,
    required this.agent,
    required this.onSelectAgent,
    required this.onMessageAgent,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final double rating = (agent['rating'] as num?)?.toDouble() ?? 0.0;
    final int completedTrades = agent['completedTrades'] as int? ?? 0;
    final String responseTime = agent['responseTime'] as String? ?? '';
    final List<dynamic> paymentMethods =
        agent['paymentMethods'] as List<dynamic>? ?? [];
    final List<dynamic> recentReviews =
        agent['recentReviews'] as List<dynamic>? ?? [];
    final Map<String, dynamic> ratingBreakdown =
        agent['ratingBreakdown'] as Map<String, dynamic>? ?? {};

    return Container(
      height: 85.h,
      decoration: BoxDecoration(
        color: AppTheme.lightTheme.scaffoldBackgroundColor,
        borderRadius: const BorderRadius.vertical(top: Radius.circular(20)),
      ),
      child: Column(
        children: [
          // Handle Bar
          Container(
            margin: EdgeInsets.only(top: 1.h),
            width: 12.w,
            height: 4,
            decoration: BoxDecoration(
              color: AppTheme.lightTheme.colorScheme.outline,
              borderRadius: BorderRadius.circular(2),
            ),
          ),

          // Header
          Padding(
            padding: EdgeInsets.all(4.w),
            child: Row(
              children: [
                Text(
                  'Agent Profile',
                  style: AppTheme.lightTheme.textTheme.headlineSmall?.copyWith(
                    fontWeight: FontWeight.w600,
                  ),
                ),
                const Spacer(),
                IconButton(
                  onPressed: () => Navigator.pop(context),
                  icon: CustomIconWidget(
                    iconName: 'close',
                    color: AppTheme.lightTheme.colorScheme.onSurface,
                    size: 24,
                  ),
                ),
              ],
            ),
          ),

          Expanded(
            child: SingleChildScrollView(
              padding: EdgeInsets.symmetric(horizontal: 4.w),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Agent Header Info
                  Row(
                    children: [
                      Container(
                        width: 20.w,
                        height: 20.w,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color:
                              AppTheme.lightTheme.colorScheme.primaryContainer,
                        ),
                        child: CustomImageWidget(
                          imageUrl: agent['avatar'] as String? ?? '',
                          width: 20.w,
                          height: 20.w,
                          fit: BoxFit.cover,
                        ),
                      ),
                      SizedBox(width: 4.w),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              agent['nickname'] as String? ?? 'Unknown Agent',
                              style: AppTheme.lightTheme.textTheme.headlineSmall
                                  ?.copyWith(
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                            SizedBox(height: 1.h),
                            Row(
                              children: [
                                Container(
                                  width: 8,
                                  height: 8,
                                  decoration: BoxDecoration(
                                    shape: BoxShape.circle,
                                    color: (agent['isOnline'] as bool? ?? false)
                                        ? AppTheme.getSuccessColor(true)
                                        : AppTheme.getNeutralColor(true),
                                  ),
                                ),
                                SizedBox(width: 2.w),
                                Text(
                                  (agent['isOnline'] as bool? ?? false)
                                      ? 'Online'
                                      : 'Offline',
                                  style: AppTheme
                                      .lightTheme.textTheme.bodyMedium
                                      ?.copyWith(
                                    color: (agent['isOnline'] as bool? ?? false)
                                        ? AppTheme.getSuccessColor(true)
                                        : AppTheme.lightTheme.colorScheme
                                            .onSurfaceVariant,
                                  ),
                                ),
                              ],
                            ),
                            SizedBox(height: 0.5.h),
                            Text(
                              '$completedTrades completed trades',
                              style: AppTheme.lightTheme.textTheme.bodyMedium
                                  ?.copyWith(
                                color: AppTheme
                                    .lightTheme.colorScheme.onSurfaceVariant,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),

                  SizedBox(height: 3.h),

                  // Rating Overview
                  _buildSectionTitle('Rating Overview'),
                  SizedBox(height: 1.h),
                  Row(
                    children: [
                      Text(
                        rating.toStringAsFixed(1),
                        style: AppTheme.lightTheme.textTheme.displaySmall
                            ?.copyWith(
                          fontWeight: FontWeight.w700,
                          color: AppTheme.lightTheme.primaryColor,
                        ),
                      ),
                      SizedBox(width: 3.w),
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: List.generate(5, (index) {
                              return CustomIconWidget(
                                iconName: index < rating.floor()
                                    ? 'star'
                                    : 'star_border',
                                color: index < rating.floor()
                                    ? AppTheme.getWarningColor(true)
                                    : AppTheme.getNeutralColor(true),
                                size: 20,
                              );
                            }),
                          ),
                          SizedBox(height: 0.5.h),
                          Text(
                            'Avg response: $responseTime',
                            style: AppTheme.lightTheme.textTheme.bodySmall,
                          ),
                        ],
                      ),
                    ],
                  ),

                  if (ratingBreakdown.isNotEmpty) ...[
                    SizedBox(height: 2.h),
                    _buildRatingBreakdown(ratingBreakdown),
                  ],

                  SizedBox(height: 3.h),

                  // Payment Methods
                  _buildSectionTitle('Supported Payment Methods'),
                  SizedBox(height: 1.h),
                  Wrap(
                    spacing: 2.w,
                    runSpacing: 1.h,
                    children: (paymentMethods).map((method) {
                      return Container(
                        padding: EdgeInsets.symmetric(
                            horizontal: 3.w, vertical: 1.h),
                        decoration: BoxDecoration(
                          color: AppTheme
                              .lightTheme.colorScheme.secondaryContainer,
                          borderRadius: BorderRadius.circular(12),
                          border: Border.all(
                            color: AppTheme.lightTheme.colorScheme.secondary
                                .withValues(alpha: 0.3),
                          ),
                        ),
                        child: Text(
                          method.toString(),
                          style: AppTheme.lightTheme.textTheme.bodyMedium
                              ?.copyWith(
                            color: AppTheme
                                .lightTheme.colorScheme.onSecondaryContainer,
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                      );
                    }).toList(),
                  ),

                  SizedBox(height: 3.h),

                  // Recent Reviews
                  if (recentReviews.isNotEmpty) ...[
                    _buildSectionTitle('Recent Reviews'),
                    SizedBox(height: 1.h),
                    ...recentReviews.take(3).map((review) {
                      return _buildReviewCard(review as Map<String, dynamic>);
                    }).toList(),
                  ],

                  SizedBox(height: 4.h),
                ],
              ),
            ),
          ),

          // Action Buttons
          Container(
            padding: EdgeInsets.all(4.w),
            decoration: BoxDecoration(
              color: AppTheme.lightTheme.scaffoldBackgroundColor,
              border: Border(
                top: BorderSide(
                  color: AppTheme.lightTheme.colorScheme.outline
                      .withValues(alpha: 0.2),
                ),
              ),
            ),
            child: Row(
              children: [
                Expanded(
                  child: OutlinedButton(
                    onPressed: onMessageAgent,
                    child: Text('Message'),
                  ),
                ),
                SizedBox(width: 3.w),
                Expanded(
                  flex: 2,
                  child: ElevatedButton(
                    onPressed: onSelectAgent,
                    child: Text('Select Agent'),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSectionTitle(String title) {
    return Text(
      title,
      style: AppTheme.lightTheme.textTheme.titleMedium?.copyWith(
        fontWeight: FontWeight.w600,
      ),
    );
  }

  Widget _buildRatingBreakdown(Map<String, dynamic> breakdown) {
    return Column(
      children: breakdown.entries.map((entry) {
        final int starCount =
            int.tryParse(entry.key.replaceAll(' stars', '')) ?? 0;
        final int count = entry.value as int? ?? 0;
        final double percentage =
            count / 100.0; // Assuming total of 100 for percentage

        return Padding(
          padding: EdgeInsets.symmetric(vertical: 0.5.h),
          child: Row(
            children: [
              Text(
                '$starCount',
                style: AppTheme.lightTheme.textTheme.bodySmall,
              ),
              SizedBox(width: 1.w),
              CustomIconWidget(
                iconName: 'star',
                color: AppTheme.getWarningColor(true),
                size: 14,
              ),
              SizedBox(width: 2.w),
              Expanded(
                child: LinearProgressIndicator(
                  value: percentage,
                  backgroundColor: AppTheme.lightTheme.colorScheme.outline
                      .withValues(alpha: 0.2),
                  valueColor: AlwaysStoppedAnimation<Color>(
                      AppTheme.getWarningColor(true)),
                ),
              ),
              SizedBox(width: 2.w),
              Text(
                '$count',
                style: AppTheme.lightTheme.textTheme.bodySmall,
              ),
            ],
          ),
        );
      }).toList(),
    );
  }

  Widget _buildReviewCard(Map<String, dynamic> review) {
    final double rating = (review['rating'] as num?)?.toDouble() ?? 0.0;
    final String comment = review['comment'] as String? ?? '';
    final String reviewer = review['reviewer'] as String? ?? 'Anonymous';
    final String date = review['date'] as String? ?? '';

    return Container(
      margin: EdgeInsets.only(bottom: 2.h),
      padding: EdgeInsets.all(3.w),
      decoration: BoxDecoration(
        color: AppTheme.lightTheme.cardColor,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: AppTheme.lightTheme.colorScheme.outline.withValues(alpha: 0.2),
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Row(
                children: List.generate(5, (index) {
                  return CustomIconWidget(
                    iconName: index < rating.floor() ? 'star' : 'star_border',
                    color: index < rating.floor()
                        ? AppTheme.getWarningColor(true)
                        : AppTheme.getNeutralColor(true),
                    size: 16,
                  );
                }),
              ),
              const Spacer(),
              Text(
                date,
                style: AppTheme.lightTheme.textTheme.bodySmall?.copyWith(
                  color: AppTheme.lightTheme.colorScheme.onSurfaceVariant,
                ),
              ),
            ],
          ),
          if (comment.isNotEmpty) ...[
            SizedBox(height: 1.h),
            Text(
              comment,
              style: AppTheme.lightTheme.textTheme.bodyMedium,
              maxLines: 3,
              overflow: TextOverflow.ellipsis,
            ),
          ],
          SizedBox(height: 1.h),
          Text(
            '- $reviewer',
            style: AppTheme.lightTheme.textTheme.bodySmall?.copyWith(
              fontStyle: FontStyle.italic,
              color: AppTheme.lightTheme.colorScheme.onSurfaceVariant,
            ),
          ),
        ],
      ),
    );
  }
}
