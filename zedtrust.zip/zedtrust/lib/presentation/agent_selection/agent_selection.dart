import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../core/app_export.dart';
import '../../core/services/supabase_service.dart';
import './widgets/agent_card_widget.dart';
import './widgets/agent_filter_bottom_sheet.dart';
import './widgets/agent_map_view_widget.dart';
import './widgets/agent_profile_modal.dart';
import './widgets/agent_quick_actions_modal.dart';
import './widgets/city_search_bottom_sheet.dart';

class AgentSelection extends StatefulWidget {
  const AgentSelection({Key? key}) : super(key: key);

  @override
  State<AgentSelection> createState() => _AgentSelectionState();
}

class _AgentSelectionState extends State<AgentSelection> {
  final TextEditingController _searchController = TextEditingController();
  final GlobalKey _mapKey = GlobalKey();
  final SupabaseService _supabaseService = SupabaseService.instance;

  bool _isMapView = false;
  bool _isLoading = false;
  String? _selectedAgentId;
  String? _selectedCity;
  String? _buyerCity;
  String? _sellerCity;

  Map<String, dynamic> _filters = {
    'distanceRadius': 50.0,
    'minimumRating': 0.0,
    'onlineOnly': false,
    'paymentMethods': <String>[],
  };

  List<Map<String, dynamic>> _allAgents = [];
  List<Map<String, dynamic>> _filteredAgents = [];

  @override
  void initState() {
    super.initState();
    _searchController.addListener(_onSearchChanged);

    // Get trade context from arguments
    WidgetsBinding.instance.addPostFrameCallback((_) {
      final args =
          ModalRoute.of(context)?.settings.arguments as Map<String, dynamic>?;
      if (args != null) {
        _buyerCity = args['buyerCity'] as String?;
        _sellerCity = args['sellerCity'] as String?;
        _selectedCity = _sellerCity; // Default to seller city
      }
      _loadVerifiedAgents();
    });
  }

  @override
  void dispose() {
    _searchController.removeListener(_onSearchChanged);
    _searchController.dispose();
    super.dispose();
  }

  Future<void> _loadVerifiedAgents() async {
    setState(() => _isLoading = true);

    try {
      final agents = await _supabaseService.getVerifiedAgents();

      // Transform Supabase data to match the UI expectations
      final transformedAgents =
          agents
              .map(
                (agent) => {
                  'id': agent['id'],
                  'name': agent['name'],
                  'alias': agent['alias'],
                  'nickname':
                      agent['alias'], // For compatibility with existing UI
                  'avatar':
                      'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&h=150&fit=crop&crop=face', // Default avatar
                  'isOnline': true, // Default to online for verified agents
                  'distance':
                      '${(5.0 + (agent['rating'] ?? 0) * 2).toStringAsFixed(1)} km', // Calculate based on rating
                  'city':
                      'Multiple Cities', // Since agents can have multiple locations
                  'state': 'Multiple States',
                  'rating': (agent['rating'] as num?)?.toDouble() ?? 0.0,
                  'completedTrades':
                      0, // Would need to be calculated from trades table
                  'responseTime':
                      '${(15 - (agent['rating'] ?? 0) * 2).round()} min',
                  'specializations': ['Cash Exchange', 'Bank Transfer'],
                  'paymentMethods': [
                    'Cash Exchange',
                    'Bank Transfer',
                    'Mobile Money',
                  ],
                  'agent_type': agent['agent_type'] ?? 'hawala',
                  'mobile_number': agent['mobile_number'],
                  'is_verified': agent['is_verified'],
                  'created_at': agent['created_at'],
                },
              )
              .toList();

      setState(() {
        _allAgents = transformedAgents;
        _filteredAgents = transformedAgents;
        _isLoading = false;
      });
    } catch (e) {
      setState(() => _isLoading = false);
      _showErrorMessage('Failed to load agents: $e');
    }
  }

  void _onSearchChanged() {
    _filterAgents();
  }

  void _filterAgents() {
    setState(() {
      _filteredAgents =
          _allAgents.where((agent) {
            // Search filter (name, alias)
            final searchQuery = _searchController.text.toLowerCase();
            final matchesSearch =
                searchQuery.isEmpty ||
                (agent['name'] as String).toLowerCase().contains(searchQuery) ||
                (agent['alias'] as String).toLowerCase().contains(
                  searchQuery,
                ) ||
                (agent['nickname'] as String).toLowerCase().contains(
                  searchQuery,
                );

            // City filter - For agent selection, we check if agent has locations in selected city
            final matchesCity =
                _selectedCity == null ||
                _selectedCity == 'Multiple Cities' ||
                (agent['city'] as String).contains(_selectedCity!);

            // Rating filter
            final agentRating = (agent['rating'] as num?)?.toDouble() ?? 0.0;
            final matchesRating =
                agentRating >= (_filters['minimumRating'] as double);

            // Online status filter (all verified agents are considered online)
            final isOnline = agent['isOnline'] as bool? ?? true;
            final matchesOnlineStatus =
                !(_filters['onlineOnly'] as bool) || isOnline;

            // Agent type filter
            final agentType = agent['agent_type'] as String? ?? 'hawala';
            final matchesAgentType = true; // All agent types allowed for now

            return matchesSearch &&
                matchesCity &&
                matchesRating &&
                matchesOnlineStatus &&
                matchesAgentType;
          }).toList();

      // Sort by rating (highest first)
      _filteredAgents.sort((a, b) {
        final aRating = (a['rating'] as num?)?.toDouble() ?? 0.0;
        final bRating = (b['rating'] as num?)?.toDouble() ?? 0.0;
        return bRating.compareTo(aRating);
      });
    });
  }

  void _showFilterBottomSheet() {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder:
          (context) => AgentFilterBottomSheet(
            currentFilters: _filters,
            onFiltersChanged: (newFilters) {
              setState(() {
                _filters = newFilters;
              });
              _filterAgents();
            },
          ),
    );
  }

  void _showCitySearchBottomSheet() {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder:
          (context) => CitySearchBottomSheet(
            onCitySelected: (city) {
              setState(() {
                _selectedCity = city;
                _searchController.text = city;
              });
              _filterAgents();
            },
          ),
    );
  }

  void _showAgentProfile(Map<String, dynamic> agent) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder:
          (context) => AgentProfileModal(
            agent: agent,
            onSelectAgent: () {
              Navigator.pop(context);
              _selectAgent(agent['id'] as String);
            },
            onMessageAgent: () {
              Navigator.pop(context);
              _messageAgent(agent);
            },
          ),
    );
  }

  void _showQuickActions(Map<String, dynamic> agent) {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      builder:
          (context) => AgentQuickActionsModal(
            agent: agent,
            onViewProfile: () => _showAgentProfile(agent),
            onMessageAgent: () => _messageAgent(agent),
            onReportAgent: () => _reportAgent(agent),
          ),
    );
  }

  void _selectAgent(String agentId) {
    setState(() {
      _selectedAgentId = agentId;
    });

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('Agent selected successfully'),
        backgroundColor: AppTheme.getSuccessColor(true),
        duration: const Duration(seconds: 2),
      ),
    );
  }

  void _messageAgent(Map<String, dynamic> agent) {
    Navigator.pushNamed(
      context,
      '/in-app-chat',
      arguments: {'agentId': agent['id'], 'agentName': agent['nickname']},
    );
  }

  void _reportAgent(Map<String, dynamic> agent) {
    showDialog(
      context: context,
      builder:
          (context) => AlertDialog(
            title: Text('Report Agent'),
            content: Text(
              'Are you sure you want to report ${agent['nickname']}? This action will be reviewed by our team.',
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(context),
                child: Text('Cancel'),
              ),
              ElevatedButton(
                onPressed: () {
                  Navigator.pop(context);
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(
                      content: Text('Report submitted successfully'),
                      backgroundColor: AppTheme.getSuccessColor(true),
                    ),
                  );
                },
                style: ElevatedButton.styleFrom(
                  backgroundColor: AppTheme.lightTheme.colorScheme.error,
                ),
                child: Text('Report'),
              ),
            ],
          ),
    );
  }

  Future<void> _chooseSelectedAgent() async {
    if (_selectedAgentId != null && _buyerCity != null && _sellerCity != null) {
      final selectedAgent = _allAgents.firstWhere(
        (agent) => agent['id'] == _selectedAgentId,
        orElse: () => {},
      );

      // Check if agent has locations in both cities
      try {
        final buyerLocations = await _supabaseService.getAgentLocationsByCity(
          agentId: _selectedAgentId!,
          city: _buyerCity!,
        );

        final sellerLocations = await _supabaseService.getAgentLocationsByCity(
          agentId: _selectedAgentId!,
          city: _sellerCity!,
        );

        if (sellerLocations.isEmpty) {
          _showErrorMessage(
            'Selected agent does not have active locations in $_sellerCity. Please choose a different agent.',
          );
          return;
        }

        if (buyerLocations.isEmpty) {
          _showErrorMessage(
            'Selected agent does not have active locations in $_buyerCity. Please change the buyer city or choose a different agent.',
          );
          return;
        }

        // Return the selected agent with location info
        Navigator.pop(context, {
          ...selectedAgent,
          'sellerLocation': sellerLocations.first,
          'buyerLocation': buyerLocations.first,
        });
      } catch (e) {
        _showErrorMessage('Error checking agent locations: $e');
      }
    }
  }

  void _expandSearchRadius() {
    setState(() {
      _filters['distanceRadius'] =
          (_filters['distanceRadius'] as double) + 25.0;
    });
    _filterAgents();

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          'Search radius expanded to ${(_filters['distanceRadius'] as double).round()} km',
        ),
      ),
    );
  }

  void _clearCityFilter() {
    setState(() {
      _selectedCity = _sellerCity; // Reset to default seller city
      _searchController.clear();
    });
    _filterAgents();
  }

  void _showErrorMessage(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        backgroundColor: AppTheme.lightTheme.colorScheme.error,
        duration: const Duration(seconds: 4),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.lightTheme.scaffoldBackgroundColor,
      body: SafeArea(
        child: Column(
          children: [
            // Header
            Container(
              padding: EdgeInsets.all(4.w),
              decoration: BoxDecoration(
                color: AppTheme.lightTheme.cardColor,
                boxShadow: [
                  BoxShadow(
                    color: AppTheme.lightTheme.colorScheme.shadow,
                    blurRadius: 4,
                    offset: const Offset(0, 2),
                  ),
                ],
              ),
              child: Column(
                children: [
                  // Top Row
                  Row(
                    children: [
                      IconButton(
                        onPressed: () => Navigator.pop(context),
                        icon: CustomIconWidget(
                          iconName: 'arrow_back',
                          color: AppTheme.lightTheme.colorScheme.onSurface,
                          size: 24,
                        ),
                      ),
                      Expanded(
                        child: Column(
                          children: [
                            Text(
                              'Select Agent',
                              style: AppTheme.lightTheme.textTheme.headlineSmall
                                  ?.copyWith(
                                    fontWeight: FontWeight.w700,
                                    color:
                                        AppTheme
                                            .lightTheme
                                            .colorScheme
                                            .onSurface,
                                  ),
                            ),
                            if (_buyerCity != null && _sellerCity != null) ...[
                              SizedBox(height: 4),
                              Text(
                                '$_sellerCity → $_buyerCity',
                                style: AppTheme.lightTheme.textTheme.bodySmall
                                    ?.copyWith(
                                      color:
                                          AppTheme
                                              .lightTheme
                                              .colorScheme
                                              .onSurfaceVariant,
                                    ),
                              ),
                            ],
                          ],
                        ),
                      ),
                      IconButton(
                        onPressed: () {
                          setState(() {
                            _isMapView = !_isMapView;
                          });
                        },
                        icon: CustomIconWidget(
                          iconName: _isMapView ? 'list' : 'map',
                          color: AppTheme.lightTheme.primaryColor,
                          size: 24,
                        ),
                      ),
                    ],
                  ),

                  SizedBox(height: 2.h),

                  // Search Bar
                  Row(
                    children: [
                      Expanded(
                        child: Container(
                          decoration: BoxDecoration(
                            color: AppTheme.lightTheme.colorScheme.surface,
                            borderRadius: BorderRadius.circular(12),
                            border: Border.all(
                              color: AppTheme.lightTheme.colorScheme.outline
                                  .withValues(alpha: 0.5),
                            ),
                          ),
                          child: TextField(
                            controller: _searchController,
                            style: AppTheme.lightTheme.textTheme.bodyMedium
                                ?.copyWith(
                                  fontWeight: FontWeight.w500,
                                  color:
                                      AppTheme.lightTheme.colorScheme.onSurface,
                                ),
                            decoration: InputDecoration(
                              hintText: 'Search agents by name or alias',
                              hintStyle: AppTheme
                                  .lightTheme
                                  .textTheme
                                  .bodyMedium
                                  ?.copyWith(
                                    color: AppTheme
                                        .lightTheme
                                        .colorScheme
                                        .onSurfaceVariant
                                        .withValues(alpha: 0.8),
                                    fontWeight: FontWeight.w400,
                                  ),
                              prefixIcon: Padding(
                                padding: EdgeInsets.all(3.w),
                                child: CustomIconWidget(
                                  iconName: 'search',
                                  color:
                                      AppTheme
                                          .lightTheme
                                          .colorScheme
                                          .onSurfaceVariant,
                                  size: 20,
                                ),
                              ),
                              suffixIcon: GestureDetector(
                                onTap: _showCitySearchBottomSheet,
                                child: Padding(
                                  padding: EdgeInsets.all(3.w),
                                  child: CustomIconWidget(
                                    iconName: 'location_on',
                                    color: AppTheme.lightTheme.primaryColor,
                                    size: 20,
                                  ),
                                ),
                              ),
                              border: InputBorder.none,
                              contentPadding: EdgeInsets.symmetric(
                                horizontal: 4.w,
                                vertical: 2.h,
                              ),
                            ),
                          ),
                        ),
                      ),
                      SizedBox(width: 3.w),
                      Container(
                        decoration: BoxDecoration(
                          color: AppTheme.lightTheme.primaryColor,
                          borderRadius: BorderRadius.circular(12),
                          boxShadow: [
                            BoxShadow(
                              color: AppTheme.lightTheme.primaryColor
                                  .withValues(alpha: 0.3),
                              blurRadius: 8,
                              offset: const Offset(0, 2),
                            ),
                          ],
                        ),
                        child: IconButton(
                          onPressed: _showFilterBottomSheet,
                          icon: CustomIconWidget(
                            iconName: 'tune',
                            color: Colors.white,
                            size: 24,
                          ),
                        ),
                      ),
                    ],
                  ),

                  // Selected city chip
                  if (_selectedCity != null &&
                      _selectedCity != _sellerCity) ...[
                    SizedBox(height: 2.h),
                    Row(
                      children: [
                        Container(
                          padding: EdgeInsets.symmetric(
                            horizontal: 3.w,
                            vertical: 1.h,
                          ),
                          decoration: BoxDecoration(
                            color: AppTheme.lightTheme.primaryColor.withValues(
                              alpha: 0.15,
                            ),
                            borderRadius: BorderRadius.circular(20),
                            border: Border.all(
                              color: AppTheme.lightTheme.primaryColor
                                  .withValues(alpha: 0.3),
                              width: 1,
                            ),
                          ),
                          child: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Icon(
                                Icons.location_city,
                                size: 16,
                                color: AppTheme.lightTheme.primaryColor,
                              ),
                              SizedBox(width: 1.w),
                              Text(
                                _selectedCity!,
                                style: AppTheme.lightTheme.textTheme.bodySmall
                                    ?.copyWith(
                                      color: AppTheme.lightTheme.primaryColor,
                                      fontWeight: FontWeight.w600,
                                    ),
                              ),
                              SizedBox(width: 1.w),
                              GestureDetector(
                                onTap: _clearCityFilter,
                                child: Icon(
                                  Icons.close,
                                  size: 16,
                                  color: AppTheme.lightTheme.primaryColor,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ],
                ],
              ),
            ),

            // Content
            Expanded(child: _isMapView ? _buildMapView() : _buildListView()),

            // Choose Agent Button
            if (_selectedAgentId != null)
              Container(
                padding: EdgeInsets.all(4.w),
                decoration: BoxDecoration(
                  color: AppTheme.lightTheme.cardColor,
                  border: Border(
                    top: BorderSide(
                      color: AppTheme.lightTheme.colorScheme.outline.withValues(
                        alpha: 0.2,
                      ),
                    ),
                  ),
                ),
                child: SizedBox(
                  width: double.infinity,
                  child: ElevatedButton(
                    onPressed: _chooseSelectedAgent,
                    child: Text('Choose Agent'),
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }

  Widget _buildListView() {
    if (_isLoading) {
      return _buildLoadingState();
    }

    if (_filteredAgents.isEmpty) {
      return _buildEmptyState();
    }

    return ListView.builder(
      padding: EdgeInsets.symmetric(vertical: 1.h),
      itemCount: _filteredAgents.length,
      itemBuilder: (context, index) {
        final agent = _filteredAgents[index];
        final isSelected = agent['id'] == _selectedAgentId;

        return AgentCardWidget(
          agent: agent,
          isSelected: isSelected,
          onTap: () => _selectAgent(agent['id'] as String),
          onLongPress: () => _showQuickActions(agent),
        );
      },
    );
  }

  Widget _buildMapView() {
    if (kIsWeb) {
      return Container(
        color: AppTheme.lightTheme.colorScheme.surface,
        child: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              CustomIconWidget(
                iconName: 'map',
                color: AppTheme.lightTheme.colorScheme.onSurfaceVariant,
                size: 64,
              ),
              SizedBox(height: 2.h),
              Text(
                'Map View',
                style: AppTheme.lightTheme.textTheme.headlineSmall?.copyWith(
                  color: AppTheme.lightTheme.colorScheme.onSurfaceVariant,
                ),
              ),
              SizedBox(height: 1.h),
              Text(
                'Map view is not available on web.\nPlease use the mobile app for map functionality.',
                style: AppTheme.lightTheme.textTheme.bodyMedium?.copyWith(
                  color: AppTheme.lightTheme.colorScheme.onSurfaceVariant,
                ),
                textAlign: TextAlign.center,
              ),
              SizedBox(height: 3.h),
              ElevatedButton(
                onPressed: () {
                  setState(() {
                    _isMapView = false;
                  });
                },
                child: Text('Switch to List View'),
              ),
            ],
          ),
        ),
      );
    }

    return AgentMapViewWidget(
      key: _mapKey,
      agents: _filteredAgents,
      selectedAgentId: _selectedAgentId,
      onAgentSelected: _selectAgent,
      onAgentProfileTap: _showAgentProfile,
    );
  }

  Widget _buildLoadingState() {
    return ListView.builder(
      padding: EdgeInsets.symmetric(vertical: 1.h),
      itemCount: 5,
      itemBuilder: (context, index) {
        return Container(
          margin: EdgeInsets.symmetric(horizontal: 4.w, vertical: 1.h),
          padding: EdgeInsets.all(4.w),
          decoration: BoxDecoration(
            color: AppTheme.lightTheme.cardColor,
            borderRadius: BorderRadius.circular(12),
          ),
          child: Column(
            children: [
              Row(
                children: [
                  Container(
                    width: 12.w,
                    height: 12.w,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: AppTheme.lightTheme.colorScheme.outline.withValues(
                        alpha: 0.3,
                      ),
                    ),
                  ),
                  SizedBox(width: 3.w),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Container(
                          height: 16,
                          width: 40.w,
                          decoration: BoxDecoration(
                            color: AppTheme.lightTheme.colorScheme.outline
                                .withValues(alpha: 0.3),
                            borderRadius: BorderRadius.circular(4),
                          ),
                        ),
                        SizedBox(height: 1.h),
                        Container(
                          height: 12,
                          width: 25.w,
                          decoration: BoxDecoration(
                            color: AppTheme.lightTheme.colorScheme.outline
                                .withValues(alpha: 0.3),
                            borderRadius: BorderRadius.circular(4),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
              SizedBox(height: 2.h),
              Row(
                children: [
                  Container(
                    height: 12,
                    width: 30.w,
                    decoration: BoxDecoration(
                      color: AppTheme.lightTheme.colorScheme.outline.withValues(
                        alpha: 0.3,
                      ),
                      borderRadius: BorderRadius.circular(4),
                    ),
                  ),
                  const Spacer(),
                  Container(
                    height: 12,
                    width: 20.w,
                    decoration: BoxDecoration(
                      color: AppTheme.lightTheme.colorScheme.outline.withValues(
                        alpha: 0.3,
                      ),
                      borderRadius: BorderRadius.circular(4),
                    ),
                  ),
                ],
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _buildEmptyState() {
    return Center(
      child: Padding(
        padding: EdgeInsets.all(8.w),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            CustomIconWidget(
              iconName: 'search_off',
              color: AppTheme.lightTheme.colorScheme.onSurfaceVariant,
              size: 64,
            ),
            SizedBox(height: 3.h),
            Text(
              _selectedCity != null
                  ? 'No agents found in $_selectedCity'
                  : 'No agents found',
              style: AppTheme.lightTheme.textTheme.headlineSmall?.copyWith(
                color: AppTheme.lightTheme.colorScheme.onSurfaceVariant,
              ),
            ),
            SizedBox(height: 1.h),
            Text(
              _selectedCity != null
                  ? 'Try searching in a different city or clear the location filter.'
                  : 'No agents match your current search criteria.\nTry adjusting your filters or expanding the search radius.',
              style: AppTheme.lightTheme.textTheme.bodyMedium?.copyWith(
                color: AppTheme.lightTheme.colorScheme.onSurfaceVariant,
              ),
              textAlign: TextAlign.center,
            ),
            SizedBox(height: 4.h),
            Row(
              children: [
                Expanded(
                  child: OutlinedButton(
                    onPressed: () {
                      setState(() {
                        _filters = {
                          'distanceRadius': 50.0,
                          'minimumRating': 0.0,
                          'onlineOnly': false,
                          'paymentMethods': <String>[],
                        };
                        _selectedCity = null;
                        _searchController.clear();
                      });
                      _filterAgents();
                    },
                    child: Text('Clear All Filters'),
                  ),
                ),
                if (_selectedCity == null) ...[
                  SizedBox(width: 3.w),
                  Expanded(
                    child: ElevatedButton(
                      onPressed: _expandSearchRadius,
                      child: Text('Expand Search'),
                    ),
                  ),
                ],
              ],
            ),
          ],
        ),
      ),
    );
  }
}
