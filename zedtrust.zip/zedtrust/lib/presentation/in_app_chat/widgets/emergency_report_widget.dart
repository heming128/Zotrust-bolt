import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';

class EmergencyReportWidget extends StatefulWidget {
  final String tradeId;
  final VoidCallback? onReport;
  final VoidCallback? onEscalate;

  const EmergencyReportWidget({
    Key? key,
    required this.tradeId,
    this.onReport,
    this.onEscalate,
  }) : super(key: key);

  @override
  State<EmergencyReportWidget> createState() => _EmergencyReportWidgetState();
}

class _EmergencyReportWidgetState extends State<EmergencyReportWidget>
    with TickerProviderStateMixin {
  late AnimationController _pulseController;
  late Animation<double> _pulseAnimation;
  bool _isPressed = false;

  @override
  void initState() {
    super.initState();
    _setupAnimations();
  }

  void _setupAnimations() {
    _pulseController = AnimationController(
      duration: const Duration(milliseconds: 1000),
      vsync: this,
    );
    _pulseAnimation = Tween<double>(
      begin: 1.0,
      end: 1.1,
    ).animate(CurvedAnimation(
      parent: _pulseController,
      curve: Curves.easeInOut,
    ));

    _pulseController.repeat(reverse: true);
  }

  @override
  void dispose() {
    _pulseController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Positioned(
      right: 4.w,
      bottom: 15.h,
      child: AnimatedBuilder(
        animation: _pulseAnimation,
        builder: (context, child) {
          return Transform.scale(
            scale: _pulseAnimation.value,
            child: GestureDetector(
              onTapDown: (_) => setState(() => _isPressed = true),
              onTapUp: (_) => setState(() => _isPressed = false),
              onTapCancel: () => setState(() => _isPressed = false),
              onTap: _showEmergencyOptions,
              child: Container(
                width: 14.w,
                height: 14.w,
                decoration: BoxDecoration(
                  color: _isPressed ? Colors.red.shade700 : Colors.red,
                  shape: BoxShape.circle,
                  boxShadow: [
                    BoxShadow(
                      color: Colors.red.withValues(alpha: 0.4),
                      blurRadius: 12,
                      offset: const Offset(0, 4),
                    ),
                    if (_isPressed)
                      BoxShadow(
                        color: Colors.red.withValues(alpha: 0.6),
                        blurRadius: 20,
                        offset: const Offset(0, 8),
                      ),
                  ],
                ),
                child: Center(
                  child: CustomIconWidget(
                    iconName: 'emergency',
                    color: Colors.white,
                    size: 7.w,
                  ),
                ),
              ),
            ),
          );
        },
      ),
    );
  }

  void _showEmergencyOptions() {
    HapticFeedback.heavyImpact();

    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isDismissible: true,
      builder: (context) => _buildEmergencySheet(),
    );
  }

  Widget _buildEmergencySheet() {
    return Container(
      decoration: BoxDecoration(
        color: Theme.of(context).cardColor,
        borderRadius: const BorderRadius.vertical(top: Radius.circular(20)),
      ),
      padding: EdgeInsets.all(6.w),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            width: 12.w,
            height: 0.5.h,
            decoration: BoxDecoration(
              color: AppTheme.getNeutralColor(true),
              borderRadius: BorderRadius.circular(4),
            ),
          ),
          SizedBox(height: 4.h),
          _buildEmergencyHeader(),
          SizedBox(height: 4.h),
          _buildEmergencyOptions(),
          SizedBox(height: 3.h),
          _buildDisclaimerText(),
          SizedBox(height: 2.h),
        ],
      ),
    );
  }

  Widget _buildEmergencyHeader() {
    return Column(
      children: [
        Container(
          width: 20.w,
          height: 20.w,
          decoration: BoxDecoration(
            color: Colors.red.withValues(alpha: 0.1),
            shape: BoxShape.circle,
            border: Border.all(
              color: Colors.red.withValues(alpha: 0.3),
              width: 2,
            ),
          ),
          child: Center(
            child: CustomIconWidget(
              iconName: 'warning',
              color: Colors.red,
              size: 10.w,
            ),
          ),
        ),
        SizedBox(height: 3.h),
        Text(
          'Emergency Dispute',
          style: Theme.of(context).textTheme.titleLarge?.copyWith(
                fontWeight: FontWeight.w700,
                color: Colors.red,
              ),
        ),
        SizedBox(height: 1.h),
        Text(
          'Report serious issues or escalate disputes to platform administrators',
          style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                color: Theme.of(context).colorScheme.onSurfaceVariant,
              ),
          textAlign: TextAlign.center,
        ),
      ],
    );
  }

  Widget _buildEmergencyOptions() {
    return Column(
      children: [
        _buildEmergencyOption(
          'Report Issue',
          'Report suspicious behavior or policy violations',
          'flag',
          AppTheme.getWarningColor(true),
          () => _handleReportIssue(),
        ),
        SizedBox(height: 2.h),
        _buildEmergencyOption(
          'Escalate Dispute',
          'Request immediate platform intervention',
          'gavel',
          Colors.red,
          () => _handleEscalateDispute(),
        ),
        SizedBox(height: 3.h),
        SizedBox(
          width: double.infinity,
          child: OutlinedButton(
            onPressed: () => Navigator.pop(context),
            style: OutlinedButton.styleFrom(
              side: BorderSide(color: AppTheme.getNeutralColor(true)),
              padding: EdgeInsets.symmetric(vertical: 3.h),
            ),
            child: Text(
              'Cancel',
              style: Theme.of(context).textTheme.titleMedium?.copyWith(
                    color: Theme.of(context).colorScheme.onSurfaceVariant,
                  ),
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildEmergencyOption(
    String title,
    String description,
    String iconName,
    Color color,
    VoidCallback onTap,
  ) {
    return Container(
      width: double.infinity,
      decoration: BoxDecoration(
        color: color.withValues(alpha: 0.05),
        borderRadius: BorderRadius.circular(3.w),
        border: Border.all(
          color: color.withValues(alpha: 0.2),
        ),
      ),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: onTap,
          borderRadius: BorderRadius.circular(3.w),
          child: Padding(
            padding: EdgeInsets.all(4.w),
            child: Row(
              children: [
                Container(
                  width: 12.w,
                  height: 12.w,
                  decoration: BoxDecoration(
                    color: color.withValues(alpha: 0.1),
                    shape: BoxShape.circle,
                  ),
                  child: Center(
                    child: CustomIconWidget(
                      iconName: iconName,
                      color: color,
                      size: 6.w,
                    ),
                  ),
                ),
                SizedBox(width: 4.w),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        title,
                        style:
                            Theme.of(context).textTheme.titleMedium?.copyWith(
                                  fontWeight: FontWeight.w600,
                                  color: color,
                                ),
                      ),
                      SizedBox(height: 0.5.h),
                      Text(
                        description,
                        style: Theme.of(context).textTheme.bodySmall?.copyWith(
                              color: color.withValues(alpha: 0.8),
                            ),
                      ),
                    ],
                  ),
                ),
                CustomIconWidget(
                  iconName: 'chevron_right',
                  color: color,
                  size: 5.w,
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildDisclaimerText() {
    return Container(
      padding: EdgeInsets.all(3.w),
      decoration: BoxDecoration(
        color: AppTheme.lightTheme.primaryColor.withValues(alpha: 0.05),
        borderRadius: BorderRadius.circular(2.w),
        border: Border.all(
          color: AppTheme.lightTheme.primaryColor.withValues(alpha: 0.2),
        ),
      ),
      child: Row(
        children: [
          CustomIconWidget(
            iconName: 'info',
            color: AppTheme.lightTheme.primaryColor,
            size: 5.w,
          ),
          SizedBox(width: 3.w),
          Expanded(
            child: Text(
              'Emergency reports include full chat transcript and trade history for platform review.',
              style: Theme.of(context).textTheme.bodySmall?.copyWith(
                    color: AppTheme.lightTheme.primaryColor,
                  ),
            ),
          ),
        ],
      ),
    );
  }

  void _handleReportIssue() {
    Navigator.pop(context);
    _showReportDialog();
  }

  void _handleEscalateDispute() {
    Navigator.pop(context);
    _showEscalateDialog();
  }

  void _showReportDialog() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Row(
          children: [
            CustomIconWidget(
              iconName: 'flag',
              color: AppTheme.getWarningColor(true),
              size: 6.w,
            ),
            SizedBox(width: 3.w),
            Text(
              'Report Issue',
              style: Theme.of(context).textTheme.titleLarge?.copyWith(
                    fontWeight: FontWeight.w600,
                  ),
            ),
          ],
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Describe the issue you want to report:',
              style: Theme.of(context).textTheme.bodyMedium,
            ),
            SizedBox(height: 2.h),
            TextField(
              maxLines: 4,
              decoration: InputDecoration(
                hintText: 'Please provide details about the issue...',
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(2.w),
                ),
              ),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(context);
              _processReport();
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: AppTheme.getWarningColor(true),
            ),
            child: Text(
              'Submit Report',
              style: TextStyle(color: Colors.white),
            ),
          ),
        ],
      ),
    );
  }

  void _showEscalateDialog() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Row(
          children: [
            CustomIconWidget(
              iconName: 'gavel',
              color: Colors.red,
              size: 6.w,
            ),
            SizedBox(width: 3.w),
            Text(
              'Escalate Dispute',
              style: Theme.of(context).textTheme.titleLarge?.copyWith(
                    fontWeight: FontWeight.w600,
                  ),
            ),
          ],
        ),
        content: Text(
          'This will immediately escalate the dispute to platform administrators with full chat transcript and trade history. This action cannot be undone.',
          style: Theme.of(context).textTheme.bodyMedium,
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(context);
              _processEscalation();
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.red,
            ),
            child: Text(
              'Escalate Now',
              style: TextStyle(color: Colors.white),
            ),
          ),
        ],
      ),
    );
  }

  void _processReport() {
    HapticFeedback.lightImpact();

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
            'Report submitted successfully. Case #RP${DateTime.now().millisecondsSinceEpoch.toString().substring(8)}'),
        backgroundColor: AppTheme.getWarningColor(true),
        duration: const Duration(seconds: 4),
      ),
    );

    if (widget.onReport != null) {
      widget.onReport!();
    }
  }

  void _processEscalation() {
    HapticFeedback.heavyImpact();

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
            'Dispute escalated. Admin will contact you within 15 minutes.'),
        backgroundColor: Colors.red,
        duration: const Duration(seconds: 5),
      ),
    );

    if (widget.onEscalate != null) {
      widget.onEscalate!();
    }
  }
}
