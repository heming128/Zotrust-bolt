import 'dart:io' show Platform;

import 'package:flutter/foundation.dart' show kIsWeb;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';

class ChatInputWidget extends StatefulWidget {
  final Function(String) onSendMessage;
  final Function(String) onSendOtp;
  final VoidCallback? onAttachment;
  final VoidCallback? onEmoji;
  final bool isTyping;
  final bool isEnabled;

  const ChatInputWidget({
    Key? key,
    required this.onSendMessage,
    required this.onSendOtp,
    this.onAttachment,
    this.onEmoji,
    this.isTyping = false,
    this.isEnabled = true,
  }) : super(key: key);

  @override
  State<ChatInputWidget> createState() => _ChatInputWidgetState();
}

class _ChatInputWidgetState extends State<ChatInputWidget>
    with TickerProviderStateMixin {
  late TextEditingController _textController;
  late FocusNode _focusNode;
  late AnimationController _sendButtonAnimationController;
  late Animation<double> _sendButtonAnimation;
  bool _isComposing = false;
  bool _showAttachmentOptions = false;

  @override
  void initState() {
    super.initState();
    _textController = TextEditingController();
    _focusNode = FocusNode();
    _sendButtonAnimationController = AnimationController(
      duration: const Duration(milliseconds: 200),
      vsync: this,
    );
    _sendButtonAnimation = Tween<double>(
      begin: 0.0,
      end: 1.0,
    ).animate(CurvedAnimation(
      parent: _sendButtonAnimationController,
      curve: Curves.easeInOut,
    ));

    _textController.addListener(() {
      final isComposing = _textController.text.isNotEmpty;
      if (isComposing != _isComposing) {
        setState(() {
          _isComposing = isComposing;
        });
        if (isComposing) {
          _sendButtonAnimationController.forward();
        } else {
          _sendButtonAnimationController.reverse();
        }
      }
    });
  }

  @override
  void dispose() {
    _textController.dispose();
    _focusNode.dispose();
    _sendButtonAnimationController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: Theme.of(context).scaffoldBackgroundColor,
        border: Border(
          top: BorderSide(
            color: Theme.of(context).dividerColor,
            width: 0.5,
          ),
        ),
      ),
      child: SafeArea(
        child: Column(
          children: [
            if (_showAttachmentOptions) _buildAttachmentOptions(),
            _buildInputArea(),
          ],
        ),
      ),
    );
  }

  Widget _buildInputArea() {
    return Padding(
      padding: EdgeInsets.symmetric(horizontal: 4.w, vertical: 2.h),
      child: Row(
        children: [
          _buildAttachmentButton(),
          SizedBox(width: 2.w),
          Expanded(child: _buildTextInput()),
          SizedBox(width: 2.w),
          _buildSendButton(),
        ],
      ),
    );
  }

  Widget _buildAttachmentButton() {
    return GestureDetector(
      onTap: () {
        HapticFeedback.lightImpact();
        setState(() {
          _showAttachmentOptions = !_showAttachmentOptions;
        });
      },
      child: Container(
        width: 10.w,
        height: 10.w,
        decoration: BoxDecoration(
          color: _showAttachmentOptions
              ? AppTheme.lightTheme.primaryColor
              : AppTheme.lightTheme.primaryColor.withValues(alpha: 0.1),
          shape: BoxShape.circle,
        ),
        child: Center(
          child: AnimatedRotation(
            turns: _showAttachmentOptions ? 0.125 : 0,
            duration: const Duration(milliseconds: 200),
            child: CustomIconWidget(
              iconName: 'add',
              color: _showAttachmentOptions
                  ? Colors.white
                  : AppTheme.lightTheme.primaryColor,
              size: 6.w,
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildTextInput() {
    return Container(
      constraints: BoxConstraints(
        minHeight: 10.w,
        maxHeight: 30.w,
      ),
      decoration: BoxDecoration(
        color: Theme.of(context).cardColor,
        borderRadius: BorderRadius.circular(5.w),
        border: Border.all(
          color: _focusNode.hasFocus
              ? AppTheme.lightTheme.primaryColor
              : Theme.of(context).dividerColor,
          width: _focusNode.hasFocus ? 2 : 1,
        ),
      ),
      child: Row(
        children: [
          Expanded(
            child: TextField(
              controller: _textController,
              focusNode: _focusNode,
              enabled: widget.isEnabled,
              maxLines: null,
              textCapitalization: TextCapitalization.sentences,
              decoration: InputDecoration(
                hintText: 'Type a message...',
                hintStyle: Theme.of(context).textTheme.bodyMedium?.copyWith(
                      color: Theme.of(context).colorScheme.onSurfaceVariant,
                    ),
                border: InputBorder.none,
                contentPadding: EdgeInsets.symmetric(
                  horizontal: 4.w,
                  vertical: 2.5.w,
                ),
              ),
              style: Theme.of(context).textTheme.bodyMedium,
              onSubmitted: _handleSubmitted,
            ),
          ),
          if (!kIsWeb && Platform.isIOS)
            GestureDetector(
              onTap: () {
                if (widget.onEmoji != null) {
                  HapticFeedback.lightImpact();
                  widget.onEmoji!();
                }
              },
              child: Padding(
                padding: EdgeInsets.only(right: 3.w),
                child: CustomIconWidget(
                  iconName: 'emoji_emotions',
                  color: AppTheme.lightTheme.primaryColor,
                  size: 6.w,
                ),
              ),
            ),
        ],
      ),
    );
  }

  Widget _buildSendButton() {
    return AnimatedBuilder(
      animation: _sendButtonAnimation,
      builder: (context, child) {
        return Transform.scale(
          scale: 0.8 + (_sendButtonAnimation.value * 0.2),
          child: GestureDetector(
            onTap: _isComposing && widget.isEnabled
                ? () => _handleSubmitted(_textController.text)
                : null,
            child: Container(
              width: 10.w,
              height: 10.w,
              decoration: BoxDecoration(
                color: _isComposing && widget.isEnabled
                    ? AppTheme.lightTheme.primaryColor
                    : AppTheme.getNeutralColor(true),
                shape: BoxShape.circle,
                boxShadow: _isComposing && widget.isEnabled
                    ? [
                        BoxShadow(
                          color: AppTheme.lightTheme.primaryColor
                              .withValues(alpha: 0.3),
                          blurRadius: 8,
                          offset: const Offset(0, 2),
                        ),
                      ]
                    : null,
              ),
              child: Center(
                child: CustomIconWidget(
                  iconName: 'send',
                  color: Colors.white,
                  size: 5.w,
                ),
              ),
            ),
          ),
        );
      },
    );
  }

  Widget _buildAttachmentOptions() {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 4.w, vertical: 2.h),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        children: [
          _buildAttachmentOption(
            'OTP Share',
            'verified_user',
            AppTheme.getSuccessColor(true),
            () => _showOtpDialog(),
          ),
          _buildAttachmentOption(
            'Document',
            'description',
            AppTheme.lightTheme.primaryColor,
            widget.onAttachment,
          ),
          _buildAttachmentOption(
            'Camera',
            'camera_alt',
            AppTheme.getWarningColor(true),
            () => _handleCameraCapture(),
          ),
          _buildAttachmentOption(
            'Gallery',
            'photo_library',
            AppTheme.getAccentColor(true),
            () => _handleGalleryPicker(),
          ),
        ],
      ),
    );
  }

  Widget _buildAttachmentOption(
    String label,
    String iconName,
    Color color,
    VoidCallback? onTap,
  ) {
    return GestureDetector(
      onTap: () {
        if (onTap != null) {
          HapticFeedback.lightImpact();
          setState(() {
            _showAttachmentOptions = false;
          });
          onTap();
        }
      },
      child: Column(
        children: [
          Container(
            width: 12.w,
            height: 12.w,
            decoration: BoxDecoration(
              color: color.withValues(alpha: 0.1),
              shape: BoxShape.circle,
              border: Border.all(
                color: color.withValues(alpha: 0.3),
                width: 1,
              ),
            ),
            child: Center(
              child: CustomIconWidget(
                iconName: iconName,
                color: color,
                size: 6.w,
              ),
            ),
          ),
          SizedBox(height: 1.h),
          Text(
            label,
            style: Theme.of(context).textTheme.bodySmall?.copyWith(
                  color: color,
                  fontWeight: FontWeight.w500,
                ),
          ),
        ],
      ),
    );
  }

  void _handleSubmitted(String text) {
    if (text.trim().isEmpty || !widget.isEnabled) return;

    HapticFeedback.lightImpact();
    widget.onSendMessage(text.trim());
    _textController.clear();

    // Auto-hide keyboard on mobile after sending
    if (!kIsWeb) {
      FocusScope.of(context).unfocus();
    }
  }

  void _showOtpDialog() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(
          'Share OTP',
          style: Theme.of(context).textTheme.titleLarge?.copyWith(
                fontWeight: FontWeight.w600,
              ),
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              'Generate and share a one-time password for trade verification.',
              style: Theme.of(context).textTheme.bodyMedium,
            ),
            SizedBox(height: 2.h),
            Container(
              padding: EdgeInsets.all(4.w),
              decoration: BoxDecoration(
                color: AppTheme.getSuccessColor(true).withValues(alpha: 0.1),
                borderRadius: BorderRadius.circular(3.w),
                border: Border.all(
                  color: AppTheme.getSuccessColor(true).withValues(alpha: 0.3),
                ),
              ),
              child: Row(
                children: [
                  CustomIconWidget(
                    iconName: 'security',
                    color: AppTheme.getSuccessColor(true),
                    size: 6.w,
                  ),
                  SizedBox(width: 3.w),
                  Expanded(
                    child: Text(
                      'This OTP will be valid for 5 minutes and can only be used once.',
                      style: Theme.of(context).textTheme.bodySmall?.copyWith(
                            color: AppTheme.getSuccessColor(true),
                          ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text(
              'Cancel',
              style: Theme.of(context).textTheme.titleMedium?.copyWith(
                    color: Theme.of(context).colorScheme.onSurfaceVariant,
                  ),
            ),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(context);
              final otp = _generateOtp();
              widget.onSendOtp(otp);
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: AppTheme.getSuccessColor(true),
            ),
            child: Text(
              'Generate & Send',
              style: Theme.of(context).textTheme.titleMedium?.copyWith(
                    color: Colors.white,
                  ),
            ),
          ),
        ],
      ),
    );
  }

  String _generateOtp() {
    // Generate a 6-digit OTP
    final random = DateTime.now().millisecondsSinceEpoch % 1000000;
    return random.toString().padLeft(6, '0');
  }

  void _handleCameraCapture() {
    // This would integrate with the camera package for real implementation
    widget.onSendMessage('📷 Photo captured and shared');
  }

  void _handleGalleryPicker() {
    // This would integrate with image_picker package for real implementation
    widget.onSendMessage('🖼️ Image selected from gallery');
  }
}
