import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';

enum CallState { idle, ringing, connected, ended }

class VoipCallWidget extends StatefulWidget {
  final String counterpartyName;
  final bool isCallActive;
  final CallState callState;
  final Duration callDuration;
  final VoidCallback? onStartCall;
  final VoidCallback? onEndCall;
  final VoidCallback? onToggleMute;
  final VoidCallback? onToggleSpeaker;
  final bool isMuted;
  final bool isSpeakerOn;
  final bool isAvailable;

  const VoipCallWidget({
    Key? key,
    required this.counterpartyName,
    this.isCallActive = false,
    this.callState = CallState.idle,
    this.callDuration = Duration.zero,
    this.onStartCall,
    this.onEndCall,
    this.onToggleMute,
    this.onToggleSpeaker,
    this.isMuted = false,
    this.isSpeakerOn = false,
    this.isAvailable = true,
  }) : super(key: key);

  @override
  State<VoipCallWidget> createState() => _VoipCallWidgetState();
}

class _VoipCallWidgetState extends State<VoipCallWidget>
    with TickerProviderStateMixin {
  late AnimationController _pulseAnimationController;
  late Animation<double> _pulseAnimation;
  late AnimationController _connectingAnimationController;
  late Animation<double> _connectingAnimation;

  @override
  void initState() {
    super.initState();
    _setupAnimations();
  }

  void _setupAnimations() {
    // Pulse animation for call button
    _pulseAnimationController = AnimationController(
      duration: const Duration(milliseconds: 1000),
      vsync: this,
    );
    _pulseAnimation = Tween<double>(
      begin: 1.0,
      end: 1.2,
    ).animate(CurvedAnimation(
      parent: _pulseAnimationController,
      curve: Curves.easeInOut,
    ));

    // Connecting animation
    _connectingAnimationController = AnimationController(
      duration: const Duration(milliseconds: 1500),
      vsync: this,
    );
    _connectingAnimation = Tween<double>(
      begin: 0.0,
      end: 1.0,
    ).animate(CurvedAnimation(
      parent: _connectingAnimationController,
      curve: Curves.easeInOut,
    ));

    if (widget.callState == CallState.ringing) {
      _pulseAnimationController.repeat(reverse: true);
      _connectingAnimationController.repeat();
    } else if (widget.callState == CallState.connected) {
      _connectingAnimationController.stop();
      _pulseAnimationController.stop();
    }
  }

  @override
  void didUpdateWidget(VoipCallWidget oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.callState != widget.callState) {
      _updateAnimationsForState();
    }
  }

  void _updateAnimationsForState() {
    switch (widget.callState) {
      case CallState.ringing:
        _pulseAnimationController.repeat(reverse: true);
        _connectingAnimationController.repeat();
        break;
      case CallState.connected:
        _pulseAnimationController.stop();
        _connectingAnimationController.stop();
        break;
      case CallState.ended:
      case CallState.idle:
        _pulseAnimationController.stop();
        _connectingAnimationController.stop();
        break;
    }
  }

  @override
  void dispose() {
    _pulseAnimationController.dispose();
    _connectingAnimationController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (!widget.isCallActive && widget.callState == CallState.idle) {
      return _buildFloatingCallButton();
    }

    return _buildActiveCallInterface();
  }

  Widget _buildFloatingCallButton() {
    return Positioned(
      right: 4.w,
      top: 20.h,
      child: AnimatedBuilder(
        animation: _pulseAnimation,
        builder: (context, child) {
          return Transform.scale(
            scale: widget.callState == CallState.ringing
                ? _pulseAnimation.value
                : 1.0,
            child: GestureDetector(
              onTap: widget.isAvailable ? _handleCallAction : null,
              child: Container(
                width: 14.w,
                height: 14.w,
                decoration: BoxDecoration(
                  color: widget.isAvailable
                      ? AppTheme.getSuccessColor(true)
                      : AppTheme.getNeutralColor(true),
                  shape: BoxShape.circle,
                  boxShadow: [
                    BoxShadow(
                      color: widget.isAvailable
                          ? AppTheme.getSuccessColor(true)
                              .withValues(alpha: 0.3)
                          : Colors.black.withValues(alpha: 0.1),
                      blurRadius: 12,
                      offset: const Offset(0, 4),
                    ),
                  ],
                ),
                child: Stack(
                  children: [
                    Center(
                      child: CustomIconWidget(
                        iconName: 'call',
                        color: Colors.white,
                        size: 7.w,
                      ),
                    ),
                    if (widget.isAvailable)
                      Positioned(
                        right: 0,
                        top: 0,
                        child: Container(
                          width: 4.w,
                          height: 4.w,
                          decoration: BoxDecoration(
                            color: AppTheme.getSuccessColor(true),
                            shape: BoxShape.circle,
                            border: Border.all(
                              color: Colors.white,
                              width: 2,
                            ),
                          ),
                        ),
                      ),
                  ],
                ),
              ),
            ),
          );
        },
      ),
    );
  }

  Widget _buildActiveCallInterface() {
    return Container(
      width: double.infinity,
      height: double.infinity,
      color: Colors.black.withValues(alpha: 0.9),
      child: SafeArea(
        child: Column(
          children: [
            _buildCallHeader(),
            Expanded(child: _buildCallContent()),
            _buildCallControls(),
            SizedBox(height: 4.h),
          ],
        ),
      ),
    );
  }

  Widget _buildCallHeader() {
    return Container(
      padding: EdgeInsets.all(4.w),
      child: Row(
        children: [
          GestureDetector(
            onTap: () {
              if (widget.callState == CallState.connected) {
                _showMinimizeOption();
              }
            },
            child: Container(
              padding: EdgeInsets.all(2.w),
              decoration: BoxDecoration(
                color: Colors.white.withValues(alpha: 0.1),
                borderRadius: BorderRadius.circular(2.w),
              ),
              child: CustomIconWidget(
                iconName: 'keyboard_arrow_down',
                color: Colors.white,
                size: 6.w,
              ),
            ),
          ),
          Expanded(
            child: Column(
              children: [
                Text(
                  _getCallStateText(),
                  style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                        color: Colors.white.withValues(alpha: 0.7),
                      ),
                ),
                if (widget.callState == CallState.connected)
                  Text(
                    _formatCallDuration(),
                    style: Theme.of(context).textTheme.titleMedium?.copyWith(
                          color: Colors.white,
                          fontWeight: FontWeight.w600,
                        ),
                  ),
              ],
            ),
          ),
          _buildEncryptionIndicator(),
        ],
      ),
    );
  }

  Widget _buildCallContent() {
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        _buildCallerAvatar(),
        SizedBox(height: 4.h),
        Text(
          widget.counterpartyName,
          style: Theme.of(context).textTheme.headlineMedium?.copyWith(
                color: Colors.white,
                fontWeight: FontWeight.w600,
              ),
        ),
        SizedBox(height: 2.h),
        if (widget.callState == CallState.ringing)
          AnimatedBuilder(
            animation: _connectingAnimation,
            builder: (context, child) {
              return Text(
                'Connecting...',
                style: Theme.of(context).textTheme.titleMedium?.copyWith(
                      color: Colors.white.withValues(
                        alpha: 0.5 + (_connectingAnimation.value * 0.5),
                      ),
                    ),
              );
            },
          )
        else if (widget.callState == CallState.connected)
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              CustomIconWidget(
                iconName: 'security',
                color: AppTheme.getSuccessColor(true),
                size: 5.w,
              ),
              SizedBox(width: 2.w),
              Text(
                'Encrypted Call',
                style: Theme.of(context).textTheme.titleMedium?.copyWith(
                      color: AppTheme.getSuccessColor(true),
                    ),
              ),
            ],
          ),
      ],
    );
  }

  Widget _buildCallerAvatar() {
    return Container(
      width: 40.w,
      height: 40.w,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        gradient: LinearGradient(
          colors: [
            AppTheme.lightTheme.primaryColor,
            AppTheme.lightTheme.primaryColor.withValues(alpha: 0.7),
          ],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        boxShadow: [
          BoxShadow(
            color: AppTheme.lightTheme.primaryColor.withValues(alpha: 0.3),
            blurRadius: 20,
            offset: const Offset(0, 8),
          ),
        ],
      ),
      child: Center(
        child: Text(
          widget.counterpartyName.substring(0, 1).toUpperCase(),
          style: Theme.of(context).textTheme.displayMedium?.copyWith(
                color: Colors.white,
                fontWeight: FontWeight.w700,
              ),
        ),
      ),
    );
  }

  Widget _buildCallControls() {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 8.w),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        children: [
          _buildControlButton(
            'mic_off',
            widget.isMuted,
            () {
              HapticFeedback.lightImpact();
              if (widget.onToggleMute != null) widget.onToggleMute!();
            },
          ),
          _buildControlButton(
            'volume_up',
            widget.isSpeakerOn,
            () {
              HapticFeedback.lightImpact();
              if (widget.onToggleSpeaker != null) widget.onToggleSpeaker!();
            },
          ),
          _buildEndCallButton(),
        ],
      ),
    );
  }

  Widget _buildControlButton(
      String iconName, bool isActive, VoidCallback onTap) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: 15.w,
        height: 15.w,
        decoration: BoxDecoration(
          color: isActive ? Colors.white : Colors.white.withValues(alpha: 0.1),
          shape: BoxShape.circle,
          border: Border.all(
            color: Colors.white.withValues(alpha: 0.3),
            width: 1,
          ),
        ),
        child: Center(
          child: CustomIconWidget(
            iconName: iconName,
            color: isActive ? Colors.black : Colors.white,
            size: 7.w,
          ),
        ),
      ),
    );
  }

  Widget _buildEndCallButton() {
    return GestureDetector(
      onTap: () {
        HapticFeedback.heavyImpact();
        if (widget.onEndCall != null) widget.onEndCall!();
      },
      child: Container(
        width: 18.w,
        height: 18.w,
        decoration: BoxDecoration(
          color: Colors.red,
          shape: BoxShape.circle,
          boxShadow: [
            BoxShadow(
              color: Colors.red.withValues(alpha: 0.4),
              blurRadius: 12,
              offset: const Offset(0, 4),
            ),
          ],
        ),
        child: Center(
          child: CustomIconWidget(
            iconName: 'call_end',
            color: Colors.white,
            size: 8.w,
          ),
        ),
      ),
    );
  }

  Widget _buildEncryptionIndicator() {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 3.w, vertical: 1.h),
      decoration: BoxDecoration(
        color: AppTheme.getSuccessColor(true).withValues(alpha: 0.2),
        borderRadius: BorderRadius.circular(2.w),
        border: Border.all(
          color: AppTheme.getSuccessColor(true),
          width: 1,
        ),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          CustomIconWidget(
            iconName: 'lock',
            color: AppTheme.getSuccessColor(true),
            size: 4.w,
          ),
          SizedBox(width: 1.w),
          Text(
            'E2E',
            style: Theme.of(context).textTheme.bodySmall?.copyWith(
                  color: AppTheme.getSuccessColor(true),
                  fontWeight: FontWeight.w600,
                ),
          ),
        ],
      ),
    );
  }

  void _handleCallAction() {
    HapticFeedback.mediumImpact();
    if (widget.onStartCall != null) {
      widget.onStartCall!();
    }
  }

  void _showMinimizeOption() {
    // This would minimize the call interface and return to chat
    // Implementation would depend on the specific navigation pattern
  }

  String _getCallStateText() {
    switch (widget.callState) {
      case CallState.ringing:
        return 'Connecting...';
      case CallState.connected:
        return 'Secure Call Active';
      case CallState.ended:
        return 'Call Ended';
      default:
        return '';
    }
  }

  String _formatCallDuration() {
    final minutes = widget.callDuration.inMinutes;
    final seconds = widget.callDuration.inSeconds % 60;
    return '${minutes.toString().padLeft(2, '0')}:${seconds.toString().padLeft(2, '0')}';
  }
}
