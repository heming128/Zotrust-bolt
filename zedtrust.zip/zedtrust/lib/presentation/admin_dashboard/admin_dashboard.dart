import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

import '../../core/app_export.dart';
import '../../core/services/supabase_service.dart';
import '../../routes/app_routes.dart';
import './widgets/admin_analytics_chart_widget.dart';
import './widgets/admin_quick_actions_widget.dart';
import './widgets/admin_stats_card_widget.dart';
import './widgets/recent_activities_widget.dart';
import './widgets/system_health_widget.dart';

class AdminDashboard extends StatefulWidget {
  const AdminDashboard({Key? key}) : super(key: key);

  @override
  State<AdminDashboard> createState() => _AdminDashboardState();
}

class _AdminDashboardState extends State<AdminDashboard> {
  bool _isLoading = true;
  Map<String, dynamic> _dashboardData = {};
  List<Map<String, dynamic>> _recentActivities = [];
  Map<String, dynamic> _systemHealth = {};

  @override
  void initState() {
    super.initState();
    _loadDashboardData();
  }

  Future<void> _loadDashboardData() async {
    setState(() {
      _isLoading = true;
    });

    try {
      // Fetch admin dashboard data
      await Future.wait([
        _loadStatsData(),
        _loadRecentActivities(),
        _loadSystemHealth(),
      ]);
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Error loading dashboard: ${e.toString()}'),
            backgroundColor: Colors.red[700],
          ),
        );
      }
    } finally {
      setState(() {
        _isLoading = false;
      });
    }
  }

  Future<void> _loadStatsData() async {
    try {
      // Get total agents count
      final agentsCount =
          await SupabaseService.instance.client.from('agents').select().count();

      // Get verified agents count
      final verifiedAgentsCount = await SupabaseService.instance.client
          .from('agents')
          .select()
          .eq('is_verified', true)
          .count();

      // Get total locations count
      final locationsCount = await SupabaseService.instance.client
          .from('agent_locations')
          .select()
          .count();

      // Get active trades count
      final activeTradesCount = await SupabaseService.instance.client
          .from('trades')
          .select()
          .neq('status', 'COMPLETED')
          .neq('status', 'CANCELLED')
          .count();

      setState(() {
        _dashboardData = {
          'totalAgents': agentsCount.count,
          'verifiedAgents': verifiedAgentsCount.count,
          'totalLocations': locationsCount.count,
          'activeTrades': activeTradesCount.count,
          'pendingVerifications': agentsCount.count - verifiedAgentsCount.count,
        };
      });
    } catch (e) {
      print('Error loading stats: $e');
      // Fallback to mock data
      setState(() {
        _dashboardData = {
          'totalAgents': 25,
          'verifiedAgents': 18,
          'totalLocations': 67,
          'activeTrades': 142,
          'pendingVerifications': 7,
        };
      });
    }
  }

  Future<void> _loadRecentActivities() async {
    try {
      // Get recent trades
      final trades =
          await SupabaseService.instance.client.from('trades').select('''
            id, status, created_at,
            buyer_city, seller_city,
            agents!inner(name, alias)
          ''').order('created_at', ascending: false).limit(10);

      setState(() {
        _recentActivities = List<Map<String, dynamic>>.from(trades)
            .map((trade) => {
                  'id': trade['id'],
                  'type': 'trade',
                  'title': 'Trade ${trade['status']}',
                  'subtitle':
                      '${trade['buyer_city']} → ${trade['seller_city']}',
                  'agent': trade['agents']?['name'] ?? 'Unknown Agent',
                  'time': DateTime.parse(trade['created_at']),
                  'status': trade['status'],
                })
            .toList();
      });
    } catch (e) {
      print('Error loading activities: $e');
      // Fallback to mock data
      setState(() {
        _recentActivities = [
          {
            'id': '1',
            'type': 'agent_verified',
            'title': 'Agent Verified',
            'subtitle': 'Rajnikant Aagnya Hawala',
            'time': DateTime.now().subtract(const Duration(minutes: 15)),
            'status': 'success',
          },
          {
            'id': '2',
            'type': 'trade_created',
            'title': 'New Trade Created',
            'subtitle': 'Mumbai → Surat',
            'time': DateTime.now().subtract(const Duration(hours: 1)),
            'status': 'pending',
          },
          {
            'id': '3',
            'type': 'location_added',
            'title': 'Location Added',
            'subtitle': 'Pune - Koregaon Park',
            'time': DateTime.now().subtract(const Duration(hours: 2)),
            'status': 'success',
          },
        ];
      });
    }
  }

  Future<void> _loadSystemHealth() async {
    // Mock system health data
    setState(() {
      _systemHealth = {
        'apiStatus': 'healthy',
        'databaseStatus': 'healthy',
        'authStatus': 'healthy',
        'storageStatus': 'warning',
        'uptime': '99.9%',
        'responseTime': '120ms',
      };
    });
  }

  Future<void> _logout() async {
    try {
      await SupabaseService.instance.client.auth.signOut();
      if (mounted) {
        Navigator.pushNamedAndRemoveUntil(
          context,
          AppRoutes.adminAuthenticationPortal,
          (route) => false,
        );
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Logout failed: ${e.toString()}'),
          backgroundColor: Colors.red[700],
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0F172A),
      appBar: _buildAppBar(),
      drawer: _buildDrawer(),
      body: _isLoading
          ? const Center(
              child: CircularProgressIndicator(
                color: Color(0xFF3B82F6),
              ),
            )
          : RefreshIndicator(
              onRefresh: _loadDashboardData,
              child: SingleChildScrollView(
                padding: const EdgeInsets.all(24),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    _buildWelcomeSection(),
                    const SizedBox(height: 32),
                    _buildStatsGrid(),
                    const SizedBox(height: 32),
                    _buildQuickActions(),
                    const SizedBox(height: 32),
                    Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Expanded(
                          flex: 2,
                          child: _buildAnalyticsSection(),
                        ),
                        const SizedBox(width: 24),
                        Expanded(
                          child: Column(
                            children: [
                              _buildSystemHealthSection(),
                              const SizedBox(height: 24),
                              _buildRecentActivitiesSection(),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
    );
  }

  PreferredSizeWidget _buildAppBar() {
    return AppBar(
      backgroundColor: const Color(0xFF1E293B),
      elevation: 0,
      title: Text(
        'Admin Dashboard',
        style: GoogleFonts.inter(
          fontSize: 20,
          fontWeight: FontWeight.w600,
          color: Colors.white,
        ),
      ),
      actions: [
        IconButton(
          onPressed: _loadDashboardData,
          icon: const Icon(Icons.refresh, color: Colors.white),
          tooltip: 'Refresh',
        ),
        PopupMenuButton<String>(
          onSelected: (value) {
            switch (value) {
              case 'logout':
                _logout();
                break;
            }
          },
          itemBuilder: (context) => [
            PopupMenuItem(
              value: 'logout',
              child: Row(
                children: [
                  const Icon(Icons.logout, size: 20),
                  const SizedBox(width: 8),
                  Text(
                    'Logout',
                    style: GoogleFonts.inter(fontSize: 14),
                  ),
                ],
              ),
            ),
          ],
          icon: const Icon(Icons.account_circle, color: Colors.white),
        ),
      ],
    );
  }

  Widget _buildDrawer() {
    return Drawer(
      backgroundColor: const Color(0xFF1E293B),
      child: Column(
        children: [
          DrawerHeader(
            decoration: const BoxDecoration(
              color: Color(0xFF0F172A),
            ),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const Icon(
                  Icons.admin_panel_settings,
                  color: Color(0xFF3B82F6),
                  size: 48,
                ),
                const SizedBox(height: 12),
                Text(
                  'ZedTrust Admin',
                  style: GoogleFonts.inter(
                    fontSize: 18,
                    fontWeight: FontWeight.w600,
                    color: Colors.white,
                  ),
                ),
              ],
            ),
          ),
          _buildDrawerItem(
            icon: Icons.dashboard,
            title: 'Dashboard',
            isSelected: true,
            onTap: () {
              Navigator.pop(context);
            },
          ),
          _buildDrawerItem(
            icon: Icons.people,
            title: 'Agent Management',
            onTap: () {
              Navigator.pop(context);
              Navigator.pushNamed(context, AppRoutes.adminAgentManagement);
            },
          ),
          _buildDrawerItem(
            icon: Icons.location_on,
            title: 'Location Hub',
            onTap: () {
              Navigator.pop(context);
              Navigator.pushNamed(context, AppRoutes.locationManagementHub);
            },
          ),
          _buildDrawerItem(
            icon: Icons.verified_user,
            title: 'Verification Center',
            onTap: () {
              Navigator.pop(context);
              Navigator.pushNamed(context, AppRoutes.agentVerificationCenter);
            },
          ),
          _buildDrawerItem(
            icon: Icons.analytics,
            title: 'Analytics',
            onTap: () {
              Navigator.pop(context);
              // Navigate to analytics screen
            },
          ),
          const Divider(color: Color(0xFF475569)),
          _buildDrawerItem(
            icon: Icons.account_balance_wallet,
            title: 'Platform Settings',
            onTap: () {
              Navigator.pop(context);
              Navigator.pushNamed(context, AppRoutes.adminPlatformSettings);
            },
          ),
          _buildDrawerItem(
            icon: Icons.settings,
            title: 'Settings',
            onTap: () {
              Navigator.pop(context);
              // Navigate to general settings screen
            },
          ),
          const Spacer(),
          _buildDrawerItem(
            icon: Icons.logout,
            title: 'Logout',
            isDestructive: true,
            onTap: _logout,
          ),
        ],
      ),
    );
  }

  Widget _buildDrawerItem({
    required IconData icon,
    required String title,
    required VoidCallback onTap,
    bool isSelected = false,
    bool isDestructive = false,
  }) {
    return ListTile(
      leading: Icon(
        icon,
        color: isDestructive
            ? Colors.red[400]
            : isSelected
                ? const Color(0xFF3B82F6)
                : Colors.grey[400],
      ),
      title: Text(
        title,
        style: GoogleFonts.inter(
          fontSize: 14,
          fontWeight: isSelected ? FontWeight.w600 : FontWeight.w400,
          color: isDestructive
              ? Colors.red[400]
              : isSelected
                  ? const Color(0xFF3B82F6)
                  : Colors.white,
        ),
      ),
      tileColor: isSelected ? const Color(0xFF3B82F6).withAlpha(26) : null,
      onTap: onTap,
    );
  }

  Widget _buildWelcomeSection() {
    final user = SupabaseService.instance.client.auth.currentUser;
    return Container(
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [Color(0xFF3B82F6), Color(0xFF1E40AF)],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(16),
      ),
      child: Row(
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Welcome back, Administrator',
                  style: GoogleFonts.inter(
                    fontSize: 24,
                    fontWeight: FontWeight.w700,
                    color: Colors.white,
                  ),
                ),
                const SizedBox(height: 8),
                Text(
                  user?.email ?? 'admin@zedtrust.com',
                  style: GoogleFonts.inter(
                    fontSize: 14,
                    color: Colors.blue[100],
                  ),
                ),
                const SizedBox(height: 16),
                Text(
                  'Manage agents, locations, and monitor system operations from your central control panel.',
                  style: GoogleFonts.inter(
                    fontSize: 14,
                    color: Colors.blue[50],
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(width: 16),
          Container(
            width: 80,
            height: 80,
            decoration: BoxDecoration(
              color: Colors.white.withAlpha(51),
              borderRadius: BorderRadius.circular(40),
            ),
            child: const Icon(
              Icons.admin_panel_settings,
              color: Colors.white,
              size: 40,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildStatsGrid() {
    return GridView.builder(
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 5,
        crossAxisSpacing: 16,
        mainAxisSpacing: 16,
        childAspectRatio: 1.2,
      ),
      itemCount: 5,
      itemBuilder: (context, index) {
        final stats = [
          {
            'title': 'Total Agents',
            'value': _dashboardData['totalAgents']?.toString() ?? '0',
            'icon': Icons.people,
            'color': const Color(0xFF10B981),
            'change': '+12%',
          },
          {
            'title': 'Verified Agents',
            'value': _dashboardData['verifiedAgents']?.toString() ?? '0',
            'icon': Icons.verified,
            'color': const Color(0xFF3B82F6),
            'change': '+8%',
          },
          {
            'title': 'Locations',
            'value': _dashboardData['totalLocations']?.toString() ?? '0',
            'icon': Icons.location_on,
            'color': const Color(0xFF8B5CF6),
            'change': '+15%',
          },
          {
            'title': 'Active Trades',
            'value': _dashboardData['activeTrades']?.toString() ?? '0',
            'icon': Icons.trending_up,
            'color': const Color(0xFF06B6D4),
            'change': '+23%',
          },
          {
            'title': 'Pending Reviews',
            'value': _dashboardData['pendingVerifications']?.toString() ?? '0',
            'icon': Icons.pending_actions,
            'color': const Color(0xFFF59E0B),
            'change': '-5%',
          },
        ];

        return AdminStatsCardWidget(
          title: stats[index]['title'] as String,
          value: stats[index]['value'] as String,
          icon: stats[index]['icon'] as IconData,
          color: stats[index]['color'] as Color,
          change: stats[index]['change'] as String,
        );
      },
    );
  }

  Widget _buildQuickActions() {
    return AdminQuickActionsWidget(
      onAgentManagement: () {
        Navigator.pushNamed(context, AppRoutes.adminAgentManagement);
      },
      onLocationManagement: () {
        Navigator.pushNamed(context, AppRoutes.locationManagementHub);
      },
      onVerificationCenter: () {
        Navigator.pushNamed(context, AppRoutes.agentVerificationCenter);
      },
      onPlatformSettings: () {
        Navigator.pushNamed(context, AppRoutes.adminPlatformSettings);
      },
    );
  }

  Widget _buildAnalyticsSection() {
    return Container(
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(
        color: const Color(0xFF1E293B),
        borderRadius: BorderRadius.circular(16),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Trade Analytics',
            style: GoogleFonts.inter(
              fontSize: 18,
              fontWeight: FontWeight.w600,
              color: Colors.white,
            ),
          ),
          const SizedBox(height: 24),
          AdminAnalyticsChartWidget(),
        ],
      ),
    );
  }

  Widget _buildSystemHealthSection() {
    return SystemHealthWidget(healthData: _systemHealth);
  }

  Widget _buildRecentActivitiesSection() {
    return RecentActivitiesWidget(activities: _recentActivities);
  }
}
