import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class AdminQuickActionsWidget extends StatelessWidget {
  final VoidCallback onAgentManagement;
  final VoidCallback onLocationManagement;
  final VoidCallback onVerificationCenter;
  final VoidCallback? onPlatformSettings;

  const AdminQuickActionsWidget({
    Key? key,
    required this.onAgentManagement,
    required this.onLocationManagement,
    required this.onVerificationCenter,
    this.onPlatformSettings,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(
        color: const Color(0xFF1E293B),
        borderRadius: BorderRadius.circular(16),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Quick Actions',
            style: GoogleFonts.inter(
              fontSize: 18,
              fontWeight: FontWeight.w600,
              color: Colors.white,
            ),
          ),
          const SizedBox(height: 20),
          Row(
            children: [
              Expanded(
                child: _buildActionCard(
                  icon: Icons.people_outline,
                  title: 'Agent Management',
                  subtitle: 'Manage and verify agents',
                  color: const Color(0xFF3B82F6),
                  onTap: onAgentManagement,
                ),
              ),
              const SizedBox(width: 16),
              Expanded(
                child: _buildActionCard(
                  icon: Icons.location_on_outlined,
                  title: 'Location Hub',
                  subtitle: 'Manage agent locations',
                  color: const Color(0xFF8B5CF6),
                  onTap: onLocationManagement,
                ),
              ),
              const SizedBox(width: 16),
              Expanded(
                child: _buildActionCard(
                  icon: Icons.verified_user_outlined,
                  title: 'Verification Center',
                  subtitle: 'Review pending agents',
                  color: const Color(0xFF10B981),
                  onTap: onVerificationCenter,
                ),
              ),
              if (onPlatformSettings != null) ...[
                const SizedBox(width: 16),
                Expanded(
                  child: _buildActionCard(
                    icon: Icons.account_balance_wallet_outlined,
                    title: 'Platform Settings',
                    subtitle: 'Configure fees & wallet',
                    color: const Color(0xFFF59E0B),
                    onTap: onPlatformSettings!,
                  ),
                ),
              ],
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildActionCard({
    required IconData icon,
    required String title,
    required String subtitle,
    required Color color,
    required VoidCallback onTap,
  }) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(12),
      child: Container(
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(
          color: const Color(0xFF0F172A),
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: const Color(0xFF334155)),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: color.withAlpha(26),
                borderRadius: BorderRadius.circular(8),
              ),
              child: Icon(
                icon,
                color: color,
                size: 24,
              ),
            ),
            const SizedBox(height: 16),
            Text(
              title,
              style: GoogleFonts.inter(
                fontSize: 14,
                fontWeight: FontWeight.w600,
                color: Colors.white,
              ),
            ),
            const SizedBox(height: 4),
            Text(
              subtitle,
              style: GoogleFonts.inter(
                fontSize: 12,
                color: Colors.grey[400],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
