import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class SystemHealthWidget extends StatelessWidget {
  final Map<String, dynamic> healthData;

  const SystemHealthWidget({
    Key? key,
    required this.healthData,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(
        color: const Color(0xFF1E293B),
        borderRadius: BorderRadius.circular(16),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                'System Health',
                style: GoogleFonts.inter(
                  fontSize: 18,
                  fontWeight: FontWeight.w600,
                  color: Colors.white,
                ),
              ),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                decoration: BoxDecoration(
                  color: const Color(0xFF10B981).withAlpha(26),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Text(
                  'All Systems Operational',
                  style: GoogleFonts.inter(
                    fontSize: 10,
                    fontWeight: FontWeight.w500,
                    color: const Color(0xFF10B981),
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 24),
          _buildHealthItem(
            'API Service',
            healthData['apiStatus'] ?? 'unknown',
            Icons.api,
          ),
          const SizedBox(height: 16),
          _buildHealthItem(
            'Database',
            healthData['databaseStatus'] ?? 'unknown',
            Icons.storage,
          ),
          const SizedBox(height: 16),
          _buildHealthItem(
            'Authentication',
            healthData['authStatus'] ?? 'unknown',
            Icons.security,
          ),
          const SizedBox(height: 16),
          _buildHealthItem(
            'File Storage',
            healthData['storageStatus'] ?? 'unknown',
            Icons.cloud_upload,
          ),
          const SizedBox(height: 24),
          const Divider(color: Color(0xFF334155)),
          const SizedBox(height: 16),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              _buildMetric(
                'Uptime',
                healthData['uptime'] ?? '0%',
                const Color(0xFF10B981),
              ),
              _buildMetric(
                'Response Time',
                healthData['responseTime'] ?? '0ms',
                const Color(0xFF3B82F6),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildHealthItem(String name, String status, IconData icon) {
    final Color statusColor = _getStatusColor(status);
    final IconData statusIcon = _getStatusIcon(status);

    return Row(
      children: [
        Container(
          padding: const EdgeInsets.all(6),
          decoration: BoxDecoration(
            color: statusColor.withAlpha(26),
            borderRadius: BorderRadius.circular(6),
          ),
          child: Icon(
            icon,
            color: statusColor,
            size: 16,
          ),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: Text(
            name,
            style: GoogleFonts.inter(
              fontSize: 14,
              color: Colors.white,
            ),
          ),
        ),
        Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(
              statusIcon,
              color: statusColor,
              size: 14,
            ),
            const SizedBox(width: 4),
            Text(
              status.toUpperCase(),
              style: GoogleFonts.inter(
                fontSize: 12,
                fontWeight: FontWeight.w500,
                color: statusColor,
              ),
            ),
          ],
        ),
      ],
    );
  }

  Widget _buildMetric(String label, String value, Color color) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        Text(
          value,
          style: GoogleFonts.inter(
            fontSize: 20,
            fontWeight: FontWeight.w700,
            color: color,
          ),
        ),
        const SizedBox(height: 4),
        Text(
          label,
          style: GoogleFonts.inter(
            fontSize: 12,
            color: Colors.grey[400],
          ),
        ),
      ],
    );
  }

  Color _getStatusColor(String status) {
    switch (status.toLowerCase()) {
      case 'healthy':
      case 'operational':
        return const Color(0xFF10B981);
      case 'warning':
      case 'degraded':
        return const Color(0xFFF59E0B);
      case 'critical':
      case 'down':
      case 'error':
        return const Color(0xFFEF4444);
      default:
        return const Color(0xFF6B7280);
    }
  }

  IconData _getStatusIcon(String status) {
    switch (status.toLowerCase()) {
      case 'healthy':
      case 'operational':
        return Icons.check_circle;
      case 'warning':
      case 'degraded':
        return Icons.warning;
      case 'critical':
      case 'down':
      case 'error':
        return Icons.error;
      default:
        return Icons.help;
    }
  }
}
