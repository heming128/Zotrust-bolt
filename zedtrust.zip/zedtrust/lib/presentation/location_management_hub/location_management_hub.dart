import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:sizer/sizer.dart';

import '../../core/app_export.dart';
import '../../core/services/supabase_service.dart';
import './widgets/add_location_modal.dart';
import './widgets/bulk_import_widget.dart';
import './widgets/location_analytics_widget.dart';
import './widgets/location_map_widget.dart';
import './widgets/location_tree_widget.dart';

class LocationManagementHub extends StatefulWidget {
  const LocationManagementHub({super.key});

  @override
  State<LocationManagementHub> createState() => _LocationManagementHubState();
}

class _LocationManagementHubState extends State<LocationManagementHub>
    with TickerProviderStateMixin {
  final TextEditingController _searchController = TextEditingController();
  final SupabaseService _supabaseService = SupabaseService.instance;

  List<Map<String, dynamic>> _locations = [];
  List<Map<String, dynamic>> _filteredLocations = [];
  bool _isLoading = false;
  bool _isMapView = false;
  String _selectedCity = 'all';
  String _selectedStatusFilter = 'all';

  late TabController _tabController;
  late AnimationController _fadeController;
  late Animation<double> _fadeAnimation;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this);
    _fadeController = AnimationController(
      duration: const Duration(milliseconds: 800),
      vsync: this,
    );
    _fadeAnimation = CurvedAnimation(
      parent: _fadeController,
      curve: Curves.easeInOut,
    );
    _loadLocations();
    _fadeController.forward();
  }

  @override
  void dispose() {
    _tabController.dispose();
    _fadeController.dispose();
    _searchController.dispose();
    super.dispose();
  }

  Future<void> _loadLocations() async {
    setState(() => _isLoading = true);

    try {
      // Load real agent locations from Supabase
      final locations = <Map<String, dynamic>>[];

      // Get all agents first
      final agents = await _supabaseService.getAllAgentsWithLocationCounts();

      // Get locations for each agent
      for (final agent in agents) {
        final agentLocations = await _supabaseService
            .getAgentLocationsForManagement(agent['id']);

        for (final location in agentLocations) {
          locations.add({
            ...location,
            'name': '${location['display_alias']} - ${agent['name']}',
            'address':
                '${location['address_line']}, ${location['city']}, ${location['area']}',
            'status': location['is_active'] ? 'active' : 'inactive',
            'agents_count': 1, // Each location belongs to one agent
            'capacity': 15, // Default capacity
            'operating_hours': '09:00-20:00',
            'trade_volume': 0, // Would need to be calculated from trades
            'coordinates': {
              'lat': location['geo_lat'] ?? 0.0,
              'lng': location['geo_lng'] ?? 0.0,
            },
            'agent_name': agent['name'],
            'agent_id': agent['id'],
          });
        }
      }

      setState(() {
        _locations = locations;
        _filteredLocations = locations;
        _isLoading = false;
      });
    } catch (e) {
      setState(() => _isLoading = false);
      _showErrorToast('Failed to load locations: $e');
    }
  }

  void _filterLocations() {
    setState(() {
      _filteredLocations =
          _locations.where((location) {
            final matchesSearch =
                location['name'].toString().toLowerCase().contains(
                  _searchController.text.toLowerCase(),
                ) ||
                location['address'].toString().toLowerCase().contains(
                  _searchController.text.toLowerCase(),
                );

            final matchesCity =
                _selectedCity == 'all' || location['city'] == _selectedCity;

            final matchesStatus =
                _selectedStatusFilter == 'all' ||
                (_selectedStatusFilter == 'active' &&
                    location['status'] == 'active') ||
                (_selectedStatusFilter == 'inactive' &&
                    location['status'] == 'inactive') ||
                (_selectedStatusFilter == 'maintenance' &&
                    location['status'] == 'maintenance') ||
                (_selectedStatusFilter == 'high_capacity' &&
                    location['agents_count'] >= (location['capacity'] * 0.8));

            return matchesSearch && matchesCity && matchesStatus;
          }).toList();
    });
  }

  void _showErrorToast(String message) {
    Fluttertoast.showToast(
      msg: message,
      toastLength: Toast.LENGTH_LONG,
      backgroundColor: AppTheme.errorLight,
      textColor: Colors.white,
    );
  }

  void _showSuccessToast(String message) {
    Fluttertoast.showToast(
      msg: message,
      toastLength: Toast.LENGTH_SHORT,
      backgroundColor: AppTheme.successLight,
      textColor: Colors.white,
    );
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;

    return Scaffold(
      backgroundColor: Theme.of(context).scaffoldBackgroundColor,
      appBar: AppBar(
        title: Text(
          'Location Management Hub',
          style: GoogleFonts.inter(
            fontSize: 18.sp,
            fontWeight: FontWeight.w600,
            color: Theme.of(context).textTheme.titleLarge?.color,
          ),
        ),
        centerTitle: true,
        elevation: 0,
        backgroundColor: Theme.of(context).scaffoldBackgroundColor,
        leading: IconButton(
          onPressed: () => Navigator.pop(context),
          icon: Icon(
            Icons.arrow_back_ios,
            color: Theme.of(context).iconTheme.color,
            size: 20.sp,
          ),
        ),
        actions: [
          IconButton(
            onPressed: () {
              setState(() {
                _isMapView = !_isMapView;
              });
            },
            icon: Container(
              padding: EdgeInsets.all(8.sp),
              decoration: BoxDecoration(
                color: _isMapView ? AppTheme.primaryLight : Colors.transparent,
                borderRadius: BorderRadius.circular(8.sp),
              ),
              child: CustomIconWidget(
                iconName: _isMapView ? 'list' : 'map',
                color:
                    _isMapView
                        ? Colors.white
                        : Theme.of(context).iconTheme.color,
                size: 18,
              ),
            ),
          ),
          IconButton(
            onPressed: _showAddLocationModal,
            icon: Container(
              padding: EdgeInsets.all(8.sp),
              decoration: BoxDecoration(
                color: AppTheme.primaryLight,
                borderRadius: BorderRadius.circular(8.sp),
              ),
              child: CustomIconWidget(
                iconName: 'add_location',
                color: Colors.white,
                size: 18,
              ),
            ),
          ),
          SizedBox(width: 16.w),
        ],
        bottom: TabBar(
          controller: _tabController,
          labelColor: AppTheme.primaryLight,
          unselectedLabelColor: AppTheme.textSecondaryLight,
          indicatorColor: AppTheme.primaryLight,
          labelStyle: GoogleFonts.inter(
            fontSize: 14.sp,
            fontWeight: FontWeight.w600,
          ),
          unselectedLabelStyle: GoogleFonts.inter(
            fontSize: 14.sp,
            fontWeight: FontWeight.w400,
          ),
          tabs: [Tab(text: 'Locations'), Tab(text: 'Analytics')],
        ),
      ),
      body: FadeTransition(
        opacity: _fadeAnimation,
        child: TabBarView(
          controller: _tabController,
          children: [_buildLocationsTab(isDark), _buildAnalyticsTab()],
        ),
      ),
    );
  }

  Widget _buildLocationsTab(bool isDark) {
    return Column(
      children: [
        // Statistics Header
        Container(
          padding: EdgeInsets.all(16.sp),
          decoration: BoxDecoration(
            color: AppTheme.primaryLight.withAlpha(26),
            border: Border(
              bottom: BorderSide(
                color: AppTheme.getNeutralColor(!isDark),
                width: 0.5,
              ),
            ),
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: [
              _buildStatItem(
                'Total Locations',
                '${_locations.length}',
                AppTheme.primaryLight,
              ),
              _buildStatItem(
                'Active',
                '${_locations.where((loc) => loc['status'] == 'active').length}',
                AppTheme.successLight,
              ),
              _buildStatItem(
                'Total Agents',
                '${_locations.fold(0, (sum, loc) => sum + (loc['agents_count'] as int))}',
                AppTheme.primaryLight,
              ),
            ],
          ),
        ),

        // Search and Filter Bar
        Container(
          padding: EdgeInsets.all(16.sp),
          decoration: BoxDecoration(
            color: Theme.of(context).cardColor,
            boxShadow: [
              BoxShadow(
                color: AppTheme.shadowLight,
                blurRadius: 4,
                offset: const Offset(0, 1),
              ),
            ],
          ),
          child: Column(
            children: [
              // Search Bar
              Container(
                decoration: BoxDecoration(
                  color: isDark ? AppTheme.cardDark : AppTheme.surfaceLight,
                  borderRadius: BorderRadius.circular(12.sp),
                  border: Border.all(color: AppTheme.getNeutralColor(!isDark)),
                ),
                child: TextField(
                  controller: _searchController,
                  onChanged: (_) => _filterLocations(),
                  decoration: InputDecoration(
                    hintText: 'Search locations by name or address...',
                    prefixIcon: Icon(
                      Icons.search,
                      color: AppTheme.textSecondaryLight,
                      size: 20.sp,
                    ),
                    border: InputBorder.none,
                    contentPadding: EdgeInsets.symmetric(
                      horizontal: 16.w,
                      vertical: 12.h,
                    ),
                  ),
                ),
              ),

              SizedBox(height: 12.h),

              // Filter Chips
              Row(
                children: [
                  Expanded(child: _buildCitySelector()),
                  SizedBox(width: 12.w),
                  Expanded(child: _buildStatusFilter()),
                ],
              ),
            ],
          ),
        ),

        // Bulk Import Section
        BulkImportWidget(
          onImportCSV: _handleBulkImport,
          onDownloadTemplate: _downloadTemplate,
        ),

        // Locations Content
        Expanded(
          child:
              _isLoading
                  ? const Center(child: CircularProgressIndicator())
                  : _filteredLocations.isEmpty
                  ? _buildEmptyState()
                  : _isMapView
                  ? LocationMapWidget(
                    locations: _filteredLocations,
                    onLocationTap: _showLocationDetails,
                  )
                  : RefreshIndicator(
                    onRefresh: _loadLocations,
                    child: LocationTreeWidget(
                      locations: _filteredLocations,
                      onLocationTap: _showLocationDetails,
                      onStatusChange: _updateLocationStatus,
                      onAssignAgent: _assignAgentToLocation,
                    ),
                  ),
        ),
      ],
    );
  }

  Widget _buildAnalyticsTab() {
    return LocationAnalyticsWidget(
      locations: _locations,
      onExportReport: _exportAnalyticsReport,
    );
  }

  Widget _buildStatItem(String label, String value, Color color) {
    return Column(
      children: [
        Text(
          value,
          style: GoogleFonts.inter(
            fontSize: 20.sp,
            fontWeight: FontWeight.w700,
            color: color,
          ),
        ),
        SizedBox(height: 4.h),
        Text(
          label,
          style: GoogleFonts.inter(
            fontSize: 12.sp,
            color: AppTheme.textSecondaryLight,
          ),
          textAlign: TextAlign.center,
        ),
      ],
    );
  }

  Widget _buildCitySelector() {
    final cities = [
      'all',
      ...{'Mumbai', 'Surat', 'Delhi'},
    ];

    return DropdownButtonFormField<String>(
      value: _selectedCity,
      decoration: InputDecoration(
        labelText: 'City',
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(8.sp)),
        contentPadding: EdgeInsets.symmetric(horizontal: 12.w, vertical: 8.h),
      ),
      items:
          cities
              .map(
                (city) => DropdownMenuItem(
                  value: city,
                  child: Text(
                    city == 'all' ? 'All Cities' : city,
                    style: GoogleFonts.inter(fontSize: 14.sp),
                  ),
                ),
              )
              .toList(),
      onChanged: (value) {
        setState(() {
          _selectedCity = value!;
        });
        _filterLocations();
      },
    );
  }

  Widget _buildStatusFilter() {
    final statuses = [
      {'key': 'all', 'label': 'All Status'},
      {'key': 'active', 'label': 'Active'},
      {'key': 'inactive', 'label': 'Inactive'},
      {'key': 'maintenance', 'label': 'Maintenance'},
      {'key': 'high_capacity', 'label': 'High Capacity'},
    ];

    return DropdownButtonFormField<String>(
      value: _selectedStatusFilter,
      decoration: InputDecoration(
        labelText: 'Status',
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(8.sp)),
        contentPadding: EdgeInsets.symmetric(horizontal: 12.w, vertical: 8.h),
      ),
      items:
          statuses
              .map(
                (status) => DropdownMenuItem(
                  value: status['key'],
                  child: Text(
                    status['label']!,
                    style: GoogleFonts.inter(fontSize: 14.sp),
                  ),
                ),
              )
              .toList(),
      onChanged: (value) {
        setState(() {
          _selectedStatusFilter = value!;
        });
        _filterLocations();
      },
    );
  }

  Widget _buildEmptyState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          CustomIconWidget(
            iconName: 'location_off',
            color: AppTheme.textSecondaryLight,
            size: 64,
          ),
          SizedBox(height: 24.h),
          Text(
            'No Locations Found',
            style: GoogleFonts.inter(
              fontSize: 18.sp,
              fontWeight: FontWeight.w600,
              color: AppTheme.textPrimaryLight,
            ),
          ),
          SizedBox(height: 8.h),
          Text(
            'Add your first location to get started',
            style: GoogleFonts.inter(
              fontSize: 14.sp,
              color: AppTheme.textSecondaryLight,
            ),
          ),
          SizedBox(height: 24.h),
          ElevatedButton.icon(
            onPressed: _showAddLocationModal,
            icon: CustomIconWidget(
              iconName: 'add_location',
              color: Colors.white,
              size: 16,
            ),
            label: Text('Add Location'),
            style: ElevatedButton.styleFrom(
              padding: EdgeInsets.symmetric(horizontal: 24.w, vertical: 12.h),
            ),
          ),
        ],
      ),
    );
  }

  void _showAddLocationModal() {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder:
          (context) => AddLocationModal(
            onLocationAdded: (location) {
              setState(() {
                _locations.add(location);
                _filteredLocations.add(location);
              });
              Navigator.pop(context);
              _showSuccessToast('Location added successfully');
            },
          ),
    );
  }

  void _showLocationDetails(Map<String, dynamic> location) {
    // Show detailed location modal or navigate to location details screen
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) => _buildLocationDetailsModal(location),
    );
  }

  Widget _buildLocationDetailsModal(Map<String, dynamic> location) {
    return DraggableScrollableSheet(
      initialChildSize: 0.7,
      maxChildSize: 0.9,
      minChildSize: 0.5,
      builder: (context, scrollController) {
        return Container(
          decoration: BoxDecoration(
            color: Theme.of(context).cardColor,
            borderRadius: BorderRadius.vertical(top: Radius.circular(20.sp)),
          ),
          child: Column(
            children: [
              // Handle bar
              Container(
                margin: EdgeInsets.only(top: 12.h),
                width: 40.w,
                height: 4.h,
                decoration: BoxDecoration(
                  color: AppTheme.getNeutralColor(true),
                  borderRadius: BorderRadius.circular(2.sp),
                ),
              ),

              // Header with location info
              Padding(
                padding: EdgeInsets.all(20.sp),
                child: Row(
                  children: [
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            location['name'] ?? 'Unknown Location',
                            style: GoogleFonts.inter(
                              fontSize: 20.sp,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                          Text(
                            location['address'] ?? '',
                            style: GoogleFonts.inter(
                              fontSize: 12.sp,
                              color: AppTheme.textSecondaryLight,
                            ),
                          ),
                        ],
                      ),
                    ),
                    Container(
                      padding: EdgeInsets.symmetric(
                        horizontal: 12.w,
                        vertical: 6.h,
                      ),
                      decoration: BoxDecoration(
                        color: _getStatusColor(
                          location['status'],
                        ).withAlpha(26),
                        borderRadius: BorderRadius.circular(8.sp),
                      ),
                      child: Text(
                        (location['status'] as String).toUpperCase(),
                        style: GoogleFonts.inter(
                          fontSize: 12.sp,
                          fontWeight: FontWeight.w500,
                          color: _getStatusColor(location['status']),
                        ),
                      ),
                    ),
                  ],
                ),
              ),

              // Location details content would go here...
              Expanded(
                child: SingleChildScrollView(
                  controller: scrollController,
                  padding: EdgeInsets.symmetric(horizontal: 20.w),
                  child: Column(
                    children: [
                      // Add detailed location information here
                      Text('Location details would be implemented here...'),
                      SizedBox(height: 100.h),
                    ],
                  ),
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  Color _getStatusColor(String status) {
    switch (status) {
      case 'active':
        return AppTheme.successLight;
      case 'inactive':
        return AppTheme.errorLight;
      case 'maintenance':
        return AppTheme.warningLight;
      default:
        return AppTheme.textSecondaryLight;
    }
  }

  void _updateLocationStatus(String locationId, String newStatus) async {
    try {
      // Find the location in our list
      final location = _locations.firstWhere((loc) => loc['id'] == locationId);
      final agentId = location['agent_id'];

      // Update location status in Supabase
      await _supabaseService.client
          .from('agent_locations')
          .update({'is_active': newStatus == 'active'})
          .eq('id', locationId);

      setState(() {
        final index = _locations.indexWhere((loc) => loc['id'] == locationId);
        if (index != -1) {
          _locations[index]['status'] = newStatus;
        }
        final filteredIndex = _filteredLocations.indexWhere(
          (loc) => loc['id'] == locationId,
        );
        if (filteredIndex != -1) {
          _filteredLocations[filteredIndex]['status'] = newStatus;
        }
      });

      _showSuccessToast('Location status updated successfully');
    } catch (e) {
      _showErrorToast('Failed to update status: $e');
    }
  }

  void _assignAgentToLocation(String locationId, String agentId) async {
    try {
      // This would involve creating a new assignment record
      // For now, show success message
      _showSuccessToast('Agent assignment feature coming soon');
    } catch (e) {
      _showErrorToast('Failed to assign agent: $e');
    }
  }

  void _handleBulkImport(List<Map<String, dynamic>> importedLocations) async {
    try {
      // Simulate bulk import process
      await Future.delayed(const Duration(seconds: 2));

      setState(() {
        _locations.addAll(importedLocations);
        _filteredLocations.addAll(importedLocations);
      });

      _showSuccessToast(
        '${importedLocations.length} locations imported successfully',
      );
    } catch (e) {
      _showErrorToast('Failed to import locations: $e');
    }
  }

  void _downloadTemplate() {
    // Simulate template download
    _showSuccessToast('Template downloaded successfully');
  }

  void _exportAnalyticsReport() {
    // Simulate report export
    _showSuccessToast('Analytics report exported successfully');
  }
}
