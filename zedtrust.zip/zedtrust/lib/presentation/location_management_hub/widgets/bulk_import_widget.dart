import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:sizer/sizer.dart';
import '../../../theme/app_theme.dart';
import '../../../widgets/custom_icon_widget.dart';

class BulkImportWidget extends StatelessWidget {
  final Function(List<Map<String, dynamic>>) onImportCSV;
  final VoidCallback onDownloadTemplate;

  const BulkImportWidget({
    super.key,
    required this.onImportCSV,
    required this.onDownloadTemplate,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: EdgeInsets.symmetric(horizontal: 16.w, vertical: 8.h),
      padding: EdgeInsets.all(16.sp),
      decoration: BoxDecoration(
        
        borderRadius: BorderRadius.circular(12.sp),
        border: Border.all()),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              CustomIconWidget(
                iconName: 'file_upload',
                
                size: 20),
              SizedBox(width: 8.w),
              Expanded(
                child: Text(
                  'Bulk Import Locations',
                  style: GoogleFonts.inter(
                    fontSize: 14.sp,
                    fontWeight: FontWeight.w600))),
            ]),
          
          SizedBox(height: 8.h),
          
          Text(
            'Import multiple locations at once using a CSV file. Download the template to see the required format.',
            style: GoogleFonts.inter(
              fontSize: 12.sp,
              color: AppTheme.textSecondaryLight)),
          
          SizedBox(height: 12.h),
          
          Row(
            children: [
              Expanded(
                child: OutlinedButton.icon(
                  onPressed: onDownloadTemplate,
                  icon: CustomIconWidget(
                    iconName: 'download',
                    
                    size: 16),
                  label: Text(
                    'Download Template',
                    style: GoogleFonts.inter(
                      fontSize: 12.sp,
                      fontWeight: FontWeight.w500)),
                  style: OutlinedButton.styleFrom(
                    side: BorderSide()))),
              SizedBox(width: 8.w),
              Expanded(
                child: ElevatedButton.icon(
                  onPressed: () => _showImportDialog(context),
                  icon: CustomIconWidget(
                    iconName: 'upload_file',
                    color: Colors.white,
                    size: 16),
                  label: Text(
                    'Import CSV',
                    style: GoogleFonts.inter(
                      fontSize: 12.sp,
                      fontWeight: FontWeight.w500,
                      color: Colors.white)))),
            ]),
        ]));
  }

  void _showImportDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Row(
          children: [
            CustomIconWidget(
              iconName: 'file_upload',
              
              size: 24),
            SizedBox(width: 8.w),
            Text(
              'Import Locations',
              style: GoogleFonts.inter(
                fontWeight: FontWeight.w600)),
          ]),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Select a CSV file to import locations. Make sure the file follows the template format.',
              style: GoogleFonts.inter(fontSize: 14.sp)),
            SizedBox(height: 16.h),
            
            // File selection area
            Container(
              width: double.infinity,
              padding: EdgeInsets.all(24.sp),
              decoration: BoxDecoration(
                border: Border.all(
                  color: AppTheme.getNeutralColor(true),
                  style: BorderStyle.solid),
                borderRadius: BorderRadius.circular(8.sp)),
              child: Column(
                children: [
                  CustomIconWidget(
                    iconName: 'cloud_upload',
                    color: AppTheme.textSecondaryLight,
                    size: 32),
                  SizedBox(height: 8.h),
                  Text(
                    'Click to select CSV file',
                    style: GoogleFonts.inter(
                      fontSize: 12.sp,
                      color: AppTheme.textSecondaryLight)),
                  Text(
                    'or drag and drop here',
                    style: GoogleFonts.inter(
                      fontSize: 10.sp,
                      color: AppTheme.textSecondaryLight)),
                ])),
            
            SizedBox(height: 12.h),
            
            Container(
              padding: EdgeInsets.all(12.sp),
              decoration: BoxDecoration(
                color: AppTheme.warningLight.withAlpha(26),
                borderRadius: BorderRadius.circular(8.sp)),
              child: Row(
                children: [
                  CustomIconWidget(
                    iconName: 'info',
                    color: AppTheme.warningLight,
                    size: 16),
                  SizedBox(width: 8.w),
                  Expanded(
                    child: Text(
                      'Ensure your CSV includes: Name, City, Address, Capacity columns',
                      style: GoogleFonts.inter(
                        fontSize: 11.sp,
                        color: AppTheme.warningLight))),
                ])),
          ]),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text('Cancel')),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(context);
              _simulateFileImport(context);
            },
            style: ElevatedButton.styleFrom(),
            child: Text(
              'Import',
              style: GoogleFonts.inter(
                fontWeight: FontWeight.w500,
                color: Colors.white))),
        ]));
  }

  void _simulateFileImport(BuildContext context) {
    // Show loading dialog
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => AlertDialog(
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            CircularProgressIndicator(),
            SizedBox(height: 16.h),
            Text(
              'Importing locations...',
              style: GoogleFonts.inter(fontSize: 14.sp)),
          ])));

    // Simulate import process
    Future.delayed(const Duration(seconds: 3), () {
      Navigator.pop(context); // Close loading dialog

      // Mock imported data
      final importedLocations = [
        {
          'id': 'LOC_IMP_001',
          'name': 'Imported Location 1',
          'city': 'Mumbai',
          'address': 'Imported Address 1, Mumbai, Maharashtra 400001',
          'status': 'active',
          'agents_count': 0,
          'capacity': 10,
          'operating_hours': '09:00-18:00',
          'trade_volume': 0,
          'coordinates': {'lat': 19.0760, 'lng': 72.8777},
          'created_at': DateTime.now().toIso8601String(),
        },
        {
          'id': 'LOC_IMP_002',
          'name': 'Imported Location 2',
          'city': 'Delhi',
          'address': 'Imported Address 2, Delhi, Delhi 110001',
          'status': 'active',
          'agents_count': 0,
          'capacity': 8,
          'operating_hours': '10:00-19:00',
          'trade_volume': 0,
          'coordinates': {'lat': 28.6139, 'lng': 77.2090},
          'created_at': DateTime.now().toIso8601String(),
        },
      ];

      onImportCSV(importedLocations);

      // Show success dialog
      showDialog(
        context: context,
        builder: (context) => AlertDialog(
          title: Row(
            children: [
              CustomIconWidget(
                iconName: 'check_circle',
                color: AppTheme.successLight,
                size: 24),
              SizedBox(width: 8.w),
              Text(
                'Import Successful',
                style: GoogleFonts.inter(
                  fontWeight: FontWeight.w600)),
            ]),
          content: Text(
            '${importedLocations.length} locations have been imported successfully!',
            style: GoogleFonts.inter(fontSize: 14.sp)),
          actions: [
            ElevatedButton(
              onPressed: () => Navigator.pop(context),
              child: Text('OK')),
          ]));
    });
  }
}