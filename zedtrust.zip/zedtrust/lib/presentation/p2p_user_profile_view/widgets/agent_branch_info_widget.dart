import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';
import 'package:google_fonts/google_fonts.dart';

class AgentBranchInfoWidget extends StatelessWidget {
  final List<Map<String, dynamic>> agentBranches;
  final String userCity;

  const AgentBranchInfoWidget({
    Key? key,
    required this.agentBranches,
    required this.userCity,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    // Separate local and nearby branches
    final localBranches = agentBranches
        .where((branch) => branch['distance_priority'] == 1)
        .take(3)
        .toList();

    final nearbyBranches = agentBranches
        .where((branch) => branch['distance_priority'] == 2)
        .take(2)
        .toList();

    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text('Agent Branch Network',
          style: GoogleFonts.inter(
              fontSize: 16.sp,
              fontWeight: FontWeight.w600,
              color: Colors.black87)),
      SizedBox(height: 12.h),

      // Local Branches
      if (localBranches.isNotEmpty) ...[
        _buildSectionHeader('Local Agents in $userCity', Colors.green),
        SizedBox(height: 8.h),
        ...localBranches.map((branch) => _buildAgentBranchCard(branch)),
        SizedBox(height: 12.h),
      ],

      // Nearby Branches
      if (nearbyBranches.isNotEmpty) ...[
        _buildSectionHeader('Nearby Network Agents', Colors.blue),
        SizedBox(height: 8.h),
        ...nearbyBranches.map((branch) => _buildAgentBranchCard(branch)),
      ],

      // No branches available
      if (agentBranches.isEmpty)
        Container(
            decoration: BoxDecoration(
                color: Colors.orange.shade50,
                border: Border.all(color: Colors.orange.shade200, width: 1)),
            child: Row(children: [
              Icon(Icons.info_outline, color: Colors.orange.shade700),
              SizedBox(width: 12.w),
              Expanded(
                  child: Text(
                      'No agent branches available in your area at the moment.',
                      style: GoogleFonts.inter(
                          fontSize: 14.sp, color: Colors.orange.shade800))),
            ])),
    ]);
  }

  Widget _buildSectionHeader(String title, Color color) {
    return Row(children: [
      Container(
          width: 4.w, height: 16.h, decoration: BoxDecoration(color: color)),
      SizedBox(width: 8.w),
      Text(title,
          style: GoogleFonts.inter(
              fontSize: 14.sp,
              fontWeight: FontWeight.w600,
              color: Colors.black87)),
    ]);
  }

  Widget _buildAgentBranchCard(Map<String, dynamic> branch) {
    final rating = branch['agent_rating']?.toDouble() ?? 0.0;

    return Container(
        margin: EdgeInsets.only(bottom: 8.h),
        decoration: BoxDecoration(
            color: Colors.white,
            border: Border.all(color: Colors.grey.shade200, width: 1)),
        child: Row(children: [
          // Agent icon
          Container(
              width: 40.w,
              height: 40.h,
              decoration: BoxDecoration(color: Colors.blue.shade50),
              child: Icon(Icons.business, color: Colors.blue.shade600)),

          SizedBox(width: 12.w),

          // Branch info
          Expanded(
              child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                Text(branch['branch_alias'] ?? 'Unknown Branch',
                    style: GoogleFonts.inter(
                        fontSize: 14.sp,
                        fontWeight: FontWeight.w600,
                        color: Colors.black87)),
                SizedBox(height: 2.h),
                Text(branch['agent_name'] ?? 'Unknown Agent',
                    style: GoogleFonts.inter(
                        fontSize: 12.sp, color: Colors.grey.shade600)),
                SizedBox(height: 4.h),
                Row(children: [
                  Icon(Icons.location_on, color: Colors.grey.shade500),
                  SizedBox(width: 2.w),
                  Text(branch['branch_area'] ?? 'Unknown Area',
                      style: GoogleFonts.inter(
                          fontSize: 11.sp, color: Colors.grey.shade600)),
                ]),
              ])),

          // Rating and status
          Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
            Container(
                padding: EdgeInsets.symmetric(horizontal: 6.w, vertical: 2.h),
                decoration: BoxDecoration(color: Colors.amber.shade50),
                child: Row(mainAxisSize: MainAxisSize.min, children: [
                  Icon(Icons.star, color: Colors.amber.shade700),
                  SizedBox(width: 2.w),
                  Text(rating.toStringAsFixed(1),
                      style: GoogleFonts.inter(
                          fontSize: 11.sp,
                          fontWeight: FontWeight.w600,
                          color: Colors.amber.shade800)),
                ])),
            SizedBox(height: 4.h),
            Container(
                padding: EdgeInsets.symmetric(horizontal: 6.w, vertical: 2.h),
                decoration: BoxDecoration(color: Colors.green.shade50),
                child: Text('Available',
                    style: GoogleFonts.inter(
                        fontSize: 10.sp,
                        fontWeight: FontWeight.w500,
                        color: Colors.green.shade700))),
          ]),
        ]));
  }
}
