import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';
import 'package:google_fonts/google_fonts.dart';

class CommunicationOptionsWidget extends StatelessWidget {
  final VoidCallback onSendMessage;
  final bool isCurrentUser;

  const CommunicationOptionsWidget({
    Key? key,
    required this.onSendMessage,
    required this.isCurrentUser,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    // Don't show communication options for current user's profile
    if (isCurrentUser) {
      return SizedBox.shrink();
    }

    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text('Communication',
          style: GoogleFonts.inter(
              fontSize: 16.sp,
              fontWeight: FontWeight.w600,
              color: Colors.black87)),
      SizedBox(height: 12.h),
      Container(
          decoration: BoxDecoration(
              color: Colors.grey.shade50,
              border: Border.all(color: Colors.grey.shade200, width: 1)),
          child: Column(children: [
            // Secure Messaging
            _buildCommunicationOption(
                icon: Icons.message_outlined,
                title: 'Secure Messaging',
                subtitle: 'Send encrypted messages through the app',
                color: Colors.blue,
                onTap: onSendMessage),

            SizedBox(height: 12.h),

            // VoIP Calling
            _buildCommunicationOption(
                icon: Icons.phone_outlined,
                title: 'VoIP Calling',
                subtitle: 'Make secure calls without exposing phone numbers',
                color: Colors.green,
                onTap: () {
                  _showComingSoonDialog(context, 'VoIP Calling');
                }),

            SizedBox(height: 16.h),

            // Privacy Notice
            Container(
                decoration: BoxDecoration(color: Colors.blue.shade50),
                child: Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Icon(Icons.security, color: Colors.blue.shade700),
                      SizedBox(width: 8.w),
                      Expanded(
                          child: Text(
                              'All communications are secured and encrypted. Personal contact information remains private.',
                              style: GoogleFonts.inter(
                                  fontSize: 12.sp,
                                  color: Colors.blue.shade800,
                                  height: 1.3))),
                    ])),
          ])),
    ]);
  }

  Widget _buildCommunicationOption({
    required IconData icon,
    required String title,
    required String subtitle,
    required Color color,
    required VoidCallback onTap,
  }) {
    return InkWell(
        onTap: onTap,
        child: Container(
            decoration: BoxDecoration(
                color: Colors.white,
                border: Border.all(color: Colors.grey.shade200, width: 1)),
            child: Row(children: [
              Container(
                  width: 40.w,
                  height: 40.h,
                  decoration: BoxDecoration(color: color.withAlpha(26)),
                  child: Icon(icon, color: color)),
              SizedBox(width: 12.w),
              Expanded(
                  child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                    Text(title,
                        style: GoogleFonts.inter(
                            fontSize: 14.sp,
                            fontWeight: FontWeight.w600,
                            color: Colors.black87)),
                    SizedBox(height: 2.h),
                    Text(subtitle,
                        style: GoogleFonts.inter(
                            fontSize: 12.sp,
                            color: Colors.grey.shade600,
                            height: 1.2)),
                  ])),
              Icon(Icons.arrow_forward_ios, color: Colors.grey.shade400),
            ])));
  }

  void _showComingSoonDialog(BuildContext context, String feature) {
    showDialog(
        context: context,
        builder: (BuildContext context) {
          return AlertDialog(
              title: Text('Coming Soon',
                  style: GoogleFonts.inter(
                      fontSize: 18.sp, fontWeight: FontWeight.w600)),
              content: Text('$feature will be available in a future update.',
                  style: GoogleFonts.inter(fontSize: 14.sp)),
              actions: [
                TextButton(
                    onPressed: () => Navigator.pop(context),
                    child: Text('OK',
                        style: GoogleFonts.inter(
                            color: Colors.blue, fontWeight: FontWeight.w600))),
              ]);
        });
  }
}
