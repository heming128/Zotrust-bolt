import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';
import 'package:google_fonts/google_fonts.dart';

class VerificationBadgesWidget extends StatelessWidget {
  final List<String> verificationBadges;

  const VerificationBadgesWidget({
    Key? key,
    required this.verificationBadges,
  }) : super(key: key);

  Map<String, Map<String, dynamic>> get _badgeConfig => {
        'name_verified': {
          'label': 'Name Verified',
          'icon': Icons.person_outline,
          'color': Colors.blue,
        },
        'city_verified': {
          'label': 'City Confirmed',
          'icon': Icons.location_on_outlined,
          'color': Colors.green,
        },
        'mobile_verified': {
          'label': 'Mobile Verified',
          'icon': Icons.phone_outlined,
          'color': Colors.orange,
        },
      };

  @override
  Widget build(BuildContext context) {
    if (verificationBadges.isEmpty) {
      return SizedBox.shrink();
    }

    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text('Verification Status',
          style: GoogleFonts.inter(
              fontSize: 16.sp,
              fontWeight: FontWeight.w600,
              color: Colors.black87)),
      SizedBox(height: 12.h),
      Wrap(
          spacing: 8.w,
          runSpacing: 8.h,
          children: verificationBadges.map((badge) {
            final config = _badgeConfig[badge];
            if (config == null) return SizedBox.shrink();

            return Container(
                padding: EdgeInsets.symmetric(horizontal: 12.w, vertical: 8.h),
                decoration: BoxDecoration(
                    color: (config['color'] as Color).withAlpha(26),
                    border: Border.all(
                        color: (config['color'] as Color).withAlpha(77),
                        width: 1)),
                child: Row(mainAxisSize: MainAxisSize.min, children: [
                  Icon(config['icon'], color: config['color']),
                  SizedBox(width: 6.w),
                  Text(config['label'],
                      style: GoogleFonts.inter(
                          fontSize: 12.sp,
                          fontWeight: FontWeight.w500,
                          color: config['color'])),
                  SizedBox(width: 4.w),
                  Icon(Icons.verified, color: config['color']),
                ]));
          }).toList()),
    ]);
  }
}
