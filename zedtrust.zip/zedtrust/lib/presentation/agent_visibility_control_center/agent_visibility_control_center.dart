import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

import '../../core/app_export.dart';
import './widgets/advanced_filtering_widget.dart';
import './widgets/agent_verification_status_widget.dart';
import './widgets/analytics_dashboard_widget.dart';
import './widgets/auto_hide_rules_widget.dart';
import './widgets/bulk_operations_widget.dart';
import './widgets/location_status_management_widget.dart';
import './widgets/p2p_display_preview_widget.dart';
import './widgets/visibility_rules_configuration_widget.dart';

/// Agent Visibility Control Center screen for managing display rules for agents
/// and locations across P2P interfaces with verification-based filtering
class AgentVisibilityControlCenter extends StatefulWidget {
  const AgentVisibilityControlCenter({super.key});

  @override
  State<AgentVisibilityControlCenter> createState() =>
      _AgentVisibilityControlCenterState();
}

class _AgentVisibilityControlCenterState
    extends State<AgentVisibilityControlCenter>
    with SingleTickerProviderStateMixin {
  late TabController _tabController;
  late ScrollController _scrollController;

  // Global visibility settings state
  bool _hideUnverifiedAgents = false;
  bool _hideInactiveLocations = true;
  bool _autoHideEnabled = false;

  // Selected filters state
  List<String> _selectedAgentIds = [];
  List<String> _selectedLocationIds = [];
  String _selectedAnalyticsRange = '7days';

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 4, vsync: this);
    _scrollController = ScrollController();
    _loadVisibilitySettings();
  }

  @override
  void dispose() {
    _tabController.dispose();
    _scrollController.dispose();
    super.dispose();
  }

  void _loadVisibilitySettings() async {
    // TODO: Load from Supabase platform_settings or agent_visibility_rules
    setState(() {
      _hideUnverifiedAgents = false;
      _hideInactiveLocations = true;
      _autoHideEnabled = false;
    });
  }

  void _updateGlobalSettings({
    bool? hideUnverified,
    bool? hideInactive,
    bool? autoHide,
  }) async {
    setState(() {
      if (hideUnverified != null) _hideUnverifiedAgents = hideUnverified;
      if (hideInactive != null) _hideInactiveLocations = hideInactive;
      if (autoHide != null) _autoHideEnabled = autoHide;
    });

    // TODO: Save to Supabase
    _showSettingsUpdated();
  }

  void _showSettingsUpdated() {
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Row(
            children: [
              Icon(
                Icons.check_circle,
                color: AppTheme.getSuccessColor(
                    Theme.of(context).brightness == Brightness.light),
                size: 20,
              ),
              const SizedBox(width: 12),
              Text(
                'Visibility settings updated successfully',
                style: GoogleFonts.inter(
                    fontSize: 14, fontWeight: FontWeight.w500),
              ),
            ],
          ),
          behavior: SnackBarBehavior.floating,
          margin: const EdgeInsets.all(16),
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final colors = Theme.of(context).colorScheme;

    return Scaffold(
      backgroundColor: colors.surface,
      body: SafeArea(
        child: Column(
          children: [
            // Header Section
            _buildHeader(context, colors, isDark),

            // Global Settings Toggle Bar
            _buildGlobalSettings(context, colors, isDark),

            // Tab Navigation
            _buildTabBar(context, colors),

            // Tab Content
            Expanded(
              child: TabBarView(
                controller: _tabController,
                children: [
                  // Agent & Location Management Tab
                  _buildManagementTab(),

                  // Rules & Filtering Tab
                  _buildRulesTab(),

                  // Preview & Testing Tab
                  _buildPreviewTab(),

                  // Analytics & Reports Tab
                  _buildAnalyticsTab(),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildHeader(BuildContext context, ColorScheme colors, bool isDark) {
    return Container(
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(
        color: colors.surface,
        border: Border(
          bottom: BorderSide(
            color: colors.outline.withAlpha(77),
            width: 1,
          ),
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: colors.primaryContainer,
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Icon(
                  Icons.visibility_outlined,
                  color: colors.primary,
                  size: 24,
                ),
              ),
              const SizedBox(width: 16),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Visibility Control',
                      style: GoogleFonts.inter(
                        fontSize: 24,
                        fontWeight: FontWeight.w600,
                        color: colors.onSurface,
                        letterSpacing: -0.25,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      'Manage agent and location display rules across P2P interfaces',
                      style: GoogleFonts.inter(
                        fontSize: 14,
                        fontWeight: FontWeight.w400,
                        color: colors.onSurfaceVariant,
                      ),
                    ),
                  ],
                ),
              ),
              // Quick Stats
              _buildQuickStats(colors),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildQuickStats(ColorScheme colors) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      decoration: BoxDecoration(
        color: colors.surfaceContainerHighest,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: colors.outline.withAlpha(51)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.end,
        children: [
          Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(
                Icons.people_outline,
                size: 16,
                color: colors.primary,
              ),
              const SizedBox(width: 6),
              Text(
                '24 Visible',
                style: GoogleFonts.inter(
                  fontSize: 12,
                  fontWeight: FontWeight.w600,
                  color: colors.primary,
                ),
              ),
            ],
          ),
          const SizedBox(height: 4),
          Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(
                Icons.location_on_outlined,
                size: 16,
                color: AppTheme.getSuccessColor(
                    colors.brightness == Brightness.light),
              ),
              const SizedBox(width: 6),
              Text(
                '8 Active',
                style: GoogleFonts.inter(
                  fontSize: 12,
                  fontWeight: FontWeight.w500,
                  color: AppTheme.getSuccessColor(
                      colors.brightness == Brightness.light),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildGlobalSettings(
      BuildContext context, ColorScheme colors, bool isDark) {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: colors.surfaceContainerLow,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: colors.outline.withAlpha(77)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(
                Icons.tune,
                color: colors.primary,
                size: 20,
              ),
              const SizedBox(width: 12),
              Text(
                'Global Settings',
                style: GoogleFonts.inter(
                  fontSize: 16,
                  fontWeight: FontWeight.w600,
                  color: colors.onSurface,
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          Wrap(
            spacing: 24,
            runSpacing: 12,
            children: [
              _buildToggleOption(
                'Hide Unverified Agents',
                'Automatically hide agents with incomplete verification',
                _hideUnverifiedAgents,
                (value) => _updateGlobalSettings(hideUnverified: value),
                colors,
              ),
              _buildToggleOption(
                'Hide Inactive Locations',
                'Hide location branches marked as inactive',
                _hideInactiveLocations,
                (value) => _updateGlobalSettings(hideInactive: value),
                colors,
              ),
              _buildToggleOption(
                'Auto-Hide Rules',
                'Enable automatic hiding based on rating and activity',
                _autoHideEnabled,
                (value) => _updateGlobalSettings(autoHide: value),
                colors,
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildToggleOption(
    String title,
    String subtitle,
    bool value,
    ValueChanged<bool> onChanged,
    ColorScheme colors,
  ) {
    return SizedBox(
      width: 280,
      child: Row(
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: GoogleFonts.inter(
                    fontSize: 14,
                    fontWeight: FontWeight.w500,
                    color: colors.onSurface,
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  subtitle,
                  style: GoogleFonts.inter(
                    fontSize: 12,
                    fontWeight: FontWeight.w400,
                    color: colors.onSurfaceVariant,
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(width: 12),
          Switch(
            value: value,
            onChanged: onChanged,
          ),
        ],
      ),
    );
  }

  Widget _buildTabBar(BuildContext context, ColorScheme colors) {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 24),
      child: TabBar(
        controller: _tabController,
        tabs: [
          Tab(
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(Icons.manage_accounts_outlined, size: 18),
                const SizedBox(width: 8),
                Text('Management'),
              ],
            ),
          ),
          Tab(
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(Icons.filter_list, size: 18),
                const SizedBox(width: 8),
                Text('Rules'),
              ],
            ),
          ),
          Tab(
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(Icons.preview, size: 18),
                const SizedBox(width: 8),
                Text('Preview'),
              ],
            ),
          ),
          Tab(
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(Icons.analytics_outlined, size: 18),
                const SizedBox(width: 8),
                Text('Analytics'),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildManagementTab() {
    return SingleChildScrollView(
      controller: _scrollController,
      padding: const EdgeInsets.all(24),
      child: Column(
        children: [
          // Agent Verification Status Section
          AgentVerificationStatusWidget(
            selectedAgentIds: _selectedAgentIds,
            onSelectionChanged: (ids) =>
                setState(() => _selectedAgentIds = ids),
          ),

          const SizedBox(height: 24),

          // Location Status Management Section
          LocationStatusManagementWidget(
            selectedLocationIds: _selectedLocationIds,
            onSelectionChanged: (ids) =>
                setState(() => _selectedLocationIds = ids),
          ),

          const SizedBox(height: 24),

          // Bulk Operations Section
          BulkOperationsWidget(
            selectedAgentIds: _selectedAgentIds,
            selectedLocationIds: _selectedLocationIds,
            onBulkAction: _handleBulkAction,
          ),
        ],
      ),
    );
  }

  Widget _buildRulesTab() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(24),
      child: Column(
        children: [
          // Visibility Rules Configuration
          VisibilityRulesConfigurationWidget(
            hideUnverified: _hideUnverifiedAgents,
            hideInactive: _hideInactiveLocations,
            onRulesChanged: (hideUnverified, hideInactive) => _updateGlobalSettings(
              hideUnverified: hideUnverified,
              hideInactive: hideInactive,
            ),
          ),

          const SizedBox(height: 24),

          // Auto-Hide Rules Configuration
          AutoHideRulesWidget(
            enabled: _autoHideEnabled,
            onSettingsChanged: _updateAutoHideRules,
          ),

          const SizedBox(height: 24),

          // Advanced Filtering Options
          AdvancedFilteringWidget(
            onFiltersChanged: _updateAdvancedFilters,
          ),
        ],
      ),
    );
  }

  Widget _buildPreviewTab() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(24),
      child: Column(
        children: [
          // P2P Display Preview
          P2PDisplayPreviewWidget(
            visibilitySettings: {
              'hideUnverified': _hideUnverifiedAgents,
              'hideInactive': _hideInactiveLocations,
              'autoHide': _autoHideEnabled,
            },
            onPreviewRefresh: _refreshPreview,
          ),
        ],
      ),
    );
  }

  Widget _buildAnalyticsTab() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(24),
      child: Column(
        children: [
          // Analytics Dashboard
          AnalyticsDashboardWidget(
            selectedRange: _selectedAnalyticsRange,
            onRangeChanged: (range) =>
                setState(() => _selectedAnalyticsRange = range),
          ),
        ],
      ),
    );
  }

  void _handleBulkAction(String action, List<String> targetIds) async {
    // TODO: Implement bulk actions (hide, show, verify, etc.)
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content:
            Text('Bulk action "$action" applied to ${targetIds.length} items'),
        behavior: SnackBarBehavior.floating,
      ),
    );
  }

  void _updateAutoHideRules(Map<String, dynamic> settings) async {
    // TODO: Save auto-hide rules to Supabase
    _showSettingsUpdated();
  }

  void _updateAdvancedFilters(Map<String, dynamic> filters) async {
    // TODO: Save advanced filtering rules to Supabase
    _showSettingsUpdated();
  }

  void _refreshPreview() {
    // TODO: Refresh preview data based on current settings
  }
}