import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

import '../../../theme/app_theme.dart';

/// Widget for previewing how agents appear in P2P interfaces with current visibility rules
class P2PDisplayPreviewWidget extends StatefulWidget {
  final Map<String, dynamic> visibilitySettings;
  final VoidCallback onPreviewRefresh;

  const P2PDisplayPreviewWidget({
    super.key,
    required this.visibilitySettings,
    required this.onPreviewRefresh,
  });

  @override
  State<P2PDisplayPreviewWidget> createState() =>
      _P2PDisplayPreviewWidgetState();
}

class _P2PDisplayPreviewWidgetState extends State<P2PDisplayPreviewWidget> {
  bool _showBeforeAfter = true;
  String _selectedCity = 'New York';

  // Mock data representing agents as they would appear in P2P
  final List<Map<String, dynamic>> _mockAgents = [
    {
      'id': '1',
      'name': 'Sarah Johnson',
      'city': 'New York',
      'branch': 'Manhattan Central',
      'rating': 4.8,
      'completionRate': 98,
      'verified': true,
      'isActive': true,
      'lastSeen': '2h ago',
      'trades': 156,
      'wouldBeHidden': false,
      'hiddenReason': null,
    },
    {
      'id': '2',
      'name': 'Mike Chen',
      'city': 'New York',
      'branch': 'Brooklyn Heights',
      'rating': 4.2,
      'completionRate': 85,
      'verified': false,
      'isActive': true,
      'lastSeen': '1d ago',
      'trades': 73,
      'wouldBeHidden': true,
      'hiddenReason': 'Unverified agent',
    },
    {
      'id': '3',
      'name': 'Emma Wilson',
      'city': 'New York',
      'branch': 'Queens Plaza',
      'rating': 4.9,
      'completionRate': 100,
      'verified': true,
      'isActive': false,
      'lastSeen': '5h ago',
      'trades': 203,
      'wouldBeHidden': true,
      'hiddenReason': 'Inactive location',
    },
    {
      'id': '4',
      'name': 'Alex Rodriguez',
      'city': 'Los Angeles',
      'branch': 'Downtown',
      'rating': 4.6,
      'completionRate': 92,
      'verified': true,
      'isActive': true,
      'lastSeen': '1h ago',
      'trades': 134,
      'wouldBeHidden': false,
      'hiddenReason': null,
    },
  ];

  List<Map<String, dynamic>> get _filteredAgents {
    return _mockAgents
        .where((agent) => agent['city'] == _selectedCity)
        .toList();
  }

  List<Map<String, dynamic>> get _visibleAgents {
    return _filteredAgents.where((agent) {
      // Apply visibility rules
      if (widget.visibilitySettings['hideUnverified'] == true &&
          !agent['verified']) {
        agent['wouldBeHidden'] = true;
        agent['hiddenReason'] = 'Unverified agent';
        return false;
      }
      if (widget.visibilitySettings['hideInactive'] == true &&
          !agent['isActive']) {
        agent['wouldBeHidden'] = true;
        agent['hiddenReason'] = 'Inactive location';
        return false;
      }
      agent['wouldBeHidden'] = false;
      agent['hiddenReason'] = null;
      return true;
    }).toList();
  }

  List<Map<String, dynamic>> get _hiddenAgents {
    return _filteredAgents.where((agent) => agent['wouldBeHidden']).toList();
  }

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    final isDark = Theme.of(context).brightness == Brightness.dark;

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Header
            Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: colors.tertiaryContainer,
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Icon(
                    Icons.preview,
                    color: colors.tertiary,
                    size: 20,
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'P2P Display Preview',
                        style: GoogleFonts.inter(
                          fontSize: 18,
                          fontWeight: FontWeight.w600,
                          color: colors.onSurface,
                        ),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        'Real-time simulation of how agent selection appears to users',
                        style: GoogleFonts.inter(
                          fontSize: 14,
                          fontWeight: FontWeight.w400,
                          color: colors.onSurfaceVariant,
                        ),
                      ),
                    ],
                  ),
                ),
                IconButton(
                  onPressed: widget.onPreviewRefresh,
                  icon: Icon(Icons.refresh),
                  tooltip: 'Refresh Preview',
                ),
              ],
            ),

            const SizedBox(height: 24),

            // Controls
            Row(
              children: [
                Expanded(
                  child: DropdownButtonFormField<String>(
                    value: _selectedCity,
                    decoration: InputDecoration(
                      labelText: 'Preview City',
                      border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(12)),
                    ),
                    items: ['New York', 'Los Angeles', 'Chicago']
                        .map((city) =>
                            DropdownMenuItem(value: city, child: Text(city)))
                        .toList(),
                    onChanged: (value) =>
                        setState(() => _selectedCity = value!),
                  ),
                ),
                const SizedBox(width: 16),
                SizedBox(
                  width: 200,
                  child: Row(
                    children: [
                      Switch(
                        value: _showBeforeAfter,
                        onChanged: (value) =>
                            setState(() => _showBeforeAfter = value),
                      ),
                      const SizedBox(width: 8),
                      Text(
                        'Before/After View',
                        style: GoogleFonts.inter(
                          fontSize: 14,
                          fontWeight: FontWeight.w500,
                          color: colors.onSurface,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),

            const SizedBox(height: 24),

            // Preview Stats
            _buildPreviewStats(colors, isDark),

            const SizedBox(height: 24),

            // Preview Content
            if (_showBeforeAfter) ...[
              // Before/After Comparison
              Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Expanded(
                    child: _buildPreviewColumn(
                      'Before (All Agents)',
                      _filteredAgents,
                      colors,
                      isDark,
                      isBeforeView: true,
                    ),
                  ),
                  const SizedBox(width: 24),
                  Expanded(
                    child: _buildPreviewColumn(
                      'After (With Rules Applied)',
                      _visibleAgents,
                      colors,
                      isDark,
                      isBeforeView: false,
                    ),
                  ),
                ],
              ),

              const SizedBox(height: 24),

              // Hidden Agents Summary
              if (_hiddenAgents.isNotEmpty)
                _buildHiddenAgentsSummary(colors, isDark),
            ] else ...[
              // Current State Only
              _buildPreviewColumn(
                'Current Agent Display',
                _visibleAgents,
                colors,
                isDark,
                isBeforeView: false,
              ),
            ],
          ],
        ),
      ),
    );
  }

  Widget _buildPreviewStats(ColorScheme colors, bool isDark) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: colors.surfaceContainerLow,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: colors.outline.withAlpha(51)),
      ),
      child: Row(
        children: [
          Expanded(
            child: _buildStatCard(
              'Total Agents',
              _filteredAgents.length.toString(),
              'In $_selectedCity',
              Icons.people,
              colors,
            ),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: _buildStatCard(
              'Visible',
              _visibleAgents.length.toString(),
              'After rules',
              Icons.visibility,
              colors,
            ),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: _buildStatCard(
              'Hidden',
              _hiddenAgents.length.toString(),
              'By rules',
              Icons.visibility_off,
              colors,
            ),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: _buildStatCard(
              'Impact',
              '${((_hiddenAgents.length / _filteredAgents.length) * 100).toStringAsFixed(0)}%',
              'Reduction',
              Icons.trending_down,
              colors,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildStatCard(
    String title,
    String value,
    String subtitle,
    IconData icon,
    ColorScheme colors,
  ) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: colors.surfaceContainerHighest,
        borderRadius: BorderRadius.circular(8),
      ),
      child: Column(
        children: [
          Icon(icon, color: colors.primary, size: 24),
          const SizedBox(height: 8),
          Text(
            value,
            style: GoogleFonts.inter(
              fontSize: 18,
              fontWeight: FontWeight.w600,
              color: colors.primary,
            ),
          ),
          Text(
            title,
            style: GoogleFonts.inter(
              fontSize: 12,
              fontWeight: FontWeight.w500,
              color: colors.onSurface,
            ),
          ),
          const SizedBox(height: 2),
          Text(
            subtitle,
            style: GoogleFonts.inter(
              fontSize: 10,
              fontWeight: FontWeight.w400,
              color: colors.onSurfaceVariant,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildPreviewColumn(
    String title,
    List<Map<String, dynamic>> agents,
    ColorScheme colors,
    bool isDark, {
    required bool isBeforeView,
  }) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: colors.surfaceContainerLow,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: colors.outline.withAlpha(51)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            title,
            style: GoogleFonts.inter(
              fontSize: 16,
              fontWeight: FontWeight.w600,
              color: colors.onSurface,
            ),
          ),
          const SizedBox(height: 16),
          Container(
            constraints: const BoxConstraints(maxHeight: 400),
            child: ListView.builder(
              shrinkWrap: true,
              itemCount: agents.length,
              itemBuilder: (context, index) {
                final agent = agents[index];
                return _buildAgentPreviewCard(
                    agent, colors, isDark, isBeforeView);
              },
            ),
          ),
          if (agents.isEmpty) ...[
            Container(
              padding: const EdgeInsets.all(24),
              child: Column(
                children: [
                  Icon(
                    Icons.help_outline,
                    color: colors.onSurfaceVariant,
                    size: 48,
                  ),
                  const SizedBox(height: 12),
                  Text(
                    'No agents visible',
                    style: GoogleFonts.inter(
                      fontSize: 14,
                      fontWeight: FontWeight.w500,
                      color: colors.onSurfaceVariant,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ],
      ),
    );
  }

  Widget _buildAgentPreviewCard(
    Map<String, dynamic> agent,
    ColorScheme colors,
    bool isDark,
    bool isBeforeView,
  ) {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: colors.surface,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: colors.outline.withAlpha(51)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              CircleAvatar(
                radius: 20,
                backgroundColor: colors.primaryContainer,
                child: Text(
                  agent['name'][0],
                  style: GoogleFonts.inter(
                    fontSize: 16,
                    fontWeight: FontWeight.w600,
                    color: colors.primary,
                  ),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Expanded(
                          child: Text(
                            '${agent['name']} — ${agent['branch']}',
                            style: GoogleFonts.inter(
                              fontSize: 14,
                              fontWeight: FontWeight.w500,
                              color: colors.onSurface,
                            ),
                          ),
                        ),
                        if (agent['verified'])
                          Icon(
                            Icons.verified,
                            color: AppTheme.getSuccessColor(isDark),
                            size: 16,
                          ),
                      ],
                    ),
                    const SizedBox(height: 4),
                    Text(
                      '${agent['rating']} ⭐ • ${agent['trades']} trades • ${agent['lastSeen']}',
                      style: GoogleFonts.inter(
                        fontSize: 12,
                        fontWeight: FontWeight.w400,
                        color: colors.onSurfaceVariant,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
          if (!isBeforeView && agent['wouldBeHidden']) ...[
            const SizedBox(height: 12),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
              decoration: BoxDecoration(
                color: colors.error.withAlpha(26),
                borderRadius: BorderRadius.circular(6),
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(
                    Icons.visibility_off,
                    color: colors.error,
                    size: 14,
                  ),
                  const SizedBox(width: 6),
                  Text(
                    'Hidden: ${agent['hiddenReason']}',
                    style: GoogleFonts.inter(
                      fontSize: 11,
                      fontWeight: FontWeight.w500,
                      color: colors.error,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ],
      ),
    );
  }

  Widget _buildHiddenAgentsSummary(ColorScheme colors, bool isDark) {
    final reasonCounts = <String, int>{};
    for (final agent in _hiddenAgents) {
      final reason = agent['hiddenReason'] as String? ?? 'Unknown';
      reasonCounts[reason] = (reasonCounts[reason] ?? 0) + 1;
    }

    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: colors.errorContainer.withAlpha(26),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: colors.error.withAlpha(51)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(
                Icons.info_outline,
                color: colors.error,
                size: 20,
              ),
              const SizedBox(width: 12),
              Text(
                'Hidden Agents Summary',
                style: GoogleFonts.inter(
                  fontSize: 16,
                  fontWeight: FontWeight.w600,
                  color: colors.error,
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          Wrap(
            spacing: 12,
            runSpacing: 8,
            children: reasonCounts.entries.map((entry) {
              return Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                decoration: BoxDecoration(
                  color: colors.errorContainer,
                  borderRadius: BorderRadius.circular(16),
                ),
                child: Text(
                  '${entry.value} ${entry.key}',
                  style: GoogleFonts.inter(
                    fontSize: 12,
                    fontWeight: FontWeight.w500,
                    color: colors.onErrorContainer,
                  ),
                ),
              );
            }).toList(),
          ),
        ],
      ),
    );
  }
}
