import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

import '../../../theme/app_theme.dart';

/// Widget for bulk operations on selected agents and locations
class BulkOperationsWidget extends StatefulWidget {
  final List<String> selectedAgentIds;
  final List<String> selectedLocationIds;
  final Function(String action, List<String> targetIds) onBulkAction;

  const BulkOperationsWidget({
    super.key,
    required this.selectedAgentIds,
    required this.selectedLocationIds,
    required this.onBulkAction,
  });

  @override
  State<BulkOperationsWidget> createState() => _BulkOperationsWidgetState();
}

class _BulkOperationsWidgetState extends State<BulkOperationsWidget> {
  bool _showConfirmation = false;
  String _pendingAction = '';
  List<String> _pendingTargets = [];

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    final isDark = Theme.of(context).brightness == Brightness.dark;

    final hasAgentSelection = widget.selectedAgentIds.isNotEmpty;
    final hasLocationSelection = widget.selectedLocationIds.isNotEmpty;
    final hasAnySelection = hasAgentSelection || hasLocationSelection;

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Header
            Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: colors.secondaryContainer,
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Icon(
                    Icons.playlist_add_check,
                    color: colors.secondary,
                    size: 20,
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Bulk Operations',
                        style: GoogleFonts.inter(
                          fontSize: 18,
                          fontWeight: FontWeight.w600,
                          color: colors.onSurface,
                        ),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        'Mass visibility updates across multiple agents or locations',
                        style: GoogleFonts.inter(
                          fontSize: 14,
                          fontWeight: FontWeight.w400,
                          color: colors.onSurfaceVariant,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),

            const SizedBox(height: 24),

            // Selection Summary
            _buildSelectionSummary(
                colors, isDark, hasAgentSelection, hasLocationSelection),

            const SizedBox(height: 24),

            // Action Buttons
            if (hasAnySelection) ...[
              _buildActionSection('Agent Actions', hasAgentSelection, [
                _buildActionButton(
                  'Show in P2P',
                  'Make selected agents visible in P2P interfaces',
                  Icons.visibility,
                  colors.primary,
                  () => _confirmAction('show_agents', widget.selectedAgentIds),
                  enabled: hasAgentSelection,
                ),
                _buildActionButton(
                  'Hide from P2P',
                  'Hide selected agents from P2P interfaces',
                  Icons.visibility_off,
                  AppTheme.getWarningColor(isDark),
                  () => _confirmAction('hide_agents', widget.selectedAgentIds),
                  enabled: hasAgentSelection,
                ),
                _buildActionButton(
                  'Force Verify',
                  'Mark selected agents as verified',
                  Icons.verified_user,
                  AppTheme.getSuccessColor(isDark),
                  () =>
                      _confirmAction('verify_agents', widget.selectedAgentIds),
                  enabled: hasAgentSelection,
                ),
                _buildActionButton(
                  'Suspend',
                  'Temporarily suspend selected agents',
                  Icons.block,
                  colors.error,
                  () =>
                      _confirmAction('suspend_agents', widget.selectedAgentIds),
                  enabled: hasAgentSelection,
                ),
              ]),
              const SizedBox(height: 20),
              _buildActionSection('Location Actions', hasLocationSelection, [
                _buildActionButton(
                  'Activate Locations',
                  'Set selected locations as active',
                  Icons.location_on,
                  colors.primary,
                  () => _confirmAction(
                      'activate_locations', widget.selectedLocationIds),
                  enabled: hasLocationSelection,
                ),
                _buildActionButton(
                  'Deactivate Locations',
                  'Set selected locations as inactive',
                  Icons.location_off,
                  AppTheme.getWarningColor(isDark),
                  () => _confirmAction(
                      'deactivate_locations', widget.selectedLocationIds),
                  enabled: hasLocationSelection,
                ),
                _buildActionButton(
                  'Update Visibility',
                  'Toggle P2P visibility for selected locations',
                  Icons.sync,
                  colors.tertiary,
                  () => _confirmAction(
                      'toggle_location_visibility', widget.selectedLocationIds),
                  enabled: hasLocationSelection,
                ),
                _buildActionButton(
                  'Bulk Edit',
                  'Edit properties of selected locations',
                  Icons.edit,
                  colors.secondary,
                  () => _confirmAction(
                      'bulk_edit_locations', widget.selectedLocationIds),
                  enabled: hasLocationSelection,
                ),
              ]),
              const SizedBox(height: 20),
              _buildActionSection('Combined Actions',
                  hasAgentSelection && hasLocationSelection, [
                _buildActionButton(
                  'Sync Visibility',
                  'Synchronize agent and location visibility settings',
                  Icons.sync_alt,
                  colors.primary,
                  () => _confirmAction('sync_visibility', [
                    ...widget.selectedAgentIds,
                    ...widget.selectedLocationIds
                  ]),
                  enabled: hasAgentSelection && hasLocationSelection,
                ),
                _buildActionButton(
                  'Generate Report',
                  'Create visibility impact report for selections',
                  Icons.analytics,
                  colors.tertiary,
                  () => _confirmAction('generate_report', [
                    ...widget.selectedAgentIds,
                    ...widget.selectedLocationIds
                  ]),
                  enabled: hasAgentSelection || hasLocationSelection,
                ),
              ]),
            ] else ...[
              // No Selection State
              Container(
                padding: const EdgeInsets.all(32),
                decoration: BoxDecoration(
                  color: colors.surfaceContainerLow,
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Column(
                  children: [
                    Icon(
                      Icons.check_box_outline_blank,
                      color: colors.onSurfaceVariant,
                      size: 48,
                    ),
                    const SizedBox(height: 16),
                    Text(
                      'No Items Selected',
                      style: GoogleFonts.inter(
                        fontSize: 18,
                        fontWeight: FontWeight.w600,
                        color: colors.onSurface,
                      ),
                    ),
                    const SizedBox(height: 8),
                    Text(
                      'Select agents or locations from the management tabs to perform bulk operations',
                      style: GoogleFonts.inter(
                        fontSize: 14,
                        fontWeight: FontWeight.w400,
                        color: colors.onSurfaceVariant,
                      ),
                      textAlign: TextAlign.center,
                    ),
                  ],
                ),
              ),
            ],

            // Confirmation Dialog Overlay
            if (_showConfirmation) _buildConfirmationOverlay(colors, isDark),
          ],
        ),
      ),
    );
  }

  Widget _buildSelectionSummary(
      ColorScheme colors, bool isDark, bool hasAgents, bool hasLocations) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: colors.surfaceContainerLow,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: colors.outline.withAlpha(51)),
      ),
      child: Row(
        children: [
          if (hasAgents) ...[
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
              decoration: BoxDecoration(
                color: colors.primaryContainer,
                borderRadius: BorderRadius.circular(8),
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(
                    Icons.people,
                    color: colors.primary,
                    size: 16,
                  ),
                  const SizedBox(width: 6),
                  Text(
                    '${widget.selectedAgentIds.length} Agents',
                    style: GoogleFonts.inter(
                      fontSize: 14,
                      fontWeight: FontWeight.w500,
                      color: colors.primary,
                    ),
                  ),
                ],
              ),
            ),
          ],
          if (hasAgents && hasLocations) const SizedBox(width: 12),
          if (hasLocations) ...[
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
              decoration: BoxDecoration(
                color: colors.secondaryContainer,
                borderRadius: BorderRadius.circular(8),
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(
                    Icons.location_on,
                    color: colors.secondary,
                    size: 16,
                  ),
                  const SizedBox(width: 6),
                  Text(
                    '${widget.selectedLocationIds.length} Locations',
                    style: GoogleFonts.inter(
                      fontSize: 14,
                      fontWeight: FontWeight.w500,
                      color: colors.secondary,
                    ),
                  ),
                ],
              ),
            ),
          ],
          const Spacer(),
          TextButton(
            onPressed: () {
              // Clear all selections - this would need to be implemented in parent
            },
            child: Text('Clear Selection'),
          ),
        ],
      ),
    );
  }

  Widget _buildActionSection(
      String title, bool isEnabled, List<Widget> actions) {
    final colors = Theme.of(context).colorScheme;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          title,
          style: GoogleFonts.inter(
            fontSize: 16,
            fontWeight: FontWeight.w600,
            color: isEnabled ? colors.onSurface : colors.onSurfaceVariant,
          ),
        ),
        const SizedBox(height: 12),
        Wrap(
          spacing: 12,
          runSpacing: 12,
          children: actions,
        ),
      ],
    );
  }

  Widget _buildActionButton(
    String title,
    String description,
    IconData icon,
    Color iconColor,
    VoidCallback onPressed, {
    bool enabled = true,
  }) {
    final colors = Theme.of(context).colorScheme;

    return SizedBox(
      width: 200,
      child: OutlinedButton(
        onPressed: enabled ? onPressed : null,
        style: OutlinedButton.styleFrom(
          padding: const EdgeInsets.all(16),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(12),
          ),
          side: BorderSide(
            color: enabled
                ? iconColor.withAlpha(77)
                : colors.outline.withAlpha(51),
          ),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(
                  icon,
                  color: enabled ? iconColor : colors.onSurfaceVariant,
                  size: 20,
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: Text(
                    title,
                    style: GoogleFonts.inter(
                      fontSize: 14,
                      fontWeight: FontWeight.w500,
                      color:
                          enabled ? colors.onSurface : colors.onSurfaceVariant,
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 6),
            Text(
              description,
              style: GoogleFonts.inter(
                fontSize: 12,
                fontWeight: FontWeight.w400,
                color: enabled
                    ? colors.onSurfaceVariant
                    : colors.onSurfaceVariant.withAlpha(128),
              ),
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildConfirmationOverlay(ColorScheme colors, bool isDark) {
    return Positioned.fill(
      child: Container(
        decoration: BoxDecoration(
          color: colors.scrim.withAlpha(128),
          borderRadius: BorderRadius.circular(12),
        ),
        child: Center(
          child: Container(
            width: 400,
            padding: const EdgeInsets.all(24),
            decoration: BoxDecoration(
              color: colors.surface,
              borderRadius: BorderRadius.circular(16),
              boxShadow: [
                BoxShadow(
                  color: colors.shadow,
                  blurRadius: 16,
                  spreadRadius: 4,
                ),
              ],
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.all(8),
                      decoration: BoxDecoration(
                        color: AppTheme.getWarningColor(isDark).withAlpha(26),
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: Icon(
                        Icons.warning,
                        color: AppTheme.getWarningColor(isDark),
                        size: 24,
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Text(
                        'Confirm Bulk Action',
                        style: GoogleFonts.inter(
                          fontSize: 18,
                          fontWeight: FontWeight.w600,
                          color: colors.onSurface,
                        ),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 16),
                Text(
                  'Are you sure you want to perform "$_pendingAction" on ${_pendingTargets.length} selected items? This action may significantly impact agent visibility across P2P interfaces.',
                  style: GoogleFonts.inter(
                    fontSize: 14,
                    fontWeight: FontWeight.w400,
                    color: colors.onSurfaceVariant,
                  ),
                ),
                const SizedBox(height: 24),
                Row(
                  children: [
                    Expanded(
                      child: OutlinedButton(
                        onPressed: () =>
                            setState(() => _showConfirmation = false),
                        child: Text('Cancel'),
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: ElevatedButton(
                        onPressed: () {
                          widget.onBulkAction(_pendingAction, _pendingTargets);
                          setState(() => _showConfirmation = false);
                        },
                        style: ElevatedButton.styleFrom(
                          backgroundColor: AppTheme.getWarningColor(isDark),
                          foregroundColor: Colors.white,
                        ),
                        child: Text('Confirm'),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  void _confirmAction(String action, List<String> targets) {
    setState(() {
      _pendingAction = action;
      _pendingTargets = List.from(targets);
      _showConfirmation = true;
    });
  }
}
