import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:sizer/sizer.dart';
import 'package:url_launcher/url_launcher.dart';

import '../../core/app_export.dart';
import '../../core/services/secure_wallet_service.dart';
import '../../core/services/web3_escrow_service.dart';
import './widgets/balance_display_widget.dart';
import './widgets/connection_status_widget.dart';
import './widgets/network_selector_widget.dart';
import './widgets/qr_scanner_widget.dart';
import './widgets/security_features_widget.dart';
import './widgets/wallet_provider_card_widget.dart';

class Web3WalletIntegrationHub extends StatefulWidget {
  const Web3WalletIntegrationHub({Key? key}) : super(key: key);

  @override
  State<Web3WalletIntegrationHub> createState() =>
      _Web3WalletIntegrationHubState();
}

class _Web3WalletIntegrationHubState extends State<Web3WalletIntegrationHub> {
  bool _isConnecting = false;
  String? _connectingWallet;
  bool _isQrScanning = false;
  String? _connectedWallet;
  String? _walletAddress;
  bool _showBalanceDisplay = false;
  String _selectedNetwork = 'Ethereum Mainnet';
  Map<String, double> _tokenBalances = {};
  bool _sessionActive = false;
  int _sessionTimeoutMinutes = 30;

  // Supported wallet providers with WalletConnect integration
  final List<Map<String, dynamic>> _walletProviders = [
    {
      "id": "metamask",
      "name": "MetaMask",
      "logo":
          "https://upload.wikimedia.org/wikipedia/commons/3/36/MetaMask_Fox.svg",
      "isConnected": false,
      "connectionStatus":
          "disconnected", // disconnected, connecting, connected, failed "deepLink": "metamask://",
      "universalLink": "https://metamask.app.link/",
      "supportsWalletConnect": true,
      "description": "The leading Ethereum wallet extension",
    },
    {
      "id": "trust_wallet",
      "name": "Trust Wallet",
      "logo":
          "https://trustwallet.com/assets/images/media/assets/trust_platform.png",
      "isConnected": false,
      "connectionStatus": "disconnected",
      "deepLink": "trust://",
      "universalLink": "https://link.trustwallet.com/",
      "supportsWalletConnect": true,
      "description": "Simple and secure mobile wallet",
    },
  ];

  @override
  void initState() {
    super.initState();
    _checkExistingConnection();
    _startSessionTimer();
  }

  Future<void> _checkExistingConnection() async {
    try {
      final hasWallet = await SecureWalletService.instance.hasWallet();
      final address = await SecureWalletService.instance.getWalletAddress();

      if (hasWallet && address != null) {
        setState(() {
          _connectedWallet = "Internal Wallet";
          _walletAddress = address;
          _showBalanceDisplay = true;
          _sessionActive = true;
        });
        await _loadBalances();
      }
    } catch (e) {
      if (kDebugMode) {
        print('Error checking wallet connection: $e');
      }
    }
  }

  void _startSessionTimer() {
    if (_sessionActive) {
      Future.delayed(Duration(minutes: _sessionTimeoutMinutes), () {
        if (mounted && _sessionActive) {
          _showSessionTimeoutWarning();
        }
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Theme.of(context).scaffoldBackgroundColor,
      body: SafeArea(
        child: Column(
          children: [
            // Header with ZoTrust branding and security badges
            _buildHeader(context),

            // Content
            Expanded(
              child: SingleChildScrollView(
                physics: const BouncingScrollPhysics(),
                child: Column(
                  children: [
                    SizedBox(height: 2.h),

                    // Connection Status Widget
                    ConnectionStatusWidget(
                      isConnected: _connectedWallet != null,
                      connectedWallet: _connectedWallet,
                      walletAddress: _walletAddress,
                      sessionActive: _sessionActive,
                      onDisconnect: _disconnectWallet,
                    ),

                    if (_showBalanceDisplay && _connectedWallet != null) ...[
                      SizedBox(height: 3.h),
                      // Balance Display Widget
                      BalanceDisplayWidget(
                        tokenBalances: _tokenBalances,
                        walletAddress: _walletAddress!,
                        selectedNetwork: _selectedNetwork,
                        onCopyAddress: _copyAddress,
                        onGenerateQR: _generateQRCode,
                      ),

                      SizedBox(height: 2.h),
                      // Network Selector Widget
                      NetworkSelectorWidget(
                        selectedNetwork: _selectedNetwork,
                        onNetworkChanged: _switchNetwork,
                      ),
                    ],

                    SizedBox(height: 3.h),

                    // Wallet Provider Cards
                    _buildWalletProvidersSection(),

                    SizedBox(height: 3.h),

                    // QR Code Scanner
                    QrScannerWidget(
                      onPressed: _scanQrCode,
                      isLoading: _isQrScanning,
                      onManualInput: _showManualConnectionInput,
                    ),

                    SizedBox(height: 3.h),

                    // Security Features Widget
                    const SecurityFeaturesWidget(),

                    SizedBox(height: 4.h),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildHeader(BuildContext context) {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 4.w, vertical: 2.h),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [
            AppTheme.lightTheme.colorScheme.primary,
            AppTheme.lightTheme.colorScheme.primary.withValues(alpha: 0.8),
          ],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        boxShadow: [
          BoxShadow(
            color:
                AppTheme.lightTheme.colorScheme.primary.withValues(alpha: 0.3),
            blurRadius: 15,
            offset: const Offset(0, 5),
          ),
        ],
      ),
      child: Column(
        children: [
          Row(
            children: [
              // Back Button
              IconButton(
                onPressed: () => Navigator.pop(context),
                icon: CustomIconWidget(
                  iconName: 'arrow_back',
                  color: Colors.white,
                  size: 6.w,
                ),
                style: IconButton.styleFrom(
                  backgroundColor: Colors.white.withValues(alpha: 0.2),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                ),
              ),

              SizedBox(width: 4.w),

              // Title and ZoTrust Branding
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Text(
                      'ZoTrust',
                      style:
                          Theme.of(context).textTheme.headlineSmall?.copyWith(
                                color: Colors.white,
                                fontWeight: FontWeight.w800,
                                letterSpacing: 1.2,
                              ),
                      textAlign: TextAlign.center,
                    ),
                    SizedBox(height: 0.5.h),
                    Text(
                      'Web3 Wallet Integration Hub',
                      style: Theme.of(context).textTheme.titleMedium?.copyWith(
                            color: Colors.white.withValues(alpha: 0.9),
                            fontWeight: FontWeight.w600,
                          ),
                      textAlign: TextAlign.center,
                    ),
                  ],
                ),
              ),

              SizedBox(width: 4.w),

              // Security Status Indicator
              Container(
                padding: EdgeInsets.symmetric(horizontal: 3.w, vertical: 1.h),
                decoration: BoxDecoration(
                  color: Colors.white.withValues(alpha: 0.2),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    CustomIconWidget(
                      iconName: 'security',
                      color: Colors.white,
                      size: 4.w,
                    ),
                    SizedBox(width: 2.w),
                    Text(
                      'Secure',
                      style: Theme.of(context).textTheme.labelSmall?.copyWith(
                            color: Colors.white,
                            fontWeight: FontWeight.w600,
                          ),
                    ),
                  ],
                ),
              ),
            ],
          ),

          SizedBox(height: 1.h),

          // ZoTrust Security Badges
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              _buildSecurityBadge('End-to-End Encryption', Icons.lock),
              SizedBox(width: 4.w),
              _buildSecurityBadge('Device Fingerprinting', Icons.fingerprint),
              SizedBox(width: 4.w),
              _buildSecurityBadge('Session Management', Icons.timer),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildSecurityBadge(String label, IconData icon) {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 2.w, vertical: 0.5.h),
      decoration: BoxDecoration(
        color: Colors.white.withValues(alpha: 0.15),
        borderRadius: BorderRadius.circular(8),
        border: Border.all(
          color: Colors.white.withValues(alpha: 0.3),
          width: 1,
        ),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(
            icon,
            color: Colors.white,
            size: 3.w,
          ),
          SizedBox(width: 1.w),
          Text(
            label,
            style: Theme.of(context).textTheme.labelSmall?.copyWith(
                  color: Colors.white.withValues(alpha: 0.9),
                  fontWeight: FontWeight.w500,
                  fontSize: 10.sp,
                ),
          ),
        ],
      ),
    );
  }

  Widget _buildWalletProvidersSection() {
    return Padding(
      padding: EdgeInsets.symmetric(horizontal: 4.w),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            _connectedWallet != null
                ? 'Switch Wallet Provider'
                : 'Connect Wallet Provider',
            style: Theme.of(context).textTheme.titleLarge?.copyWith(
                  fontWeight: FontWeight.w700,
                ),
          ),
          SizedBox(height: 1.h),
          Text(
            'Choose your preferred wallet for secure Web3 transactions',
            style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                  color: Theme.of(context).colorScheme.onSurfaceVariant,
                ),
          ),
          SizedBox(height: 2.h),

          // Wallet Provider Cards
          ...List.generate(_walletProviders.length, (index) {
            final provider = _walletProviders[index];
            return WalletProviderCardWidget(
              walletName: provider["name"] as String,
              walletLogo: provider["logo"] as String,
              description: provider["description"] as String,
              isConnected: provider["isConnected"] as bool,
              connectionStatus: provider["connectionStatus"] as String,
              isLoading: _isConnecting && _connectingWallet == provider["id"],
              onConnect: () => _connectWalletProvider(provider),
            );
          }),
        ],
      ),
    );
  }

  Future<void> _connectWalletProvider(Map<String, dynamic> provider) async {
    if (_isConnecting) return;

    setState(() {
      _isConnecting = true;
      _connectingWallet = provider["id"] as String;
    });

    try {
      // Haptic feedback
      HapticFeedback.lightImpact();

      // Update connection status to connecting
      provider["connectionStatus"] = "connecting";
      setState(() {});

      // Simulate WalletConnect v2 connection process
      await _initiateWalletConnect(provider);
    } catch (e) {
      provider["connectionStatus"] = "failed";
      if (mounted) {
        _showConnectionError(provider["name"] as String);
      }
    } finally {
      if (mounted) {
        setState(() {
          _isConnecting = false;
          _connectingWallet = null;
        });
      }
    }
  }

  Future<void> _initiateWalletConnect(Map<String, dynamic> provider) async {
    final walletName = provider["name"] as String;

    // Show connecting dialog
    _showConnectingDialog(walletName);

    // Simulate WalletConnect v2 pairing process
    await Future.delayed(const Duration(seconds: 2));

    if (mounted) {
      Navigator.pop(context); // Close connecting dialog

      // Launch wallet app for approval
      await _launchWalletApp(provider);

      // Wait for user approval simulation
      await Future.delayed(const Duration(seconds: 3));

      if (mounted) {
        // Simulate successful connection
        _handleSuccessfulConnection(provider);
      }
    }
  }

  Future<void> _launchWalletApp(Map<String, dynamic> provider) async {
    try {
      final deepLink = provider["deepLink"] as String;
      final universalLink = provider["universalLink"] as String;

      // Try deep link first, then universal link
      final Uri deepUri = Uri.parse('${deepLink}wc?uri=wc%3A1234567890');
      final Uri universalUri =
          Uri.parse('${universalLink}wc?uri=wc%3A1234567890');

      bool launched = false;

      if (deepLink.isNotEmpty) {
        launched =
            await launchUrl(deepUri, mode: LaunchMode.externalApplication);
      }

      if (!launched && universalLink.isNotEmpty) {
        launched =
            await launchUrl(universalUri, mode: LaunchMode.externalApplication);
      }

      if (!launched) {
        // Fallback: show manual connection instructions
        _showManualConnectionInstructions(provider["name"] as String);
      }
    } catch (e) {
      if (kDebugMode) {
        print('Error launching wallet app: $e');
      }
      _showManualConnectionInstructions(provider["name"] as String);
    }
  }

  void _handleSuccessfulConnection(Map<String, dynamic> provider) {
    // Disconnect other providers
    for (var p in _walletProviders) {
      p["isConnected"] = false;
      p["connectionStatus"] = "disconnected";
    }

    // Connect selected provider
    provider["isConnected"] = true;
    provider["connectionStatus"] = "connected";

    // Mock wallet address for demo
    final mockAddress = '0x742d35Cc6635C0532925a3b8D24E3e3d0c2b3E3F';

    setState(() {
      _connectedWallet = provider["name"] as String;
      _walletAddress = mockAddress;
      _showBalanceDisplay = true;
      _sessionActive = true;
    });

    // Load mock balances
    _loadMockBalances();

    // Show success feedback
    _showConnectionSuccess(provider["name"] as String);

    // Start session timer
    _startSessionTimer();

    // Navigate to dashboard after short delay
    Future.delayed(const Duration(seconds: 2), () {
      if (mounted) {
        Navigator.pushReplacementNamed(context, '/dashboard');
      }
    });
  }

  Future<void> _loadBalances() async {
    try {
      await Web3EscrowService.instance.initialize();
      // Load actual token balances if Web3 service is available
      _loadMockBalances();
    } catch (e) {
      // Fallback to mock data
      _loadMockBalances();
    }
  }

  void _loadMockBalances() {
    setState(() {
      _tokenBalances = {
        'USDC': 1500.0,
        'ETH': 0.75,
        'MATIC': 100.0,
        'DAI': 500.0,
      };
    });
  }

  Future<void> _scanQrCode() async {
    if (_isQrScanning) return;

    setState(() {
      _isQrScanning = true;
    });

    try {
      // Haptic feedback
      HapticFeedback.lightImpact();

      // Simulate QR scanning for WalletConnect
      await Future.delayed(const Duration(seconds: 2));

      if (mounted) {
        _showQrScanResult();
      }
    } catch (e) {
      if (mounted) {
        _showError('Failed to scan QR code');
      }
    } finally {
      if (mounted) {
        setState(() {
          _isQrScanning = false;
        });
      }
    }
  }

  void _showQrScanResult() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: Theme.of(context).cardColor,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(16),
        ),
        title: Row(
          children: [
            CustomIconWidget(
              iconName: 'qr_code_scanner',
              color: AppTheme.lightTheme.colorScheme.primary,
              size: 6.w,
            ),
            SizedBox(width: 3.w),
            Text(
              'Desktop Wallet Detected',
              style: Theme.of(context).textTheme.titleMedium?.copyWith(
                    fontWeight: FontWeight.w600,
                  ),
            ),
          ],
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              'WalletConnect session detected from desktop wallet.',
              style: Theme.of(context).textTheme.bodyMedium,
            ),
            SizedBox(height: 2.h),
            Text(
              'Connection will be established with encryption and session management.',
              style: Theme.of(context).textTheme.bodySmall?.copyWith(
                    color: Theme.of(context).colorScheme.onSurfaceVariant,
                  ),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(context);
              _connectDesktopWallet();
            },
            child: const Text('Connect'),
          ),
        ],
      ),
    );
  }

  Future<void> _connectDesktopWallet() async {
    _showConnectingDialog('Desktop Wallet');

    // Simulate desktop wallet connection
    await Future.delayed(const Duration(seconds: 3));

    if (mounted) {
      Navigator.pop(context);

      // Mock desktop wallet connection
      setState(() {
        _connectedWallet = 'Desktop MetaMask';
        _walletAddress = '0x123...abc';
        _showBalanceDisplay = true;
        _sessionActive = true;
      });

      _loadMockBalances();
      _showConnectionSuccess('Desktop Wallet');

      Future.delayed(const Duration(seconds: 2), () {
        if (mounted) {
          Navigator.pushReplacementNamed(context, '/dashboard');
        }
      });
    }
  }

  void _showManualConnectionInput() {
    final connectionController = TextEditingController();

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: Theme.of(context).cardColor,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(16),
        ),
        title: Text(
          'Manual Connection',
          style: Theme.of(context).textTheme.titleMedium?.copyWith(
                fontWeight: FontWeight.w600,
              ),
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
              controller: connectionController,
              decoration: InputDecoration(
                labelText: 'WalletConnect URI',
                hintText: 'wc:1234567890@2?relay-protocol=...',
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
                prefixIcon: Icon(
                  Icons.link,
                  color: AppTheme.lightTheme.colorScheme.primary,
                ),
              ),
              maxLines: 3,
            ),
            SizedBox(height: 2.h),
            Text(
              'Paste the WalletConnect URI from your desktop wallet',
              style: Theme.of(context).textTheme.bodySmall?.copyWith(
                    color: Theme.of(context).colorScheme.onSurfaceVariant,
                  ),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(context);
              if (connectionController.text.isNotEmpty) {
                _connectWithURI(connectionController.text);
              }
            },
            child: const Text('Connect'),
          ),
        ],
      ),
    );
  }

  Future<void> _connectWithURI(String uri) async {
    _showConnectingDialog('Manual Connection');

    await Future.delayed(const Duration(seconds: 2));

    if (mounted) {
      Navigator.pop(context);
      _handleSuccessfulConnection({
        "name": "Manual Connection",
        "isConnected": false,
        "connectionStatus": "disconnected"
      });
    }
  }

  Future<void> _switchNetwork(String network) async {
    setState(() {
      _selectedNetwork = network;
    });

    // Show network switching feedback
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('Switched to $network'),
        backgroundColor: AppTheme.lightTheme.colorScheme.secondary,
        behavior: SnackBarBehavior.floating,
        duration: const Duration(seconds: 2),
      ),
    );

    // Reload balances for new network
    await Future.delayed(const Duration(milliseconds: 500));
    _loadMockBalances();
  }

  Future<void> _disconnectWallet() async {
    final confirm = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: Theme.of(context).cardColor,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(16),
        ),
        title: const Text('Disconnect Wallet'),
        content: const Text(
          'Are you sure you want to disconnect your wallet? This will end your current session.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () => Navigator.pop(context, true),
            style: ElevatedButton.styleFrom(
              backgroundColor: AppTheme.lightTheme.colorScheme.error,
            ),
            child: const Text('Disconnect'),
          ),
        ],
      ),
    );

    if (confirm == true) {
      // Clear all connections
      for (var provider in _walletProviders) {
        provider["isConnected"] = false;
        provider["connectionStatus"] = "disconnected";
      }

      setState(() {
        _connectedWallet = null;
        _walletAddress = null;
        _showBalanceDisplay = false;
        _sessionActive = false;
        _tokenBalances.clear();
      });

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Wallet disconnected successfully'),
          backgroundColor: Colors.orange,
          behavior: SnackBarBehavior.floating,
        ),
      );
    }
  }

  void _copyAddress(String address) {
    Clipboard.setData(ClipboardData(text: address));
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('Address copied to clipboard'),
        behavior: SnackBarBehavior.floating,
        duration: Duration(seconds: 2),
      ),
    );
    HapticFeedback.lightImpact();
  }

  void _generateQRCode() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: Theme.of(context).cardColor,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(16),
        ),
        title: const Text('Receive Funds'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              padding: EdgeInsets.all(4.w),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(12),
              ),
              child: Icon(
                Icons.qr_code,
                size: 30.w,
                color: Colors.black87,
              ),
            ),
            SizedBox(height: 2.h),
            Text(
              _walletAddress ?? '',
              style: Theme.of(context).textTheme.bodySmall?.copyWith(
                    fontFamily: 'monospace',
                  ),
              textAlign: TextAlign.center,
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Close'),
          ),
          ElevatedButton(
            onPressed: () {
              _copyAddress(_walletAddress!);
              Navigator.pop(context);
            },
            child: const Text('Copy Address'),
          ),
        ],
      ),
    );
  }

  void _showSessionTimeoutWarning() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: Theme.of(context).cardColor,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(16),
        ),
        title: Row(
          children: [
            Icon(
              Icons.timer_off,
              color: Colors.orange,
              size: 6.w,
            ),
            SizedBox(width: 3.w),
            const Text('Session Timeout Warning'),
          ],
        ),
        content: Text(
          'Your wallet session will expire in 5 minutes due to inactivity. Do you want to extend the session?',
          style: Theme.of(context).textTheme.bodyMedium,
        ),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.pop(context);
              _disconnectWallet();
            },
            child: const Text('Disconnect'),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(context);
              setState(() {
                _sessionActive = true;
              });
              _startSessionTimer();
            },
            child: const Text('Extend Session'),
          ),
        ],
      ),
    );
  }

  void _showConnectingDialog(String walletName) {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => AlertDialog(
        backgroundColor: Theme.of(context).cardColor,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(16),
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            SizedBox(
              width: 15.w,
              height: 15.w,
              child: CircularProgressIndicator(
                strokeWidth: 3,
                valueColor: AlwaysStoppedAnimation<Color>(
                  AppTheme.lightTheme.colorScheme.primary,
                ),
              ),
            ),
            SizedBox(height: 3.h),
            Text(
              'Connecting to $walletName',
              style: Theme.of(context).textTheme.titleMedium?.copyWith(
                    fontWeight: FontWeight.w600,
                  ),
              textAlign: TextAlign.center,
            ),
            SizedBox(height: 1.h),
            Text(
              'Please approve the connection in your wallet app',
              style: Theme.of(context).textTheme.bodySmall?.copyWith(
                    color: Theme.of(context).colorScheme.onSurfaceVariant,
                  ),
              textAlign: TextAlign.center,
            ),
          ],
        ),
      ),
    );
  }

  void _showConnectionSuccess(String walletName) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Row(
          children: [
            CustomIconWidget(
              iconName: 'check_circle',
              color: Colors.white,
              size: 5.w,
            ),
            SizedBox(width: 3.w),
            Expanded(
              child: Text(
                '$walletName connected successfully!',
                style: const TextStyle(color: Colors.white),
              ),
            ),
          ],
        ),
        backgroundColor: AppTheme.lightTheme.colorScheme.secondary,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12),
        ),
        duration: const Duration(seconds: 2),
      ),
    );

    HapticFeedback.mediumImpact();
  }

  void _showConnectionError(String walletName) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Row(
          children: [
            CustomIconWidget(
              iconName: 'error',
              color: Colors.white,
              size: 5.w,
            ),
            SizedBox(width: 3.w),
            Expanded(
              child: Text(
                'Failed to connect to $walletName',
                style: const TextStyle(color: Colors.white),
              ),
            ),
          ],
        ),
        backgroundColor: AppTheme.lightTheme.colorScheme.error,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12),
        ),
        duration: const Duration(seconds: 3),
      ),
    );
  }

  void _showManualConnectionInstructions(String walletName) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: Theme.of(context).cardColor,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(16),
        ),
        title: Text('Connect $walletName Manually'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              '1. Open $walletName app on your device',
              style: Theme.of(context).textTheme.bodyMedium,
            ),
            SizedBox(height: 1.h),
            Text(
              '2. Go to Settings > WalletConnect',
              style: Theme.of(context).textTheme.bodyMedium,
            ),
            SizedBox(height: 1.h),
            Text(
              '3. Scan the QR code or paste the connection URI',
              style: Theme.of(context).textTheme.bodyMedium,
            ),
            SizedBox(height: 2.h),
            Text(
              'If you need help, contact ZoTrust support.',
              style: Theme.of(context).textTheme.bodySmall?.copyWith(
                    color: Theme.of(context).colorScheme.onSurfaceVariant,
                  ),
            ),
          ],
        ),
        actions: [
          ElevatedButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Got it'),
          ),
        ],
      ),
    );
  }

  void _showError(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        backgroundColor: AppTheme.lightTheme.colorScheme.error,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12),
        ),
      ),
    );
  }
}
