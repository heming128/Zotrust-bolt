import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';

class WalletProviderCardWidget extends StatelessWidget {
  final String walletName;
  final String walletLogo;
  final String description;
  final bool isConnected;
  final String connectionStatus; // disconnected, connecting, connected, failed
  final bool isLoading;
  final VoidCallback onConnect;

  const WalletProviderCardWidget({
    Key? key,
    required this.walletName,
    required this.walletLogo,
    required this.description,
    required this.isConnected,
    required this.connectionStatus,
    required this.isLoading,
    required this.onConnect,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: EdgeInsets.only(bottom: 2.h),
      decoration: BoxDecoration(
        color: Theme.of(context).cardColor,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: _getBorderColor(context),
          width: isConnected ? 2 : 1,
        ),
        boxShadow: [
          BoxShadow(
            color: Theme.of(context).shadowColor.withValues(alpha: 0.1),
            blurRadius: 8,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Padding(
        padding: EdgeInsets.all(4.w),
        child: Row(
          children: [
            // Wallet Logo with Status Indicator
            Stack(
              children: [
                Container(
                  width: 14.w,
                  height: 14.w,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(12),
                    color: Theme.of(context).colorScheme.surface,
                  ),
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(12),
                    child: CustomImageWidget(
                      imageUrl: walletLogo,
                      width: 14.w,
                      height: 14.w,
                      fit: BoxFit.contain,
                    ),
                  ),
                ),

                // Connection Status Indicator
                Positioned(
                  bottom: 0,
                  right: 0,
                  child: Container(
                    width: 4.w,
                    height: 4.w,
                    decoration: BoxDecoration(
                      color: _getStatusColor(),
                      borderRadius: BorderRadius.circular(2.w),
                      border: Border.all(
                        color: Theme.of(context).cardColor,
                        width: 2,
                      ),
                    ),
                    child: connectionStatus == 'connecting'
                        ? Center(
                            child: SizedBox(
                              width: 2.w,
                              height: 2.w,
                              child: CircularProgressIndicator(
                                strokeWidth: 1.5,
                                valueColor: AlwaysStoppedAnimation<Color>(
                                  Colors.white,
                                ),
                              ),
                            ),
                          )
                        : null,
                  ),
                ),
              ],
            ),

            SizedBox(width: 4.w),

            // Wallet Info
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Expanded(
                        child: Text(
                          walletName,
                          style:
                              Theme.of(context).textTheme.titleMedium?.copyWith(
                                    fontWeight: FontWeight.w600,
                                  ),
                          overflow: TextOverflow.ellipsis,
                        ),
                      ),
                      if (isConnected) ...[
                        Container(
                          padding: EdgeInsets.symmetric(
                              horizontal: 2.w, vertical: 0.5.h),
                          decoration: BoxDecoration(
                            color: AppTheme.lightTheme.colorScheme.secondary
                                .withValues(alpha: 0.1),
                            borderRadius: BorderRadius.circular(8),
                          ),
                          child: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              CustomIconWidget(
                                iconName: 'check_circle',
                                color:
                                    AppTheme.lightTheme.colorScheme.secondary,
                                size: 12,
                              ),
                              SizedBox(width: 1.w),
                              Text(
                                'Active',
                                style: Theme.of(context)
                                    .textTheme
                                    .labelSmall
                                    ?.copyWith(
                                      color: AppTheme
                                          .lightTheme.colorScheme.secondary,
                                      fontWeight: FontWeight.w600,
                                    ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ],
                  ),

                  SizedBox(height: 0.5.h),

                  Text(
                    description,
                    style: Theme.of(context).textTheme.bodySmall?.copyWith(
                          color: Theme.of(context).colorScheme.onSurfaceVariant,
                        ),
                    overflow: TextOverflow.ellipsis,
                  ),

                  SizedBox(height: 1.h),

                  // Connection Status Text
                  Row(
                    children: [
                      CustomIconWidget(
                        iconName: _getStatusIcon(),
                        color: _getStatusColor(),
                        size: 3.w,
                      ),
                      SizedBox(width: 1.w),
                      Text(
                        _getStatusText(),
                        style: Theme.of(context).textTheme.labelSmall?.copyWith(
                              color: _getStatusColor(),
                              fontWeight: FontWeight.w500,
                            ),
                      ),
                    ],
                  ),
                ],
              ),
            ),

            SizedBox(width: 3.w),

            // Connect/Action Button
            SizedBox(
              width: 22.w,
              height: 5.h,
              child: ElevatedButton(
                onPressed: isLoading ? null : onConnect,
                style: ElevatedButton.styleFrom(
                  backgroundColor: _getButtonColor(),
                  foregroundColor: _getButtonTextColor(),
                  elevation: isConnected ? 0 : 2,
                  padding: EdgeInsets.zero,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                ),
                child: isLoading
                    ? SizedBox(
                        width: 4.w,
                        height: 4.w,
                        child: CircularProgressIndicator(
                          strokeWidth: 2,
                          valueColor: AlwaysStoppedAnimation<Color>(
                            _getButtonTextColor(),
                          ),
                        ),
                      )
                    : Text(
                        _getButtonText(),
                        style:
                            Theme.of(context).textTheme.labelMedium?.copyWith(
                                  fontWeight: FontWeight.w600,
                                  color: _getButtonTextColor(),
                                ),
                      ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Color _getBorderColor(BuildContext context) {
    switch (connectionStatus) {
      case 'connected':
        return AppTheme.lightTheme.colorScheme.secondary;
      case 'connecting':
        return AppTheme.lightTheme.colorScheme.primary;
      case 'failed':
        return AppTheme.lightTheme.colorScheme.error;
      default:
        return Theme.of(context).dividerColor;
    }
  }

  Color _getStatusColor() {
    switch (connectionStatus) {
      case 'connected':
        return AppTheme.lightTheme.colorScheme.secondary;
      case 'connecting':
        return AppTheme.lightTheme.colorScheme.primary;
      case 'failed':
        return AppTheme.lightTheme.colorScheme.error;
      default:
        return Colors.grey;
    }
  }

  String _getStatusIcon() {
    switch (connectionStatus) {
      case 'connected':
        return 'check_circle';
      case 'connecting':
        return 'sync';
      case 'failed':
        return 'error';
      default:
        return 'radio_button_unchecked';
    }
  }

  String _getStatusText() {
    switch (connectionStatus) {
      case 'connected':
        return 'Connected & Secured';
      case 'connecting':
        return 'Establishing Connection...';
      case 'failed':
        return 'Connection Failed';
      default:
        return 'Ready to Connect';
    }
  }

  Color _getButtonColor() {
    if (isConnected) {
      return AppTheme.lightTheme.colorScheme.surface.withValues(alpha: 0.8);
    }
    return AppTheme.lightTheme.colorScheme.primary;
  }

  Color _getButtonTextColor() {
    if (isConnected) {
      return AppTheme.lightTheme.colorScheme.onSurface;
    }
    return Colors.white;
  }

  String _getButtonText() {
    if (isConnected) {
      return 'Disconnect';
    }
    return 'Connect';
  }
}
