import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';

class OrderLimitsWidget extends StatelessWidget {
  final double minLimit;
  final double maxLimit;
  final String fiat;
  final Function(double, double) onLimitsChanged;

  const OrderLimitsWidget({
    Key? key,
    required this.minLimit,
    required this.maxLimit,
    required this.fiat,
    required this.onLimitsChanged,
  }) : super(key: key);

  String get _currencySymbol {
    switch (fiat) {
      case 'INR':
        return '₹';
      case 'USD':
        return '\$';
      case 'EUR':
        return '€';
      case 'GBP':
        return '£';
      default:
        return '₹';
    }
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.all(4.w),
      decoration: BoxDecoration(
        color: AppTheme.lightTheme.cardColor,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: AppTheme.lightTheme.colorScheme.outline.withValues(alpha: 0.2),
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Order Limit',
            style: AppTheme.lightTheme.textTheme.titleMedium?.copyWith(
              fontWeight: FontWeight.w600,
              color: AppTheme.lightTheme.primaryColor,
            ),
          ),
          SizedBox(height: 1.h),
          Text(
            'Set minimum and maximum INR trade amounts (₹200 ~ ₹20,00,000)',
            style: AppTheme.lightTheme.textTheme.bodyMedium?.copyWith(
              color: AppTheme.lightTheme.colorScheme.onSurfaceVariant,
            ),
          ),
          SizedBox(height: 3.h),

          // Range display
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                '$_currencySymbol${minLimit.toStringAsFixed(0)}',
                style: AppTheme.lightTheme.textTheme.titleMedium?.copyWith(
                  fontWeight: FontWeight.w600,
                  color: AppTheme.lightTheme.primaryColor,
                ),
              ),
              Text(
                '$_currencySymbol${maxLimit >= 100000 ? "${(maxLimit / 100000).toStringAsFixed(0)},00,000" : maxLimit.toStringAsFixed(0)}',
                style: AppTheme.lightTheme.textTheme.titleMedium?.copyWith(
                  fontWeight: FontWeight.w600,
                  color: AppTheme.lightTheme.primaryColor,
                ),
              ),
            ],
          ),
          SizedBox(height: 1.h),

          // Range slider
          RangeSlider(
            values: RangeValues(minLimit, maxLimit),
            min: 200,
            max: 2000000,
            divisions: 200,
            labels: RangeLabels(
              '$_currencySymbol${minLimit.toStringAsFixed(0)}',
              '$_currencySymbol${maxLimit >= 100000 ? "${(maxLimit / 100000).toStringAsFixed(0)},00,000" : maxLimit.toStringAsFixed(0)}',
            ),
            activeColor: AppTheme.lightTheme.primaryColor,
            inactiveColor:
                AppTheme.lightTheme.primaryColor.withValues(alpha: 0.3),
            onChanged: (RangeValues values) {
              onLimitsChanged(values.start, values.end);
            },
          ),

          SizedBox(height: 1.h),

          // Quick limit presets
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              _buildPresetButton(context, 'Low', 200, 50000),
              _buildPresetButton(context, 'Medium', 1000, 500000),
              _buildPresetButton(context, 'High', 10000, 2000000),
            ],
          ),

          SizedBox(height: 2.h),

          Container(
            padding: EdgeInsets.symmetric(horizontal: 3.w, vertical: 1.h),
            decoration: BoxDecoration(
              color: AppTheme.lightTheme.primaryColor.withValues(alpha: 0.1),
              borderRadius: BorderRadius.circular(8),
            ),
            child: Row(
              children: [
                CustomIconWidget(
                  iconName: 'info',
                  color: AppTheme.lightTheme.primaryColor,
                  size: 16,
                ),
                SizedBox(width: 2.w),
                Expanded(
                  child: Text(
                    'Example: ₹500 trade will be possible within your set range',
                    style: AppTheme.lightTheme.textTheme.bodySmall?.copyWith(
                      color: AppTheme.lightTheme.primaryColor,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildPresetButton(
      BuildContext context, String label, double min, double max) {
    final isSelected = minLimit == min && maxLimit == max;

    return GestureDetector(
      onTap: () => onLimitsChanged(min, max),
      child: Container(
        padding: EdgeInsets.symmetric(horizontal: 4.w, vertical: 1.h),
        decoration: BoxDecoration(
          color: isSelected
              ? AppTheme.lightTheme.primaryColor
              : AppTheme.lightTheme.scaffoldBackgroundColor,
          borderRadius: BorderRadius.circular(8),
          border: Border.all(
            color: isSelected
                ? AppTheme.lightTheme.primaryColor
                : AppTheme.lightTheme.colorScheme.outline
                    .withValues(alpha: 0.3),
          ),
        ),
        child: Text(
          label,
          style: AppTheme.lightTheme.textTheme.bodySmall?.copyWith(
            color: isSelected
                ? Colors.white
                : AppTheme.lightTheme.colorScheme.onSurfaceVariant,
            fontWeight: FontWeight.w600,
          ),
        ),
      ),
    );
  }
}
