import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../core/app_export.dart';
import './widgets/advanced_settings_widget.dart';
import './widgets/amount_input_section_widget.dart';
import './widgets/order_limits_widget.dart';
import './widgets/payment_methods_widget.dart';
import './widgets/terms_preview_widget.dart';
import './widgets/time_limit_widget.dart';

class SetAmountMethod extends StatefulWidget {
  const SetAmountMethod({Key? key}) : super(key: key);

  @override
  State<SetAmountMethod> createState() => _SetAmountMethodState();
}

class _SetAmountMethodState extends State<SetAmountMethod> {
  String _totalAmount = '';
  double _minLimit = 200;
  double _maxLimit = 2000000;
  String _selectedPaymentMethod = 'Cash Exchange';
  int _timeLimit = 2; // Default 2 hours
  bool _isLoading = false;

  Map<String, dynamic>? _adData;

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    if (_adData == null) {
      _adData =
          ModalRoute.of(context)?.settings.arguments as Map<String, dynamic>?;
    }
  }

  bool get _isFormValid =>
      _totalAmount.isNotEmpty &&
      double.tryParse(_totalAmount) != null &&
      _selectedPaymentMethod.isNotEmpty;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.lightTheme.scaffoldBackgroundColor,
      appBar: _buildAppBar(),
      body: _buildBody(),
    );
  }

  PreferredSizeWidget _buildAppBar() {
    return AppBar(
      backgroundColor: AppTheme.lightTheme.scaffoldBackgroundColor,
      elevation: 0,
      leading: IconButton(
        onPressed: () => Navigator.pop(context),
        icon: CustomIconWidget(
          iconName: 'arrow_back',
          color: AppTheme.lightTheme.colorScheme.onSurface,
          size: 24,
        ),
      ),
      title: Text(
        'Post Ad',
        style: AppTheme.lightTheme.textTheme.titleLarge?.copyWith(
          fontWeight: FontWeight.w600,
          color: AppTheme.lightTheme.primaryColor,
        ),
      ),
      centerTitle: true,
    );
  }

  Widget _buildBody() {
    return SafeArea(
      child: Column(
        children: [
          Expanded(
            child: SingleChildScrollView(
              padding: EdgeInsets.symmetric(horizontal: 4.w, vertical: 2.h),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Progress indicator
                  _buildProgressIndicator(),

                  SizedBox(height: 3.h),

                  // Amount Input Section
                  AmountInputSectionWidget(
                    amount: _totalAmount,
                    asset: _adData?['asset'] ?? 'USDT',
                    onAmountChanged: (amount) {
                      setState(() {
                        _totalAmount = amount;
                      });
                    },
                  ),

                  SizedBox(height: 2.h),

                  // Order Limits
                  OrderLimitsWidget(
                    minLimit: _minLimit,
                    maxLimit: _maxLimit,
                    fiat: _adData?['fiat'] ?? 'INR',
                    onLimitsChanged: (min, max) {
                      setState(() {
                        _minLimit = min;
                        _maxLimit = max;
                      });
                    },
                  ),

                  SizedBox(height: 2.h),

                  // Payment Methods
                  PaymentMethodsWidget(
                    selectedMethod: _selectedPaymentMethod,
                    onMethodChanged: (method) {
                      setState(() {
                        _selectedPaymentMethod = method;
                      });
                    },
                  ),

                  SizedBox(height: 2.h),

                  // Time Limit
                  TimeLimitWidget(
                    timeLimit: _timeLimit,
                    onTimeLimitChanged: (limit) {
                      setState(() {
                        _timeLimit = limit;
                      });
                    },
                  ),

                  SizedBox(height: 2.h),

                  // Advanced Settings
                  AdvancedSettingsWidget(),

                  SizedBox(height: 2.h),

                  // Terms Preview
                  TermsPreviewWidget(
                    adData: _adData,
                    totalAmount: _totalAmount,
                    minLimit: _minLimit,
                    maxLimit: _maxLimit,
                    paymentMethod: _selectedPaymentMethod,
                    timeLimit: _timeLimit,
                  ),

                  SizedBox(height: 2.h),
                ],
              ),
            ),
          ),

          // Post Advertisement Button
          Container(
            padding: EdgeInsets.all(4.w),
            child: SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed:
                    _isFormValid && !_isLoading ? _onPostAdPressed : null,
                style: ElevatedButton.styleFrom(
                  backgroundColor: _isFormValid && !_isLoading
                      ? AppTheme.lightTheme.primaryColor
                      : AppTheme.getNeutralColor(true),
                  foregroundColor: Colors.white,
                  padding: EdgeInsets.symmetric(vertical: 2.h),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                  elevation: 0,
                ),
                child: _isLoading
                    ? SizedBox(
                        height: 20,
                        width: 20,
                        child: CircularProgressIndicator(
                          strokeWidth: 2,
                          valueColor:
                              AlwaysStoppedAnimation<Color>(Colors.white),
                        ),
                      )
                    : Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          CustomIconWidget(
                            iconName: 'add_circle',
                            color: Colors.white,
                            size: 20,
                          ),
                          SizedBox(width: 2.w),
                          Text(
                            'Post Advertisement',
                            style: AppTheme.lightTheme.textTheme.titleMedium
                                ?.copyWith(
                              color: Colors.white,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                        ],
                      ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildProgressIndicator() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Step 2 of 2',
          style: AppTheme.lightTheme.textTheme.bodyMedium?.copyWith(
            color: AppTheme.lightTheme.colorScheme.onSurfaceVariant,
          ),
        ),
        SizedBox(height: 1.h),
        LinearProgressIndicator(
          value: 1.0,
          backgroundColor:
              AppTheme.getNeutralColor(true).withValues(alpha: 0.3),
          valueColor: AlwaysStoppedAnimation<Color>(
            AppTheme.lightTheme.primaryColor,
          ),
        ),
      ],
    );
  }

  void _onPostAdPressed() async {
    setState(() {
      _isLoading = true;
    });

    // Simulate API call
    await Future.delayed(Duration(seconds: 2));

    setState(() {
      _isLoading = false;
    });

    // Generate ad ID
    final adId =
        'AD${DateTime.now().millisecondsSinceEpoch.toString().substring(8)}';

    // Show success dialog
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Row(
            children: [
              CustomIconWidget(
                iconName: 'check_circle',
                color: Colors.green,
                size: 24,
              ),
              SizedBox(width: 2.w),
              Text('Ad Posted Successfully!'),
            ],
          ),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('Your advertisement has been posted successfully.'),
              SizedBox(height: 1.h),
              Container(
                padding: EdgeInsets.all(3.w),
                decoration: BoxDecoration(
                  color:
                      AppTheme.lightTheme.primaryColor.withValues(alpha: 0.1),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Row(
                  children: [
                    Text(
                      'Ad ID: ',
                      style: AppTheme.lightTheme.textTheme.bodyMedium?.copyWith(
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    Text(
                      adId,
                      style: AppTheme.lightTheme.textTheme.bodyMedium?.copyWith(
                        color: AppTheme.lightTheme.primaryColor,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.of(context).pop(); // Close dialog
                Navigator.of(context).pop(); // Go back to previous screen
                Navigator.of(context).pop(); // Go back to P2P screen
              },
              child: Text('View My Ads'),
            ),
            ElevatedButton(
              onPressed: () {
                Navigator.of(context).pop(); // Close dialog
                Navigator.of(context).pop(); // Go back to previous screen
                Navigator.of(context).pop(); // Go back to P2P screen
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: AppTheme.lightTheme.primaryColor,
                foregroundColor: Colors.white,
              ),
              child: Text('Done'),
            ),
          ],
        );
      },
    );
  }
}
