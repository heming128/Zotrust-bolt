import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:sizer/sizer.dart';

import '../../core/app_export.dart';
import './widgets/action_buttons_widget.dart';
import './widgets/communication_panel_widget.dart';
import './widgets/otp_section_widget.dart';
import './widgets/trade_info_card_widget.dart';
import './widgets/trade_status_badge_widget.dart';
import './widgets/trade_status_timeline_widget.dart';

class TradeDetails extends StatefulWidget {
  const TradeDetails({Key? key}) : super(key: key);

  @override
  State<TradeDetails> createState() => _TradeDetailsState();
}

class _TradeDetailsState extends State<TradeDetails> {
  bool _isLoading = false;
  bool _showOtpSection = false;
  int _unreadMessages = 3;
  bool _isCallActive = false;
  bool _isReleasingUSDC = false;
  bool _cashReceived = false;

  // Mock trade data
  final Map<String, dynamic> _tradeData = {
    'tradeId': 'TRD-2025-001847',
    'status': 'Created',
    'userRole': 'seller',
    'usdcAmount': '500.00',
    'fiatAmount': '500.00',
    'counterpartyAddress': '0x742d35Cc6634C0532925a3b8D4C8C8b4c8C8b4c8',
    'agentNickname': 'CryptoExchange_Downtown',
    'createdAt': DateTime.now().subtract(const Duration(hours: 2)),
    'paidAt': null,
    'releasedAt': null,
    'completedAt': null,
    'blockchainTxHash': null,
    'gasFee': null,
    'gasFeeUsd': null,
    'usdcReleased': false,
    'cashReceivedAt': null,
  };

  // Updated OTP data - specific OTP code as requested
  final Map<String, dynamic> _otpData = {
    'code': '789123',
    'colorCode': '#00C851',
    'tradeId': 'TRD-2025-001847',
    'expiresAt': DateTime.now().add(const Duration(minutes: 15)),
  };

  @override
  void initState() {
    super.initState();
    _checkOtpVisibility();
  }

  void _checkOtpVisibility() {
    setState(() {
      // Updated OTP visibility logic based on user role and trade status
      if (_tradeData['userRole'] == 'buyer') {
        // Buyer can see OTP from the beginning when trade is paid
        _showOtpSection = _tradeData['status'] == 'Paid' ||
            _tradeData['status'] == 'CashReceived' ||
            _tradeData['status'] == 'Released';
      } else if (_tradeData['userRole'] == 'seller') {
        // Seller can see OTP after confirming cash receipt
        _showOtpSection = _tradeData['status'] == 'CashReceived' ||
            _tradeData['status'] == 'Released';
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Theme.of(context).scaffoldBackgroundColor,
      appBar: _buildAppBar(context),
      body: RefreshIndicator(
        onRefresh: _refreshTradeData,
        child: SingleChildScrollView(
          physics: const AlwaysScrollableScrollPhysics(),
          child: SafeArea(
            child: Column(
              children: [
                SizedBox(height: 2.h),
                _buildStatusBadge(),
                SizedBox(height: 2.h),
                TradeStatusTimelineWidget(
                  currentStatus: _tradeData['status'] as String,
                  tradeData: _tradeData,
                ),
                TradeInfoCardWidget(
                  tradeData: _tradeData,
                ),
                OtpSectionWidget(
                  tradeId: _tradeData['tradeId'] as String,
                  tradeData: _tradeData,
                  onTradeUpdate: (updatedTradeData) {
                    setState(() {
                      _tradeData.addAll(updatedTradeData);
                    });
                  },
                ),
                ActionButtonsWidget(
                  userRole: _tradeData['userRole'] as String,
                  tradeStatus: _tradeData['status'] as String,
                  onMarkAsPaid: _handleMarkAsPaid,
                  onConfirmPayment: _handleConfirmPayment,
                  onCancelTrade: _handleCancelTrade,
                  onReportIssue: _handleReportIssue,
                  onCashReceived: _handleCashReceived,
                ),
                CommunicationPanelWidget(
                  tradeId: _tradeData['tradeId'] as String,
                  onOpenChat: _handleOpenChat,
                  onStartCall: _handleStartCall,
                  unreadMessages: _unreadMessages,
                  isCallActive: _isCallActive,
                ),
                SizedBox(height: 4.h),
              ],
            ),
          ),
        ),
      ),
    );
  }

  PreferredSizeWidget _buildAppBar(BuildContext context) {
    return AppBar(
      title: Column(
        children: [
          Text(
            'Trade Details',
            style: Theme.of(context).appBarTheme.titleTextStyle,
          ),
          Text(
            _tradeData['tradeId'] as String,
            style: Theme.of(context).textTheme.bodySmall?.copyWith(
                  color: Theme.of(context).colorScheme.onSurfaceVariant,
                ),
          ),
        ],
      ),
      leading: IconButton(
        onPressed: () => Navigator.of(context).pop(),
        icon: CustomIconWidget(
          iconName: 'arrow_back',
          color: Theme.of(context).colorScheme.onSurface,
          size: 6.w,
        ),
      ),
      actions: [
        IconButton(
          onPressed: _handleShareTrade,
          icon: CustomIconWidget(
            iconName: 'share',
            color: Theme.of(context).colorScheme.onSurface,
            size: 6.w,
          ),
        ),
        IconButton(
          onPressed: _handleRefresh,
          icon: CustomIconWidget(
            iconName: 'refresh',
            color: Theme.of(context).colorScheme.onSurface,
            size: 6.w,
          ),
        ),
      ],
    );
  }

  Widget _buildStatusBadge() {
    return Padding(
      padding: EdgeInsets.symmetric(horizontal: 4.w),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          TradeStatusBadgeWidget(
            status: _tradeData['status'] as String,
            isAnimated: true,
          ),
        ],
      ),
    );
  }

  Future<void> _refreshTradeData() async {
    setState(() {
      _isLoading = true;
    });

    // Simulate API call
    await Future.delayed(const Duration(seconds: 1));

    // Mock status update
    if (_tradeData['status'] == 'Created') {
      // Simulate random status progression for demo
      final random = DateTime.now().millisecond % 3;
      if (random == 0) {
        setState(() {
          _tradeData['status'] = 'Paid';
          _tradeData['paidAt'] = DateTime.now();
          _showOtpSection = true;
        });
      }
    }

    setState(() {
      _isLoading = false;
    });

    HapticFeedback.lightImpact();
  }

  void _handleMarkAsPaid() {
    HapticFeedback.mediumImpact();

    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Row(
            children: [
              CustomIconWidget(
                iconName: 'payment',
                color: AppTheme.lightTheme.colorScheme.secondary,
                size: 6.w,
              ),
              SizedBox(width: 3.w),
              Text('Confirm Payment'),
            ],
          ),
          content: Text(
            'Have you sent the payment to the seller? This action will notify the agent to verify the payment.',
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(context).pop(),
              child: Text('Cancel'),
            ),
            ElevatedButton(
              onPressed: () {
                Navigator.of(context).pop();
                _updateTradeStatus('Paid');
              },
              child: Text('Confirm Payment Sent'),
            ),
          ],
        );
      },
    );
  }

  void _handleConfirmPayment() {
    HapticFeedback.mediumImpact();

    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Row(
            children: [
              CustomIconWidget(
                iconName: 'check_circle',
                color: AppTheme.lightTheme.colorScheme.secondary,
                size: 6.w,
              ),
              SizedBox(width: 3.w),
              Text('Complete Transaction'),
            ],
          ),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                'Complete the trade by releasing USDC from the smart contract escrow to the buyer.',
              ),
              SizedBox(height: 2.h),
              Container(
                padding: EdgeInsets.all(3.w),
                decoration: BoxDecoration(
                  color: AppTheme.lightTheme.colorScheme.primary
                      .withValues(alpha: 0.1),
                  borderRadius: BorderRadius.circular(2.w),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      '⚠️ Final Step:',
                      style: Theme.of(context).textTheme.titleSmall?.copyWith(
                            color: AppTheme.lightTheme.colorScheme.primary,
                            fontWeight: FontWeight.w600,
                          ),
                    ),
                    SizedBox(height: 1.h),
                    Text(
                      'This action will release the locked USDC to the buyer and mark the trade as complete. This cannot be reversed.',
                      style: Theme.of(context).textTheme.bodySmall?.copyWith(
                            color: AppTheme.lightTheme.colorScheme.primary,
                          ),
                    ),
                  ],
                ),
              ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(context).pop(),
              child: Text('Cancel'),
            ),
            ElevatedButton(
              onPressed: _isReleasingUSDC
                  ? null
                  : () {
                      Navigator.of(context).pop();
                      _releaseUSDCAndUpdateStatus();
                    },
              child: _isReleasingUSDC
                  ? SizedBox(
                      width: 20,
                      height: 20,
                      child: CircularProgressIndicator(strokeWidth: 2),
                    )
                  : Text('Release USDC & Complete'),
            ),
          ],
        );
      },
    );
  }

  Future<void> _releaseUSDCAndUpdateStatus() async {
    setState(() {
      _isReleasingUSDC = true;
    });

    try {
      // Simulate smart contract interaction
      await Future.delayed(const Duration(seconds: 3));

      // Simulate blockchain transaction
      final mockTxHash =
          '0x8f4a2b1c9d6e3f7a8b5c2d9e6f3a7b4c1d8e5f2a9b6c3d0e7f4a1b8c5d2e9f6a3';

      setState(() {
        _tradeData['status'] = 'Released';
        _tradeData['releasedAt'] = DateTime.now();
        _tradeData['blockchainTxHash'] = mockTxHash;
        _tradeData['gasFee'] = '0.0023';
        _tradeData['gasFeeUsd'] = '0.12';
        _tradeData['usdcReleased'] = true;
        _isReleasingUSDC = false;
      });

      // Update OTP visibility after USDC release
      _checkOtpVisibility();

      HapticFeedback.mediumImpact();

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                '✅ USDC Released Successfully!',
                style: TextStyle(fontWeight: FontWeight.w600),
              ),
              Text(
                'Transaction: ${mockTxHash.substring(0, 10)}...',
                style: TextStyle(fontSize: 12),
              ),
              if (_tradeData['userRole'] == 'seller')
                Text(
                  '🔢 OTP now available - show to agent for cash collection',
                  style: TextStyle(fontSize: 12),
                ),
            ],
          ),
          backgroundColor: AppTheme.getSuccessColor(true),
          duration: const Duration(seconds: 5),
        ),
      );
    } catch (e) {
      setState(() {
        _isReleasingUSDC = false;
      });

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Failed to release USDC. Please try again.'),
          backgroundColor: AppTheme.lightTheme.colorScheme.error,
        ),
      );
    }
  }

  void _handleCancelTrade() {
    HapticFeedback.lightImpact();

    setState(() {
      _tradeData['status'] = 'Cancelled';
    });

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('Trade has been cancelled'),
        backgroundColor: AppTheme.lightTheme.colorScheme.error,
      ),
    );
  }

  void _handleReportIssue() {
    HapticFeedback.lightImpact();

    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Row(
            children: [
              CustomIconWidget(
                iconName: 'report',
                color: AppTheme.getWarningColor(true),
                size: 6.w,
              ),
              SizedBox(width: 3.w),
              Text('Report Issue'),
            ],
          ),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text('What type of issue are you experiencing?'),
              SizedBox(height: 2.h),
              ...[
                'Payment not received',
                'Counterparty not responding',
                'Technical issue',
                'Other'
              ].map(
                (issue) => ListTile(
                  title: Text(issue),
                  onTap: () {
                    Navigator.of(context).pop();
                    _submitIssueReport(issue);
                  },
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  void _handleOpenChat() {
    HapticFeedback.lightImpact();
    setState(() {
      _unreadMessages = 0;
    });
    Navigator.pushNamed(context, '/in-app-chat');
  }

  void _handleStartCall() {
    HapticFeedback.lightImpact();
    setState(() {
      _isCallActive = !_isCallActive;
    });

    if (_isCallActive) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Voice call started'),
          backgroundColor: AppTheme.getSuccessColor(true),
        ),
      );
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Voice call ended'),
        ),
      );
    }
  }

  void _handleShareTrade() {
    HapticFeedback.lightImpact();

    final tradeLink = 'https://zedtrust.app/trade/${_tradeData['tradeId']}';
    Clipboard.setData(ClipboardData(text: tradeLink));

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('Trade link copied to clipboard'),
        duration: const Duration(seconds: 2),
      ),
    );
  }

  void _handleRefresh() {
    HapticFeedback.lightImpact();
    _refreshTradeData();
  }

  void _updateTradeStatus(String newStatus) {
    setState(() {
      _tradeData['status'] = newStatus;

      switch (newStatus) {
        case 'Paid':
          _tradeData['paidAt'] = DateTime.now();
          if (_tradeData['userRole'] == 'buyer') {
            _showOtpSection = true;
          }
          break;
        case 'CashReceived':
          _tradeData['cashReceivedAt'] = DateTime.now();
          _cashReceived = true;
          _showOtpSection = true;
          break;
        case 'Released':
          _tradeData['releasedAt'] = DateTime.now();
          _tradeData['blockchainTxHash'] =
              '0x8f4a2b1c9d6e3f7a8b5c2d9e6f3a7b4c1d8e5f2a9b6c3d0e7f4a1b8c5d2e9f6a3';
          _tradeData['gasFee'] = '0.0023';
          _tradeData['gasFeeUsd'] = '0.12';
          _tradeData['usdcReleased'] = true;
          break;
        case 'Completed':
          _tradeData['completedAt'] = DateTime.now();
          break;
      }
    });

    // Update OTP visibility after status change
    _checkOtpVisibility();

    HapticFeedback.mediumImpact();

    String message = '';
    switch (newStatus) {
      case 'CashReceived':
        message = 'Cash receipt confirmed - OTP now available';
        break;
      case 'Released':
        message = 'USDC released successfully - Trade completed';
        break;
      default:
        message = 'Trade status updated to $newStatus';
    }

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        backgroundColor: AppTheme.getSuccessColor(true),
      ),
    );
  }

  void _submitIssueReport(String issue) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('Issue reported: $issue'),
        backgroundColor: AppTheme.getWarningColor(true),
      ),
    );
  }

  void _handleCashReceived() {
    HapticFeedback.mediumImpact();

    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Row(
            children: [
              CustomIconWidget(
                iconName: 'attach_money',
                color: AppTheme.getSuccessColor(true),
                size: 6.w,
              ),
              SizedBox(width: 3.w),
              Text('Confirm Cash Receipt'),
            ],
          ),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                'Have you received the cash payment from the buyer?',
              ),
              SizedBox(height: 2.h),
              Container(
                padding: EdgeInsets.all(3.w),
                decoration: BoxDecoration(
                  color: AppTheme.lightTheme.colorScheme.primary
                      .withValues(alpha: 0.1),
                  borderRadius: BorderRadius.circular(2.w),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      '📱 Next Step:',
                      style: Theme.of(context).textTheme.titleSmall?.copyWith(
                            color: AppTheme.lightTheme.colorScheme.primary,
                            fontWeight: FontWeight.w600,
                          ),
                    ),
                    SizedBox(height: 1.h),
                    Text(
                      'After confirming, you will receive the OTP code to show the agent for verification. The USDC will then be released to complete the trade.',
                      style: Theme.of(context).textTheme.bodySmall?.copyWith(
                            color: AppTheme.lightTheme.colorScheme.primary,
                          ),
                    ),
                  ],
                ),
              ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(context).pop(),
              child: Text('Cancel'),
            ),
            ElevatedButton(
              onPressed: () {
                Navigator.of(context).pop();
                _updateTradeStatus('CashReceived');
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: AppTheme.getSuccessColor(true),
              ),
              child: Text('Yes, I have received cash'),
            ),
          ],
        );
      },
    );
  }
}