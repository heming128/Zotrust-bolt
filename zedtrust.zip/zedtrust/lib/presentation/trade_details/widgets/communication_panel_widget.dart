import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';

class CommunicationPanelWidget extends StatelessWidget {
  final String tradeId;
  final VoidCallback? onOpenChat;
  final VoidCallback? onStartCall;
  final int unreadMessages;
  final bool isCallActive;

  const CommunicationPanelWidget({
    Key? key,
    required this.tradeId,
    this.onOpenChat,
    this.onStartCall,
    this.unreadMessages = 0,
    this.isCallActive = false,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: EdgeInsets.all(4.w),
      margin: EdgeInsets.symmetric(horizontal: 4.w, vertical: 1.h),
      decoration: BoxDecoration(
        color: Theme.of(context).cardColor,
        borderRadius: BorderRadius.circular(3.w),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.05),
            blurRadius: 8,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              CustomIconWidget(
                iconName: 'chat',
                color: AppTheme.lightTheme.colorScheme.primary,
                size: 6.w,
              ),
              SizedBox(width: 3.w),
              Text(
                'Communication',
                style: Theme.of(context).textTheme.titleMedium?.copyWith(
                      fontWeight: FontWeight.w600,
                    ),
              ),
              const Spacer(),
              if (unreadMessages > 0)
                Container(
                  padding:
                      EdgeInsets.symmetric(horizontal: 2.w, vertical: 0.5.h),
                  decoration: BoxDecoration(
                    color: AppTheme.lightTheme.colorScheme.error,
                    borderRadius: BorderRadius.circular(3.w),
                  ),
                  child: Text(
                    unreadMessages > 99 ? '99+' : unreadMessages.toString(),
                    style: Theme.of(context).textTheme.bodySmall?.copyWith(
                          color: Colors.white,
                          fontWeight: FontWeight.w600,
                        ),
                  ),
                ),
            ],
          ),
          SizedBox(height: 3.h),
          _buildCommunicationOptions(context),
          SizedBox(height: 3.h),
          _buildSecurityInfo(context),
        ],
      ),
    );
  }

  Widget _buildCommunicationOptions(BuildContext context) {
    return Row(
      children: [
        Expanded(
          child: _buildCommunicationButton(
            context,
            'Secure Chat',
            'chat_bubble',
            AppTheme.lightTheme.colorScheme.primary,
            onOpenChat,
            unreadMessages > 0,
          ),
        ),
        SizedBox(width: 3.w),
        Expanded(
          child: _buildCommunicationButton(
            context,
            isCallActive ? 'End Call' : 'Voice Call',
            isCallActive ? 'call_end' : 'call',
            isCallActive
                ? AppTheme.lightTheme.colorScheme.error
                : AppTheme.getSuccessColor(true),
            onStartCall,
            isCallActive,
          ),
        ),
      ],
    );
  }

  Widget _buildCommunicationButton(
    BuildContext context,
    String label,
    String iconName,
    Color color,
    VoidCallback? onPressed,
    bool hasIndicator,
  ) {
    return Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(2.w),
        boxShadow: hasIndicator
            ? [
                BoxShadow(
                  color: color.withValues(alpha: 0.3),
                  blurRadius: 8,
                  offset: const Offset(0, 2),
                ),
              ]
            : null,
      ),
      child: ElevatedButton(
        onPressed: onPressed != null
            ? () {
                HapticFeedback.lightImpact();
                onPressed();
              }
            : null,
        style: ElevatedButton.styleFrom(
          backgroundColor: hasIndicator ? color : color.withValues(alpha: 0.1),
          foregroundColor: hasIndicator ? Colors.white : color,
          elevation: hasIndicator ? 4 : 0,
          padding: EdgeInsets.symmetric(vertical: 3.h),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(2.w),
            side: hasIndicator
                ? BorderSide.none
                : BorderSide(color: color.withValues(alpha: 0.3)),
          ),
        ),
        child: Column(
          children: [
            Stack(
              children: [
                CustomIconWidget(
                  iconName: iconName,
                  color: hasIndicator ? Colors.white : color,
                  size: 6.w,
                ),
                if (hasIndicator && !isCallActive)
                  Positioned(
                    right: 0,
                    top: 0,
                    child: Container(
                      width: 2.w,
                      height: 2.w,
                      decoration: BoxDecoration(
                        color: Colors.white,
                        shape: BoxShape.circle,
                        border: Border.all(
                          color: color,
                          width: 1,
                        ),
                      ),
                    ),
                  ),
              ],
            ),
            SizedBox(height: 1.h),
            Text(
              label,
              style: Theme.of(context).textTheme.bodySmall?.copyWith(
                    color: hasIndicator ? Colors.white : color,
                    fontWeight: FontWeight.w500,
                  ),
              textAlign: TextAlign.center,
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildSecurityInfo(BuildContext context) {
    return Container(
      padding: EdgeInsets.all(3.w),
      decoration: BoxDecoration(
        color: AppTheme.getSuccessColor(true).withValues(alpha: 0.05),
        borderRadius: BorderRadius.circular(2.w),
        border: Border.all(
          color: AppTheme.getSuccessColor(true).withValues(alpha: 0.2),
        ),
      ),
      child: Row(
        children: [
          CustomIconWidget(
            iconName: 'security',
            color: AppTheme.getSuccessColor(true),
            size: 5.w,
          ),
          SizedBox(width: 3.w),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'End-to-End Encrypted',
                  style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                        color: AppTheme.getSuccessColor(true),
                        fontWeight: FontWeight.w600,
                      ),
                ),
                Text(
                  'Your communications are secure and private. No phone numbers are shared.',
                  style: Theme.of(context).textTheme.bodySmall?.copyWith(
                        color: AppTheme.getSuccessColor(true),
                      ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
