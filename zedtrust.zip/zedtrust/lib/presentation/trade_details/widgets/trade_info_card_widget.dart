import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';
import '../../../theme/app_theme.dart';
import '../../dashboard/widgets/platform_fees_widget.dart';

class TradeInfoCardWidget extends StatefulWidget {
  final Map<String, dynamic> tradeData;

  const TradeInfoCardWidget({
    Key? key,
    required this.tradeData,
  }) : super(key: key);

  @override
  State<TradeInfoCardWidget> createState() => _TradeInfoCardWidgetState();
}

class _TradeInfoCardWidgetState extends State<TradeInfoCardWidget> {
  bool _showFeesExpanded = false;

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: EdgeInsets.symmetric(horizontal: 4.w, vertical: 1.h),
      child: Column(
        children: [
          Container(
            padding: EdgeInsets.all(4.w),
            decoration: BoxDecoration(
              color: AppTheme.lightTheme.cardColor,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(
                color: AppTheme.lightTheme.colorScheme.outline
                    .withValues(alpha: 0.2),
              ),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withValues(alpha: 0.05),
                  blurRadius: 8,
                  offset: const Offset(0, 2),
                ),
              ],
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Trade Information',
                  style: AppTheme.lightTheme.textTheme.titleLarge?.copyWith(
                    fontWeight: FontWeight.w600,
                  ),
                ),
                SizedBox(height: 3.h),
                _buildInfoRow('Amount', '\$${widget.tradeData['usdcAmount']}'),
                _buildInfoRow('Counterparty',
                    '${widget.tradeData['counterpartyAddress']?.toString().substring(0, 10)}...'),
                _buildInfoRow('Agent', widget.tradeData['agentNickname']),
                _buildInfoRow(
                    'Role',
                    widget.tradeData['userRole'] == 'buyer'
                        ? 'Buyer'
                        : 'Seller'),
                _buildInfoRow(
                    'Created', _formatDateTime(widget.tradeData['createdAt'])),
                if (widget.tradeData['blockchainTxHash'] != null) ...[
                  SizedBox(height: 2.h),
                  _buildInfoRow('Blockchain Tx',
                      '${widget.tradeData['blockchainTxHash']?.toString().substring(0, 10)}...'),
                  if (widget.tradeData['gasFee'] != null)
                    _buildInfoRow('Gas Fee',
                        '\$${widget.tradeData['gasFeeUsd']} (${widget.tradeData['gasFee']} MATIC)'),
                ],
              ],
            ),
          ),
          SizedBox(height: 2.h),
          PlatformFeesWidget(
            amount:
                double.tryParse(widget.tradeData['usdcAmount'] ?? '0') ?? 0.0,
            role: widget.tradeData['userRole'] ?? 'buyer',
            isExpanded: _showFeesExpanded,
            onToggle: () {
              setState(() {
                _showFeesExpanded = !_showFeesExpanded;
              });
            },
          ),
        ],
      ),
    );
  }

  Widget _buildInfoRow(String label, String value) {
    return Padding(
      padding: EdgeInsets.symmetric(vertical: 1.h),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(
            width: 25.w,
            child: Text(
              label,
              style: AppTheme.lightTheme.textTheme.bodySmall?.copyWith(
                color: AppTheme.lightTheme.colorScheme.onSurfaceVariant,
              ),
            ),
          ),
          Expanded(
            child: Text(
              value,
              style: AppTheme.lightTheme.textTheme.bodyMedium?.copyWith(
                fontWeight: FontWeight.w500,
              ),
            ),
          ),
        ],
      ),
    );
  }

  String _formatDateTime(DateTime? dateTime) {
    if (dateTime == null) return 'N/A';
    return '${dateTime.day}/${dateTime.month}/${dateTime.year} ${dateTime.hour}:${dateTime.minute.toString().padLeft(2, '0')}';
  }
}
