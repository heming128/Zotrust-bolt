import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';
import '../../../theme/app_theme.dart';

class TradeStatusBadgeWidget extends StatefulWidget {
  final String status;
  final bool isAnimated;

  const TradeStatusBadgeWidget({
    Key? key,
    required this.status,
    this.isAnimated = false,
  }) : super(key: key);

  @override
  State<TradeStatusBadgeWidget> createState() => _TradeStatusBadgeWidgetState();
}

class _TradeStatusBadgeWidgetState extends State<TradeStatusBadgeWidget>
    with SingleTickerProviderStateMixin {
  late AnimationController _animationController;
  late Animation<double> _scaleAnimation;
  late Animation<double> _opacityAnimation;

  @override
  void initState() {
    super.initState();
    _animationController = AnimationController(
      duration: const Duration(milliseconds: 800),
      vsync: this,
    );

    _scaleAnimation = Tween<double>(
      begin: 0.8,
      end: 1.0,
    ).animate(CurvedAnimation(
      parent: _animationController,
      curve: Curves.elasticOut,
    ));

    _opacityAnimation = Tween<double>(
      begin: 0.0,
      end: 1.0,
    ).animate(CurvedAnimation(
      parent: _animationController,
      curve: Curves.easeInOut,
    ));

    if (widget.isAnimated) {
      _animationController.forward();
    } else {
      _animationController.value = 1.0;
    }
  }

  @override
  void dispose() {
    _animationController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _animationController,
      builder: (context, child) {
        return Transform.scale(
          scale: _scaleAnimation.value,
          child: Opacity(
            opacity: _opacityAnimation.value,
            child: Container(
              padding: EdgeInsets.symmetric(horizontal: 6.w, vertical: 2.h),
              decoration: BoxDecoration(
                color: _getStatusColor().withValues(alpha: 0.1),
                borderRadius: BorderRadius.circular(8.w),
                border: Border.all(
                  color: _getStatusColor(),
                  width: 1.5,
                ),
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Container(
                    width: 3.w,
                    height: 3.w,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: _getStatusColor(),
                    ),
                  ),
                  SizedBox(width: 2.w),
                  Text(
                    _getStatusText(),
                    style: Theme.of(context).textTheme.labelLarge?.copyWith(
                          color: _getStatusColor(),
                          fontWeight: FontWeight.w600,
                        ),
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  Color _getStatusColor() {
    switch (widget.status.toLowerCase()) {
      case 'created':
        return AppTheme.lightTheme.colorScheme.primary;
      case 'paid':
        return AppTheme.getWarningColor(true);
      case 'released':
        return AppTheme.lightTheme.colorScheme.secondary;
      case 'completed':
        return AppTheme.getSuccessColor(true);
      case 'cancelled':
        return AppTheme.lightTheme.colorScheme.error;
      default:
        return AppTheme.lightTheme.colorScheme.outline;
    }
  }

  String _getStatusText() {
    switch (widget.status.toLowerCase()) {
      case 'created':
        return 'Awaiting Payment';
      case 'paid':
        return 'Payment Confirmed';
      case 'released':
        return 'USDC Released';
      case 'completed':
        return 'Trade Completed';
      case 'cancelled':
        return 'Trade Cancelled';
      default:
        return widget.status;
    }
  }
}
