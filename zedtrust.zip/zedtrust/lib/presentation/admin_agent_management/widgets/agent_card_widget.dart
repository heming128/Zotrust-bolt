import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';
import 'package:google_fonts/google_fonts.dart';
import '../../../theme/app_theme.dart';

class AgentCardWidget extends StatelessWidget {
  final Map<String, dynamic> agent;
  final bool isSelected;
  final VoidCallback onTap;
  final VoidCallback onLongPress;
  final Function(bool) onVerificationToggle;

  const AgentCardWidget({
    super.key,
    required this.agent,
    required this.isSelected,
    required this.onTap,
    required this.onLongPress,
    required this.onVerificationToggle,
  });

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final isVerified = agent['is_verified'] == true;
    final locationCount = (agent['agent_locations'] as List? ?? []).length;
    final rating = (agent['rating'] as num?)?.toDouble() ?? 0.0;

    return GestureDetector(
      onTap: onTap,
      onLongPress: onLongPress,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        margin: EdgeInsets.only(bottom: 12.h),
        padding: EdgeInsets.all(16.sp),
        decoration: BoxDecoration(
          color: isSelected
              ? AppTheme.primaryLight.withAlpha(26)
              : Theme.of(context).cardColor,
          borderRadius: BorderRadius.circular(12.sp),
          border: Border.all(
            color: isSelected
                ? AppTheme.primaryLight
                : AppTheme.getNeutralColor(!isDark),
            width: isSelected ? 2 : 1,
          ),
          boxShadow: [
            BoxShadow(
              color: isDark ? Colors.black26 : AppTheme.shadowLight,
              blurRadius: 8,
              offset: const Offset(0, 2),
            ),
          ],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Header Row
            Row(
              children: [
                // Agent Avatar
                Container(
                  width: 50.w,
                  height: 50.h,
                  decoration: BoxDecoration(
                    color: isVerified
                        ? AppTheme.successLight.withAlpha(26)
                        : AppTheme.warningLight.withAlpha(26),
                    borderRadius: BorderRadius.circular(25.sp),
                  ),
                  child: Icon(
                    Icons.person,
                    color: isVerified
                        ? AppTheme.successLight
                        : AppTheme.warningLight,
                    size: 24.sp,
                  ),
                ),

                SizedBox(width: 12.w),

                // Agent Info
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Expanded(
                            child: Text(
                              agent['name'] ?? 'Unknown Agent',
                              style: GoogleFonts.inter(
                                fontSize: 16.sp,
                                fontWeight: FontWeight.w600,
                                color: Theme.of(context)
                                    .textTheme
                                    .titleLarge
                                    ?.color,
                              ),
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                            ),
                          ),
                          if (isVerified)
                            Container(
                              padding: EdgeInsets.symmetric(
                                  horizontal: 6.w, vertical: 2.h),
                              decoration: BoxDecoration(
                                color: AppTheme.successLight,
                                borderRadius: BorderRadius.circular(4.sp),
                              ),
                              child: Icon(
                                Icons.verified,
                                color: Colors.white,
                                size: 12.sp,
                              ),
                            ),
                        ],
                      ),
                      SizedBox(height: 4.h),
                      Text(
                        agent['alias'] ?? '',
                        style: GoogleFonts.inter(
                          fontSize: 14.sp,
                          color: AppTheme.textSecondaryLight,
                        ),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      ),
                    ],
                  ),
                ),

                // Selection Indicator
                if (isSelected)
                  Container(
                    width: 24.w,
                    height: 24.h,
                    decoration: BoxDecoration(
                      color: AppTheme.primaryLight,
                      borderRadius: BorderRadius.circular(12.sp),
                    ),
                    child: Icon(
                      Icons.check,
                      color: Colors.white,
                      size: 16.sp,
                    ),
                  ),
              ],
            ),

            SizedBox(height: 16.h),

            // Stats Row
            Row(
              children: [
                _buildStatItem(
                  icon: Icons.location_on_outlined,
                  label:
                      '$locationCount Location${locationCount != 1 ? 's' : ''}',
                  color: AppTheme.primaryLight,
                ),

                SizedBox(width: 16.w),

                _buildStatItem(
                  icon: Icons.star_outline,
                  label: '${rating.toStringAsFixed(1)} Rating',
                  color: AppTheme.warningLight,
                ),

                const Spacer(),

                // Status Badge
                Container(
                  padding: EdgeInsets.symmetric(horizontal: 8.w, vertical: 4.h),
                  decoration: BoxDecoration(
                    color: isVerified
                        ? AppTheme.successLight.withAlpha(26)
                        : AppTheme.warningLight.withAlpha(26),
                    borderRadius: BorderRadius.circular(6.sp),
                  ),
                  child: Text(
                    isVerified ? 'Active' : 'Pending',
                    style: GoogleFonts.inter(
                      fontSize: 10.sp,
                      fontWeight: FontWeight.w500,
                      color: isVerified
                          ? AppTheme.successLight
                          : AppTheme.warningLight,
                    ),
                  ),
                ),
              ],
            ),

            SizedBox(height: 16.h),

            // Quick Actions
            Row(
              children: [
                Expanded(
                  child: OutlinedButton.icon(
                    onPressed: () => onVerificationToggle(!isVerified),
                    icon: Icon(
                      isVerified ? Icons.block : Icons.verified,
                      size: 16.sp,
                    ),
                    label: Text(
                      isVerified ? 'Suspend' : 'Verify',
                      style: GoogleFonts.inter(fontSize: 12.sp),
                    ),
                    style: OutlinedButton.styleFrom(
                      padding: EdgeInsets.symmetric(vertical: 8.h),
                      side: BorderSide(
                        color: isVerified
                            ? AppTheme.errorLight
                            : AppTheme.successLight,
                      ),
                      foregroundColor: isVerified
                          ? AppTheme.errorLight
                          : AppTheme.successLight,
                    ),
                  ),
                ),
                SizedBox(width: 8.w),
                Expanded(
                  child: ElevatedButton.icon(
                    onPressed: onTap,
                    icon: Icon(
                      Icons.settings,
                      size: 16.sp,
                    ),
                    label: Text(
                      'Manage',
                      style: GoogleFonts.inter(fontSize: 12.sp),
                    ),
                    style: ElevatedButton.styleFrom(
                      padding: EdgeInsets.symmetric(vertical: 8.h),
                      backgroundColor: AppTheme.primaryLight,
                      foregroundColor: Colors.white,
                    ),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildStatItem({
    required IconData icon,
    required String label,
    required Color color,
  }) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Icon(
          icon,
          size: 16.sp,
          color: color,
        ),
        SizedBox(width: 4.w),
        Text(
          label,
          style: GoogleFonts.inter(
            fontSize: 12.sp,
            fontWeight: FontWeight.w500,
            color: AppTheme.textSecondaryLight,
          ),
        ),
      ],
    );
  }
}
