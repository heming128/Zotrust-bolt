import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';
import 'package:google_fonts/google_fonts.dart';
import '../../../theme/app_theme.dart';

class AgentFilterWidget extends StatelessWidget {
  final String selectedFilter;
  final Function(String) onFilterChanged;

  const AgentFilterWidget({
    super.key,
    required this.selectedFilter,
    required this.onFilterChanged,
  });

  @override
  Widget build(BuildContext context) {
    final filters = [
      {'id': 'all', 'label': 'All Agents', 'icon': Icons.group},
      {'id': 'verified', 'label': 'Verified', 'icon': Icons.verified},
      {'id': 'unverified', 'label': 'Pending', 'icon': Icons.pending},
      {'id': 'active', 'label': 'Active', 'icon': Icons.check_circle},
      {'id': 'inactive', 'label': 'Inactive', 'icon': Icons.cancel},
    ];

    return SizedBox(
      height: 40.h,
      child: ListView.separated(
        scrollDirection: Axis.horizontal,
        itemCount: filters.length,
        separatorBuilder: (context, index) => SizedBox(width: 8.w),
        itemBuilder: (context, index) {
          final filter = filters[index];
          final isSelected = selectedFilter == filter['id'];

          return FilterChip(
            selected: isSelected,
            onSelected: (selected) {
              if (selected) {
                onFilterChanged(filter['id'] as String);
              }
            },
            avatar: Icon(
              filter['icon'] as IconData,
              size: 16.sp,
              color: isSelected ? Colors.white : AppTheme.textSecondaryLight,
            ),
            label: Text(
              filter['label'] as String,
              style: GoogleFonts.inter(
                fontSize: 12.sp,
                fontWeight: FontWeight.w500,
                color: isSelected ? Colors.white : AppTheme.textSecondaryLight,
              ),
            ),
            backgroundColor: Theme.of(context).scaffoldBackgroundColor,
            selectedColor: AppTheme.primaryLight,
            checkmarkColor: Colors.white,
            side: BorderSide(
              color: isSelected
                  ? AppTheme.primaryLight
                  : AppTheme.getNeutralColor(true),
            ),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(20.sp),
            ),
            padding: EdgeInsets.symmetric(horizontal: 8.w, vertical: 4.h),
            materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
          );
        },
      ),
    );
  }
}
