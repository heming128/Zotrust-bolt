import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';

class P2PFiltersWidget extends StatelessWidget {
  final String selectedPaymentMethod;
  final Function(String) onPaymentMethodChanged;

  const P2PFiltersWidget({
    Key? key,
    required this.selectedPaymentMethod,
    required this.onPaymentMethodChanged,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final filterOptions = ['Payment', 'Amount', 'Post Ad'];

    return Container(
      margin: EdgeInsets.symmetric(horizontal: 4.w, vertical: 2.h),
      height: 5.h,
      child: ListView.builder(
        scrollDirection: Axis.horizontal,
        itemCount: filterOptions.length,
        itemBuilder: (context, index) {
          final option = filterOptions[index];
          final isSelected = selectedPaymentMethod == option ||
              (option == 'Payment' && selectedPaymentMethod == 'Cash Exchange');

          return GestureDetector(
            onTap: () {
              if (option == 'Payment') {
                _showPaymentMethodDropdown(context);
              } else if (option == 'Post Ad') {
                Navigator.pushNamed(context, AppRoutes.setTypePrice);
              } else {
                onPaymentMethodChanged(option);
              }
            },
            child: Container(
              margin: EdgeInsets.only(right: 2.w),
              padding: EdgeInsets.symmetric(horizontal: 4.w, vertical: 1.h),
              decoration: BoxDecoration(
                color: isSelected
                    ? AppTheme.lightTheme.primaryColor
                    : AppTheme.lightTheme.cardColor,
                borderRadius: BorderRadius.circular(20),
                border: Border.all(
                  color: isSelected
                      ? AppTheme.lightTheme.primaryColor
                      : AppTheme.lightTheme.colorScheme.outline
                          .withValues(alpha: 0.3),
                ),
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  if (option == 'Post Ad')
                    Icon(
                      Icons.add,
                      color: isSelected
                          ? Colors.white
                          : AppTheme.lightTheme.primaryColor,
                      size: 16,
                    ),
                  if (option == 'Post Ad') SizedBox(width: 1.w),
                  Text(
                    selectedPaymentMethod == 'Cash Exchange' &&
                            option == 'Payment'
                        ? 'Cash Exchange'
                        : option,
                    style: AppTheme.lightTheme.textTheme.bodyMedium?.copyWith(
                      color: isSelected
                          ? Colors.white
                          : AppTheme.lightTheme.colorScheme.onSurface,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                  if (option == 'Payment') ...[
                    SizedBox(width: 1.w),
                    Icon(
                      Icons.keyboard_arrow_down,
                      color: isSelected
                          ? Colors.white
                          : AppTheme.lightTheme.colorScheme.onSurface,
                      size: 18,
                    ),
                  ],
                ],
              ),
            ),
          );
        },
      ),
    );
  }

  void _showPaymentMethodDropdown(BuildContext context) {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (BuildContext context) {
        return Container(
          decoration: BoxDecoration(
            color: AppTheme.lightTheme.cardColor,
            borderRadius: const BorderRadius.vertical(top: Radius.circular(20)),
          ),
          padding: EdgeInsets.all(6.w),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              // Handle bar
              Container(
                width: 12.w,
                height: 0.5.h,
                decoration: BoxDecoration(
                  color: AppTheme.getNeutralColor(true),
                  borderRadius: BorderRadius.circular(4),
                ),
              ),
              SizedBox(height: 3.h),
              Text(
                'Select Payment Method',
                style: AppTheme.lightTheme.textTheme.titleLarge?.copyWith(
                  fontWeight: FontWeight.w600,
                ),
              ),
              SizedBox(height: 3.h),

              // All Payment Methods option
              ListTile(
                contentPadding:
                    EdgeInsets.symmetric(horizontal: 4.w, vertical: 1.h),
                leading: Icon(
                  Icons.payment,
                  color: AppTheme.lightTheme.primaryColor,
                  size: 24,
                ),
                title: Text(
                  'All Payment Methods',
                  style: AppTheme.lightTheme.textTheme.titleMedium,
                ),
                trailing: selectedPaymentMethod == 'Payment'
                    ? Icon(
                        Icons.check_circle,
                        color: AppTheme.lightTheme.primaryColor,
                        size: 20,
                      )
                    : null,
                onTap: () {
                  Navigator.pop(context);
                  onPaymentMethodChanged('Payment');
                },
              ),

              Divider(
                color: AppTheme.lightTheme.colorScheme.outline
                    .withValues(alpha: 0.3),
                thickness: 1,
              ),

              // Cash Exchange option
              ListTile(
                contentPadding:
                    EdgeInsets.symmetric(horizontal: 4.w, vertical: 1.h),
                leading: Icon(
                  Icons.local_atm,
                  color: AppTheme.lightTheme.primaryColor,
                  size: 24,
                ),
                title: Text(
                  'Cash Exchange',
                  style: AppTheme.lightTheme.textTheme.titleMedium,
                ),
                trailing: selectedPaymentMethod == 'Cash Exchange'
                    ? Icon(
                        Icons.check_circle,
                        color: AppTheme.lightTheme.primaryColor,
                        size: 20,
                      )
                    : null,
                onTap: () {
                  Navigator.pop(context);
                  onPaymentMethodChanged('Cash Exchange');
                },
              ),

              SizedBox(height: 2.h),
            ],
          ),
        );
      },
    );
  }
}
