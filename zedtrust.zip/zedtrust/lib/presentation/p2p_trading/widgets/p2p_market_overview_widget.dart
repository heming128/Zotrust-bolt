import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';
import '../../../core/services/currency_service.dart';

class P2PMarketOverviewWidget extends StatefulWidget {
  final String selectedCurrency;
  final Function(String) onCurrencyChanged;

  const P2PMarketOverviewWidget({
    Key? key,
    required this.selectedCurrency,
    required this.onCurrencyChanged,
  }) : super(key: key);

  @override
  State<P2PMarketOverviewWidget> createState() =>
      _P2PMarketOverviewWidgetState();
}

class _P2PMarketOverviewWidgetState extends State<P2PMarketOverviewWidget> {
  final CurrencyService _currencyService = CurrencyService();
  String _bestBuyPriceINR = '₹83.30';
  String _bestSellPriceINR = '₹83.67';
  bool _isLoadingRates = false;

  @override
  void initState() {
    super.initState();
    _loadINRPrices();
  }

  Future<void> _loadINRPrices() async {
    setState(() {
      _isLoadingRates = true;
    });

    try {
      // Convert hardcoded USD prices to INR
      final buyPriceINR = await _currencyService.convertUSDToINR(0.998);
      final sellPriceINR = await _currencyService.convertUSDToINR(1.002);

      setState(() {
        _bestBuyPriceINR = _currencyService.formatINRPrice(buyPriceINR);
        _bestSellPriceINR = _currencyService.formatINRPrice(sellPriceINR);
        _isLoadingRates = false;
      });
    } catch (e) {
      setState(() {
        _isLoadingRates = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: EdgeInsets.symmetric(horizontal: 4.w),
      padding: EdgeInsets.all(4.w),
      decoration: BoxDecoration(
        color: AppTheme.lightTheme.cardColor,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: AppTheme.lightTheme.colorScheme.outline.withValues(alpha: 0.2),
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                'Market Overview',
                style: AppTheme.lightTheme.textTheme.titleMedium?.copyWith(
                  fontWeight: FontWeight.w600,
                ),
              ),
              Row(
                children: [
                  if (_isLoadingRates)
                    Container(
                      width: 16,
                      height: 16,
                      margin: EdgeInsets.only(right: 2.w),
                      child: CircularProgressIndicator(
                        strokeWidth: 2,
                        valueColor: AlwaysStoppedAnimation<Color>(
                          AppTheme.lightTheme.primaryColor,
                        ),
                      ),
                    ),
                  GestureDetector(
                    onTap: () => _showCurrencySelector(context),
                    child: Container(
                      padding:
                          EdgeInsets.symmetric(horizontal: 3.w, vertical: 1.h),
                      decoration: BoxDecoration(
                        color: AppTheme.lightTheme.primaryColor
                            .withValues(alpha: 0.1),
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Text(
                            widget.selectedCurrency,
                            style: AppTheme.lightTheme.textTheme.titleSmall
                                ?.copyWith(
                              fontWeight: FontWeight.w600,
                              color: AppTheme.lightTheme.primaryColor,
                            ),
                          ),
                          SizedBox(width: 1.w),
                          CustomIconWidget(
                            iconName: 'expand_more',
                            color: AppTheme.lightTheme.primaryColor,
                            size: 16,
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ],
          ),
          SizedBox(height: 2.h),
          Row(
            children: [
              Expanded(
                child: _buildMarketStat(
                  'Best Buy Price',
                  _bestBuyPriceINR,
                  Colors.green,
                  'trending_up',
                ),
              ),
              SizedBox(width: 3.w),
              Expanded(
                child: _buildMarketStat(
                  'Best Sell Price',
                  _bestSellPriceINR,
                  Colors.red,
                  'trending_down',
                ),
              ),
            ],
          ),
          SizedBox(height: 2.h),
          Row(
            children: [
              Expanded(
                child: _buildMarketStat(
                  '24h Volume',
                  '₹10.02Cr',
                  AppTheme.lightTheme.primaryColor,
                  'bar_chart',
                ),
              ),
              SizedBox(width: 3.w),
              Expanded(
                child: _buildMarketStat(
                  'Active Orders',
                  '1,547',
                  AppTheme.lightTheme.primaryColor,
                  'swap_horiz',
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildMarketStat(
      String label, String value, Color color, String icon) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            CustomIconWidget(
              iconName: icon,
              color: color,
              size: 16,
            ),
            SizedBox(width: 1.w),
            Text(
              label,
              style: AppTheme.lightTheme.textTheme.bodySmall?.copyWith(
                color: AppTheme.lightTheme.colorScheme.onSurfaceVariant,
              ),
            ),
          ],
        ),
        SizedBox(height: 0.5.h),
        Text(
          value,
          style: AppTheme.lightTheme.textTheme.titleMedium?.copyWith(
            fontWeight: FontWeight.w600,
            color: color,
          ),
        ),
      ],
    );
  }

  void _showCurrencySelector(BuildContext context) {
    final currencies = ['USDC', 'USDT', 'BTC', 'ETH'];

    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      builder: (context) => Container(
        decoration: BoxDecoration(
          color: AppTheme.lightTheme.cardColor,
          borderRadius: const BorderRadius.vertical(top: Radius.circular(20)),
        ),
        padding: EdgeInsets.all(6.w),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 12.w,
              height: 0.5.h,
              decoration: BoxDecoration(
                color: AppTheme.getNeutralColor(true),
                borderRadius: BorderRadius.circular(4),
              ),
            ),
            SizedBox(height: 3.h),
            Text(
              'Select Currency',
              style: AppTheme.lightTheme.textTheme.titleLarge?.copyWith(
                fontWeight: FontWeight.w600,
              ),
            ),
            SizedBox(height: 3.h),
            ...currencies
                .map((currency) => ListTile(
                      leading: Container(
                        padding: EdgeInsets.all(1.w),
                        decoration: BoxDecoration(
                          color: AppTheme.lightTheme.primaryColor
                              .withValues(alpha: 0.1),
                          borderRadius: BorderRadius.circular(8),
                        ),
                        child: CustomIconWidget(
                          iconName: 'monetization_on',
                          color: AppTheme.lightTheme.primaryColor,
                          size: 20,
                        ),
                      ),
                      title: Text(
                        currency,
                        style: AppTheme.lightTheme.textTheme.titleMedium,
                      ),
                      trailing: widget.selectedCurrency == currency
                          ? CustomIconWidget(
                              iconName: 'check',
                              color: AppTheme.getSuccessColor(true),
                              size: 20,
                            )
                          : null,
                      onTap: () {
                        Navigator.pop(context);
                        widget.onCurrencyChanged(currency);
                      },
                    ))
                .toList(),
            SizedBox(height: 2.h),
          ],
        ),
      ),
    );
  }
}
