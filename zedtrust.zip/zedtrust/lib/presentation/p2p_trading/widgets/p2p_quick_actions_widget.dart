import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';

class P2PQuickActionsWidget extends StatelessWidget {
  final VoidCallback onBuyPressed;
  final VoidCallback onSellPressed;

  const P2PQuickActionsWidget({
    Key? key,
    required this.onBuyPressed,
    required this.onSellPressed,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: EdgeInsets.all(4.w),
      child: Row(
        children: [
          Expanded(
            child: _buildQuickActionButton(
              title: 'Buy USDC',
              subtitle: 'Purchase crypto',
              icon: 'trending_up',
              color: AppTheme.getSuccessColor(true),
              onTap: onBuyPressed,
            ),
          ),
          SizedBox(width: 3.w),
          Expanded(
            child: _buildQuickActionButton(
              title: 'Sell USDC',
              subtitle: 'Sell your crypto',
              icon: 'trending_down',
              color: AppTheme.lightTheme.colorScheme.error,
              onTap: onSellPressed,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildQuickActionButton({
    required String title,
    required String subtitle,
    required String icon,
    required Color color,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: EdgeInsets.all(4.w),
        decoration: BoxDecoration(
          color: color.withValues(alpha: 0.1),
          borderRadius: BorderRadius.circular(12),
          border: Border.all(
            color: color.withValues(alpha: 0.3),
            width: 1,
          ),
        ),
        child: Column(
          children: [
            Container(
              padding: EdgeInsets.all(2.w),
              decoration: BoxDecoration(
                color: color.withValues(alpha: 0.2),
                borderRadius: BorderRadius.circular(8),
              ),
              child: CustomIconWidget(
                iconName: icon,
                color: color,
                size: 24,
              ),
            ),
            SizedBox(height: 2.h),
            Text(
              title,
              style: AppTheme.lightTheme.textTheme.titleMedium?.copyWith(
                fontWeight: FontWeight.w600,
                color: color,
              ),
            ),
            SizedBox(height: 0.5.h),
            Text(
              subtitle,
              style: AppTheme.lightTheme.textTheme.bodySmall?.copyWith(
                color: AppTheme.lightTheme.colorScheme.onSurfaceVariant,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
