import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class SessionManagementWidget extends StatelessWidget {
  final List<Map<String, dynamic>> activeSessions;
  final Function(String sessionId) onRemoteLogout;

  const SessionManagementWidget({
    Key? key,
    required this.activeSessions,
    required this.onRemoteLogout,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: const Color(0xFF1A1F3A),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: const Color(0xFF2D3748)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Text(
                'Active Sessions',
                style: GoogleFonts.inter(
                  color: Colors.white,
                  fontSize: 18,
                  fontWeight: FontWeight.w600,
                ),
              ),
              const Spacer(),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                decoration: BoxDecoration(
                  color: Colors.blue[900]?.withAlpha(77),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Text(
                  '${activeSessions.length}',
                  style: GoogleFonts.inter(
                    color: Colors.blue[400],
                    fontSize: 12,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          ...activeSessions.map((session) => _buildSessionItem(session)),
        ],
      ),
    );
  }

  Widget _buildSessionItem(Map<String, dynamic> session) {
    final bool isCurrent = session['current'] ?? false;
    final DateTime lastActive = session['lastActive'] as DateTime;
    final String timeAgo = _getTimeAgo(lastActive);

    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: isCurrent
            ? Colors.green[900]?.withAlpha(77)
            : const Color(0xFF0F172A),
        borderRadius: BorderRadius.circular(8),
        border: Border.all(
          color: isCurrent ? Colors.green[700]! : const Color(0xFF374151),
        ),
      ),
      child: Row(
        children: [
          Container(
            width: 40,
            height: 40,
            decoration: BoxDecoration(
              color: isCurrent ? Colors.green[400] : Colors.grey[600],
              borderRadius: BorderRadius.circular(8),
            ),
            child: Icon(
              _getDeviceIcon(session['device']),
              color: Colors.white,
              size: 20,
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Text(
                      session['device'] ?? 'Unknown Device',
                      style: GoogleFonts.inter(
                        color: Colors.white,
                        fontSize: 14,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                    if (isCurrent) ...[
                      const SizedBox(width: 8),
                      Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 6, vertical: 2),
                        decoration: BoxDecoration(
                          color: Colors.green[600],
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: Text(
                          'Current',
                          style: GoogleFonts.inter(
                            color: Colors.white,
                            fontSize: 10,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ),
                    ],
                  ],
                ),
                const SizedBox(height: 4),
                Text(
                  '${session['location']} • $timeAgo',
                  style: GoogleFonts.inter(
                    color: Colors.grey[400],
                    fontSize: 12,
                  ),
                ),
              ],
            ),
          ),
          if (!isCurrent) ...[
            const SizedBox(width: 8),
            IconButton(
              onPressed: () => _showLogoutDialog(session['id']),
              icon: const Icon(
                Icons.logout,
                color: Colors.red,
                size: 20,
              ),
              tooltip: 'End Session',
            ),
          ] else ...[
            const SizedBox(width: 8),
            Container(
              width: 8,
              height: 8,
              decoration: BoxDecoration(
                color: Colors.green[400],
                borderRadius: BorderRadius.circular(4),
              ),
            ),
          ],
        ],
      ),
    );
  }

  IconData _getDeviceIcon(String? device) {
    if (device == null) return Icons.device_unknown;

    final deviceLower = device.toLowerCase();
    if (deviceLower.contains('chrome') ||
        deviceLower.contains('firefox') ||
        deviceLower.contains('safari') ||
        deviceLower.contains('edge')) {
      return Icons.web;
    } else if (deviceLower.contains('iphone') || deviceLower.contains('ios')) {
      return Icons.phone_iphone;
    } else if (deviceLower.contains('android')) {
      return Icons.phone_android;
    } else if (deviceLower.contains('windows') ||
        deviceLower.contains('mac') ||
        deviceLower.contains('linux')) {
      return Icons.computer;
    }
    return Icons.device_unknown;
  }

  String _getTimeAgo(DateTime dateTime) {
    final now = DateTime.now();
    final difference = now.difference(dateTime);

    if (difference.inMinutes < 1) {
      return 'Just now';
    } else if (difference.inMinutes < 60) {
      return '${difference.inMinutes}m ago';
    } else if (difference.inHours < 24) {
      return '${difference.inHours}h ago';
    } else {
      return '${difference.inDays}d ago';
    }
  }

  void _showLogoutDialog(String sessionId) {
    // This would typically show a confirmation dialog
    // For now, we'll call the logout directly
    onRemoteLogout(sessionId);
  }
}
