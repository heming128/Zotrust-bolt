import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class SecurityIndicatorsWidget extends StatelessWidget {
  final String? ipAddress;
  final String? deviceFingerprint;
  final String? location;
  final int failedAttempts;

  const SecurityIndicatorsWidget({
    Key? key,
    required this.ipAddress,
    required this.deviceFingerprint,
    required this.location,
    required this.failedAttempts,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: const Color(0xFF1A1F3A),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: const Color(0xFF2D3748)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Security Information',
            style: GoogleFonts.inter(
              color: Colors.white,
              fontSize: 18,
              fontWeight: FontWeight.w600,
            ),
          ),
          const SizedBox(height: 16),
          _buildSecurityItem(
            icon: Icons.public,
            label: 'IP Address',
            value: ipAddress ?? 'Unknown',
            isSecure: ipAddress != null,
          ),
          const SizedBox(height: 12),
          _buildSecurityItem(
            icon: Icons.fingerprint,
            label: 'Device Fingerprint',
            value: deviceFingerprint ?? 'Unknown',
            isSecure: deviceFingerprint != null,
          ),
          const SizedBox(height: 12),
          _buildSecurityItem(
            icon: Icons.location_on,
            label: 'Location',
            value: location ?? 'Unknown',
            isSecure: location != null,
          ),
          const SizedBox(height: 12),
          _buildSecurityItem(
            icon: Icons.warning,
            label: 'Failed Attempts',
            value: '$failedAttempts/5',
            isSecure: failedAttempts < 3,
          ),
        ],
      ),
    );
  }

  Widget _buildSecurityItem({
    required IconData icon,
    required String label,
    required String value,
    required bool isSecure,
  }) {
    return Row(
      children: [
        Icon(
          icon,
          color: isSecure ? Colors.green[400] : Colors.red[400],
          size: 16,
        ),
        const SizedBox(width: 8),
        Expanded(
          child: Text(
            label,
            style: GoogleFonts.inter(
              color: Colors.grey[400],
              fontSize: 12,
            ),
          ),
        ),
        Text(
          value,
          style: GoogleFonts.inter(
            color: isSecure ? Colors.green[400] : Colors.red[400],
            fontSize: 12,
            fontWeight: FontWeight.w500,
          ),
        ),
      ],
    );
  }
}
