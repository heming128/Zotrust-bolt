import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

import '../../core/app_export.dart';
import '../../routes/app_routes.dart';
import './widgets/authentication_form_widget.dart';
import './widgets/biometric_auth_widget.dart';
import './widgets/security_indicators_widget.dart';
import './widgets/session_management_widget.dart';
import './widgets/two_factor_auth_widget.dart';

class AdminSecurityGateway extends StatefulWidget {
  const AdminSecurityGateway({Key? key}) : super(key: key);

  @override
  State<AdminSecurityGateway> createState() => _AdminSecurityGatewayState();
}

class _AdminSecurityGatewayState extends State<AdminSecurityGateway> {
  final PageController _pageController = PageController();
  int _currentStep = 0;
  bool _isLoading = false;
  bool _isAuthenticated = false;
  bool _showTwoFactor = false;
  bool _biometricEnabled = false;

  // Security tracking
  String? _currentIP = '192.168.1.100';
  String? _deviceFingerprint = 'Chrome-Windows-10-001';
  String? _location = 'Mumbai, Maharashtra, India';
  int _failedAttempts = 0;
  List<Map<String, dynamic>> _activeSessions = [];

  @override
  void initState() {
    super.initState();
    _loadSecurityInfo();
    _checkBiometricAvailability();

    // Add debug logging to confirm route is working
    if (kDebugMode) {
      print('AdminSecurityGateway initialized - route working correctly');
    }
  }

  void _loadSecurityInfo() {
    setState(() {
      _currentIP = '192.168.1.100';
      _deviceFingerprint = 'Chrome-Windows-10-001';
      _location = 'Mumbai, Maharashtra, India';
      _failedAttempts = 0;
      _activeSessions = [
        {
          'id': '1',
          'device': 'Chrome on Windows',
          'location': 'Mumbai, India',
          'lastActive': DateTime.now().subtract(const Duration(minutes: 5)),
          'current': true,
        },
        {
          'id': '2',
          'device': 'Safari on iPhone',
          'location': 'Delhi, India',
          'lastActive': DateTime.now().subtract(const Duration(hours: 2)),
          'current': false,
        },
      ];
    });
  }

  void _checkBiometricAvailability() {
    setState(() {
      _biometricEnabled = !kIsWeb;
    });
  }

  Future<void> _handlePrimaryAuth(String username, String password) async {
    setState(() {
      _isLoading = true;
    });

    try {
      // Validate admin domain
      if (!username.contains('@zedtrust.admin')) {
        throw Exception('Invalid admin domain. Must use @zedtrust.admin');
      }

      // Mock authentication - replace with actual implementation
      await Future.delayed(const Duration(seconds: 2));

      if (password.length >= 8) {
        setState(() {
          _isAuthenticated = true;
          _showTwoFactor = true;
          _currentStep = 1;
        });

        _pageController.nextPage(
          duration: const Duration(milliseconds: 300),
          curve: Curves.easeInOut,
        );
      } else {
        throw Exception('Password must meet complexity requirements');
      }
    } catch (e) {
      setState(() {
        _failedAttempts++;
      });

      _showErrorSnackBar('Authentication failed: ${e.toString()}');
    } finally {
      setState(() {
        _isLoading = false;
      });
    }
  }

  Future<void> _handleTwoFactorAuth(String otpCode) async {
    setState(() {
      _isLoading = true;
    });

    try {
      // Mock OTP verification - replace with actual implementation
      await Future.delayed(const Duration(seconds: 1));

      if (otpCode == '123456' || otpCode.length == 6) {
        // Success - navigate to Admin Control Center
        if (mounted) {
          Navigator.pushReplacementNamed(
            context,
            AppRoutes.adminControlCenter,
            arguments: {
              'loginTime': DateTime.now(),
              'securityLevel': 'elevated',
            },
          );
        }
      } else {
        throw Exception('Invalid OTP code');
      }
    } catch (e) {
      setState(() {
        _failedAttempts++;
      });

      _showErrorSnackBar('Two-factor authentication failed: ${e.toString()}');
    } finally {
      setState(() {
        _isLoading = false;
      });
    }
  }

  Future<void> _handleBiometricAuth() async {
    setState(() {
      _isLoading = true;
    });

    try {
      // Mock biometric authentication
      await Future.delayed(const Duration(seconds: 1));

      if (mounted) {
        Navigator.pushReplacementNamed(
          context,
          AppRoutes.adminControlCenter,
          arguments: {
            'loginTime': DateTime.now(),
            'securityLevel': 'biometric',
          },
        );
      }
    } catch (e) {
      _showErrorSnackBar('Biometric authentication failed: ${e.toString()}');
    } finally {
      setState(() {
        _isLoading = false;
      });
    }
  }

  void _handleEmergencyAccess() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: const Color(0xFF1A1F3A),
        title: Text(
          'Emergency Access Protocol',
          style: GoogleFonts.inter(
            color: Colors.white,
            fontWeight: FontWeight.w600,
          ),
        ),
        content: Text(
          'Emergency access requires additional verification. Contact system administrator at emergency@zedtrust.com with your admin ID.',
          style: GoogleFonts.inter(
            color: Colors.grey[300],
            fontSize: 14,
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text(
              'Understood',
              style: GoogleFonts.inter(
                color: const Color(0xFF3B82F6),
                fontWeight: FontWeight.w500,
              ),
            ),
          ),
        ],
      ),
    );
  }

  void _showErrorSnackBar(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        backgroundColor: Colors.red[700],
        behavior: SnackBarBehavior.floating,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0A0E27),
      body: SafeArea(
        child: Stack(
          children: [
            // Background Pattern
            _buildBackgroundPattern(),

            // Main Content
            Center(
              child: Container(
                constraints: const BoxConstraints(maxWidth: 1200),
                padding: EdgeInsets.all(
                    MediaQuery.of(context).size.width > 800 ? 24 : 16),
                child: Column(
                  children: [
                    // Header Section
                    _buildHeader(),

                    const SizedBox(height: 40),

                    // Main Authentication Flow
                    Expanded(
                      child: PageView(
                        controller: _pageController,
                        physics: const NeverScrollableScrollPhysics(),
                        children: [
                          _buildPrimaryAuthPage(),
                          if (_showTwoFactor) _buildTwoFactorPage(),
                        ],
                      ),
                    ),

                    // Security Footer
                    _buildSecurityFooter(),
                  ],
                ),
              ),
            ),

            // Loading Overlay
            if (_isLoading) _buildLoadingOverlay(),
          ],
        ),
      ),
    );
  }

  Widget _buildBackgroundPattern() {
    return Positioned.fill(
      child: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [
              Color(0xFF0A0E27),
              Color(0xFF1A1F3A),
              Color(0xFF0F172A),
            ],
          ),
        ),
        child: CustomPaint(
          painter: SecurityPatternPainter(),
        ),
      ),
    );
  }

  Widget _buildHeader() {
    return Column(
      children: [
        // ZedTrust Admin Logo
        Container(
          width: 100,
          height: 100,
          decoration: BoxDecoration(
            gradient: const LinearGradient(
              colors: [Color(0xFF3B82F6), Color(0xFF1E40AF)],
            ),
            borderRadius: BorderRadius.circular(25),
            boxShadow: [
              BoxShadow(
                color: const Color(0xFF3B82F6).withAlpha(77),
                blurRadius: 30,
                offset: const Offset(0, 10),
              ),
            ],
          ),
          child: const Icon(
            Icons.admin_panel_settings,
            color: Colors.white,
            size: 50,
          ),
        ),

        const SizedBox(height: 24),

        Text(
          'Administrative Portal',
          style: GoogleFonts.inter(
            fontSize: 32,
            fontWeight: FontWeight.w700,
            color: Colors.white,
            letterSpacing: -0.5,
          ),
        ),

        const SizedBox(height: 8),

        Text(
          'Multi-layered security gateway for system administrators',
          style: GoogleFonts.inter(
            fontSize: 16,
            color: Colors.grey[400],
            height: 1.4,
          ),
        ),

        const SizedBox(height: 16),

        // Security Level Indicator
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
          decoration: BoxDecoration(
            color: Colors.green[900]?.withAlpha(77),
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: Colors.green[700]!),
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(
                Icons.shield,
                color: Colors.green[400],
                size: 16,
              ),
              const SizedBox(width: 8),
              Text(
                'High Security Zone',
                style: GoogleFonts.inter(
                  color: Colors.green[400],
                  fontSize: 12,
                  fontWeight: FontWeight.w500,
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildPrimaryAuthPage() {
    return SingleChildScrollView(
      child: LayoutBuilder(
        builder: (context, constraints) {
          final isWideScreen = constraints.maxWidth > 800;

          if (isWideScreen) {
            return Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Main Authentication Form
                Expanded(
                  flex: 2,
                  child: AuthenticationFormWidget(
                    onAuthenticate: _handlePrimaryAuth,
                    isLoading: _isLoading,
                    failedAttempts: _failedAttempts,
                  ),
                ),

                const SizedBox(width: 32),

                // Security Information Panel
                Expanded(
                  child: _buildSecurityPanel(),
                ),
              ],
            );
          } else {
            return Column(
              children: [
                // Main Authentication Form
                AuthenticationFormWidget(
                  onAuthenticate: _handlePrimaryAuth,
                  isLoading: _isLoading,
                  failedAttempts: _failedAttempts,
                ),

                const SizedBox(height: 32),

                // Security Information Panel
                _buildSecurityPanel(),
              ],
            );
          }
        },
      ),
    );
  }

  Widget _buildSecurityPanel() {
    return Column(
      children: [
        SecurityIndicatorsWidget(
          ipAddress: _currentIP,
          deviceFingerprint: _deviceFingerprint,
          location: _location,
          failedAttempts: _failedAttempts,
        ),

        const SizedBox(height: 24),

        SessionManagementWidget(
          activeSessions: _activeSessions,
          onRemoteLogout: (sessionId) {
            setState(() {
              _activeSessions
                  .removeWhere((session) => session['id'] == sessionId);
            });
          },
        ),

        if (_biometricEnabled) ...[
          const SizedBox(height: 24),
          BiometricAuthWidget(
            onBiometricAuth: _handleBiometricAuth,
            isEnabled: _biometricEnabled,
          ),
        ],

        const SizedBox(height: 24),

        // Emergency Access
        Container(
          width: double.infinity,
          padding: const EdgeInsets.all(20),
          decoration: BoxDecoration(
            color: Colors.orange[900]?.withAlpha(26),
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: Colors.orange[700]!),
          ),
          child: Column(
            children: [
              Icon(
                Icons.warning,
                color: Colors.orange[400],
                size: 32,
              ),
              const SizedBox(height: 12),
              Text(
                'Emergency Access',
                style: GoogleFonts.inter(
                  color: Colors.orange[400],
                  fontSize: 16,
                  fontWeight: FontWeight.w600,
                ),
              ),
              const SizedBox(height: 8),
              Text(
                'For critical system issues only',
                style: GoogleFonts.inter(
                  color: Colors.grey[400],
                  fontSize: 12,
                ),
              ),
              const SizedBox(height: 16),
              SizedBox(
                width: double.infinity,
                child: OutlinedButton(
                  onPressed: _handleEmergencyAccess,
                  style: OutlinedButton.styleFrom(
                    side: BorderSide(color: Colors.orange[700]!),
                    foregroundColor: Colors.orange[400],
                  ),
                  child: Text(
                    'Emergency Access',
                    style: GoogleFonts.inter(
                      fontSize: 14,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildTwoFactorPage() {
    return Center(
      child: Container(
        constraints: const BoxConstraints(maxWidth: 500),
        child: TwoFactorAuthWidget(
          onVerify: _handleTwoFactorAuth,
          isLoading: _isLoading,
          onResendCode: () {
            _showErrorSnackBar('New code sent to your authenticator app');
          },
        ),
      ),
    );
  }

  Widget _buildSecurityFooter() {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: const Color(0xFF1A1F3A),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: const Color(0xFF2D3748)),
      ),
      child: Column(
        children: [
          Row(
            children: [
              Icon(
                Icons.security,
                color: Colors.blue[400],
                size: 20,
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Text(
                  'All administrative access is monitored and logged for security auditing',
                  style: GoogleFonts.inter(
                    color: Colors.grey[300],
                    fontSize: 12,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                'Session Timeout: 30 minutes',
                style: GoogleFonts.inter(
                  color: Colors.grey[400],
                  fontSize: 10,
                ),
              ),
              Text(
                'Failed Attempts: $_failedAttempts/5',
                style: GoogleFonts.inter(
                  color:
                      _failedAttempts >= 3 ? Colors.red[400] : Colors.grey[400],
                  fontSize: 10,
                  fontWeight:
                      _failedAttempts >= 3 ? FontWeight.w600 : FontWeight.w400,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildLoadingOverlay() {
    return Container(
      color: Colors.black54,
      child: Center(
        child: Container(
          padding: const EdgeInsets.all(32),
          decoration: BoxDecoration(
            color: const Color(0xFF1A1F3A),
            borderRadius: BorderRadius.circular(16),
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const CircularProgressIndicator(
                color: Color(0xFF3B82F6),
              ),
              const SizedBox(height: 16),
              Text(
                'Verifying Security Credentials...',
                style: GoogleFonts.inter(
                  color: Colors.white,
                  fontSize: 16,
                  fontWeight: FontWeight.w500,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  @override
  void dispose() {
    _pageController.dispose();
    super.dispose();
  }
}

class SecurityPatternPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = Colors.white.withAlpha(13)
      ..strokeWidth = 1.0
      ..style = PaintingStyle.stroke;

    // Draw grid pattern
    for (double i = 0; i < size.width; i += 50) {
      canvas.drawLine(Offset(i, 0), Offset(i, size.height), paint);
    }

    for (double i = 0; i < size.height; i += 50) {
      canvas.drawLine(Offset(0, i), Offset(size.width, i), paint);
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}
