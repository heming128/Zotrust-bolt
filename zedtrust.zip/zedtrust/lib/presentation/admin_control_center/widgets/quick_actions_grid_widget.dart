import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class QuickActionsGridWidget extends StatelessWidget {
  final VoidCallback onAgentManagement;
  final VoidCallback onLocationControl;
  final VoidCallback onVerificationCenter;
  final VoidCallback onAuditLogs;
  final VoidCallback onSystemConfig;

  const QuickActionsGridWidget({
    Key? key,
    required this.onAgentManagement,
    required this.onLocationControl,
    required this.onVerificationCenter,
    required this.onAuditLogs,
    required this.onSystemConfig,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(
        color: const Color(0xFF1E293B),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: const Color(0xFF475569)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(
                Icons.dashboard_customize,
                color: Colors.purple[400],
                size: 24,
              ),
              const SizedBox(width: 12),
              Text(
                'Quick Actions',
                style: GoogleFonts.inter(
                  fontSize: 18,
                  fontWeight: FontWeight.w700,
                  color: Colors.white,
                ),
              ),
              const SizedBox(width: 8),
              Text(
                'One-tap access to core functions',
                style: GoogleFonts.inter(
                  fontSize: 12,
                  color: Colors.grey[500],
                ),
              ),
            ],
          ),
          const SizedBox(height: 20),
          GridView.builder(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 3,
              crossAxisSpacing: 12,
              mainAxisSpacing: 12,
              childAspectRatio: 1.2,
            ),
            itemCount: 6,
            itemBuilder: (context, index) {
              final actions = [
                {
                  'title': 'Agent Network',
                  'subtitle': 'Management',
                  'icon': Icons.people,
                  'color': const Color(0xFF10B981),
                  'badge': '12',
                  'onTap': onAgentManagement,
                },
                {
                  'title': 'Location Control',
                  'subtitle': 'System',
                  'icon': Icons.location_on,
                  'color': const Color(0xFF8B5CF6),
                  'badge': '67',
                  'onTap': onLocationControl,
                },
                {
                  'title': 'Verification',
                  'subtitle': 'Center',
                  'icon': Icons.verified_user,
                  'color': const Color(0xFF3B82F6),
                  'badge': '7',
                  'onTap': onVerificationCenter,
                },
                {
                  'title': 'Audit Logs',
                  'subtitle': 'History',
                  'icon': Icons.history,
                  'color': const Color(0xFFF59E0B),
                  'badge': 'New',
                  'onTap': onAuditLogs,
                },
                {
                  'title': 'System',
                  'subtitle': 'Configuration',
                  'icon': Icons.settings,
                  'color': const Color(0xFF6B7280),
                  'badge': '',
                  'onTap': onSystemConfig,
                },
                {
                  'title': 'Reports',
                  'subtitle': 'Export',
                  'icon': Icons.analytics,
                  'color': const Color(0xFF06B6D4),
                  'badge': '',
                  'onTap': () {
                    // Handle reports export
                  },
                },
              ];

              return _buildActionCard(actions[index]);
            },
          ),
        ],
      ),
    );
  }

  Widget _buildActionCard(Map<String, dynamic> action) {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: action['onTap'],
        borderRadius: BorderRadius.circular(12),
        child: Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: const Color(0xFF0F172A),
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: const Color(0xFF374151)),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Container(
                    padding: const EdgeInsets.all(8),
                    decoration: BoxDecoration(
                      color: action['color'].withAlpha(51),
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: Icon(
                      action['icon'],
                      color: action['color'],
                      size: 20,
                    ),
                  ),
                  const Spacer(),
                  if (action['badge'].toString().isNotEmpty)
                    Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 6, vertical: 2),
                      decoration: BoxDecoration(
                        color: action['color'],
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: Text(
                        action['badge'],
                        style: GoogleFonts.inter(
                          color: Colors.white,
                          fontSize: 10,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                    ),
                ],
              ),

              const SizedBox(height: 12),

              Text(
                action['title'],
                style: GoogleFonts.inter(
                  fontSize: 14,
                  fontWeight: FontWeight.w600,
                  color: Colors.white,
                ),
              ),

              Text(
                action['subtitle'],
                style: GoogleFonts.inter(
                  fontSize: 12,
                  color: Colors.grey[500],
                ),
              ),

              const Spacer(),

              // Quick stats or info
              Row(
                children: [
                  Icon(
                    Icons.arrow_forward,
                    color: action['color'],
                    size: 16,
                  ),
                  const SizedBox(width: 4),
                  Text(
                    'Access',
                    style: GoogleFonts.inter(
                      color: action['color'],
                      fontSize: 11,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}
