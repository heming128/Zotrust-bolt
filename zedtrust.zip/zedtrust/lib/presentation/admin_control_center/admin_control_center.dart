import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

import '../../core/app_export.dart';
import '../../routes/app_routes.dart';
import './widgets/admin_analytics_panel_widget.dart';
import './widgets/emergency_controls_widget.dart';
import './widgets/priority_alerts_widget.dart';
import './widgets/quick_actions_grid_widget.dart';
import './widgets/recent_activity_timeline_widget.dart';
import './widgets/system_health_dashboard_widget.dart';

class AdminControlCenter extends StatefulWidget {
  const AdminControlCenter({Key? key}) : super(key: key);

  @override
  State<AdminControlCenter> createState() => _AdminControlCenterState();
}

class _AdminControlCenterState extends State<AdminControlCenter>
    with TickerProviderStateMixin {
  late TabController _tabController;
  bool _isLoading = false;
  bool _maintenanceMode = false;

  // Dashboard Data
  Map<String, dynamic> _systemMetrics = {};
  List<Map<String, dynamic>> _priorityAlerts = [];
  List<Map<String, dynamic>> _recentActivities = [];
  Map<String, dynamic> _analyticsData = {};

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 4, vsync: this);
    _loadDashboardData();
  }

  Future<void> _loadDashboardData() async {
    setState(() {
      _isLoading = true;
    });

    try {
      await Future.wait([
        _loadSystemMetrics(),
        _loadPriorityAlerts(),
        _loadRecentActivities(),
        _loadAnalyticsData(),
      ]);
    } catch (e) {
      _showErrorSnackBar('Failed to load dashboard data: ${e.toString()}');
    } finally {
      setState(() {
        _isLoading = false;
      });
    }
  }

  Future<void> _loadSystemMetrics() async {
    // Mock data - replace with actual API calls
    await Future.delayed(const Duration(milliseconds: 500));
    setState(() {
      _systemMetrics = {
        'totalAgents': 142,
        'pendingVerifications': 12,
        'tradeVolume': 25680000,
        'platformStatus': 'operational',
        'activeAgents': 89,
        'completionRate': 96.8,
        'avgResponseTime': 120,
        'systemUptime': 99.9,
      };
    });
  }

  Future<void> _loadPriorityAlerts() async {
    await Future.delayed(const Duration(milliseconds: 300));
    setState(() {
      _priorityAlerts = [
        {
          'id': '1',
          'type': 'agent_application',
          'title': 'New Agent Application',
          'message': 'Rajnikant Aagnya Hawala submitted verification documents',
          'priority': 'high',
          'timestamp': DateTime.now().subtract(const Duration(minutes: 15)),
          'action': 'review',
        },
        {
          'id': '2',
          'type': 'disputed_trade',
          'title': 'Trade Dispute',
          'message': 'Trade #TR-2024-001 requires administrative review',
          'priority': 'critical',
          'timestamp': DateTime.now().subtract(const Duration(hours: 1)),
          'action': 'resolve',
        },
        {
          'id': '3',
          'type': 'system_issue',
          'title': 'System Alert',
          'message': 'High memory usage detected on server cluster 2',
          'priority': 'medium',
          'timestamp': DateTime.now().subtract(const Duration(hours: 2)),
          'action': 'investigate',
        },
      ];
    });
  }

  Future<void> _loadRecentActivities() async {
    await Future.delayed(const Duration(milliseconds: 400));
    setState(() {
      _recentActivities = [
        {
          'id': '1',
          'type': 'agent_verified',
          'title': 'Agent Verified',
          'subtitle': 'Mumbai Hawala Services',
          'agent': 'Approved by Admin',
          'timestamp': DateTime.now().subtract(const Duration(minutes: 30)),
          'status': 'success',
        },
        {
          'id': '2',
          'type': 'location_added',
          'title': 'New Location Added',
          'subtitle': 'Surat Ring Road - Commercial District',
          'agent': 'System Admin',
          'timestamp': DateTime.now().subtract(const Duration(hours: 1)),
          'status': 'info',
        },
        {
          'id': '3',
          'type': 'trade_completed',
          'title': 'High-Value Trade Completed',
          'subtitle': '₹15,00,000 - Mumbai to Delhi',
          'agent': 'Agent Network',
          'timestamp': DateTime.now().subtract(const Duration(hours: 2)),
          'status': 'success',
        },
      ];
    });
  }

  Future<void> _loadAnalyticsData() async {
    await Future.delayed(const Duration(milliseconds: 600));
    setState(() {
      _analyticsData = {
        'tradesByRegion': {
          'Mumbai': 45,
          'Delhi': 38,
          'Surat': 32,
          'Pune': 28,
          'Ahmedabad': 25,
        },
        'agentPerformance': {
          'excellent': 67,
          'good': 58,
          'average': 17,
        },
        'revenueGrowth': [
          {'month': 'Jan', 'value': 2100000},
          {'month': 'Feb', 'value': 2350000},
          {'month': 'Mar', 'value': 2680000},
          {'month': 'Apr', 'value': 2890000},
          {'month': 'May', 'value': 3100000},
        ],
      };
    });
  }

  void _handleMaintenanceMode() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: const Color(0xFF1A1F3A),
        title: Text(
          'Platform Maintenance Mode',
          style: GoogleFonts.inter(
            color: Colors.white,
            fontWeight: FontWeight.w600,
          ),
        ),
        content: Text(
          _maintenanceMode
              ? 'Are you sure you want to disable maintenance mode? This will restore normal platform operations.'
              : 'Are you sure you want to enable maintenance mode? This will temporarily restrict user access.',
          style: GoogleFonts.inter(
            color: Colors.grey[300],
            fontSize: 14,
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text(
              'Cancel',
              style: GoogleFonts.inter(
                color: Colors.grey[400],
                fontWeight: FontWeight.w500,
              ),
            ),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(context);
              setState(() {
                _maintenanceMode = !_maintenanceMode;
              });
              _showSuccessSnackBar(
                _maintenanceMode
                    ? 'Maintenance mode enabled'
                    : 'Maintenance mode disabled',
              );
            },
            style: ElevatedButton.styleFrom(
              backgroundColor:
                  _maintenanceMode ? Colors.green[600] : Colors.orange[600],
            ),
            child: Text(
              _maintenanceMode ? 'Disable' : 'Enable',
              style: GoogleFonts.inter(
                color: Colors.white,
                fontWeight: FontWeight.w600,
              ),
            ),
          ),
        ],
      ),
    );
  }

  void _handleEmergencyAnnouncement() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: const Color(0xFF1A1F3A),
        title: Text(
          'Emergency Announcement',
          style: GoogleFonts.inter(
            color: Colors.white,
            fontWeight: FontWeight.w600,
          ),
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
              style: GoogleFonts.inter(color: Colors.white),
              maxLines: 3,
              decoration: InputDecoration(
                hintText: 'Enter emergency message...',
                hintStyle: GoogleFonts.inter(color: Colors.grey[600]),
                filled: true,
                fillColor: const Color(0xFF0F172A),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(8),
                  borderSide: BorderSide.none,
                ),
              ),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text(
              'Cancel',
              style: GoogleFonts.inter(
                color: Colors.grey[400],
                fontWeight: FontWeight.w500,
              ),
            ),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(context);
              _showSuccessSnackBar('Emergency announcement sent to all users');
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.red[600],
            ),
            child: Text(
              'Send',
              style: GoogleFonts.inter(
                color: Colors.white,
                fontWeight: FontWeight.w600,
              ),
            ),
          ),
        ],
      ),
    );
  }

  void _showErrorSnackBar(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        backgroundColor: Colors.red[700],
        behavior: SnackBarBehavior.floating,
      ),
    );
  }

  void _showSuccessSnackBar(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        backgroundColor: Colors.green[700],
        behavior: SnackBarBehavior.floating,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0F172A),
      body: _isLoading ? _buildLoadingScreen() : _buildMainContent(),
    );
  }

  Widget _buildLoadingScreen() {
    return const Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          CircularProgressIndicator(color: Color(0xFF3B82F6)),
          SizedBox(height: 16),
          Text(
            'Loading Admin Control Center...',
            style: TextStyle(color: Colors.white),
          ),
        ],
      ),
    );
  }

  Widget _buildMainContent() {
    return SafeArea(
      child: Column(
        children: [
          _buildAppBar(),
          Expanded(
            child: TabBarView(
              controller: _tabController,
              children: [
                _buildOverviewTab(),
                _buildAgentManagementTab(),
                _buildAnalyticsTab(),
                _buildSystemTab(),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildAppBar() {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: const BoxDecoration(
        color: Color(0xFF1E293B),
        border: Border(
          bottom: BorderSide(color: Color(0xFF475569)),
        ),
      ),
      child: Column(
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  gradient: const LinearGradient(
                    colors: [Color(0xFF3B82F6), Color(0xFF1E40AF)],
                  ),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: const Icon(
                  Icons.admin_panel_settings,
                  color: Colors.white,
                  size: 24,
                ),
              ),
              const SizedBox(width: 16),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Admin Control Center',
                      style: GoogleFonts.inter(
                        fontSize: 24,
                        fontWeight: FontWeight.w700,
                        color: Colors.white,
                      ),
                    ),
                    Text(
                      'Platform oversight and management hub',
                      style: GoogleFonts.inter(
                        fontSize: 14,
                        color: Colors.grey[400],
                      ),
                    ),
                  ],
                ),
              ),
              // System Status Indicator
              Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                decoration: BoxDecoration(
                  color: _maintenanceMode
                      ? Colors.orange[900]?.withAlpha(77)
                      : Colors.green[900]?.withAlpha(77),
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(
                    color: _maintenanceMode
                        ? Colors.orange[700]!
                        : Colors.green[700]!,
                  ),
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(
                      _maintenanceMode ? Icons.build : Icons.check_circle,
                      color: _maintenanceMode
                          ? Colors.orange[400]
                          : Colors.green[400],
                      size: 16,
                    ),
                    const SizedBox(width: 6),
                    Text(
                      _maintenanceMode ? 'MAINTENANCE' : 'OPERATIONAL',
                      style: GoogleFonts.inter(
                        color: _maintenanceMode
                            ? Colors.orange[400]
                            : Colors.green[400],
                        fontSize: 12,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),

          const SizedBox(height: 20),

          // Tab Bar
          TabBar(
            controller: _tabController,
            tabs: [
              Tab(
                icon: const Icon(Icons.dashboard),
                text: 'Overview',
              ),
              Tab(
                icon: const Icon(Icons.people),
                text: 'Agent Network',
              ),
              Tab(
                icon: const Icon(Icons.analytics),
                text: 'Analytics',
              ),
              Tab(
                icon: const Icon(Icons.settings),
                text: 'System',
              ),
            ],
            labelColor: const Color(0xFF3B82F6),
            unselectedLabelColor: Colors.grey[400],
            indicatorColor: const Color(0xFF3B82F6),
            labelStyle: GoogleFonts.inter(
              fontSize: 12,
              fontWeight: FontWeight.w600,
            ),
            unselectedLabelStyle: GoogleFonts.inter(
              fontSize: 12,
              fontWeight: FontWeight.w400,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildOverviewTab() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(24),
      child: Column(
        children: [
          // System Health Dashboard
          SystemHealthDashboardWidget(
            metrics: _systemMetrics,
            onRefresh: _loadSystemMetrics,
          ),

          const SizedBox(height: 24),

          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Left Column
              Expanded(
                flex: 2,
                child: Column(
                  children: [
                    // Priority Alerts
                    PriorityAlertsWidget(
                      alerts: _priorityAlerts,
                      onResolveAlert: (alertId) {
                        setState(() {
                          _priorityAlerts
                              .removeWhere((alert) => alert['id'] == alertId);
                        });
                      },
                    ),

                    const SizedBox(height: 24),

                    // Quick Actions Grid
                    QuickActionsGridWidget(
                      onAgentManagement: () => _tabController.animateTo(1),
                      onLocationControl: () {
                        Navigator.pushNamed(
                            context, AppRoutes.locationManagementHub);
                      },
                      onVerificationCenter: () {
                        Navigator.pushNamed(
                            context, AppRoutes.agentVerificationCenter);
                      },
                      onAuditLogs: () {
                        _showSuccessSnackBar('Audit logs feature coming soon');
                      },
                      onSystemConfig: () => _tabController.animateTo(3),
                    ),
                  ],
                ),
              ),

              const SizedBox(width: 24),

              // Right Column
              Expanded(
                child: Column(
                  children: [
                    // Recent Activity Timeline
                    RecentActivityTimelineWidget(
                      activities: _recentActivities,
                    ),

                    const SizedBox(height: 24),

                    // Emergency Controls
                    EmergencyControlsWidget(
                      maintenanceMode: _maintenanceMode,
                      onMaintenanceToggle: _handleMaintenanceMode,
                      onEmergencyAnnouncement: _handleEmergencyAnnouncement,
                    ),
                  ],
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildAgentManagementTab() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(
            Icons.people,
            color: Colors.grey[600],
            size: 64,
          ),
          const SizedBox(height: 16),
          Text(
            'Agent Network Management',
            style: GoogleFonts.inter(
              fontSize: 20,
              fontWeight: FontWeight.w600,
              color: Colors.white,
            ),
          ),
          const SizedBox(height: 8),
          Text(
            'Navigate to dedicated agent management screens',
            style: GoogleFonts.inter(
              fontSize: 14,
              color: Colors.grey[400],
            ),
          ),
          const SizedBox(height: 24),
          ElevatedButton(
            onPressed: () {
              Navigator.pushNamed(context, AppRoutes.adminAgentManagement);
            },
            child: const Text('Open Agent Management'),
          ),
        ],
      ),
    );
  }

  Widget _buildAnalyticsTab() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(24),
      child: AdminAnalyticsPanelWidget(
        analyticsData: _analyticsData,
        onExportReport: () {
          _showSuccessSnackBar('Analytics report exported successfully');
        },
      ),
    );
  }

  Widget _buildSystemTab() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(
            Icons.settings,
            color: Colors.grey[600],
            size: 64,
          ),
          const SizedBox(height: 16),
          Text(
            'System Configuration',
            style: GoogleFonts.inter(
              fontSize: 20,
              fontWeight: FontWeight.w600,
              color: Colors.white,
            ),
          ),
          const SizedBox(height: 8),
          Text(
            'Advanced system settings and configurations',
            style: GoogleFonts.inter(
              fontSize: 14,
              color: Colors.grey[400],
            ),
          ),
          const SizedBox(height: 24),
          Text(
            'Coming Soon',
            style: GoogleFonts.inter(
              fontSize: 16,
              fontWeight: FontWeight.w500,
              color: Colors.orange[400],
            ),
          ),
        ],
      ),
    );
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }
}
