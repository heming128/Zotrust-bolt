import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:geolocator/geolocator.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:sizer/sizer.dart';

import '../../core/app_export.dart';
import '../../core/services/supabase_service.dart';
import './widgets/agent_availability_widget.dart';
import './widgets/location_detection_widget.dart';
import './widgets/privacy_protection_widget.dart';
import './widgets/trade_confirmation_widget.dart';

class AgentLocationAssignment extends StatefulWidget {
  const AgentLocationAssignment({super.key});

  @override
  State<AgentLocationAssignment> createState() =>
      _AgentLocationAssignmentState();
}

class _AgentLocationAssignmentState extends State<AgentLocationAssignment>
    with TickerProviderStateMixin {
  final SupabaseService _supabaseService = SupabaseService.instance;

  Map<String, dynamic>? _selectedAgent;
  String? _userCity;
  List<Map<String, dynamic>> _availableLocations = [];
  Map<String, dynamic>? _assignedLocation;
  bool _isLoadingLocation = false;
  bool _isCreatingTrade = false;
  String _locationError = '';

  late AnimationController _slideController;
  late Animation<Offset> _slideAnimation;
  late AnimationController _fadeController;
  late Animation<double> _fadeAnimation;

  @override
  void initState() {
    super.initState();

    _slideController = AnimationController(
      duration: const Duration(milliseconds: 600),
      vsync: this,
    );
    _slideAnimation = Tween<Offset>(
      begin: const Offset(0, 0.1),
      end: Offset.zero,
    ).animate(CurvedAnimation(
      parent: _slideController,
      curve: Curves.easeOutCubic,
    ));

    _fadeController = AnimationController(
      duration: const Duration(milliseconds: 800),
      vsync: this,
    );
    _fadeAnimation = CurvedAnimation(
      parent: _fadeController,
      curve: Curves.easeInOut,
    );

    _initializeData();
    _slideController.forward();
    _fadeController.forward();
  }

  @override
  void dispose() {
    _slideController.dispose();
    _fadeController.dispose();
    super.dispose();
  }

  void _initializeData() {
    // Get agent data from navigation arguments
    WidgetsBinding.instance.addPostFrameCallback((_) {
      final args =
          ModalRoute.of(context)?.settings.arguments as Map<String, dynamic>?;
      if (args != null) {
        setState(() {
          _selectedAgent = args['agent'];
        });
        _detectUserLocation();
      }
    });
  }

  Future<void> _detectUserLocation() async {
    setState(() {
      _isLoadingLocation = true;
      _locationError = '';
    });

    try {
      // Check location permissions
      LocationPermission permission = await Geolocator.checkPermission();
      if (permission == LocationPermission.denied) {
        permission = await Geolocator.requestPermission();
        if (permission == LocationPermission.denied) {
          throw Exception('Location permissions are denied');
        }
      }

      if (permission == LocationPermission.deniedForever) {
        throw Exception('Location permissions are permanently denied');
      }

      // Get current position
      final Position position = await Geolocator.getCurrentPosition(
        locationSettings: const LocationSettings(
          accuracy: LocationAccuracy.high,
          timeLimit: Duration(seconds: 30),
        ),
      );

      // For demo purposes, we'll simulate city detection based on coordinates
      // In a real app, you'd use reverse geocoding
      final String detectedCity = _detectCityFromCoordinates(position);

      setState(() {
        _userCity = detectedCity;
      });

      await _loadAgentLocations();
    } catch (e) {
      setState(() {
        _locationError = 'Failed to detect location: ${e.toString()}';
        // Fallback to manual city selection
        _userCity = 'Unknown';
      });
    } finally {
      setState(() {
        _isLoadingLocation = false;
      });
    }
  }

  String _detectCityFromCoordinates(Position position) {
    // Simulate city detection based on coordinates
    // In a real app, this would use a geocoding service
    if (position.latitude > 21.0 &&
        position.latitude < 22.0 &&
        position.longitude > 72.0 &&
        position.longitude < 73.0) {
      return 'Surat';
    } else if (position.latitude > 18.0 &&
        position.latitude < 20.0 &&
        position.longitude > 72.0 &&
        position.longitude < 73.0) {
      return 'Mumbai';
    } else {
      return 'Other';
    }
  }

  Future<void> _loadAgentLocations() async {
    if (_selectedAgent == null || _userCity == null) return;

    try {
      final locations = await _supabaseService.getAgentLocationsByCity(
        agentId: _selectedAgent!['id'],
        city: _userCity!,
      );

      setState(() {
        _availableLocations = locations;
        if (locations.isNotEmpty) {
          // Auto-assign the first available location (highest priority)
          _assignedLocation = locations.first;
        }
      });
    } catch (e) {
      _showErrorToast('Failed to load agent locations: $e');
    }
  }

  Future<void> _createTradeWithAssignment() async {
    if (_selectedAgent == null || _assignedLocation == null) return;

    setState(() => _isCreatingTrade = true);

    try {
      // In a real app, you'd get buyer/seller IDs from user context
      const String mockBuyerId = 'mock-buyer-id';
      const String mockSellerId = 'mock-seller-id';
      const String mockSellerCity =
          'Mumbai'; // Would come from seller's actual city

      await _supabaseService.createTradeWithAgentAssignment(
        buyerId: mockBuyerId,
        sellerId: mockSellerId,
        agentId: _selectedAgent!['id'],
        buyerCity: _userCity!,
        sellerCity: mockSellerCity,
      );

      _showSuccessToast('Trade created successfully with agent assigned');

      // Navigate to trade details or next step
      Navigator.pop(context, {
        'success': true,
        'agent': _selectedAgent,
        'location': _assignedLocation,
      });
    } catch (e) {
      _showErrorToast('Failed to create trade: $e');
    } finally {
      setState(() => _isCreatingTrade = false);
    }
  }

  void _showAlternativeAgents() {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) => _buildAlternativeAgentsModal(),
    );
  }

  Widget _buildAlternativeAgentsModal() {
    return DraggableScrollableSheet(
      initialChildSize: 0.6,
      maxChildSize: 0.8,
      minChildSize: 0.4,
      builder: (context, scrollController) {
        return Container(
          decoration: BoxDecoration(
            color: Theme.of(context).cardColor,
            borderRadius: BorderRadius.vertical(top: Radius.circular(20.sp)),
          ),
          child: Column(
            children: [
              // Handle bar
              Container(
                margin: EdgeInsets.only(top: 12.h),
                width: 40.w,
                height: 4.h,
                decoration: BoxDecoration(
                  color: AppTheme.getNeutralColor(true),
                  borderRadius: BorderRadius.circular(2.sp),
                ),
              ),

              // Header
              Padding(
                padding: EdgeInsets.all(20.sp),
                child: Text(
                  'Alternative Agents in $_userCity',
                  style: GoogleFonts.inter(
                    fontSize: 18.sp,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ),

              // Alternative agents list would go here
              Expanded(
                child: Center(
                  child: Text(
                    'Loading alternative agents...',
                    style: GoogleFonts.inter(
                      fontSize: 14.sp,
                      color: AppTheme.textSecondaryLight,
                    ),
                  ),
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  void _showErrorToast(String message) {
    Fluttertoast.showToast(
      msg: message,
      toastLength: Toast.LENGTH_LONG,
      backgroundColor: AppTheme.errorLight,
      textColor: Colors.white,
    );
  }

  void _showSuccessToast(String message) {
    Fluttertoast.showToast(
      msg: message,
      backgroundColor: AppTheme.successLight,
      textColor: Colors.white,
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Theme.of(context).scaffoldBackgroundColor,
      appBar: AppBar(
        title: Text(
          'Agent Location Assignment',
          style: GoogleFonts.inter(
            fontSize: 18.sp,
            fontWeight: FontWeight.w600,
          ),
        ),
        centerTitle: true,
        elevation: 0,
        backgroundColor: Theme.of(context).scaffoldBackgroundColor,
        leading: IconButton(
          onPressed: () => Navigator.pop(context),
          icon: Icon(
            Icons.arrow_back_ios,
            size: 20.sp,
          ),
        ),
      ),
      body: FadeTransition(
        opacity: _fadeAnimation,
        child: SlideTransition(
          position: _slideAnimation,
          child: SafeArea(
            child: SingleChildScrollView(
              padding: EdgeInsets.all(20.sp),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Selected Agent Display
                  if (_selectedAgent != null)
                    Container(
                      padding: EdgeInsets.all(20.sp),
                      decoration: BoxDecoration(
                        color: Theme.of(context).cardColor,
                        borderRadius: BorderRadius.circular(16.sp),
                        boxShadow: [
                          BoxShadow(
                            color: AppTheme.shadowLight,
                            blurRadius: 12,
                            offset: const Offset(0, 4),
                          ),
                        ],
                      ),
                      child: Row(
                        children: [
                          Container(
                            width: 60.w,
                            height: 60.h,
                            decoration: BoxDecoration(
                              color: AppTheme.primaryLight.withAlpha(26),
                              borderRadius: BorderRadius.circular(30.sp),
                            ),
                            child: Icon(
                              Icons.verified_user,
                              color: AppTheme.primaryLight,
                              size: 28.sp,
                            ),
                          ),
                          SizedBox(width: 16.w),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Row(
                                  children: [
                                    Expanded(
                                      child: Text(
                                        _selectedAgent!['name'] ??
                                            'Unknown Agent',
                                        style: GoogleFonts.inter(
                                          fontSize: 18.sp,
                                          fontWeight: FontWeight.w600,
                                        ),
                                      ),
                                    ),
                                    Container(
                                      padding: EdgeInsets.symmetric(
                                        horizontal: 8.w,
                                        vertical: 4.h,
                                      ),
                                      decoration: BoxDecoration(
                                        color: AppTheme.successLight,
                                        borderRadius:
                                            BorderRadius.circular(6.sp),
                                      ),
                                      child: Text(
                                        'Verified',
                                        style: GoogleFonts.inter(
                                          fontSize: 10.sp,
                                          fontWeight: FontWeight.w500,
                                          color: Colors.white,
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                                SizedBox(height: 4.h),
                                Text(
                                  _selectedAgent!['alias'] ?? '',
                                  style: GoogleFonts.inter(
                                    fontSize: 14.sp,
                                    color: AppTheme.textSecondaryLight,
                                  ),
                                ),
                                SizedBox(height: 8.h),
                                Row(
                                  children: [
                                    Icon(
                                      Icons.star,
                                      color: AppTheme.warningLight,
                                      size: 16.sp,
                                    ),
                                    SizedBox(width: 4.w),
                                    Text(
                                      '${(_selectedAgent!['rating'] as num?)?.toStringAsFixed(1) ?? '0.0'} Rating',
                                      style: GoogleFonts.inter(
                                        fontSize: 12.sp,
                                        fontWeight: FontWeight.w500,
                                        color: AppTheme.textSecondaryLight,
                                      ),
                                    ),
                                  ],
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),

                  SizedBox(height: 24.h),

                  // Location Detection Section
                  LocationDetectionWidget(
                    isLoading: _isLoadingLocation,
                    detectedCity: _userCity,
                    error: _locationError,
                    onRetryLocation: _detectUserLocation,
                    onManualCitySelect: (city) {
                      setState(() {
                        _userCity = city;
                      });
                      _loadAgentLocations();
                    },
                  ),

                  SizedBox(height: 24.h),

                  // Agent Availability
                  if (_userCity != null && !_isLoadingLocation)
                    AgentAvailabilityWidget(
                      agent: _selectedAgent,
                      userCity: _userCity!,
                      availableLocations: _availableLocations,
                      assignedLocation: _assignedLocation,
                      onLocationSelected: (location) {
                        setState(() {
                          _assignedLocation = location;
                        });
                      },
                      onShowAlternatives: _showAlternativeAgents,
                    ),

                  SizedBox(height: 24.h),

                  // Privacy Protection Notice
                  const PrivacyProtectionWidget(),

                  SizedBox(height: 24.h),

                  // Trade Confirmation
                  if (_assignedLocation != null)
                    TradeConfirmationWidget(
                      agent: _selectedAgent!,
                      location: _assignedLocation!,
                      userCity: _userCity!,
                      isCreating: _isCreatingTrade,
                      onConfirmTrade: _createTradeWithAssignment,
                    ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
