import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

class CallTimerWidget extends StatelessWidget {
  final Duration duration;

  const CallTimerWidget({
    Key? key,
    required this.duration,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Text(
      _formatDuration(duration),
      style: TextStyle(
        fontSize: 24.sp,
        fontWeight: FontWeight.w300,
        color: Colors.white,
        letterSpacing: 1.5,
      ),
    );
  }

  String _formatDuration(Duration duration) {
    final minutes = duration.inMinutes.remainder(60).toString().padLeft(2, '0');
    final seconds = duration.inSeconds.remainder(60).toString().padLeft(2, '0');

    if (duration.inHours > 0) {
      final hours = duration.inHours.toString().padLeft(2, '0');
      return '$hours:$minutes:$seconds';
    }

    return '$minutes:$seconds';
  }
}
