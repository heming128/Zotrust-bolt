import 'dart:async';

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_webrtc/flutter_webrtc.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:sizer/sizer.dart';

import '../../core/app_export.dart';
import './widgets/call_controls_widget.dart';
import './widgets/call_quality_indicator_widget.dart';
import './widgets/call_timer_widget.dart';
import './widgets/connection_status_widget.dart';

class WebRTCVoiceCallInterface extends StatefulWidget {
  final String counterparty;
  final bool isVerified;
  final String conversationId;

  const WebRTCVoiceCallInterface({
    Key? key,
    required this.counterparty,
    required this.isVerified,
    required this.conversationId,
  }) : super(key: key);

  @override
  State<WebRTCVoiceCallInterface> createState() =>
      _WebRTCVoiceCallInterfaceState();
}

class _WebRTCVoiceCallInterfaceState extends State<WebRTCVoiceCallInterface>
    with WidgetsBindingObserver {
  // WebRTC components
  RTCPeerConnection? _peerConnection;
  MediaStream? _localStream;
  MediaStream? _remoteStream;

  // Call state
  CallState _callState = CallState.connecting;
  Duration _callDuration = Duration.zero;
  Timer? _callTimer;
  bool _isMuted = false;
  bool _isSpeakerOn = false;

  // Call quality
  CallQuality _callQuality = CallQuality.excellent;
  int _signalStrength = 100;
  int _latency = 0;
  Timer? _qualityTimer;

  // Call statistics
  Map<String, dynamic> _callStats = {};

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _initializeWebRTC();
  }

  @override
  void dispose() {
    _cleanup();
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.paused) {
      _pauseCall();
    } else if (state == AppLifecycleState.resumed) {
      _resumeCall();
    }
  }

  Future<void> _initializeWebRTC() async {
    try {
      // Request microphone permission
      await _requestMicrophonePermission();

      // Initialize peer connection
      await _createPeerConnection();

      // Get user media (audio only)
      await _getUserMedia();

      // Start call simulation (in real implementation, handle signaling)
      await _simulateCallConnection();
    } catch (e) {
      _handleCallError('Failed to initialize call: $e');
    }
  }

  Future<void> _requestMicrophonePermission() async {
    if (kIsWeb) return; // Browser handles permissions

    final status = await Permission.microphone.request();
    if (!status.isGranted) {
      throw Exception('Microphone permission denied');
    }
  }

  Future<void> _createPeerConnection() async {
    final configuration = {
      'iceServers': [
        {'urls': 'stun:stun.l.google.com:19302'},
        {'urls': 'stun:stun1.l.google.com:19302'},
      ]
    };

    _peerConnection = await createPeerConnection(configuration);

    _peerConnection?.onIceConnectionState = (state) {
      _handleIceConnectionStateChange(state);
    };

    _peerConnection?.onAddStream = (stream) {
      setState(() {
        _remoteStream = stream;
      });
    };

    _peerConnection?.onIceCandidate = (candidate) {
      // In real implementation, send candidate to remote peer
    };
  }

  Future<void> _getUserMedia() async {
    try {
      final constraints = {
        'audio': {
          'echoCancellation': true,
          'noiseSuppression': true,
          'autoGainControl': true,
        },
        'video': false,
      };

      _localStream = await navigator.mediaDevices.getUserMedia(constraints);

      if (_peerConnection != null && _localStream != null) {
        await _peerConnection!.addStream(_localStream!);
      }
    } catch (e) {
      throw Exception('Failed to get user media: $e');
    }
  }

  Future<void> _simulateCallConnection() async {
    setState(() {
      _callState = CallState.connecting;
    });

    // Simulate connection process
    await Future.delayed(const Duration(seconds: 2));

    if (mounted) {
      setState(() {
        _callState = CallState.connected;
      });
      _startCallTimer();
      _startQualityMonitoring();
    }
  }

  void _startCallTimer() {
    _callTimer = Timer.periodic(const Duration(seconds: 1), (timer) {
      if (mounted) {
        setState(() {
          _callDuration = Duration(seconds: _callDuration.inSeconds + 1);
        });
      }
    });
  }

  void _startQualityMonitoring() {
    _qualityTimer = Timer.periodic(const Duration(seconds: 5), (timer) {
      if (mounted) {
        _updateCallQuality();
      }
    });
  }

  void _updateCallQuality() {
    // Simulate call quality variations
    final random = DateTime.now().millisecond % 100;

    if (random < 10) {
      setState(() {
        _callQuality = CallQuality.poor;
        _signalStrength = 30 + (random * 2);
        _latency = 200 + random;
      });
    } else if (random < 30) {
      setState(() {
        _callQuality = CallQuality.fair;
        _signalStrength = 60 + random;
        _latency = 100 + (random ~/ 2);
      });
    } else {
      setState(() {
        _callQuality = CallQuality.excellent;
        _signalStrength = 80 + (random ~/ 5);
        _latency = 20 + (random ~/ 10);
      });
    }
  }

  void _handleIceConnectionStateChange(RTCIceConnectionState state) {
    switch (state) {
      case RTCIceConnectionState.RTCIceConnectionStateConnected:
        setState(() {
          _callState = CallState.connected;
        });
        break;
      case RTCIceConnectionState.RTCIceConnectionStateDisconnected:
      case RTCIceConnectionState.RTCIceConnectionStateFailed:
        setState(() {
          _callState = CallState.reconnecting;
        });
        _attemptReconnection();
        break;
      case RTCIceConnectionState.RTCIceConnectionStateClosed:
        _endCall();
        break;
      default:
        break;
    }
  }

  void _attemptReconnection() {
    Future.delayed(const Duration(seconds: 3), () {
      if (mounted && _callState == CallState.reconnecting) {
        setState(() {
          _callState = CallState.connected;
        });
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: SafeArea(
        child: Column(
          children: [
            SizedBox(height: 8.h),

            // Counterparty avatar and info
            _buildCounterpartyInfo(),

            SizedBox(height: 4.h),

            // Call status and timer
            _buildCallStatusSection(),

            SizedBox(height: 6.h),

            // Call quality indicators
            CallQualityIndicatorWidget(
              quality: _callQuality,
              signalStrength: _signalStrength,
              latency: _latency,
            ),

            const Spacer(),

            // Connection status
            ConnectionStatusWidget(
              state: _callState,
              onReconnectTap: _attemptReconnection,
            ),

            SizedBox(height: 4.h),

            // Call controls
            CallControlsWidget(
              isMuted: _isMuted,
              isSpeakerOn: _isSpeakerOn,
              onMuteToggle: _toggleMute,
              onSpeakerToggle: _toggleSpeaker,
              onEndCall: _endCall,
              onReportCall: _showReportDialog,
            ),

            SizedBox(height: 6.h),
          ],
        ),
      ),
    );
  }

  Widget _buildCounterpartyInfo() {
    return Column(
      children: [
        // Avatar
        Container(
          width: 32.w,
          height: 32.w,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            gradient: LinearGradient(
              colors: [
                AppTheme.lightTheme.primaryColor,
                AppTheme.lightTheme.primaryColor.withValues(alpha: 0.7),
              ],
            ),
            border: Border.all(
              color: Colors.white.withValues(alpha: 0.3),
              width: 3,
            ),
          ),
          child: Center(
            child: Text(
              widget.counterparty.isNotEmpty
                  ? widget.counterparty[0].toUpperCase()
                  : '?',
              style: TextStyle(
                fontSize: 20.sp,
                fontWeight: FontWeight.bold,
                color: Colors.white,
              ),
            ),
          ),
        ),

        SizedBox(height: 3.h),

        // Name and verification
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              widget.counterparty,
              style: TextStyle(
                fontSize: 20.sp,
                fontWeight: FontWeight.w600,
                color: Colors.white,
              ),
            ),
            if (widget.isVerified) ...[
              SizedBox(width: 2.w),
              CustomIconWidget(
                iconName: 'verified',
                color: Colors.blue,
                size: 6.w,
              ),
            ],
          ],
        ),
      ],
    );
  }

  Widget _buildCallStatusSection() {
    return Column(
      children: [
        // Call status
        Text(
          _getCallStatusText(),
          style: TextStyle(
            fontSize: 16.sp,
            color: _getCallStatusColor(),
            fontWeight: FontWeight.w500,
          ),
        ),

        SizedBox(height: 2.h),

        // Call timer
        if (_callState == CallState.connected)
          CallTimerWidget(duration: _callDuration),
      ],
    );
  }

  String _getCallStatusText() {
    switch (_callState) {
      case CallState.connecting:
        return 'Connecting...';
      case CallState.connected:
        return 'Connected';
      case CallState.reconnecting:
        return 'Reconnecting...';
      case CallState.ended:
        return 'Call Ended';
    }
  }

  Color _getCallStatusColor() {
    switch (_callState) {
      case CallState.connecting:
      case CallState.reconnecting:
        return Colors.orange;
      case CallState.connected:
        return Colors.green;
      case CallState.ended:
        return Colors.red;
    }
  }

  void _toggleMute() {
    setState(() {
      _isMuted = !_isMuted;
    });

    _localStream?.getAudioTracks().forEach((track) {
      track.enabled = !_isMuted;
    });

    HapticFeedback.lightImpact();
  }

  void _toggleSpeaker() {
    setState(() {
      _isSpeakerOn = !_isSpeakerOn;
    });

    // Platform-specific speaker toggle implementation would go here
    if (!kIsWeb) {
      try {
        Helper.setSpeakerphoneOn(_isSpeakerOn);
      } catch (e) {
        // Handle error silently
      }
    }

    HapticFeedback.lightImpact();
  }

  void _endCall() {
    HapticFeedback.heavyImpact();

    setState(() {
      _callState = CallState.ended;
    });

    _cleanup();

    // Navigate back with call summary
    Navigator.pop(context, {
      'duration': _callDuration,
      'quality': _callQuality,
      'endedBy': 'user',
    });
  }

  void _pauseCall() {
    _localStream?.getAudioTracks().forEach((track) {
      track.enabled = false;
    });
  }

  void _resumeCall() {
    if (!_isMuted) {
      _localStream?.getAudioTracks().forEach((track) {
        track.enabled = true;
      });
    }
  }

  void _cleanup() {
    _callTimer?.cancel();
    _qualityTimer?.cancel();

    _localStream?.dispose();
    _remoteStream?.dispose();
    _peerConnection?.close();
    _peerConnection?.dispose();
  }

  void _handleCallError(String error) {
    setState(() {
      _callState = CallState.ended;
    });

    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => AlertDialog(
        title: const Text('Call Failed'),
        content: Text(
            'Unable to connect the call. Please try again later.\n\nError: $error'),
        actions: [
          ElevatedButton(
            onPressed: () {
              Navigator.pop(context);
              Navigator.pop(context);
            },
            child: const Text('OK'),
          ),
        ],
      ),
    );
  }

  void _showReportDialog() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: AppTheme.lightTheme.cardColor,
        title: const Text('Report Call'),
        content: const Text('Report this call for inappropriate behavior?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(context);
              // Handle report logic
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: AppTheme.lightTheme.colorScheme.error,
            ),
            child: const Text('Report'),
          ),
        ],
      ),
    );
  }
}

// Enums for call states and quality
enum CallState {
  connecting,
  connected,
  reconnecting,
  ended,
}

enum CallQuality {
  poor,
  fair,
  excellent,
}
