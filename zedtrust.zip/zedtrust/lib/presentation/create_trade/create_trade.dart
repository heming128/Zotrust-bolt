import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../core/app_export.dart';
import '../../core/services/escrow_settlement_service.dart';
import '../../core/services/trade_fee_logic_service.dart';
import './widgets/agent_selection_widget.dart';
import './widgets/amount_input_widget.dart';
import './widgets/counterparty_input_widget.dart';
import './widgets/gas_fee_widget.dart';
import './widgets/role_selector_widget.dart';
import './widgets/trade_terms_widget.dart';

class CreateTrade extends StatefulWidget {
  const CreateTrade({Key? key}) : super(key: key);

  @override
  State<CreateTrade> createState() => _CreateTradeState();
}

class _CreateTradeState extends State<CreateTrade> {
  final _formKey = GlobalKey<FormState>();
  final _amountController = TextEditingController();
  final _counterpartyController = TextEditingController();
  final _descriptionController = TextEditingController();

  String _selectedRole = 'buying';
  String? _selectedAgentId;
  double _timeoutHours = 2.0;
  bool _isCreatingTrade = false;
  bool _hasUnsavedChanges = false;
  bool _feesAcknowledged = false;

  // Validation states
  String? _amountError;
  String? _counterpartyError;

  // Mock wallet balance
  final double _walletBalance = 1250.75;

  // Use TradeFeeLogicService for exact platform fees calculation
  double get _tradeAmount => double.tryParse(_amountController.text) ?? 0.0;

  Map<String, dynamic> get _feeCalculation =>
      _tradeAmount > 0
          ? TradeFeeLogicService.instance.calculateTradeFees(
            grossTradeAmount: _tradeAmount,
          )
          : {};

  double get _platformFeeBuyer =>
      _feeCalculation.isNotEmpty ? _feeCalculation['platformFeeBuyer'] : 0.0;

  double get _platformFeeSeller =>
      _feeCalculation.isNotEmpty ? _feeCalculation['platformFeeSeller'] : 0.0;

  double get _totalAmountBuyer => _tradeAmount + _platformFeeBuyer;

  double get _netToSeller =>
      _feeCalculation.isNotEmpty ? _feeCalculation['netToBuyer'] : 0.0;

  double get _sellerLockAmount =>
      _feeCalculation.isNotEmpty
          ? _feeCalculation['requiredLockFromSeller']
          : 0.0;

  @override
  void initState() {
    super.initState();
    _amountController.addListener(_onFormChanged);
    _counterpartyController.addListener(_onFormChanged);
    _descriptionController.addListener(_onFormChanged);
  }

  @override
  void dispose() {
    _amountController.dispose();
    _counterpartyController.dispose();
    _descriptionController.dispose();
    super.dispose();
  }

  void _onFormChanged() {
    setState(() {
      _hasUnsavedChanges =
          _amountController.text.isNotEmpty ||
          _counterpartyController.text.isNotEmpty ||
          _descriptionController.text.isNotEmpty ||
          _selectedAgentId != null;
    });
  }

  void _validateAmount(String value) {
    setState(() {
      if (value.isEmpty) {
        _amountError = null;
      } else {
        try {
          final amount = double.parse(value);
          if (amount <= 0) {
            _amountError = 'Amount must be greater than 0';
          } else if (_selectedRole == 'selling' &&
              _sellerLockAmount > _walletBalance) {
            _amountError =
                'Insufficient balance for escrow lock. Required: ${_sellerLockAmount.toStringAsFixed(2)} USDC, Available: ${_walletBalance.toStringAsFixed(2)} USDC';
          } else if (amount < 1) {
            _amountError = 'Minimum amount is 1 USDC';
          } else if (amount > 10000) {
            _amountError = 'Maximum amount is 10,000 USDC';
          } else {
            _amountError = null;
          }
        } catch (e) {
          _amountError = 'Invalid amount format';
        }
      }
    });
  }

  void _validateCounterparty(String value) {
    setState(() {
      if (value.isEmpty) {
        _counterpartyError = null;
      } else {
        final isValidAddress = RegExp(r'^0x[a-fA-F0-9]{40}$').hasMatch(value);
        if (!isValidAddress) {
          _counterpartyError = 'Invalid wallet address format';
        } else {
          _counterpartyError = null;
        }
      }
    });
  }

  bool _isFormValid() {
    return _amountController.text.isNotEmpty &&
        _counterpartyController.text.isNotEmpty &&
        _selectedAgentId != null &&
        _amountError == null &&
        _counterpartyError == null &&
        _feesAcknowledged;
  }

  Future<void> _handleQrScan() async {
    try {
      // Mock QR scan result
      await Future.delayed(const Duration(seconds: 1));
      const mockAddress = '0x742d35Cc6634C0532925a3b8D0C9C0C8c5C8c8c8';
      _counterpartyController.text = mockAddress;
      _validateCounterparty(mockAddress);

      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(
              'Wallet address scanned successfully',
              style: AppTheme.lightTheme.textTheme.bodyMedium?.copyWith(
                color: Colors.white,
              ),
            ),
            backgroundColor: AppTheme.getSuccessColor(true),
            behavior: SnackBarBehavior.floating,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(2.w),
            ),
          ),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(
              'Failed to scan QR code. Please try again.',
              style: AppTheme.lightTheme.textTheme.bodyMedium?.copyWith(
                color: Colors.white,
              ),
            ),
            backgroundColor: AppTheme.lightTheme.colorScheme.error,
            behavior: SnackBarBehavior.floating,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(2.w),
            ),
          ),
        );
      }
    }
  }

  Future<void> _createTrade() async {
    if (!_isFormValid()) return;

    // Show fees confirmation dialog with exact calculations
    final confirmed = await _showFeesConfirmationDialog();
    if (!confirmed) return;

    setState(() => _isCreatingTrade = true);

    try {
      // Create escrow lock using EscrowSettlementService
      final escrowResult = await EscrowSettlementService.instance.createEscrowLock(
        tradeId:
            'TRD${DateTime.now().millisecondsSinceEpoch.toString().substring(8)}',
        grossTradeAmount: _tradeAmount,
        sellerAddress:
            _selectedRole == 'selling'
                ? '0xYOUR_ADDRESS'
                : _counterpartyController.text,
        buyerAddress:
            _selectedRole == 'buying'
                ? '0xYOUR_ADDRESS'
                : _counterpartyController.text,
        agentAddress: _selectedAgentId,
      );

      if (!escrowResult['success']) {
        throw Exception(escrowResult['message']);
      }

      final tradeId = escrowResult['transaction']['tradeId'];

      if (mounted) {
        // Show success dialog with exact fee information
        await showDialog(
          context: context,
          barrierDismissible: false,
          builder:
              (context) => AlertDialog(
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(3.w),
                ),
                title: Row(
                  children: [
                    CustomIconWidget(
                      iconName: 'check_circle',
                      color: AppTheme.getSuccessColor(true),
                      size: 6.w,
                    ),
                    SizedBox(width: 3.w),
                    Text(
                      'Trade Created!',
                      style: AppTheme.lightTheme.textTheme.titleLarge?.copyWith(
                        fontWeight: FontWeight.w600,
                        color: AppTheme.lightTheme.colorScheme.onSurface,
                      ),
                    ),
                  ],
                ),
                content: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Your trade has been successfully created with exact platform fees applied according to the 1%+1% fee structure.',
                      style: AppTheme.lightTheme.textTheme.bodyMedium?.copyWith(
                        color: AppTheme.lightTheme.colorScheme.onSurfaceVariant,
                      ),
                    ),
                    SizedBox(height: 2.h),

                    // Trade summary with exact fees
                    Container(
                      padding: EdgeInsets.all(3.w),
                      decoration: BoxDecoration(
                        color: AppTheme.lightTheme.colorScheme.primaryContainer
                            .withValues(alpha: 0.3),
                        borderRadius: BorderRadius.circular(2.w),
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'Trade Summary (USDC 6-Decimal)',
                            style: AppTheme.lightTheme.textTheme.bodySmall
                                ?.copyWith(
                                  color:
                                      AppTheme
                                          .lightTheme
                                          .colorScheme
                                          .onSurfaceVariant,
                                  fontWeight: FontWeight.w600,
                                ),
                          ),
                          SizedBox(height: 1.h),
                          _buildConfirmationRow('Trade ID', tradeId),
                          _buildConfirmationRow(
                            'Gross Amount (G)',
                            '\$${_tradeAmount.toStringAsFixed(6)}',
                          ),
                          if (_selectedRole == 'buying') ...[
                            _buildConfirmationRow(
                              'Platform Fee (1%)',
                              '+\$${_platformFeeBuyer.toStringAsFixed(6)}',
                            ),
                            SizedBox(height: 1.h),
                            Container(
                              height: 1,
                              color: AppTheme.lightTheme.colorScheme.outline
                                  .withValues(alpha: 0.2),
                            ),
                            SizedBox(height: 1.h),
                            _buildConfirmationRow(
                              'Total You Pay',
                              '\$${_totalAmountBuyer.toStringAsFixed(6)}',
                              isTotal: true,
                            ),
                          ] else ...[
                            _buildConfirmationRow(
                              'Escrow Lock Amount',
                              '\$${_sellerLockAmount.toStringAsFixed(6)}',
                            ),
                            _buildConfirmationRow(
                              'Platform Fee (1%)',
                              '-\$${_platformFeeSeller.toStringAsFixed(6)}',
                            ),
                            SizedBox(height: 1.h),
                            Container(
                              height: 1,
                              color: AppTheme.lightTheme.colorScheme.outline
                                  .withValues(alpha: 0.2),
                            ),
                            SizedBox(height: 1.h),
                            _buildConfirmationRow(
                              'Buyer Will Receive',
                              '\$${_netToSeller.toStringAsFixed(6)}',
                              isTotal: true,
                            ),
                          ],
                          _buildConfirmationRow(
                            'Platform Collects Total',
                            '\$${_feeCalculation['platformFeeTotal'].toStringAsFixed(6)}',
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
                actions: [
                  TextButton(
                    onPressed: () {
                      Navigator.of(context).pop();
                      Navigator.pushReplacementNamed(context, '/dashboard');
                    },
                    child: Text(
                      'Go to Dashboard',
                      style: AppTheme.lightTheme.textTheme.titleSmall?.copyWith(
                        color: AppTheme.lightTheme.colorScheme.primary,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  ),
                  ElevatedButton(
                    onPressed: () {
                      Navigator.of(context).pop();
                      Navigator.pushNamed(
                        context,
                        '/trade-details',
                        arguments: tradeId,
                      );
                    },
                    child: Text('View Trade'),
                  ),
                ],
              ),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(
              'Failed to create trade: ${e.toString()}',
              style: AppTheme.lightTheme.textTheme.bodyMedium?.copyWith(
                color: Colors.white,
              ),
            ),
            backgroundColor: AppTheme.lightTheme.colorScheme.error,
            behavior: SnackBarBehavior.floating,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(2.w),
            ),
          ),
        );
      }
    } finally {
      if (mounted) {
        setState(() => _isCreatingTrade = false);
      }
    }
  }

  Future<bool> _showFeesConfirmationDialog() async {
    // Generate exact fee example for user confirmation
    final example = TradeFeeLogicService.instance.generateExampleCalculation(
      _tradeAmount,
    );

    final result = await showDialog<bool>(
      context: context,
      barrierDismissible: false,
      builder:
          (context) => AlertDialog(
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(3.w),
            ),
            title: Row(
              children: [
                CustomIconWidget(
                  iconName: 'account_balance',
                  color: AppTheme.lightTheme.primaryColor,
                  size: 6.w,
                ),
                SizedBox(width: 3.w),
                Text(
                  'Confirm Exact Platform Fees',
                  style: AppTheme.lightTheme.textTheme.titleLarge?.copyWith(
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ],
            ),
            content: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Please confirm the exact platform fees for this USDC trade:',
                  style: AppTheme.lightTheme.textTheme.bodyMedium,
                ),
                SizedBox(height: 3.h),
                Container(
                  padding: EdgeInsets.all(3.w),
                  decoration: BoxDecoration(
                    color: AppTheme.lightTheme.primaryColor.withValues(
                      alpha: 0.05,
                    ),
                    borderRadius: BorderRadius.circular(2.w),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Fee Calculation (6-Decimal USDC)',
                        style: AppTheme.lightTheme.textTheme.titleSmall
                            ?.copyWith(
                              fontWeight: FontWeight.w600,
                              color: AppTheme.lightTheme.primaryColor,
                            ),
                      ),
                      SizedBox(height: 1.h),
                      _buildConfirmationRow(
                        'Gross Trade Amount (G)',
                        '\$${_tradeAmount.toStringAsFixed(6)}',
                      ),
                      if (_selectedRole == 'buying') ...[
                        _buildConfirmationRow(
                          'Platform Fee (1%)',
                          '+\$${_platformFeeBuyer.toStringAsFixed(6)}',
                        ),
                        SizedBox(height: 1.h),
                        Container(
                          height: 1,
                          color: AppTheme.lightTheme.colorScheme.outline
                              .withValues(alpha: 0.2),
                        ),
                        SizedBox(height: 1.h),
                        _buildConfirmationRow(
                          'Total You Pay',
                          '\$${_totalAmountBuyer.toStringAsFixed(6)}',
                          isTotal: true,
                        ),
                      ] else ...[
                        _buildConfirmationRow(
                          'Escrow Lock Amount',
                          '\$${_sellerLockAmount.toStringAsFixed(6)}',
                        ),
                        _buildConfirmationRow(
                          'Platform Fee (1%)',
                          '-\$${_platformFeeSeller.toStringAsFixed(6)}',
                        ),
                        SizedBox(height: 1.h),
                        Container(
                          height: 1,
                          color: AppTheme.lightTheme.colorScheme.outline
                              .withValues(alpha: 0.2),
                        ),
                        SizedBox(height: 1.h),
                        _buildConfirmationRow(
                          'Buyer Will Receive',
                          '\$${_netToSeller.toStringAsFixed(6)}',
                          isTotal: true,
                        ),
                      ],
                    ],
                  ),
                ),
                SizedBox(height: 3.h),
                Container(
                  padding: EdgeInsets.all(3.w),
                  decoration: BoxDecoration(
                    color: AppTheme.getWarningColor(
                      true,
                    ).withValues(alpha: 0.1),
                    borderRadius: BorderRadius.circular(2.w),
                  ),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      CustomIconWidget(
                        iconName: 'info',
                        color: AppTheme.getWarningColor(true),
                        size: 5.w,
                      ),
                      SizedBox(width: 2.w),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              _selectedRole == 'buying'
                                  ? 'As a buyer, you pay an additional 1% platform fee on top of the trade amount.'
                                  : 'As a seller, you lock 1.01*G in escrow. On success, buyer gets 0.99*G and platform keeps 0.02*G total.',
                              style: AppTheme.lightTheme.textTheme.bodySmall
                                  ?.copyWith(
                                    color: AppTheme.getWarningColor(true),
                                    fontWeight: FontWeight.w600,
                                  ),
                            ),
                            SizedBox(height: 1.h),
                            Text(
                              '${example['example']}\n${example['steps'].join('\n')}',
                              style: AppTheme.lightTheme.textTheme.bodySmall
                                  ?.copyWith(
                                    color: AppTheme.getWarningColor(true),
                                    fontSize: 10,
                                  ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.of(context).pop(false),
                child: Text(
                  'Cancel',
                  style: AppTheme.lightTheme.textTheme.titleSmall?.copyWith(
                    color: AppTheme.lightTheme.colorScheme.onSurfaceVariant,
                  ),
                ),
              ),
              ElevatedButton(
                onPressed: () => Navigator.of(context).pop(true),
                child: Text('Confirm & Create Trade'),
              ),
            ],
          ),
    );

    return result ?? false;
  }

  Widget _buildConfirmationRow(
    String label,
    String amount, {
    bool isTotal = false,
  }) {
    return Padding(
      padding: EdgeInsets.symmetric(vertical: 0.5.h),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            label,
            style: AppTheme.lightTheme.textTheme.bodyMedium?.copyWith(
              fontWeight: isTotal ? FontWeight.w600 : FontWeight.normal,
              color:
                  isTotal
                      ? AppTheme.lightTheme.primaryColor
                      : AppTheme.lightTheme.colorScheme.onSurfaceVariant,
            ),
          ),
          Text(
            amount,
            style: AppTheme.lightTheme.textTheme.bodyMedium?.copyWith(
              fontWeight: isTotal ? FontWeight.w700 : FontWeight.w600,
              color:
                  isTotal
                      ? AppTheme.lightTheme.primaryColor
                      : AppTheme.lightTheme.colorScheme.onSurface,
            ),
          ),
        ],
      ),
    );
  }

  Future<bool> _onWillPop() async {
    if (!_hasUnsavedChanges) return true;

    final result = await showDialog<bool>(
      context: context,
      builder:
          (context) => AlertDialog(
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(3.w),
            ),
            title: Text(
              'Discard Changes?',
              style: AppTheme.lightTheme.textTheme.titleLarge?.copyWith(
                fontWeight: FontWeight.w600,
                color: AppTheme.lightTheme.colorScheme.onSurface,
              ),
            ),
            content: Text(
              'You have unsaved changes. Are you sure you want to leave?',
              style: AppTheme.lightTheme.textTheme.bodyMedium?.copyWith(
                color: AppTheme.lightTheme.colorScheme.onSurfaceVariant,
              ),
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.of(context).pop(false),
                child: Text(
                  'Stay',
                  style: AppTheme.lightTheme.textTheme.titleSmall?.copyWith(
                    color: AppTheme.lightTheme.primaryColor,
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ),
              TextButton(
                onPressed: () => Navigator.of(context).pop(true),
                child: Text(
                  'Discard',
                  style: AppTheme.lightTheme.textTheme.titleSmall?.copyWith(
                    color: AppTheme.lightTheme.colorScheme.error,
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ),
            ],
          ),
    );

    return result ?? false;
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: _onWillPop,
      child: Scaffold(
        backgroundColor: AppTheme.lightTheme.scaffoldBackgroundColor,
        appBar: AppBar(
          title: Text(
            'Create Trade',
            style: AppTheme.lightTheme.textTheme.titleLarge?.copyWith(
              fontWeight: FontWeight.w600,
              color: AppTheme.lightTheme.colorScheme.onSurface,
            ),
          ),
          leading: IconButton(
            onPressed: () async {
              final canPop = await _onWillPop();
              if (canPop && mounted) {
                Navigator.of(context).pop();
              }
            },
            icon: CustomIconWidget(
              iconName: 'close',
              color: AppTheme.lightTheme.colorScheme.onSurface,
              size: 6.w,
            ),
          ),
          actions: [
            Container(
              margin: EdgeInsets.only(right: 4.w),
              padding: EdgeInsets.symmetric(horizontal: 3.w, vertical: 1.h),
              decoration: BoxDecoration(
                color: AppTheme.getSuccessColor(true).withValues(alpha: 0.1),
                borderRadius: BorderRadius.circular(2.w),
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  CustomIconWidget(
                    iconName: 'account_balance_wallet',
                    color: AppTheme.getSuccessColor(true),
                    size: 4.w,
                  ),
                  SizedBox(width: 1.w),
                  Text(
                    '${_walletBalance.toStringAsFixed(2)} USDC',
                    style: AppTheme.lightTheme.textTheme.bodySmall?.copyWith(
                      color: AppTheme.getSuccessColor(true),
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
        body: SafeArea(
          child: Form(
            key: _formKey,
            child: Column(
              children: [
                Expanded(
                  child: SingleChildScrollView(
                    padding: EdgeInsets.all(4.w),
                    child: Column(
                      children: [
                        // Role Selector
                        RoleSelectorWidget(
                          selectedRole: _selectedRole,
                          onRoleChanged: (role) {
                            setState(() {
                              _selectedRole = role;
                              _hasUnsavedChanges = true;
                            });
                            _validateAmount(_amountController.text);
                          },
                        ),

                        SizedBox(height: 4.h),

                        // Amount Input with Fees Preview
                        AmountInputWidget(
                          controller: _amountController,
                          errorText: _amountError,
                          onChanged: _validateAmount,
                          selectedRole: _selectedRole,
                        ),

                        SizedBox(height: 4.h),

                        // Counterparty Input
                        CounterpartyInputWidget(
                          controller: _counterpartyController,
                          errorText: _counterpartyError,
                          onChanged: _validateCounterparty,
                          onQrScan: _handleQrScan,
                        ),

                        SizedBox(height: 4.h),

                        // Agent Selection
                        AgentSelectionWidget(
                          selectedAgentId: _selectedAgentId,
                          onAgentSelected: (agentId) {
                            setState(() {
                              _selectedAgentId = agentId;
                              _hasUnsavedChanges = true;
                            });
                          },
                        ),

                        SizedBox(height: 4.h),

                        // Trade Terms
                        TradeTermsWidget(
                          timeoutHours: _timeoutHours,
                          onTimeoutChanged: (hours) {
                            setState(() {
                              _timeoutHours = hours;
                              _hasUnsavedChanges = true;
                            });
                          },
                          descriptionController: _descriptionController,
                          onDescriptionChanged: (description) {
                            setState(() {
                              _hasUnsavedChanges = true;
                            });
                          },
                        ),

                        SizedBox(height: 4.h),

                        // Platform Fees Acknowledgment with exact calculations
                        if (_tradeAmount > 0) ...[
                          Container(
                            padding: EdgeInsets.all(3.w),
                            decoration: BoxDecoration(
                              color: AppTheme.lightTheme.primaryColor
                                  .withValues(alpha: 0.05),
                              borderRadius: BorderRadius.circular(2.w),
                              border: Border.all(
                                color: AppTheme.lightTheme.primaryColor
                                    .withValues(alpha: 0.3),
                              ),
                            ),
                            child: Row(
                              children: [
                                Checkbox(
                                  value: _feesAcknowledged,
                                  onChanged: (value) {
                                    setState(() {
                                      _feesAcknowledged = value ?? false;
                                    });
                                  },
                                  activeColor: AppTheme.lightTheme.primaryColor,
                                ),
                                Expanded(
                                  child: GestureDetector(
                                    onTap: () {
                                      setState(() {
                                        _feesAcknowledged = !_feesAcknowledged;
                                      });
                                    },
                                    child: Text(
                                      _selectedRole == 'buying'
                                          ? 'I acknowledge that a 1% platform fee (\$${_platformFeeBuyer.toStringAsFixed(6)}) will be added to my trade amount. Total payment: \$${_totalAmountBuyer.toStringAsFixed(2)}'
                                          : 'I acknowledge that I will lock \$${_sellerLockAmount.toStringAsFixed(6)} in escrow, with 1% platform fee (\$${_platformFeeSeller.toStringAsFixed(6)}) deducted on successful trade.',
                                      style: AppTheme
                                          .lightTheme
                                          .textTheme
                                          .bodySmall
                                          ?.copyWith(
                                            color:
                                                AppTheme
                                                    .lightTheme
                                                    .colorScheme
                                                    .onSurface,
                                          ),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          SizedBox(height: 4.h),
                        ],

                        // Gas Fee Preview
                        GasFeeWidget(
                          selectedRole: _selectedRole,
                          amount: _amountController.text,
                        ),

                        SizedBox(height: 8.h), // Extra space for button
                      ],
                    ),
                  ),
                ),

                // Create Trade Button with Exact Fees Display
                Container(
                  padding: EdgeInsets.all(4.w),
                  decoration: BoxDecoration(
                    color: AppTheme.lightTheme.scaffoldBackgroundColor,
                    boxShadow: [
                      BoxShadow(
                        color: AppTheme.lightTheme.colorScheme.shadow,
                        blurRadius: 8,
                        offset: const Offset(0, -2),
                      ),
                    ],
                  ),
                  child: Column(
                    children: [
                      // Exact fees summary row
                      if (_tradeAmount > 0) ...[
                        Container(
                          padding: EdgeInsets.symmetric(
                            horizontal: 4.w,
                            vertical: 2.h,
                          ),
                          decoration: BoxDecoration(
                            color: AppTheme.lightTheme.primaryColor.withValues(
                              alpha: 0.05,
                            ),
                            borderRadius: BorderRadius.circular(2.w),
                          ),
                          child: Column(
                            children: [
                              Row(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                children: [
                                  Text(
                                    _selectedRole == 'buying'
                                        ? 'Total You Pay:'
                                        : 'Escrow Lock Amount:',
                                    style: AppTheme
                                        .lightTheme
                                        .textTheme
                                        .titleSmall
                                        ?.copyWith(fontWeight: FontWeight.w600),
                                  ),
                                  Text(
                                    '\$${(_selectedRole == 'buying' ? _totalAmountBuyer : _sellerLockAmount).toStringAsFixed(6)}',
                                    style: AppTheme
                                        .lightTheme
                                        .textTheme
                                        .titleMedium
                                        ?.copyWith(
                                          fontWeight: FontWeight.w700,
                                          color:
                                              AppTheme.lightTheme.primaryColor,
                                        ),
                                  ),
                                ],
                              ),
                              if (_selectedRole == 'selling') ...[
                                SizedBox(height: 1.h),
                                Row(
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,
                                  children: [
                                    Text(
                                      'Buyer Will Receive:',
                                      style: AppTheme
                                          .lightTheme
                                          .textTheme
                                          .bodySmall
                                          ?.copyWith(
                                            fontWeight: FontWeight.w500,
                                          ),
                                    ),
                                    Text(
                                      '\$${_netToSeller.toStringAsFixed(6)}',
                                      style: AppTheme
                                          .lightTheme
                                          .textTheme
                                          .bodySmall
                                          ?.copyWith(
                                            fontWeight: FontWeight.w600,
                                            color: AppTheme.getSuccessColor(
                                              true,
                                            ),
                                          ),
                                    ),
                                  ],
                                ),
                              ],
                            ],
                          ),
                        ),
                        SizedBox(height: 2.h),
                      ],

                      // Create Trade Button
                      SizedBox(
                        width: double.infinity,
                        height: 7.h,
                        child: ElevatedButton(
                          onPressed:
                              _isFormValid() && !_isCreatingTrade
                                  ? _createTrade
                                  : null,
                          style: ElevatedButton.styleFrom(
                            backgroundColor:
                                _isFormValid()
                                    ? AppTheme.lightTheme.colorScheme.primary
                                    : AppTheme
                                        .lightTheme
                                        .colorScheme
                                        .onSurfaceVariant
                                        .withValues(alpha: 0.3),
                            foregroundColor: Colors.white,
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(3.w),
                            ),
                            elevation: _isFormValid() ? 4 : 0,
                          ),
                          child:
                              _isCreatingTrade
                                  ? Row(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: [
                                      SizedBox(
                                        width: 5.w,
                                        height: 5.w,
                                        child: CircularProgressIndicator(
                                          strokeWidth: 2,
                                          valueColor:
                                              AlwaysStoppedAnimation<Color>(
                                                Colors.white,
                                              ),
                                        ),
                                      ),
                                      SizedBox(width: 3.w),
                                      Text(
                                        'Creating Trade...',
                                        style: AppTheme
                                            .lightTheme
                                            .textTheme
                                            .titleMedium
                                            ?.copyWith(
                                              color: Colors.white,
                                              fontWeight: FontWeight.w600,
                                            ),
                                      ),
                                    ],
                                  )
                                  : Row(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: [
                                      CustomIconWidget(
                                        iconName: 'add_circle',
                                        color: Colors.white,
                                        size: 6.w,
                                      ),
                                      SizedBox(width: 3.w),
                                      Text(
                                        'Create Trade',
                                        style: AppTheme
                                            .lightTheme
                                            .textTheme
                                            .titleMedium
                                            ?.copyWith(
                                              color: Colors.white,
                                              fontWeight: FontWeight.w600,
                                            ),
                                      ),
                                    ],
                                  ),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
