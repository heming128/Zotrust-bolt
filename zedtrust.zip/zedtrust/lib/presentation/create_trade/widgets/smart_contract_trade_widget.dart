import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';
import '../../../core/services/secure_wallet_service.dart';
import '../../../core/services/web3_escrow_service.dart';
import '../../../theme/app_theme.dart';
import '../../../widgets/custom_icon_widget.dart';

class SmartContractTradeWidget extends StatefulWidget {
  final Function(Map<String, dynamic>) onTradeCreated;

  const SmartContractTradeWidget({
    Key? key,
    required this.onTradeCreated,
  }) : super(key: key);

  @override
  State<SmartContractTradeWidget> createState() =>
      _SmartContractTradeWidgetState();
}

class _SmartContractTradeWidgetState extends State<SmartContractTradeWidget> {
  bool _isCreatingTrade = false;
  bool _isInitialized = false;
  String? _walletAddress;

  // Form controllers
  final _amountController = TextEditingController();
  final _counterPartyController = TextEditingController();
  final _tokenAddressController = TextEditingController(
    text: '0x0000000000000000000000000000000000000000', // Native token (MATIC)
  );

  int _selectedAdType = 0; // 0 = BUY, 1 = SELL
  String? _selectedTokenSymbol = 'MATIC';

  // Supported tokens on Polygon Amoy
  final List<Map<String, String>> _supportedTokens = [
    {
      'symbol': 'MATIC',
      'address': '0x0000000000000000000000000000000000000000',
      'name': 'Polygon Native Token'
    },
    {
      'symbol': 'USDC',
      'address': '0x41e94eb019c0762f9bfcf9fb1e58725bfb0e7582',
      'name': 'USD Coin (Test)'
    },
    {
      'symbol': 'USDT',
      'address': '0x2c69095d41f191a1c0aE8f66d6E22A2ED41d6780',
      'name': 'Tether USD (Test)'
    },
  ];

  @override
  void initState() {
    super.initState();
    _initializeWallet();
  }

  @override
  void dispose() {
    _amountController.dispose();
    _counterPartyController.dispose();
    _tokenAddressController.dispose();
    super.dispose();
  }

  Future<void> _initializeWallet() async {
    try {
      final walletInfo = await SecureWalletService.instance.getWalletInfo();
      setState(() {
        _isInitialized = walletInfo['isSetup'] ?? false;
        _walletAddress = walletInfo['address'];
      });
    } catch (e) {
      if (kDebugMode) {
        print('❌ Error initializing wallet: $e');
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    if (!_isInitialized) {
      return _buildWalletRequiredCard();
    }

    return Container(
      margin: EdgeInsets.symmetric(horizontal: 6.w, vertical: 2.h),
      padding: EdgeInsets.all(4.w),
      decoration: BoxDecoration(
        color: Theme.of(context).cardColor,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: AppTheme.lightTheme.colorScheme.primary.withValues(alpha: 0.3),
          width: 1,
        ),
        boxShadow: [
          BoxShadow(
            color: Theme.of(context).shadowColor.withValues(alpha: 0.1),
            blurRadius: 8,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Header
          Row(
            children: [
              Container(
                padding: EdgeInsets.all(2.w),
                decoration: BoxDecoration(
                  color: AppTheme.lightTheme.colorScheme.primary
                      .withValues(alpha: 0.1),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: CustomIconWidget(
                  iconName: 'trending_up',
                  color: AppTheme.lightTheme.colorScheme.primary,
                  size: 6.w,
                ),
              ),
              SizedBox(width: 3.w),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Create Smart Contract Trade',
                      style: Theme.of(context).textTheme.titleMedium?.copyWith(
                            fontWeight: FontWeight.w700,
                          ),
                    ),
                    SizedBox(height: 0.5.h),
                    Text(
                      'Blockchain-secured escrow trade',
                      style: Theme.of(context).textTheme.bodySmall?.copyWith(
                            color:
                                Theme.of(context).colorScheme.onSurfaceVariant,
                          ),
                    ),
                  ],
                ),
              ),
            ],
          ),

          SizedBox(height: 3.h),

          // Trade Type Selection
          Text(
            'Trade Type',
            style: Theme.of(context).textTheme.titleSmall?.copyWith(
                  fontWeight: FontWeight.w600,
                ),
          ),
          SizedBox(height: 1.h),
          Row(
            children: [
              Expanded(
                child: _buildAdTypeCard(0, 'BUY', 'I want to buy crypto'),
              ),
              SizedBox(width: 3.w),
              Expanded(
                child: _buildAdTypeCard(1, 'SELL', 'I want to sell crypto'),
              ),
            ],
          ),

          SizedBox(height: 3.h),

          // Token Selection
          Text(
            'Select Token',
            style: Theme.of(context).textTheme.titleSmall?.copyWith(
                  fontWeight: FontWeight.w600,
                ),
          ),
          SizedBox(height: 1.h),
          DropdownButtonFormField<String>(
            value: _selectedTokenSymbol,
            decoration: InputDecoration(
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(12),
              ),
              prefixIcon: Icon(
                Icons.token,
                color: AppTheme.lightTheme.colorScheme.primary,
              ),
            ),
            items: _supportedTokens.map((token) {
              return DropdownMenuItem<String>(
                value: token['symbol'],
                child: Row(
                  children: [
                    Container(
                      width: 6.w,
                      height: 6.w,
                      decoration: BoxDecoration(
                        color: AppTheme.lightTheme.colorScheme.primary
                            .withValues(alpha: 0.1),
                        borderRadius: BorderRadius.circular(3.w),
                      ),
                      child: Center(
                        child: Text(
                          token['symbol']![0],
                          style: Theme.of(context)
                              .textTheme
                              .bodySmall
                              ?.copyWith(
                                fontWeight: FontWeight.w700,
                                color: AppTheme.lightTheme.colorScheme.primary,
                              ),
                        ),
                      ),
                    ),
                    SizedBox(width: 3.w),
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          token['symbol']!,
                          style:
                              Theme.of(context).textTheme.bodyMedium?.copyWith(
                                    fontWeight: FontWeight.w600,
                                  ),
                        ),
                        Text(
                          token['name']!,
                          style:
                              Theme.of(context).textTheme.bodySmall?.copyWith(
                                    color: Theme.of(context)
                                        .colorScheme
                                        .onSurfaceVariant,
                                  ),
                        ),
                      ],
                    ),
                  ],
                ),
              );
            }).toList(),
            onChanged: (value) {
              setState(() {
                _selectedTokenSymbol = value;
                final selectedToken = _supportedTokens.firstWhere(
                  (token) => token['symbol'] == value,
                );
                _tokenAddressController.text = selectedToken['address']!;
              });
            },
          ),

          SizedBox(height: 3.h),

          // Amount Input
          Text(
            'Amount',
            style: Theme.of(context).textTheme.titleSmall?.copyWith(
                  fontWeight: FontWeight.w600,
                ),
          ),
          SizedBox(height: 1.h),
          TextField(
            controller: _amountController,
            keyboardType: const TextInputType.numberWithOptions(decimal: true),
            decoration: InputDecoration(
              hintText: 'Enter amount (e.g., 1.5)',
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(12),
              ),
              prefixIcon: Icon(
                Icons.account_balance_wallet,
                color: AppTheme.lightTheme.colorScheme.primary,
              ),
              suffixText: _selectedTokenSymbol,
            ),
          ),

          SizedBox(height: 3.h),

          // Counterparty Address Input
          Text(
            'Counterparty Address (Optional)',
            style: Theme.of(context).textTheme.titleSmall?.copyWith(
                  fontWeight: FontWeight.w600,
                ),
          ),
          SizedBox(height: 1.h),
          TextField(
            controller: _counterPartyController,
            decoration: InputDecoration(
              hintText: 'Enter wallet address or leave empty',
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(12),
              ),
              prefixIcon: Icon(
                Icons.person,
                color: AppTheme.lightTheme.colorScheme.primary,
              ),
            ),
          ),

          SizedBox(height: 1.h),
          Text(
            'If empty, any user can accept this trade offer',
            style: Theme.of(context).textTheme.bodySmall?.copyWith(
                  color: Theme.of(context).colorScheme.onSurfaceVariant,
                  fontStyle: FontStyle.italic,
                ),
          ),

          SizedBox(height: 4.h),

          // Create Trade Button
          SizedBox(
            width: double.infinity,
            child: ElevatedButton(
              onPressed: _isCreatingTrade ? null : _createSmartContractTrade,
              style: ElevatedButton.styleFrom(
                backgroundColor: AppTheme.lightTheme.colorScheme.primary,
                foregroundColor: Colors.white,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
                padding: EdgeInsets.symmetric(vertical: 2.h),
              ),
              child: _isCreatingTrade
                  ? SizedBox(
                      width: 5.w,
                      height: 5.w,
                      child: CircularProgressIndicator(
                        strokeWidth: 2,
                        valueColor: AlwaysStoppedAnimation<Color>(Colors.white),
                      ),
                    )
                  : Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        CustomIconWidget(
                          iconName: 'security',
                          color: Colors.white,
                          size: 5.w,
                        ),
                        SizedBox(width: 2.w),
                        Text(
                          'Create Blockchain Trade',
                          style:
                              Theme.of(context).textTheme.titleMedium?.copyWith(
                                    color: Colors.white,
                                    fontWeight: FontWeight.w600,
                                  ),
                        ),
                      ],
                    ),
            ),
          ),

          SizedBox(height: 2.h),

          // Info Banner
          Container(
            padding: EdgeInsets.all(3.w),
            decoration: BoxDecoration(
              color: AppTheme.lightTheme.colorScheme.secondary
                  .withValues(alpha: 0.1),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Row(
              children: [
                CustomIconWidget(
                  iconName: 'info',
                  color: AppTheme.lightTheme.colorScheme.secondary,
                  size: 5.w,
                ),
                SizedBox(width: 3.w),
                Expanded(
                  child: Text(
                    'This trade will be secured by our smart contract on Polygon network',
                    style: Theme.of(context).textTheme.bodySmall?.copyWith(
                          color: AppTheme.lightTheme.colorScheme.secondary,
                          fontWeight: FontWeight.w500,
                        ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildWalletRequiredCard() {
    return Container(
      margin: EdgeInsets.symmetric(horizontal: 6.w, vertical: 2.h),
      padding: EdgeInsets.all(4.w),
      decoration: BoxDecoration(
        color: Theme.of(context).cardColor,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: AppTheme.lightTheme.colorScheme.error.withValues(alpha: 0.3),
          width: 1,
        ),
      ),
      child: Column(
        children: [
          CustomIconWidget(
            iconName: 'account_balance_wallet',
            color: AppTheme.lightTheme.colorScheme.error,
            size: 12.w,
          ),
          SizedBox(height: 2.h),
          Text(
            'Wallet Required',
            style: Theme.of(context).textTheme.titleMedium?.copyWith(
                  fontWeight: FontWeight.w700,
                ),
          ),
          SizedBox(height: 1.h),
          Text(
            'Connect or create a wallet to create smart contract trades',
            style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                  color: Theme.of(context).colorScheme.onSurfaceVariant,
                ),
            textAlign: TextAlign.center,
          ),
          SizedBox(height: 2.h),
          ElevatedButton.icon(
            onPressed: () => Navigator.pushNamed(context, '/wallet-connection'),
            icon: CustomIconWidget(
              iconName: 'account_balance_wallet',
              color: Colors.white,
              size: 4.w,
            ),
            label: const Text('Connect Wallet'),
            style: ElevatedButton.styleFrom(
              backgroundColor: AppTheme.lightTheme.colorScheme.primary,
              foregroundColor: Colors.white,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildAdTypeCard(int adType, String title, String subtitle) {
    final bool isSelected = _selectedAdType == adType;

    return GestureDetector(
      onTap: () {
        setState(() {
          _selectedAdType = adType;
        });
        HapticFeedback.lightImpact();
      },
      child: Container(
        padding: EdgeInsets.all(3.w),
        decoration: BoxDecoration(
          color: isSelected
              ? AppTheme.lightTheme.colorScheme.primary.withValues(alpha: 0.1)
              : Theme.of(context).colorScheme.surface,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(
            color: isSelected
                ? AppTheme.lightTheme.colorScheme.primary
                : Theme.of(context).colorScheme.outline.withValues(alpha: 0.3),
            width: isSelected ? 2 : 1,
          ),
        ),
        child: Column(
          children: [
            CustomIconWidget(
              iconName: adType == 0 ? 'trending_down' : 'trending_up',
              color: isSelected
                  ? AppTheme.lightTheme.colorScheme.primary
                  : Theme.of(context).colorScheme.onSurfaceVariant,
              size: 6.w,
            ),
            SizedBox(height: 1.h),
            Text(
              title,
              style: Theme.of(context).textTheme.titleSmall?.copyWith(
                    fontWeight: FontWeight.w600,
                    color: isSelected
                        ? AppTheme.lightTheme.colorScheme.primary
                        : Theme.of(context).colorScheme.onSurface,
                  ),
            ),
            SizedBox(height: 0.5.h),
            Text(
              subtitle,
              style: Theme.of(context).textTheme.bodySmall?.copyWith(
                    color: Theme.of(context).colorScheme.onSurfaceVariant,
                  ),
              textAlign: TextAlign.center,
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _createSmartContractTrade() async {
    // Validate inputs
    if (_amountController.text.isEmpty) {
      _showError('Please enter an amount');
      return;
    }

    final amount = double.tryParse(_amountController.text);
    if (amount == null || amount <= 0) {
      _showError('Please enter a valid amount');
      return;
    }

    setState(() {
      _isCreatingTrade = true;
    });

    try {
      // Get private key from secure storage
      final privateKey = await SecureWalletService.instance.getPrivateKey();
      if (privateKey == null) {
        throw Exception('No private key found. Please reconnect your wallet.');
      }

      // Prepare counterparty address
      String counterPartyAddress = _counterPartyController.text.trim();
      if (counterPartyAddress.isEmpty) {
        counterPartyAddress =
            '0x0000000000000000000000000000000000000000'; // Zero address for open trades
      }

      // Convert amount to wei (assuming 18 decimals for most tokens)
      final amountInWei = BigInt.from((amount * 1e18).toInt());

      // Create trade on smart contract with database sync
      final result = await Web3EscrowService.instance.createTradeWithSync(
        privateKey: privateKey,
        sellerId: 'current_user_id', // TODO: Get from auth service
        buyerId:
            counterPartyAddress == '0x0000000000000000000000000000000000000000'
                ? 'open_trade'
                : 'specific_counterparty',
        adType: _selectedAdType,
        tokenAddress: _tokenAddressController.text,
        amountInUSDC: amount,
        counterPartyAddress: counterPartyAddress,
        escrowData: {
          'token_symbol': _selectedTokenSymbol,
          'created_via': 'mobile_app',
          'trade_type': _selectedAdType == 0 ? 'BUY' : 'SELL',
        },
      );

      if (result['success']) {
        // Show success feedback
        HapticFeedback.mediumImpact();

        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Row(
              children: [
                CustomIconWidget(
                  iconName: 'check_circle',
                  color: Colors.white,
                  size: 5.w,
                ),
                SizedBox(width: 3.w),
                Expanded(
                  child: Text(
                    'Smart contract trade created successfully!',
                    style: Theme.of(context).snackBarTheme.contentTextStyle,
                  ),
                ),
              ],
            ),
            backgroundColor: AppTheme.lightTheme.colorScheme.secondary,
            behavior: SnackBarBehavior.floating,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(12),
            ),
            duration: const Duration(seconds: 3),
          ),
        );

        // Call parent callback
        widget.onTradeCreated(result);

        // Clear form
        _clearForm();
      } else {
        throw Exception(result['message'] ?? 'Unknown error occurred');
      }
    } catch (e) {
      _showError('Failed to create trade: $e');
      HapticFeedback.heavyImpact();
    } finally {
      setState(() {
        _isCreatingTrade = false;
      });
    }
  }

  void _showError(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Row(
          children: [
            CustomIconWidget(
              iconName: 'error',
              color: Colors.white,
              size: 5.w,
            ),
            SizedBox(width: 3.w),
            Expanded(child: Text(message)),
          ],
        ),
        backgroundColor: AppTheme.lightTheme.colorScheme.error,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12),
        ),
      ),
    );
  }

  void _clearForm() {
    _amountController.clear();
    _counterPartyController.clear();
    setState(() {
      _selectedAdType = 0;
      _selectedTokenSymbol = 'MATIC';
      _tokenAddressController.text =
          '0x0000000000000000000000000000000000000000';
    });
  }
}
