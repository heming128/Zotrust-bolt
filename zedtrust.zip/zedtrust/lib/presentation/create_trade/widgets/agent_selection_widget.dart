import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';
import '../../../core/services/agent_auto_matching_service.dart';
import '../../../core/services/supabase_service.dart';

class AgentSelectionWidget extends StatefulWidget {
  final String? selectedAgentId;
  final Function(String) onAgentSelected;

  const AgentSelectionWidget({
    Key? key,
    this.selectedAgentId,
    required this.onAgentSelected,
  }) : super(key: key);

  @override
  State<AgentSelectionWidget> createState() => _AgentSelectionWidgetState();
}

class _AgentSelectionWidgetState extends State<AgentSelectionWidget> {
  bool _isLoading = true;
  List<Map<String, dynamic>> _agents = [];
  String? _selectedCity;
  bool _autoMatchEnabled = true;

  @override
  void initState() {
    super.initState();
    _loadAgents();
  }

  Future<void> _loadAgents() async {
    try {
      setState(() => _isLoading = true);

      final supabaseService = SupabaseService.instance;
      final agents = await supabaseService.getVerifiedAgents();

      // Enhance agents with location information
      final List<Map<String, dynamic>> enhancedAgents = [];

      for (final agent in agents.take(6)) {
        // Limit for UI performance
        final locations = await supabaseService.getAgentLocationsForManagement(
          agent['id'],
        );
        final cities = locations.map((loc) => loc['city']).toSet().toList();

        enhancedAgents.add({
          ...agent,
          'cities': cities,
          'location_count': locations.length,
          'primary_city': cities.isNotEmpty ? cities.first : 'Unknown',
          'coverage_display':
              cities.length > 3
                  ? '${cities.take(2).join(', ')} +${cities.length - 2} more'
                  : cities.join(', '),
          'is_online':
              DateTime.now().millisecond % 2 == 0, // Mock online status
          'response_time': '< ${(3 + (agent['id'].hashCode % 7))} min',
        });
      }

      setState(() {
        _agents = enhancedAgents;
        _isLoading = false;
      });
    } catch (e) {
      setState(() => _isLoading = false);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Error loading agents: ${e.toString()}'),
            backgroundColor: AppTheme.lightTheme.colorScheme.error,
          ),
        );
      }
    }
  }

  Future<void> _performAutoMatching() async {
    if (_selectedCity == null) return;

    try {
      setState(() => _isLoading = true);

      final autoMatchingService = AgentAutoMatchingService.instance;

      // Get agents for the selected city with auto-matching
      final cityAgents = await autoMatchingService.getAgentsForCity(
        city: _selectedCity!,
        limit: 8,
      );

      setState(() {
        _agents =
            cityAgents
                .map(
                  (agent) => {
                    ...agent,
                    'is_auto_matched': true,
                    'match_score':
                        85 + (agent['id'].hashCode % 15), // Mock score
                    'cities':
                        agent['city_branches']
                            ?.map((branch) => branch['city'])
                            .toList() ??
                        [],
                    'coverage_display':
                        agent['primary_branch']?['display_alias'] ?? 'Branch',
                    'is_online': DateTime.now().millisecond % 2 == 0,
                    'response_time':
                        '< ${(2 + (agent['id'].hashCode % 5))} min',
                  },
                )
                .toList();
        _isLoading = false;
      });

      if (cityAgents.isNotEmpty && widget.selectedAgentId == null) {
        // Auto-select the best matched agent
        widget.onAgentSelected(cityAgents.first['id']);
      }
    } catch (e) {
      setState(() => _isLoading = false);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Auto-matching failed: ${e.toString()}'),
            backgroundColor: AppTheme.lightTheme.colorScheme.error,
          ),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: EdgeInsets.all(4.w),
      decoration: BoxDecoration(
        color: AppTheme.lightTheme.colorScheme.surface,
        borderRadius: BorderRadius.circular(3.w),
        border: Border.all(
          color: AppTheme.lightTheme.colorScheme.outline.withValues(alpha: 0.3),
          width: 1,
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Header with auto-matching toggle
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                'Select Trusted Agent',
                style: AppTheme.lightTheme.textTheme.titleMedium?.copyWith(
                  fontWeight: FontWeight.w600,
                  color: AppTheme.lightTheme.colorScheme.onSurface,
                ),
              ),
              Row(
                children: [
                  Switch(
                    value: _autoMatchEnabled,
                    onChanged: (value) {
                      setState(() => _autoMatchEnabled = value);
                      if (value) {
                        _performAutoMatching();
                      } else {
                        _loadAgents();
                      }
                    },
                    activeColor: AppTheme.lightTheme.primaryColor,
                  ),
                  SizedBox(width: 2.w),
                  Text(
                    'Auto-Match',
                    style: AppTheme.lightTheme.textTheme.bodySmall?.copyWith(
                      color: AppTheme.lightTheme.primaryColor,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                ],
              ),
            ],
          ),

          SizedBox(height: 2.h),

          // City filter for auto-matching
          if (_autoMatchEnabled) ...[
            Container(
              padding: EdgeInsets.symmetric(horizontal: 3.w, vertical: 1.h),
              decoration: BoxDecoration(
                color: AppTheme.lightTheme.primaryColor.withValues(alpha: 0.1),
                borderRadius: BorderRadius.circular(2.w),
              ),
              child: Row(
                children: [
                  CustomIconWidget(
                    iconName: 'location_on',
                    color: AppTheme.lightTheme.primaryColor,
                    size: 5.w,
                  ),
                  SizedBox(width: 2.w),
                  Expanded(
                    child: DropdownButtonHideUnderline(
                      child: DropdownButton<String>(
                        hint: Text('Select city for auto-matching'),
                        value: _selectedCity,
                        onChanged: (city) {
                          setState(() => _selectedCity = city);
                          if (city != null) _performAutoMatching();
                        },
                        items:
                            [
                                  'Mumbai',
                                  'Delhi',
                                  'Bangalore',
                                  'Pune',
                                  'Chennai',
                                  'Hyderabad',
                                ]
                                .map(
                                  (city) => DropdownMenuItem(
                                    value: city,
                                    child: Text(city),
                                  ),
                                )
                                .toList(),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            SizedBox(height: 2.h),
          ],

          // Agents list
          if (_isLoading) ...[
            SizedBox(
              height: 25.h,
              child: Center(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    CircularProgressIndicator(
                      color: AppTheme.lightTheme.primaryColor,
                    ),
                    SizedBox(height: 2.h),
                    Text(
                      _autoMatchEnabled
                          ? 'Auto-matching agents...'
                          : 'Loading agents...',
                      style: AppTheme.lightTheme.textTheme.bodyMedium?.copyWith(
                        color: AppTheme.lightTheme.colorScheme.onSurfaceVariant,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ] else if (_agents.isEmpty) ...[
            Container(
              height: 15.h,
              padding: EdgeInsets.all(4.w),
              decoration: BoxDecoration(
                color: AppTheme.getWarningColor(true).withValues(alpha: 0.1),
                borderRadius: BorderRadius.circular(2.w),
              ),
              child: Center(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    CustomIconWidget(
                      iconName: 'info',
                      color: AppTheme.getWarningColor(true),
                      size: 6.w,
                    ),
                    SizedBox(height: 1.h),
                    Text(
                      'No agents available',
                      style: AppTheme.lightTheme.textTheme.titleSmall?.copyWith(
                        color: AppTheme.getWarningColor(true),
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    Text(
                      _autoMatchEnabled
                          ? 'Try selecting a different city'
                          : 'Please try again later',
                      style: AppTheme.lightTheme.textTheme.bodySmall?.copyWith(
                        color: AppTheme.getWarningColor(true),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ] else ...[
            SizedBox(
              height: 25.h,
              child: ListView.separated(
                scrollDirection: Axis.horizontal,
                itemCount: _agents.length,
                separatorBuilder: (context, index) => SizedBox(width: 3.w),
                itemBuilder: (context, index) {
                  final agent = _agents[index];
                  final isSelected = widget.selectedAgentId == agent['id'];
                  final isOnline = agent['is_online'] as bool? ?? false;
                  final isAutoMatched =
                      agent['is_auto_matched'] as bool? ?? false;

                  return GestureDetector(
                    onTap: () => widget.onAgentSelected(agent['id'] as String),
                    child: Container(
                      width: 45.w,
                      padding: EdgeInsets.all(3.w),
                      decoration: BoxDecoration(
                        color:
                            isSelected
                                ? AppTheme
                                    .lightTheme
                                    .colorScheme
                                    .primaryContainer
                                : AppTheme.lightTheme.colorScheme.surface,
                        borderRadius: BorderRadius.circular(2.w),
                        border: Border.all(
                          color:
                              isSelected
                                  ? AppTheme.lightTheme.colorScheme.primary
                                  : AppTheme.lightTheme.colorScheme.outline
                                      .withValues(alpha: 0.3),
                          width: isSelected ? 2 : 1,
                        ),
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          // Header row
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Expanded(
                                child: Text(
                                  agent['name'] ?? agent['alias'] ?? 'Agent',
                                  style: AppTheme
                                      .lightTheme
                                      .textTheme
                                      .titleSmall
                                      ?.copyWith(
                                        fontWeight: FontWeight.w600,
                                        color:
                                            AppTheme
                                                .lightTheme
                                                .colorScheme
                                                .onSurface,
                                      ),
                                  overflow: TextOverflow.ellipsis,
                                ),
                              ),
                              // Online indicator
                              Container(
                                width: 2.w,
                                height: 2.w,
                                decoration: BoxDecoration(
                                  color:
                                      isOnline
                                          ? AppTheme.getSuccessColor(true)
                                          : AppTheme
                                              .lightTheme
                                              .colorScheme
                                              .onSurfaceVariant,
                                  shape: BoxShape.circle,
                                ),
                              ),
                            ],
                          ),

                          SizedBox(height: 1.h),

                          // Auto-match badge
                          if (isAutoMatched) ...[
                            Container(
                              padding: EdgeInsets.symmetric(
                                horizontal: 2.w,
                                vertical: 0.5.h,
                              ),
                              decoration: BoxDecoration(
                                color: AppTheme.lightTheme.primaryColor,
                                borderRadius: BorderRadius.circular(1.w),
                              ),
                              child: Text(
                                'AUTO-MATCHED ${agent['match_score']}%',
                                style: AppTheme.lightTheme.textTheme.bodySmall
                                    ?.copyWith(
                                      color: Colors.white,
                                      fontWeight: FontWeight.w600,
                                      fontSize: 8.sp,
                                    ),
                              ),
                            ),
                            SizedBox(height: 1.h),
                          ],

                          // Location coverage
                          Row(
                            children: [
                              CustomIconWidget(
                                iconName: 'location_on',
                                color:
                                    AppTheme
                                        .lightTheme
                                        .colorScheme
                                        .onSurfaceVariant,
                                size: 4.w,
                              ),
                              SizedBox(width: 1.w),
                              Expanded(
                                child: Text(
                                  agent['coverage_display'] ?? 'Unknown',
                                  style: AppTheme.lightTheme.textTheme.bodySmall
                                      ?.copyWith(
                                        color:
                                            AppTheme
                                                .lightTheme
                                                .colorScheme
                                                .onSurfaceVariant,
                                      ),
                                  overflow: TextOverflow.ellipsis,
                                ),
                              ),
                            ],
                          ),

                          SizedBox(height: 1.h),

                          // Rating row
                          Row(
                            children: [
                              CustomIconWidget(
                                iconName: 'star',
                                color: AppTheme.getWarningColor(true),
                                size: 4.w,
                              ),
                              SizedBox(width: 1.w),
                              Text(
                                '${agent['rating'] ?? 0.0}',
                                style: AppTheme.lightTheme.textTheme.bodySmall
                                    ?.copyWith(
                                      color:
                                          AppTheme
                                              .lightTheme
                                              .colorScheme
                                              .onSurface,
                                      fontWeight: FontWeight.w500,
                                    ),
                              ),
                              SizedBox(width: 2.w),
                              Text(
                                '(${agent['location_count'] ?? 0} branches)',
                                style: AppTheme.lightTheme.textTheme.bodySmall
                                    ?.copyWith(
                                      color:
                                          AppTheme
                                              .lightTheme
                                              .colorScheme
                                              .onSurfaceVariant,
                                    ),
                              ),
                            ],
                          ),

                          SizedBox(height: 1.h),

                          // Response time
                          Container(
                            padding: EdgeInsets.symmetric(
                              horizontal: 2.w,
                              vertical: 0.5.h,
                            ),
                            decoration: BoxDecoration(
                              color:
                                  isOnline
                                      ? AppTheme.getSuccessColor(
                                        true,
                                      ).withValues(alpha: 0.1)
                                      : AppTheme
                                          .lightTheme
                                          .colorScheme
                                          .onSurfaceVariant
                                          .withValues(alpha: 0.1),
                              borderRadius: BorderRadius.circular(1.w),
                            ),
                            child: Text(
                              isOnline
                                  ? agent['response_time'] ?? '< 5 min'
                                  : 'Offline',
                              style: AppTheme.lightTheme.textTheme.bodySmall
                                  ?.copyWith(
                                    color:
                                        isOnline
                                            ? AppTheme.getSuccessColor(true)
                                            : AppTheme
                                                .lightTheme
                                                .colorScheme
                                                .onSurfaceVariant,
                                    fontWeight: FontWeight.w500,
                                  ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  );
                },
              ),
            ),
          ],

          // View all agents button
          if (_agents.isNotEmpty) ...[
            SizedBox(height: 2.h),
            Center(
              child: TextButton.icon(
                onPressed:
                    () => Navigator.pushNamed(context, '/agent-selection'),
                icon: CustomIconWidget(
                  iconName: 'people',
                  color: AppTheme.lightTheme.primaryColor,
                  size: 5.w,
                ),
                label: Text(
                  'View All Agents',
                  style: AppTheme.lightTheme.textTheme.bodyMedium?.copyWith(
                    color: AppTheme.lightTheme.primaryColor,
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ),
            ),
          ],
        ],
      ),
    );
  }
}
