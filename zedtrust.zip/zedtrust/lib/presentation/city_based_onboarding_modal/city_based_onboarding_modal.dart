import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';
import 'package:google_fonts/google_fonts.dart';

import '../../core/services/supabase_service.dart';
import './widgets/city_selector_widget.dart';
import './widgets/community_stats_widget.dart';
import './widgets/location_privacy_widget.dart';

class CityBasedOnboardingModal extends StatefulWidget {
  const CityBasedOnboardingModal({super.key});

  @override
  State<CityBasedOnboardingModal> createState() =>
      _CityBasedOnboardingModalState();
}

class _CityBasedOnboardingModalState extends State<CityBasedOnboardingModal>
    with TickerProviderStateMixin {
  late AnimationController _slideController;
  late AnimationController _fadeController;
  late Animation<Offset> _slideAnimation;
  late Animation<double> _fadeAnimation;

  String? _selectedCity;
  bool _isLoading = false;
  bool _showGpsOption = true;

  final List<Map<String, dynamic>> _majorCities = [
    {'name': 'Mumbai', 'population': '20M+', 'traders': 1247},
    {'name': 'Delhi', 'population': '32M+', 'traders': 892},
    {'name': 'Bangalore', 'population': '13M+', 'traders': 654},
    {'name': 'Chennai', 'population': '11M+', 'traders': 423},
    {'name': 'Kolkata', 'population': '15M+', 'traders': 387},
    {'name': 'Hyderabad', 'population': '10M+', 'traders': 321},
    {'name': 'Pune', 'population': '7M+', 'traders': 298},
    {'name': 'Ahmedabad', 'population': '8M+', 'traders': 276},
    {'name': 'Surat', 'population': '6M+', 'traders': 189},
    {'name': 'Jaipur', 'population': '4M+', 'traders': 145},
  ];

  @override
  void initState() {
    super.initState();
    _setupAnimations();
    _startAnimations();
  }

  @override
  void dispose() {
    _slideController.dispose();
    _fadeController.dispose();
    super.dispose();
  }

  void _setupAnimations() {
    _slideController = AnimationController(
      duration: const Duration(milliseconds: 800),
      vsync: this,
    );

    _fadeController = AnimationController(
      duration: const Duration(milliseconds: 600),
      vsync: this,
    );

    _slideAnimation = Tween<Offset>(
      begin: const Offset(0, 1),
      end: Offset.zero,
    ).animate(CurvedAnimation(
      parent: _slideController,
      curve: Curves.easeOutCubic,
    ));

    _fadeAnimation = Tween<double>(
      begin: 0,
      end: 1,
    ).animate(CurvedAnimation(
      parent: _fadeController,
      curve: Curves.easeInOut,
    ));
  }

  void _startAnimations() {
    _slideController.forward();
    _fadeController.forward();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black.withAlpha(204),
      body: SafeArea(
        child: FadeTransition(
          opacity: _fadeAnimation,
          child: SlideTransition(
            position: _slideAnimation,
            child: Center(
              child: Container(
                margin: EdgeInsets.all(4.w),
                constraints: BoxConstraints(maxHeight: 85.h),
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [Colors.grey.shade900, Colors.grey.shade800],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                  borderRadius: BorderRadius.circular(24),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withAlpha(128),
                      blurRadius: 30,
                      offset: const Offset(0, 15),
                    ),
                  ],
                ),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    _buildHeader(),
                    Expanded(child: _buildContent()),
                    _buildActions(),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildHeader() {
    return Container(
      padding: EdgeInsets.all(6.w),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [Colors.deepPurple.shade900, Colors.indigo.shade800],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: const BorderRadius.only(
          topLeft: Radius.circular(24),
          topRight: Radius.circular(24),
        ),
      ),
      child: Row(
        children: [
          Container(
            padding: EdgeInsets.all(3.w),
            decoration: BoxDecoration(
              color: Colors.white.withAlpha(51),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Icon(
              Icons.location_city,
              color: Colors.white,
              size: 8.w,
            ),
          ),
          SizedBox(width: 4.w),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Welcome to ZoTrust!',
                  style: GoogleFonts.inter(
                    fontSize: 20.sp,
                    fontWeight: FontWeight.bold,
                    color: Colors.white,
                  ),
                ),
                SizedBox(height: 1.w),
                Text(
                  'Let us help you find trusted traders in your city',
                  style: GoogleFonts.inter(
                    fontSize: 12.sp,
                    color: Colors.white70,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildContent() {
    return SingleChildScrollView(
      padding: EdgeInsets.all(6.w),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _buildWelcomeMessage(),
          SizedBox(height: 4.w),
          LocationPrivacyWidget(),
          SizedBox(height: 4.w),
          CitySelectorWidget(
            cities: _majorCities,
            selectedCity: _selectedCity,
            onCitySelected: (city) {
              setState(() {
                _selectedCity = city;
              });
            },
            showGpsOption: _showGpsOption,
            onGpsSelected: _handleGpsSelection,
          ),
          if (_selectedCity != null) ...[
            SizedBox(height: 4.w),
            CommunityStatsWidget(
              cityName: _selectedCity!,
              traderCount: _getCityTraders(_selectedCity!),
            ),
          ],
        ],
      ),
    );
  }

  Widget _buildWelcomeMessage() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Choose Your Trading Area',
          style: GoogleFonts.inter(
            fontSize: 18.sp,
            fontWeight: FontWeight.bold,
            color: Colors.white,
          ),
        ),
        SizedBox(height: 2.w),
        Text(
          'ZoTrust connects you with verified agents and trusted traders in your city. This helps ensure safe, local transactions and builds community trust.',
          style: GoogleFonts.inter(
            fontSize: 12.sp,
            color: Colors.grey.shade300,
            height: 1.5,
          ),
        ),
      ],
    );
  }

  Widget _buildActions() {
    return Container(
      padding: EdgeInsets.all(6.w),
      decoration: BoxDecoration(
        color: Colors.grey.shade800,
        borderRadius: const BorderRadius.only(
          bottomLeft: Radius.circular(24),
          bottomRight: Radius.circular(24),
        ),
      ),
      child: Column(
        children: [
          Row(
            children: [
              Expanded(
                child: _buildActionButton(
                  label: 'Skip for Now',
                  icon: Icons.skip_next,
                  color: Colors.grey.shade600,
                  onPressed: _selectedCity == null ? _handleSkip : null,
                  isOutlined: true,
                ),
              ),
              SizedBox(width: 4.w),
              Expanded(
                flex: 2,
                child: _buildActionButton(
                  label: _isLoading ? 'Setting up...' : 'Continue',
                  icon: _isLoading ? null : Icons.arrow_forward,
                  color: Colors.cyan.shade400,
                  onPressed: _selectedCity != null && !_isLoading
                      ? _handleContinue
                      : null,
                  isLoading: _isLoading,
                ),
              ),
            ],
          ),
          SizedBox(height: 3.w),
          Text(
            'You can change your city later in profile settings',
            textAlign: TextAlign.center,
            style: GoogleFonts.inter(
              fontSize: 10.sp,
              color: Colors.grey.shade400,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildActionButton({
    required String label,
    IconData? icon,
    required Color color,
    VoidCallback? onPressed,
    bool isOutlined = false,
    bool isLoading = false,
  }) {
    return GestureDetector(
      onTap: onPressed,
      child: Container(
        padding: EdgeInsets.symmetric(vertical: 4.w),
        decoration: BoxDecoration(
          color: isOutlined ? Colors.transparent : color,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(
            color: onPressed != null ? color : Colors.grey.shade600,
            width: 2,
          ),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            if (isLoading)
              SizedBox(
                width: 4.w,
                height: 4.w,
                child: CircularProgressIndicator(
                  strokeWidth: 2,
                  valueColor: AlwaysStoppedAnimation<Color>(Colors.white),
                ),
              )
            else if (icon != null)
              Icon(
                icon,
                color: onPressed != null
                    ? (isOutlined ? color : Colors.white)
                    : Colors.grey.shade600,
                size: 5.w,
              ),
            if (!isLoading && icon != null) SizedBox(width: 2.w),
            Text(
              label,
              style: GoogleFonts.inter(
                fontSize: 14.sp,
                fontWeight: FontWeight.w600,
                color: onPressed != null
                    ? (isOutlined ? color : Colors.white)
                    : Colors.grey.shade600,
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _handleGpsSelection() {
    // In a real implementation, this would use actual GPS
    // For now, we'll simulate GPS detection
    setState(() {
      _selectedCity = 'Mumbai'; // Mock GPS result
    });

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          'Location detected: Mumbai',
          style: GoogleFonts.inter(color: Colors.white),
        ),
        backgroundColor: Colors.green.shade600,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
      ),
    );
  }

  void _handleSkip() {
    Navigator.of(context).pop();
  }

  Future<void> _handleContinue() async {
    if (_selectedCity == null || _isLoading) return;

    setState(() => _isLoading = true);

    try {
      final client = SupabaseService.instance.client;
      final user = client.auth.currentUser;

      if (user != null) {
        // Update user's city in the database
        await client.from('users').update({
          'city': _selectedCity,
          'city_set_at': DateTime.now().toIso8601String(),
        }).eq('id', user.id);
      }

      // Simulate processing time
      await Future.delayed(const Duration(seconds: 1));

      if (mounted) {
        // Show success message
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(
              'City preference saved! Welcome to ZoTrust $_selectedCity community.',
              style: GoogleFonts.inter(color: Colors.white),
            ),
            backgroundColor: Colors.green.shade600,
            behavior: SnackBarBehavior.floating,
            shape:
                RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
            duration: const Duration(seconds: 3),
          ),
        );

        // Navigate back to dashboard
        Navigator.of(context).pop();
      }
    } catch (e) {
      setState(() => _isLoading = false);

      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(
              'Failed to save city preference. Please try again.',
              style: GoogleFonts.inter(color: Colors.white),
            ),
            backgroundColor: Colors.red.shade600,
            behavior: SnackBarBehavior.floating,
            shape:
                RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
          ),
        );
      }
    }
  }

  int _getCityTraders(String cityName) {
    final city = _majorCities.firstWhere((c) => c['name'] == cityName);
    return city['traders'] ?? 0;
  }
}