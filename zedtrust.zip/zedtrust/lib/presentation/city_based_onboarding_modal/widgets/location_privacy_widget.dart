import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';
import 'package:google_fonts/google_fonts.dart'; // Add this import

class LocationPrivacyWidget extends StatelessWidget {
  const LocationPrivacyWidget({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.all(4.w),
      decoration: BoxDecoration(
        color: Colors.blue.shade900.withAlpha(77),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: Colors.blue.shade600.withAlpha(128),
          width: 1,
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _buildHeader(),
          SizedBox(height: 3.w),
          _buildPrivacyPoints(),
        ],
      ),
    );
  }

  Widget _buildHeader() {
    return Row(
      children: [
        Container(
          padding: EdgeInsets.all(2.w),
          decoration: BoxDecoration(
            color: Colors.blue.shade600.withAlpha(51),
            borderRadius: BorderRadius.circular(8),
          ),
          child: Icon(
            Icons.security,
            color: Colors.blue.shade400,
            size: 5.w,
          ),
        ),
        SizedBox(width: 3.w),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'Privacy Protection',
                style: GoogleFonts.inter(
                  fontSize: 14.sp,
                  fontWeight: FontWeight.w600,
                  color: Colors.blue.shade300,
                ),
              ),
              Text(
                'Your location data is secure',
                style: GoogleFonts.inter(
                  fontSize: 10.sp,
                  color: Colors.blue.shade200,
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildPrivacyPoints() {
    final privacyPoints = [
      'Only city name is stored, not exact location',
      'Used only for agent matching and community building',
      'Your personal information stays private',
      'You can change or remove your city anytime',
    ];

    return Column(
      children:
          privacyPoints.map((point) => _buildPrivacyPoint(point)).toList(),
    );
  }

  Widget _buildPrivacyPoint(String text) {
    return Padding(
      padding: EdgeInsets.only(bottom: 2.w),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            margin: EdgeInsets.only(top: 1.w),
            width: 1.5.w,
            height: 1.5.w,
            decoration: BoxDecoration(
              color: Colors.blue.shade400,
              shape: BoxShape.circle,
            ),
          ),
          SizedBox(width: 3.w),
          Expanded(
            child: Text(
              text,
              style: GoogleFonts.inter(
                fontSize: 11.sp,
                color: Colors.blue.shade100,
                height: 1.4,
              ),
            ),
          ),
        ],
      ),
    );
  }
}