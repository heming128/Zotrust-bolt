import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../../core/app_export.dart';

class TimerWidget extends StatelessWidget {
  final int remainingSeconds;
  final VoidCallback onRefresh;

  const TimerWidget({
    Key? key,
    required this.remainingSeconds,
    required this.onRefresh,
  }) : super(key: key);

  String _formatDuration(int seconds) {
    final hours = seconds ~/ 3600;
    final minutes = (seconds % 3600) ~/ 60;
    final secs = seconds % 60;

    if (hours > 0) {
      return '${hours.toString().padLeft(2, '0')}:${minutes.toString().padLeft(2, '0')}:${secs.toString().padLeft(2, '0')}';
    } else {
      return '${minutes.toString().padLeft(2, '0')}:${secs.toString().padLeft(2, '0')}';
    }
  }

  String _getTimeLabel() {
    final hours = remainingSeconds ~/ 3600;
    if (hours > 0) {
      return 'Hours:Minutes:Seconds';
    } else {
      return 'Minutes:Seconds';
    }
  }

  @override
  Widget build(BuildContext context) {
    final isLowTime = remainingSeconds < 600; // Less than 10 minutes
    final isExpired = remainingSeconds <= 0;

    return Container(
      width: double.infinity,
      padding: EdgeInsets.all(4.w),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            isExpired
                ? Theme.of(context).colorScheme.error.withValues(alpha: 0.1)
                : isLowTime
                    ? AppTheme.getWarningColor(
                            Theme.of(context).brightness == Brightness.light)
                        .withValues(alpha: 0.1)
                    : AppTheme.getAccentColor(
                            Theme.of(context).brightness == Brightness.light)
                        .withValues(alpha: 0.1),
            isExpired
                ? Theme.of(context).colorScheme.error.withValues(alpha: 0.05)
                : isLowTime
                    ? AppTheme.getWarningColor(
                            Theme.of(context).brightness == Brightness.light)
                        .withValues(alpha: 0.05)
                    : AppTheme.getAccentColor(
                            Theme.of(context).brightness == Brightness.light)
                        .withValues(alpha: 0.05),
          ],
        ),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: isExpired
              ? Theme.of(context).colorScheme.error.withValues(alpha: 0.3)
              : isLowTime
                  ? AppTheme.getWarningColor(
                          Theme.of(context).brightness == Brightness.light)
                      .withValues(alpha: 0.3)
                  : AppTheme.getAccentColor(
                          Theme.of(context).brightness == Brightness.light)
                      .withValues(alpha: 0.3),
          width: 1.5,
        ),
      ),
      child: Column(
        children: [
          Row(
            children: [
              CustomIconWidget(
                iconName: isExpired ? 'timer_off' : 'timer',
                color: isExpired
                    ? Theme.of(context).colorScheme.error
                    : isLowTime
                        ? AppTheme.getWarningColor(
                            Theme.of(context).brightness == Brightness.light)
                        : AppTheme.getAccentColor(
                            Theme.of(context).brightness == Brightness.light),
                size: 24,
              ),
              SizedBox(width: 3.w),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      isExpired ? 'Trade Expired' : 'Time Remaining',
                      style: Theme.of(context).textTheme.titleMedium?.copyWith(
                            fontWeight: FontWeight.w600,
                            color: isExpired
                                ? Theme.of(context).colorScheme.error
                                : isLowTime
                                    ? AppTheme.getWarningColor(
                                        Theme.of(context).brightness ==
                                            Brightness.light)
                                    : AppTheme.getAccentColor(
                                        Theme.of(context).brightness ==
                                            Brightness.light),
                          ),
                    ),
                    if (!isExpired)
                      Text(
                        _getTimeLabel(),
                        style: Theme.of(context).textTheme.bodySmall?.copyWith(
                              color: Theme.of(context)
                                  .colorScheme
                                  .onSurfaceVariant,
                            ),
                      ),
                  ],
                ),
              ),
              if (remainingSeconds > 0 && remainingSeconds < 30)
                GestureDetector(
                  onTap: onRefresh,
                  child: Container(
                    padding: EdgeInsets.all(2.w),
                    decoration: BoxDecoration(
                      color: AppTheme.getAccentColor(
                              Theme.of(context).brightness == Brightness.light)
                          .withValues(alpha: 0.1),
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: CustomIconWidget(
                      iconName: 'refresh',
                      color: AppTheme.getAccentColor(
                          Theme.of(context).brightness == Brightness.light),
                      size: 20,
                    ),
                  ),
                ),
            ],
          ),
          SizedBox(height: 2.h),
          if (!isExpired) ...[
            Text(
              _formatDuration(remainingSeconds),
              style: Theme.of(context).textTheme.displayMedium?.copyWith(
                fontWeight: FontWeight.w700,
                color: isLowTime
                    ? AppTheme.getWarningColor(
                        Theme.of(context).brightness == Brightness.light)
                    : AppTheme.getAccentColor(
                        Theme.of(context).brightness == Brightness.light),
                fontFeatures: [FontFeature.tabularFigures()],
              ),
            ),
            if (isLowTime && remainingSeconds > 0) ...[
              SizedBox(height: 1.h),
              Text(
                'Hurry up! Trade will expire soon',
                style: Theme.of(context).textTheme.bodySmall?.copyWith(
                      color: AppTheme.getWarningColor(
                          Theme.of(context).brightness == Brightness.light),
                      fontWeight: FontWeight.w500,
                    ),
                textAlign: TextAlign.center,
              ),
            ],
          ] else ...[
            Text(
              'Trade time expired',
              style: Theme.of(context).textTheme.titleMedium?.copyWith(
                    color: Theme.of(context).colorScheme.error,
                    fontWeight: FontWeight.w600,
                  ),
            ),
            SizedBox(height: 1.h),
            Text(
              'The 2-hour limit has been reached. USDC has been released back to your wallet.',
              style: Theme.of(context).textTheme.bodySmall?.copyWith(
                    color: Theme.of(context).colorScheme.onSurfaceVariant,
                  ),
              textAlign: TextAlign.center,
            ),
          ],
        ],
      ),
    );
  }
}
