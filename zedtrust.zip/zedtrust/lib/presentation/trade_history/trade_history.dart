import 'dart:convert';

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';
import 'package:universal_html/html.dart' as html;

import '../../core/app_export.dart';
import './widgets/date_filter_chips_widget.dart';
import './widgets/empty_state_widget.dart';
import './widgets/filter_bottom_sheet_widget.dart';
import './widgets/skeleton_trade_card_widget.dart';
import './widgets/statistics_card_widget.dart';
import './widgets/trade_card_widget.dart';

class TradeHistory extends StatefulWidget {
  const TradeHistory({Key? key}) : super(key: key);

  @override
  State<TradeHistory> createState() => _TradeHistoryState();
}

class _TradeHistoryState extends State<TradeHistory>
    with TickerProviderStateMixin {
  final TextEditingController _searchController = TextEditingController();
  final ScrollController _scrollController = ScrollController();

  late TabController _tabController;

  List<Map<String, dynamic>> _allTrades = [];
  List<Map<String, dynamic>> _filteredTrades = [];
  Map<String, dynamic> _currentFilters = {};
  String _selectedDateFilter = 'all';
  bool _isLoading = false;
  bool _isLoadingMore = false;
  bool _hasMoreData = true;
  bool _isMultiSelectMode = false;
  Set<String> _selectedTradeIds = {};

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 3, vsync: this, initialIndex: 1);
    _loadMockData();
    _scrollController.addListener(_onScroll);
  }

  @override
  void dispose() {
    _searchController.dispose();
    _scrollController.dispose();
    _tabController.dispose();
    super.dispose();
  }

  void _loadMockData() {
    setState(() {
      _isLoading = true;
    });

    // Simulate network delay
    Future.delayed(const Duration(milliseconds: 1500), () {
      final mockTrades = [
        {
          "tradeId": "TXN001234567890",
          "type": "buy",
          "amount": "\$1,250.00 USDC",
          "counterparty": "0x742d35Cc6634C0532925a3b8D4C0532925a3b8D4",
          "status": "completed",
          "timestamp": DateTime.now().subtract(const Duration(hours: 2)),
          "agentId": "agent1",
          "agentName": "CryptoExchange Pro",
          "fiatAmount": "\$1,250.00",
          "exchangeRate": "1.00",
          "gasFee": "\$2.50",
          "blockchainTxHash":
              "0x8f4e2a1b9c3d5e7f8a2b4c6d8e0f1a3b5c7d9e1f3a5b7c9d1e3f5a7b9c1d3e5f",
        },
        {
          "tradeId": "TXN001234567891",
          "type": "sell",
          "amount": "\$850.00 USDC",
          "counterparty": "0x8f4e2a1b9c3d5e7f8a2b4c6d8e0f1a3b5c7d9e1f",
          "status": "completed",
          "timestamp": DateTime.now().subtract(const Duration(days: 1)),
          "agentId": "agent2",
          "agentName": "BlockTrade Hub",
          "fiatAmount": "\$850.00",
          "exchangeRate": "1.00",
          "gasFee": "\$1.80",
          "blockchainTxHash":
              "0x742d35Cc6634C0532925a3b8D4C0532925a3b8D4C0532925a3b8D4C0532925a3",
        },
        {
          "tradeId": "TXN001234567892",
          "type": "buy",
          "amount": "\$2,100.00 USDC",
          "counterparty": "0x1a3b5c7d9e1f3a5b7c9d1e3f5a7b9c1d3e5f7a9b",
          "status": "cancelled",
          "timestamp": DateTime.now().subtract(const Duration(days: 3)),
          "agentId": "agent3",
          "agentName": "SecureSwap Agent",
          "fiatAmount": "\$2,100.00",
          "exchangeRate": "1.00",
          "gasFee": "\$0.00",
          "blockchainTxHash": null,
        },
        {
          "tradeId": "TXN001234567893",
          "type": "sell",
          "amount": "\$500.00 USDC",
          "counterparty": "0x5a7b9c1d3e5f7a9b1c3d5e7f9a1b3c5d7e9f1a3b",
          "status": "disputed",
          "timestamp": DateTime.now().subtract(const Duration(days: 5)),
          "agentId": "agent1",
          "agentName": "CryptoExchange Pro",
          "fiatAmount": "\$500.00",
          "exchangeRate": "1.00",
          "gasFee": "\$1.25",
          "blockchainTxHash":
              "0x9e1f3a5b7c9d1e3f5a7b9c1d3e5f7a9b1c3d5e7f9a1b3c5d7e9f1a3b5c7d9e1f",
        },
        {
          "tradeId": "TXN001234567894",
          "type": "buy",
          "amount": "\$3,750.00 USDC",
          "counterparty": "0x7e9f1a3b5c7d9e1f3a5b7c9d1e3f5a7b9c1d3e5f",
          "status": "completed",
          "timestamp": DateTime.now().subtract(const Duration(days: 7)),
          "agentId": "agent4",
          "agentName": "TrustBridge",
          "fiatAmount": "\$3,750.00",
          "exchangeRate": "1.00",
          "gasFee": "\$4.20",
          "blockchainTxHash":
              "0x1c3d5e7f9a1b3c5d7e9f1a3b5c7d9e1f3a5b7c9d1e3f5a7b9c1d3e5f7a9b1c3d",
        },
        {
          "tradeId": "TXN001234567895",
          "type": "sell",
          "amount": "\$1,800.00 USDC",
          "counterparty": "0x3c5d7e9f1a3b5c7d9e1f3a5b7c9d1e3f5a7b9c1d",
          "status": "pending",
          "timestamp": DateTime.now().subtract(const Duration(minutes: 30)),
          "agentId": "agent2",
          "agentName": "BlockTrade Hub",
          "fiatAmount": "\$1,800.00",
          "exchangeRate": "1.00",
          "gasFee": "\$2.10",
          "blockchainTxHash": null,
        },
      ];

      setState(() {
        _allTrades = mockTrades;
        _filteredTrades = List.from(_allTrades);
        _isLoading = false;
      });
    });
  }

  void _onScroll() {
    if (_scrollController.position.pixels >=
        _scrollController.position.maxScrollExtent - 200) {
      if (!_isLoadingMore && _hasMoreData) {
        _loadMoreTrades();
      }
    }
  }

  void _loadMoreTrades() {
    setState(() {
      _isLoadingMore = true;
    });

    // Simulate loading more data
    Future.delayed(const Duration(milliseconds: 1000), () {
      setState(() {
        _isLoadingMore = false;
        _hasMoreData = false; // No more data for demo
      });
    });
  }

  void _onSearchChanged(String query) {
    setState(() {
      if (query.isEmpty) {
        _filteredTrades = List.from(_allTrades);
      } else {
        _filteredTrades = _allTrades.where((trade) {
          final tradeId = (trade['tradeId'] as String).toLowerCase();
          final amount = (trade['amount'] as String).toLowerCase();
          final counterparty = (trade['counterparty'] as String).toLowerCase();
          final searchQuery = query.toLowerCase();

          return tradeId.contains(searchQuery) ||
              amount.contains(searchQuery) ||
              counterparty.contains(searchQuery);
        }).toList();
      }
    });
  }

  void _onDateFilterChanged(String filter) {
    setState(() {
      _selectedDateFilter = filter;
      _applyDateFilter();
    });
  }

  void _applyDateFilter() {
    final now = DateTime.now();
    DateTime? startDate;

    switch (_selectedDateFilter) {
      case 'today':
        startDate = DateTime(now.year, now.month, now.day);
        break;
      case 'week':
        startDate = now.subtract(const Duration(days: 7));
        break;
      case 'month':
        startDate = DateTime(now.year, now.month - 1, now.day);
        break;
      case 'all':
      default:
        startDate = null;
        break;
    }

    setState(() {
      if (startDate == null) {
        _filteredTrades = List.from(_allTrades);
      } else {
        _filteredTrades = _allTrades.where((trade) {
          final timestamp = trade['timestamp'] as DateTime;
          return timestamp.isAfter(startDate!);
        }).toList();
      }
    });
  }

  void _showFilterBottomSheet() {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) => FilterBottomSheetWidget(
        currentFilters: _currentFilters,
        onFiltersApplied: _applyFilters,
      ),
    );
  }

  void _applyFilters(Map<String, dynamic> filters) {
    setState(() {
      _currentFilters = filters;
      _filteredTrades = _allTrades.where((trade) {
        // Status filter
        if (filters['status'] != null &&
            trade['status'] != filters['status'].toLowerCase()) {
          return false;
        }

        // Amount range filter
        if (filters['minAmount'] != null || filters['maxAmount'] != null) {
          final amountStr =
              (trade['amount'] as String).replaceAll(RegExp(r'[^\d.]'), '');
          final amount = double.tryParse(amountStr) ?? 0;

          if (filters['minAmount'] != null && amount < filters['minAmount']) {
            return false;
          }
          if (filters['maxAmount'] != null && amount > filters['maxAmount']) {
            return false;
          }
        }

        // Date range filter
        if (filters['startDate'] != null || filters['endDate'] != null) {
          final timestamp = trade['timestamp'] as DateTime;

          if (filters['startDate'] != null &&
              timestamp.isBefore(filters['startDate'])) {
            return false;
          }
          if (filters['endDate'] != null &&
              timestamp.isAfter(filters['endDate'])) {
            return false;
          }
        }

        // Agent filter
        if (filters['agentId'] != null &&
            trade['agentId'] != filters['agentId']) {
          return false;
        }

        return true;
      }).toList();
    });
  }

  Future<void> _onRefresh() async {
    await Future.delayed(const Duration(milliseconds: 1000));
    _loadMockData();
  }

  void _exportTrades() async {
    final csvContent = _generateCSVContent();
    final filename =
        'trade_history_${DateTime.now().millisecondsSinceEpoch}.csv';

    if (kIsWeb) {
      final bytes = utf8.encode(csvContent);
      final blob = html.Blob([bytes]);
      final url = html.Url.createObjectUrlFromBlob(blob);
      final anchor = html.AnchorElement(href: url)
        ..setAttribute("download", filename)
        ..click();
      html.Url.revokeObjectUrl(url);
    } else {
      // For mobile platforms, you would typically use a file picker or share dialog
      // This is a simplified implementation
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Export functionality available on mobile'),
          action: SnackBarAction(
            label: 'OK',
            onPressed: () {},
          ),
        ),
      );
    }
  }

  String _generateCSVContent() {
    final header =
        'Trade ID,Type,Amount,Counterparty,Status,Date,Agent,Gas Fee\n';
    final rows = _filteredTrades.map((trade) {
      return '${trade['tradeId']},${trade['type']},${trade['amount']},${trade['counterparty']},${trade['status']},${trade['timestamp']},${trade['agentName']},${trade['gasFee'] ?? 'N/A'}';
    }).join('\n');

    return header + rows;
  }

  void _toggleMultiSelectMode() {
    setState(() {
      _isMultiSelectMode = !_isMultiSelectMode;
      if (!_isMultiSelectMode) {
        _selectedTradeIds.clear();
      }
    });
  }

  void _toggleTradeSelection(String tradeId) {
    setState(() {
      if (_selectedTradeIds.contains(tradeId)) {
        _selectedTradeIds.remove(tradeId);
      } else {
        _selectedTradeIds.add(tradeId);
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.lightTheme.scaffoldBackgroundColor,
      appBar: _buildAppBar(),
      body: Column(
        children: [
          _buildTabBar(),
          Expanded(
            child: TabBarView(
              controller: _tabController,
              children: [
                _buildPlaceholderTab('Dashboard'),
                _buildHistoryTab(),
                _buildPlaceholderTab('Analytics'),
              ],
            ),
          ),
        ],
      ),
    );
  }

  PreferredSizeWidget _buildAppBar() {
    return AppBar(
      title: _isMultiSelectMode
          ? Text('${_selectedTradeIds.length} selected')
          : TextField(
              controller: _searchController,
              decoration: InputDecoration(
                hintText: 'Search trades, amounts, addresses...',
                border: InputBorder.none,
                hintStyle: AppTheme.lightTheme.textTheme.bodyMedium?.copyWith(
                  color: AppTheme.lightTheme.colorScheme.onSurfaceVariant,
                ),
              ),
              style: AppTheme.lightTheme.textTheme.bodyMedium,
              onChanged: _onSearchChanged,
            ),
      leading: _isMultiSelectMode
          ? IconButton(
              onPressed: _toggleMultiSelectMode,
              icon: CustomIconWidget(
                iconName: 'close',
                color: AppTheme.lightTheme.colorScheme.onSurface,
                size: 24,
              ),
            )
          : null,
      actions: [
        if (_isMultiSelectMode) ...[
          if (_selectedTradeIds.isNotEmpty)
            IconButton(
              onPressed: _exportTrades,
              icon: CustomIconWidget(
                iconName: 'download',
                color: AppTheme.lightTheme.colorScheme.primary,
                size: 24,
              ),
            ),
        ] else ...[
          IconButton(
            onPressed: _showFilterBottomSheet,
            icon: CustomIconWidget(
              iconName: 'filter_list',
              color: _currentFilters.isNotEmpty
                  ? AppTheme.lightTheme.colorScheme.primary
                  : AppTheme.lightTheme.colorScheme.onSurfaceVariant,
              size: 24,
            ),
          ),
          PopupMenuButton<String>(
            onSelected: (value) {
              switch (value) {
                case 'export':
                  _exportTrades();
                  break;
                case 'multi_select':
                  _toggleMultiSelectMode();
                  break;
              }
            },
            itemBuilder: (context) => [
              PopupMenuItem(
                value: 'export',
                child: Row(
                  children: [
                    CustomIconWidget(
                      iconName: 'download',
                      color: AppTheme.lightTheme.colorScheme.onSurface,
                      size: 20,
                    ),
                    SizedBox(width: 3.w),
                    Text('Export CSV'),
                  ],
                ),
              ),
              PopupMenuItem(
                value: 'multi_select',
                child: Row(
                  children: [
                    CustomIconWidget(
                      iconName: 'checklist',
                      color: AppTheme.lightTheme.colorScheme.onSurface,
                      size: 20,
                    ),
                    SizedBox(width: 3.w),
                    Text('Multi Select'),
                  ],
                ),
              ),
            ],
          ),
        ],
      ],
    );
  }

  Widget _buildTabBar() {
    return Container(
      decoration: BoxDecoration(
        border: Border(
          bottom: BorderSide(
            color:
                AppTheme.lightTheme.colorScheme.outline.withValues(alpha: 0.2),
          ),
        ),
      ),
      child: TabBar(
        controller: _tabController,
        tabs: const [
          Tab(text: 'Dashboard'),
          Tab(text: 'History'),
          Tab(text: 'Analytics'),
        ],
      ),
    );
  }

  Widget _buildHistoryTab() {
    return Column(
      children: [
        DateFilterChipsWidget(
          selectedFilter: _selectedDateFilter,
          onFilterSelected: _onDateFilterChanged,
        ),
        SizedBox(height: 1.h),
        Expanded(
          child: _isLoading
              ? _buildLoadingState()
              : _filteredTrades.isEmpty
                  ? _buildEmptyState()
                  : _buildTradesList(),
        ),
      ],
    );
  }

  Widget _buildLoadingState() {
    return ListView.builder(
      padding: EdgeInsets.symmetric(vertical: 2.h),
      itemCount: 5,
      itemBuilder: (context, index) => const SkeletonTradeCardWidget(),
    );
  }

  Widget _buildEmptyState() {
    return _allTrades.isEmpty
        ? EmptyStateWidget(
            onStartTrading: () {
              Navigator.pushNamed(context, '/create-trade');
            },
          )
        : Center(
            child: Padding(
              padding: EdgeInsets.all(8.w),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  CustomIconWidget(
                    iconName: 'search_off',
                    color: AppTheme.lightTheme.colorScheme.onSurfaceVariant,
                    size: 48,
                  ),
                  SizedBox(height: 2.h),
                  Text(
                    'No trades found',
                    style: AppTheme.lightTheme.textTheme.titleMedium?.copyWith(
                      color: AppTheme.lightTheme.colorScheme.onSurfaceVariant,
                    ),
                  ),
                  SizedBox(height: 1.h),
                  Text(
                    'Try adjusting your search or filters',
                    style: AppTheme.lightTheme.textTheme.bodyMedium?.copyWith(
                      color: AppTheme.lightTheme.colorScheme.onSurfaceVariant,
                    ),
                  ),
                ],
              ),
            ),
          );
  }

  Widget _buildTradesList() {
    return RefreshIndicator(
      onRefresh: _onRefresh,
      child: ListView.builder(
        controller: _scrollController,
        padding: EdgeInsets.symmetric(vertical: 2.h),
        itemCount: _filteredTrades.length +
            (_allTrades.isNotEmpty ? 1 : 0) + // Statistics card
            (_isLoadingMore ? 1 : 0), // Loading indicator
        itemBuilder: (context, index) {
          if (index == 0 && _allTrades.isNotEmpty) {
            return StatisticsCardWidget(
              statistics: {
                'totalVolume': '\$8,250.00',
                'successRate': 83.3,
                'totalTrades': 6,
                'favoriteAgent': 'CryptoExchange Pro',
              },
            );
          }

          final tradeIndex = _allTrades.isNotEmpty ? index - 1 : index;

          if (tradeIndex >= _filteredTrades.length) {
            return _isLoadingMore
                ? Padding(
                    padding: EdgeInsets.all(4.w),
                    child: const Center(child: CircularProgressIndicator()),
                  )
                : const SizedBox.shrink();
          }

          final trade = _filteredTrades[tradeIndex];
          final tradeId = trade['tradeId'] as String;
          final isSelected = _selectedTradeIds.contains(tradeId);

          return _isMultiSelectMode
              ? InkWell(
                  onTap: () => _toggleTradeSelection(tradeId),
                  child: Container(
                    margin:
                        EdgeInsets.symmetric(horizontal: 4.w, vertical: 1.h),
                    decoration: BoxDecoration(
                      border: Border.all(
                        color: isSelected
                            ? AppTheme.lightTheme.colorScheme.primary
                            : Colors.transparent,
                        width: 2,
                      ),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Stack(
                      children: [
                        TradeCardWidget(
                          trade: trade,
                          onTap: () => _toggleTradeSelection(tradeId),
                        ),
                        if (isSelected)
                          Positioned(
                            top: 2.w,
                            right: 2.w,
                            child: Container(
                              padding: EdgeInsets.all(1.w),
                              decoration: BoxDecoration(
                                color: AppTheme.lightTheme.colorScheme.primary,
                                shape: BoxShape.circle,
                              ),
                              child: CustomIconWidget(
                                iconName: 'check',
                                color: Colors.white,
                                size: 16,
                              ),
                            ),
                          ),
                      ],
                    ),
                  ),
                )
              : TradeCardWidget(
                  trade: trade,
                  onTap: () {
                    Navigator.pushNamed(context, '/trade-details',
                        arguments: trade);
                  },
                  onViewReceipt: () {
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(
                          content:
                              Text('Viewing receipt for ${trade['tradeId']}')),
                    );
                  },
                  onShareTransaction: () {
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(
                          content:
                              Text('Sharing transaction ${trade['tradeId']}')),
                    );
                  },
                  onReportIssue: () {
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(
                          content:
                              Text('Reporting issue for ${trade['tradeId']}')),
                    );
                  },
                );
        },
      ),
    );
  }

  Widget _buildPlaceholderTab(String tabName) {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          CustomIconWidget(
            iconName: 'construction',
            color: AppTheme.lightTheme.colorScheme.onSurfaceVariant,
            size: 48,
          ),
          SizedBox(height: 2.h),
          Text(
            '$tabName Coming Soon',
            style: AppTheme.lightTheme.textTheme.titleMedium?.copyWith(
              color: AppTheme.lightTheme.colorScheme.onSurfaceVariant,
            ),
          ),
        ],
      ),
    );
  }
}
