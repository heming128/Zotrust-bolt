import 'package:flutter/material.dart';
import 'package:flutter/foundation.dart';
import 'package:google_fonts/google_fonts.dart';
import '../../core/app_export.dart';
import '../../routes/app_routes.dart';
import '../../core/services/supabase_service.dart';

class AdminAuthenticationPortal extends StatefulWidget {
  const AdminAuthenticationPortal({Key? key}) : super(key: key);

  @override
  State<AdminAuthenticationPortal> createState() =>
      _AdminAuthenticationPortalState();
}

class _AdminAuthenticationPortalState extends State<AdminAuthenticationPortal> {
  final _formKey = GlobalKey<FormState>();
  final _usernameController = TextEditingController();
  final _passwordController = TextEditingController();
  final _otpController = TextEditingController();

  bool _isPasswordVisible = false;
  bool _isLoading = false;
  bool _showOTP = false;
  bool _rememberDevice = false;
  bool _biometricAvailable = false;

  String? _lastLoginIP = '192.168.1.100';
  DateTime? _lastLoginTime = DateTime.now().subtract(const Duration(hours: 2));
  int _failedAttempts = 0;

  @override
  void initState() {
    super.initState();
    _checkBiometricAvailability();
    _loadLastLoginInfo();
  }

  Future<void> _checkBiometricAvailability() async {
    // Check if biometric authentication is available
    setState(() {
      _biometricAvailable = !kIsWeb; // Available on mobile platforms
    });
  }

  void _loadLastLoginInfo() {
    // Load last login information from secure storage
    setState(() {
      _lastLoginIP = '192.168.1.100';
      _lastLoginTime = DateTime.now().subtract(const Duration(hours: 2));
      _failedAttempts = 0;
    });
  }

  Future<void> _authenticate() async {
    if (!_formKey.currentState!.validate()) return;

    setState(() {
      _isLoading = true;
    });

    try {
      // Validate admin domain
      if (!_usernameController.text.contains('@zedtrust.com')) {
        throw Exception('Admin access requires @zedtrust.com domain');
      }

      // Authenticate with Supabase
      final response =
          await SupabaseService.instance.client.auth.signInWithPassword(
        email: _usernameController.text.trim(),
        password: _passwordController.text,
      );

      if (response.user != null) {
        // Check if user has admin role
        final userMetadata = response.user!.userMetadata ?? {};
        final appMetadata = response.user!.appMetadata ?? {};

        final isAdmin =
            userMetadata['role'] == 'admin' || appMetadata['role'] == 'admin';

        if (isAdmin) {
          // Show 2FA if enabled
          setState(() {
            _showOTP = true;
            _isLoading = false;
          });
        } else {
          throw Exception('Insufficient privileges for admin access');
        }
      }
    } catch (e) {
      setState(() {
        _isLoading = false;
        _failedAttempts++;
      });

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Authentication failed: ${e.toString()}'),
          backgroundColor: Colors.red[700],
        ),
      );
    }
  }

  Future<void> _verifyOTP() async {
    if (_otpController.text.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please enter OTP code')),
      );
      return;
    }

    setState(() {
      _isLoading = true;
    });

    try {
      // Simulate OTP verification (in real app, verify with backend)
      await Future.delayed(const Duration(seconds: 2));

      if (_otpController.text == '123456') {
        // Success - navigate to admin dashboard
        if (mounted) {
          Navigator.pushReplacementNamed(
            context,
            AppRoutes.adminDashboard,
            arguments: {
              'user': SupabaseService.instance.client.auth.currentUser,
              'loginTime': DateTime.now(),
            },
          );
        }
      } else {
        throw Exception('Invalid OTP code');
      }
    } catch (e) {
      setState(() {
        _isLoading = false;
        _failedAttempts++;
      });

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('OTP verification failed: ${e.toString()}'),
          backgroundColor: Colors.red[700],
        ),
      );
    }
  }

  Future<void> _authenticateWithBiometric() async {
    if (!_biometricAvailable) return;

    try {
      // Simulate biometric authentication
      setState(() {
        _isLoading = true;
      });

      await Future.delayed(const Duration(seconds: 1));

      // Navigate directly to admin dashboard
      if (mounted) {
        Navigator.pushReplacementNamed(
          context,
          AppRoutes.adminDashboard,
        );
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Biometric authentication failed: ${e.toString()}'),
          backgroundColor: Colors.red[700],
        ),
      );
    } finally {
      setState(() {
        _isLoading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0A0E27),
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(24),
            child: Container(
              constraints: const BoxConstraints(maxWidth: 400),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  // Admin Logo and Header
                  _buildHeader(),
                  const SizedBox(height: 40),

                  // Authentication Form
                  if (!_showOTP) _buildLoginForm() else _buildOTPForm(),

                  const SizedBox(height: 24),

                  // Security Features
                  _buildSecurityFeatures(),

                  const SizedBox(height: 32),

                  // Biometric Authentication
                  if (_biometricAvailable && !_showOTP) _buildBiometricAuth(),

                  const SizedBox(height: 24),

                  // Security Notices
                  _buildSecurityNotices(),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildHeader() {
    return Column(
      children: [
        Container(
          width: 80,
          height: 80,
          decoration: BoxDecoration(
            color: const Color(0xFF1E40AF),
            borderRadius: BorderRadius.circular(20),
            boxShadow: [
              BoxShadow(
                color: const Color(0xFF1E40AF).withAlpha(77),
                blurRadius: 20,
                offset: const Offset(0, 8),
              ),
            ],
          ),
          child: const Icon(
            Icons.admin_panel_settings,
            color: Colors.white,
            size: 40,
          ),
        ),
        const SizedBox(height: 16),
        Text(
          'Administrative Access',
          style: GoogleFonts.inter(
            fontSize: 28,
            fontWeight: FontWeight.bold,
            color: Colors.white,
          ),
        ),
        const SizedBox(height: 8),
        Text(
          'Secure portal for system administrators',
          style: GoogleFonts.inter(
            fontSize: 14,
            color: Colors.grey[400],
          ),
        ),
      ],
    );
  }

  Widget _buildLoginForm() {
    return Form(
      key: _formKey,
      child: Column(
        children: [
          // Username/Email Field
          Container(
            decoration: BoxDecoration(
              color: const Color(0xFF1A1F3A),
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: const Color(0xFF2D3748)),
            ),
            child: TextFormField(
              controller: _usernameController,
              style: GoogleFonts.inter(color: Colors.white),
              decoration: InputDecoration(
                labelText: 'Admin Email',
                labelStyle: GoogleFonts.inter(color: Colors.grey[400]),
                hintText: 'admin@zedtrust.com',
                hintStyle: GoogleFonts.inter(color: Colors.grey[600]),
                prefixIcon: const Icon(Icons.person, color: Color(0xFF6B7280)),
                border: InputBorder.none,
                contentPadding: const EdgeInsets.all(16),
              ),
              validator: (value) {
                if (value?.isEmpty ?? true) return 'Email is required';
                if (!value!.contains('@zedtrust.com')) {
                  return 'Admin access requires @zedtrust.com domain';
                }
                return null;
              },
              keyboardType: TextInputType.emailAddress,
            ),
          ),

          const SizedBox(height: 16),

          // Password Field
          Container(
            decoration: BoxDecoration(
              color: const Color(0xFF1A1F3A),
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: const Color(0xFF2D3748)),
            ),
            child: TextFormField(
              controller: _passwordController,
              style: GoogleFonts.inter(color: Colors.white),
              obscureText: !_isPasswordVisible,
              decoration: InputDecoration(
                labelText: 'Password',
                labelStyle: GoogleFonts.inter(color: Colors.grey[400]),
                prefixIcon: const Icon(Icons.lock, color: Color(0xFF6B7280)),
                suffixIcon: IconButton(
                  icon: Icon(
                    _isPasswordVisible
                        ? Icons.visibility_off
                        : Icons.visibility,
                    color: const Color(0xFF6B7280),
                  ),
                  onPressed: () {
                    setState(() {
                      _isPasswordVisible = !_isPasswordVisible;
                    });
                  },
                ),
                border: InputBorder.none,
                contentPadding: const EdgeInsets.all(16),
              ),
              validator: (value) {
                if (value?.isEmpty ?? true) return 'Password is required';
                if (value!.length < 6)
                  return 'Password must be at least 6 characters';
                return null;
              },
            ),
          ),

          const SizedBox(height: 24),

          // Authenticate Button
          SizedBox(
            width: double.infinity,
            height: 50,
            child: ElevatedButton(
              onPressed: _isLoading ? null : _authenticate,
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFF1E40AF),
                foregroundColor: Colors.white,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
                elevation: 0,
              ),
              child: _isLoading
                  ? const SizedBox(
                      width: 20,
                      height: 20,
                      child: CircularProgressIndicator(
                        strokeWidth: 2,
                        valueColor: AlwaysStoppedAnimation<Color>(Colors.white),
                      ),
                    )
                  : Text(
                      'Authenticate',
                      style: GoogleFonts.inter(
                        fontSize: 16,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildOTPForm() {
    return Column(
      children: [
        Container(
          padding: const EdgeInsets.all(20),
          decoration: BoxDecoration(
            color: const Color(0xFF1A1F3A),
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: const Color(0xFF2D3748)),
          ),
          child: Column(
            children: [
              const Icon(
                Icons.qr_code,
                color: Color(0xFF1E40AF),
                size: 60,
              ),
              const SizedBox(height: 16),
              Text(
                'Two-Factor Authentication',
                style: GoogleFonts.inter(
                  fontSize: 16,
                  fontWeight: FontWeight.w600,
                  color: Colors.white,
                ),
              ),
              const SizedBox(height: 8),
              Text(
                'Enter the code from your authenticator app',
                style: GoogleFonts.inter(
                  fontSize: 12,
                  color: Colors.grey[400],
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 16),
        Container(
          decoration: BoxDecoration(
            color: const Color(0xFF1A1F3A),
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: const Color(0xFF2D3748)),
          ),
          child: TextFormField(
            controller: _otpController,
            style: GoogleFonts.inter(
              color: Colors.white,
              fontSize: 18,
              letterSpacing: 4,
            ),
            textAlign: TextAlign.center,
            decoration: InputDecoration(
              labelText: '6-Digit Code',
              labelStyle: GoogleFonts.inter(color: Colors.grey[400]),
              hintText: '000000',
              hintStyle: GoogleFonts.inter(color: Colors.grey[600]),
              border: InputBorder.none,
              contentPadding: const EdgeInsets.all(16),
            ),
            keyboardType: TextInputType.number,
            maxLength: 6,
            buildCounter: (context,
                    {required currentLength, required isFocused, maxLength}) =>
                null,
          ),
        ),
        const SizedBox(height: 24),
        SizedBox(
          width: double.infinity,
          height: 50,
          child: ElevatedButton(
            onPressed: _isLoading ? null : _verifyOTP,
            style: ElevatedButton.styleFrom(
              backgroundColor: const Color(0xFF059669),
              foregroundColor: Colors.white,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12),
              ),
              elevation: 0,
            ),
            child: _isLoading
                ? const SizedBox(
                    width: 20,
                    height: 20,
                    child: CircularProgressIndicator(
                      strokeWidth: 2,
                      valueColor: AlwaysStoppedAnimation<Color>(Colors.white),
                    ),
                  )
                : Text(
                    'Verify & Continue',
                    style: GoogleFonts.inter(
                      fontSize: 16,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
          ),
        ),
      ],
    );
  }

  Widget _buildSecurityFeatures() {
    return Column(
      children: [
        // Failed Attempts Monitor
        if (_failedAttempts > 0)
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: Colors.red[900]?.withAlpha(77),
              borderRadius: BorderRadius.circular(8),
              border: Border.all(color: Colors.red[700]!),
            ),
            child: Row(
              children: [
                Icon(Icons.warning, color: Colors.red[400], size: 16),
                const SizedBox(width: 8),
                Expanded(
                  child: Text(
                    'Failed attempts: $_failedAttempts',
                    style: GoogleFonts.inter(
                      fontSize: 12,
                      color: Colors.red[400],
                    ),
                  ),
                ),
              ],
            ),
          ),

        if (_failedAttempts > 0) const SizedBox(height: 16),

        // Remember Device
        Row(
          children: [
            Checkbox(
              value: _rememberDevice,
              onChanged: (value) {
                setState(() {
                  _rememberDevice = value ?? false;
                });
              },
              activeColor: const Color(0xFF1E40AF),
            ),
            Expanded(
              child: Text(
                'Remember this device for 30 days',
                style: GoogleFonts.inter(
                  fontSize: 12,
                  color: Colors.grey[400],
                ),
              ),
            ),
          ],
        ),
      ],
    );
  }

  Widget _buildBiometricAuth() {
    return Column(
      children: [
        const Divider(color: Color(0xFF2D3748)),
        const SizedBox(height: 16),
        SizedBox(
          width: double.infinity,
          height: 50,
          child: OutlinedButton.icon(
            onPressed: _isLoading ? null : _authenticateWithBiometric,
            icon: Icon(
              kIsWeb ? Icons.fingerprint : Icons.face,
              color: const Color(0xFF1E40AF),
            ),
            label: Text(
              kIsWeb ? 'Use Fingerprint' : 'Use Face ID / Touch ID',
              style: GoogleFonts.inter(
                fontSize: 14,
                fontWeight: FontWeight.w500,
                color: const Color(0xFF1E40AF),
              ),
            ),
            style: OutlinedButton.styleFrom(
              side: const BorderSide(color: Color(0xFF1E40AF)),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12),
              ),
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildSecurityNotices() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: const Color(0xFF1A1F3A),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: const Color(0xFF2D3748)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Security Information',
            style: GoogleFonts.inter(
              fontSize: 14,
              fontWeight: FontWeight.w600,
              color: Colors.white,
            ),
          ),
          const SizedBox(height: 12),
          if (_lastLoginTime != null)
            Row(
              children: [
                Icon(Icons.schedule, color: Colors.grey[400], size: 16),
                const SizedBox(width: 8),
                Text(
                  'Last login: ${_lastLoginTime!.day}/${_lastLoginTime!.month}/${_lastLoginTime!.year} at ${_lastLoginTime!.hour}:${_lastLoginTime!.minute.toString().padLeft(2, '0')}',
                  style: GoogleFonts.inter(
                    fontSize: 12,
                    color: Colors.grey[400],
                  ),
                ),
              ],
            ),
          const SizedBox(height: 8),
          if (_lastLoginIP != null)
            Row(
              children: [
                Icon(Icons.location_on, color: Colors.grey[400], size: 16),
                const SizedBox(width: 8),
                Text(
                  'Last IP: $_lastLoginIP',
                  style: GoogleFonts.inter(
                    fontSize: 12,
                    color: Colors.grey[400],
                  ),
                ),
              ],
            ),
        ],
      ),
    );
  }

  @override
  void dispose() {
    _usernameController.dispose();
    _passwordController.dispose();
    _otpController.dispose();
    super.dispose();
  }
}
