// ... keep existing imports ...
import '../../../services/call_service.dart';

class CallQualityIndicatorWidget extends StatefulWidget {
  final CallState callState;

  const CallQualityIndicatorWidget({Key? key, required this.callState})
    : super(key: key);

  @override
  State<CallQualityIndicatorWidget> createState() =>
      _CallQualityIndicatorWidgetState();
}

class _CallQualityIndicatorWidgetState extends State<CallQualityIndicatorWidget>
    with TickerProviderStateMixin {
  late AnimationController _animationController;
  late Animation<double> _animation;

  // Simulated signal strength (in real app, get from WebRTC stats)
  int _signalStrength = 3; // 0-4 bars

  @override
  void initState() {
    super.initState();
    _animationController = AnimationController(
      duration: const Duration(seconds: 2),
      vsync: this,
    );

    _animation = Tween<double>(begin: 0.5, end: 1.0).animate(
      CurvedAnimation(parent: _animationController, curve: Curves.easeInOut),
    );

    if (widget.callState == CallState.connected) {
      _animationController.repeat(reverse: true);
      _simulateSignalChanges();
    }
  }

  void _simulateSignalChanges() {
    // Simulate signal strength changes for demo
    Timer.periodic(const Duration(seconds: 5), (timer) {
      if (mounted && widget.callState == CallState.connected) {
        setState(() {
          _signalStrength =
              (1 + (DateTime.now().millisecondsSinceEpoch ~/ 5000) % 4);
        });
      } else {
        timer.cancel();
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    if (widget.callState != CallState.connected) {
      return const SizedBox.shrink();
    }

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      decoration: BoxDecoration(
        color: Colors.black26,
        borderRadius: BorderRadius.circular(20),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          _buildSignalBars(),
          const SizedBox(width: 8),
          Text(
            _getQualityText(),
            style: const TextStyle(color: Colors.white70, fontSize: 12),
          ),
        ],
      ),
    );
  }

  Widget _buildSignalBars() {
    return Row(
      children: List.generate(4, (index) {
        return Container(
          width: 3,
          height: 8 + (index * 2),
          margin: const EdgeInsets.only(right: 2),
          decoration: BoxDecoration(
            color:
                index < _signalStrength ? _getSignalColor() : Colors.grey[600],
            borderRadius: BorderRadius.circular(1),
          ),
        );
      }),
    );
  }

  Color _getSignalColor() {
    if (_signalStrength >= 3) return Colors.green;
    if (_signalStrength >= 2) return Colors.orange;
    return Colors.red;
  }

  String _getQualityText() {
    switch (_signalStrength) {
      case 4:
        return 'Excellent';
      case 3:
        return 'Good';
      case 2:
        return 'Fair';
      case 1:
        return 'Poor';
      default:
        return 'No Signal';
    }
  }

  @override
  void dispose() {
    _animationController.dispose();
    super.dispose();
  }
}
