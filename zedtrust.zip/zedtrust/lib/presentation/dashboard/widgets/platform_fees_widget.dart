import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';
import '../../../core/services/trade_fee_logic_service.dart';

class PlatformFeesWidget extends StatelessWidget {
  final double amount;
  final String role; // 'buyer' or 'seller'
  final bool isExpanded;
  final VoidCallback? onToggle;

  const PlatformFeesWidget({
    Key? key,
    required this.amount,
    required this.role,
    this.isExpanded = false,
    this.onToggle,
  }) : super(key: key);

  // Use TradeFeeLogicService for exact calculations
  Map<String, dynamic> get _feeCalculation => TradeFeeLogicService.instance
      .calculateTradeFees(grossTradeAmount: amount);

  double get _platformFeeAmount =>
      role == 'buyer'
          ? _feeCalculation['platformFeeBuyer']
          : _feeCalculation['platformFeeSeller'];

  double get _totalAmountBuyer => amount + _feeCalculation['platformFeeBuyer'];
  double get _totalAmountSeller =>
      _feeCalculation['netToBuyer']; // What seller receives
  double get _sellerLockAmount =>
      _feeCalculation['requiredLockFromSeller']; // What seller locks

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: EdgeInsets.symmetric(horizontal: 4.w, vertical: 1.h),
      decoration: BoxDecoration(
        color: AppTheme.lightTheme.cardColor,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: AppTheme.lightTheme.primaryColor.withValues(alpha: 0.2),
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.05),
            blurRadius: 8,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Column(
        children: [
          // Header with toggle
          GestureDetector(
            onTap: onToggle,
            child: Container(
              padding: EdgeInsets.all(4.w),
              child: Row(
                children: [
                  Container(
                    padding: EdgeInsets.all(2.w),
                    decoration: BoxDecoration(
                      color: AppTheme.lightTheme.primaryColor.withValues(
                        alpha: 0.1,
                      ),
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: CustomIconWidget(
                      iconName: 'account_balance',
                      color: AppTheme.lightTheme.primaryColor,
                      size: 5.w,
                    ),
                  ),
                  SizedBox(width: 3.w),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Platform Fees (1%)',
                          style: AppTheme.lightTheme.textTheme.titleMedium
                              ?.copyWith(fontWeight: FontWeight.w600),
                        ),
                        SizedBox(height: 0.5.h),
                        Text(
                          _buildHeaderSubtext(),
                          style: AppTheme.lightTheme.textTheme.bodySmall
                              ?.copyWith(
                                color:
                                    AppTheme
                                        .lightTheme
                                        .colorScheme
                                        .onSurfaceVariant,
                              ),
                        ),
                      ],
                    ),
                  ),
                  if (onToggle != null)
                    CustomIconWidget(
                      iconName: isExpanded ? 'expand_less' : 'expand_more',
                      color: AppTheme.lightTheme.colorScheme.onSurfaceVariant,
                      size: 6.w,
                    ),
                ],
              ),
            ),
          ),

          // Expandable details
          if (isExpanded) ...[
            Container(
              width: double.infinity,
              height: 1,
              color: AppTheme.lightTheme.colorScheme.outline.withValues(
                alpha: 0.1,
              ),
            ),
            Container(
              padding: EdgeInsets.all(4.w),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Exact Fee Breakdown (USDC 6-Decimal)',
                    style: AppTheme.lightTheme.textTheme.titleSmall?.copyWith(
                      fontWeight: FontWeight.w600,
                      color: AppTheme.lightTheme.primaryColor,
                    ),
                  ),
                  SizedBox(height: 2.h),

                  // Trade amount
                  _buildFeeRow(
                    'Gross Trade Amount (G)',
                    '\$${amount.toStringAsFixed(6)}',
                    isAmount: true,
                  ),

                  SizedBox(height: 1.h),

                  // Role-specific breakdown
                  if (role == 'buyer') ...[
                    _buildFeeRow(
                      'Your Platform Fee (1%)',
                      '+\$${_feeCalculation['platformFeeBuyer'].toStringAsFixed(6)}',
                      isPositive: false,
                    ),
                    SizedBox(height: 1.h),
                    Container(
                      width: double.infinity,
                      height: 1,
                      color: AppTheme.lightTheme.colorScheme.outline.withValues(
                        alpha: 0.2,
                      ),
                    ),
                    SizedBox(height: 1.h),
                    _buildFeeRow(
                      'Total You Pay',
                      '\$${_totalAmountBuyer.toStringAsFixed(6)}',
                      isTotal: true,
                    ),
                  ] else ...[
                    _buildFeeRow(
                      'Required Lock Amount',
                      '\$${_sellerLockAmount.toStringAsFixed(6)}',
                      isPositive: false,
                    ),
                    SizedBox(height: 0.5.h),
                    _buildFeeRow(
                      'Your Platform Fee (1%)',
                      '-\$${_feeCalculation['platformFeeSeller'].toStringAsFixed(6)}',
                      isPositive: false,
                    ),
                    SizedBox(height: 1.h),
                    Container(
                      width: double.infinity,
                      height: 1,
                      color: AppTheme.lightTheme.colorScheme.outline.withValues(
                        alpha: 0.2,
                      ),
                    ),
                    SizedBox(height: 1.h),
                    _buildFeeRow(
                      'Net You Receive',
                      '\$${_totalAmountSeller.toStringAsFixed(6)}',
                      isTotal: true,
                    ),
                  ],

                  SizedBox(height: 2.h),

                  // Platform fee summary
                  Container(
                    padding: EdgeInsets.all(3.w),
                    decoration: BoxDecoration(
                      color: AppTheme.getWarningColor(
                        true,
                      ).withValues(alpha: 0.05),
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            CustomIconWidget(
                              iconName: 'info',
                              color: AppTheme.getWarningColor(true),
                              size: 4.w,
                            ),
                            SizedBox(width: 2.w),
                            Text(
                              'Platform Fees Summary',
                              style: AppTheme.lightTheme.textTheme.labelMedium
                                  ?.copyWith(
                                    fontWeight: FontWeight.w600,
                                    color: AppTheme.getWarningColor(true),
                                  ),
                            ),
                          ],
                        ),
                        SizedBox(height: 1.h),
                        Text(
                          '• Platform collects total: \$${_feeCalculation['platformFeeTotal'].toStringAsFixed(6)}',
                          style: AppTheme.lightTheme.textTheme.bodySmall
                              ?.copyWith(
                                color:
                                    AppTheme
                                        .lightTheme
                                        .colorScheme
                                        .onSurfaceVariant,
                                fontSize: 10,
                              ),
                        ),
                        Text(
                          '• Both buyer and seller pay 1% each (0.02*G total)',
                          style: AppTheme.lightTheme.textTheme.bodySmall
                              ?.copyWith(
                                color:
                                    AppTheme
                                        .lightTheme
                                        .colorScheme
                                        .onSurfaceVariant,
                                fontSize: 10,
                              ),
                        ),
                        Text(
                          '• On refund: Seller gets full lock amount back',
                          style: AppTheme.lightTheme.textTheme.bodySmall
                              ?.copyWith(
                                color:
                                    AppTheme
                                        .lightTheme
                                        .colorScheme
                                        .onSurfaceVariant,
                                fontSize: 10,
                              ),
                        ),
                      ],
                    ),
                  ),

                  SizedBox(height: 2.h),

                  // Escrow settlement info
                  Container(
                    padding: EdgeInsets.all(3.w),
                    decoration: BoxDecoration(
                      color: AppTheme.lightTheme.primaryColor.withValues(
                        alpha: 0.05,
                      ),
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            CustomIconWidget(
                              iconName: 'security',
                              color: AppTheme.lightTheme.primaryColor,
                              size: 4.w,
                            ),
                            SizedBox(width: 2.w),
                            Text(
                              'Escrow Settlement Rules',
                              style: AppTheme.lightTheme.textTheme.labelMedium
                                  ?.copyWith(
                                    fontWeight: FontWeight.w600,
                                    color: AppTheme.lightTheme.primaryColor,
                                  ),
                            ),
                          ],
                        ),
                        SizedBox(height: 1.h),
                        Text(
                          role == 'buyer'
                              ? '✅ On successful trade: You receive exactly \$${_totalAmountSeller.toStringAsFixed(2)} USDC'
                              : '🔒 You lock: \$${_sellerLockAmount.toStringAsFixed(2)} USDC in escrow\n✅ On success: Buyer gets \$${_totalAmountSeller.toStringAsFixed(2)} USDC\n🔄 On refund: You get full \$${_sellerLockAmount.toStringAsFixed(2)} USDC back',
                          style: AppTheme.lightTheme.textTheme.bodySmall
                              ?.copyWith(
                                color:
                                    AppTheme
                                        .lightTheme
                                        .colorScheme
                                        .onSurfaceVariant,
                              ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ],
        ],
      ),
    );
  }

  String _buildHeaderSubtext() {
    if (role == 'buyer') {
      return 'Fee: \$${_platformFeeAmount.toStringAsFixed(2)} • Total: \$${_totalAmountBuyer.toStringAsFixed(2)}';
    } else {
      return 'Lock: \$${_sellerLockAmount.toStringAsFixed(2)} • You receive: \$${_totalAmountSeller.toStringAsFixed(2)}';
    }
  }

  Widget _buildFeeRow(
    String label,
    String amount, {
    bool isAmount = false,
    bool? isPositive,
    bool isTotal = false,
  }) {
    Color textColor = AppTheme.lightTheme.colorScheme.onSurface;
    FontWeight fontWeight = FontWeight.normal;

    if (isTotal) {
      textColor = AppTheme.lightTheme.primaryColor;
      fontWeight = FontWeight.w700;
    } else if (isPositive == true) {
      textColor = AppTheme.getSuccessColor(true);
    } else if (isPositive == false) {
      textColor = AppTheme.lightTheme.colorScheme.error;
    }

    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(
          label,
          style: AppTheme.lightTheme.textTheme.bodyMedium?.copyWith(
            fontWeight: isTotal ? FontWeight.w600 : FontWeight.normal,
            color:
                isTotal
                    ? AppTheme.lightTheme.primaryColor
                    : AppTheme.lightTheme.colorScheme.onSurfaceVariant,
          ),
        ),
        Text(
          amount,
          style: AppTheme.lightTheme.textTheme.bodyMedium?.copyWith(
            fontWeight: fontWeight,
            color: textColor,
          ),
        ),
      ],
    );
  }
}
