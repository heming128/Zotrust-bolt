import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';
import './buy_modal_widget.dart';
import './sell_modal_widget.dart';

class NearbyTradersWidget extends StatefulWidget {
  final String selectedCity;
  final Function(String traderId) onTraderTap;
  final Function(String traderId) onMessageTrader;

  const NearbyTradersWidget({
    Key? key,
    required this.selectedCity,
    required this.onTraderTap,
    required this.onMessageTrader,
  }) : super(key: key);

  @override
  State<NearbyTradersWidget> createState() => _NearbyTradersWidgetState();
}

class _NearbyTradersWidgetState extends State<NearbyTradersWidget>
    with TickerProviderStateMixin {
  late AnimationController _refreshController;
  bool _isLoading = false;
  String _selectedFilter = 'All';

  // Mock data for nearby traders with real-time availability
  final Map<String, List<Map<String, dynamic>>> _tradersByCity = {
    'Mumbai': [
      {
        "id": "trader_001",
        "name": "Rajesh Kumar",
        "avatar":
            "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&h=150&fit=crop&crop=face",
        "isOnline": true,
        "isActive": true,
        "distance": "1.2 km",
        "rating": 4.8,
        "completedTrades": 156,
        "specialization": "Cash Exchange",
        "responseTime": "5 min",
        "lastSeen": "Online now",
        "availableAmount": "₹50,000 - ₹5,00,000",
        "verificationLevel": "Verified Plus",
        "availableUSDC": 500,
        "adType": "sell",
      },
      {
        "id": "trader_002",
        "name": "Priya Sharma",
        "avatar":
            "https://images.unsplash.com/photo-1494790108755-2616b612b786?w=150&h=150&fit=crop&crop=face",
        "isOnline": true,
        "isActive": true,
        "distance": "2.5 km",
        "rating": 4.9,
        "completedTrades": 203,
        "specialization": "UPI Transfer",
        "responseTime": "3 min",
        "lastSeen": "Online now",
        "availableAmount": "₹25,000 - ₹2,50,000",
        "verificationLevel": "Verified",
        "availableUSDC": 300,
        "adType": "buy",
      },
      {
        "id": "trader_003",
        "name": "Amit Patel",
        "avatar":
            "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=150&h=150&fit=crop&crop=face",
        "isOnline": false,
        "isActive": true,
        "distance": "3.8 km",
        "rating": 4.6,
        "completedTrades": 89,
        "specialization": "Bank Transfer",
        "responseTime": "12 min",
        "lastSeen": "2 hours ago",
        "availableAmount": "₹10,000 - ₹1,00,000",
        "verificationLevel": "Basic",
        "availableUSDC": 150,
        "adType": "sell",
      },
    ],
    'Delhi': [
      {
        "id": "trader_004",
        "name": "Vikash Singh",
        "avatar":
            "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150&h=150&fit=crop&crop=face",
        "isOnline": true,
        "isActive": true,
        "distance": "0.8 km",
        "rating": 4.7,
        "completedTrades": 127,
        "specialization": "Mobile Wallet",
        "responseTime": "4 min",
        "lastSeen": "Online now",
        "availableAmount": "₹15,000 - ₹1,50,000",
        "verificationLevel": "Verified Plus",
        "availableUSDC": 250,
        "adType": "buy",
      },
      {
        "id": "trader_005",
        "name": "Sunita Gupta",
        "avatar":
            "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=150&h=150&fit=crop&crop=face",
        "isOnline": true,
        "isActive": false,
        "distance": "4.2 km",
        "rating": 4.4,
        "completedTrades": 67,
        "specialization": "Cash Exchange",
        "responseTime": "8 min",
        "lastSeen": "Online now",
        "availableAmount": "₹5,000 - ₹75,000",
        "verificationLevel": "Basic",
        "availableUSDC": 100,
        "adType": "sell",
      },
    ],
    'Bangalore': [
      {
        "id": "trader_006",
        "name": "Karthik Rao",
        "avatar":
            "https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=150&h=150&fit=crop&crop=face",
        "isOnline": true,
        "isActive": true,
        "distance": "1.5 km",
        "rating": 4.9,
        "completedTrades": 234,
        "specialization": "Crypto Exchange",
        "responseTime": "2 min",
        "lastSeen": "Online now",
        "availableAmount": "₹75,000 - ₹7,50,000",
        "verificationLevel": "Verified Plus",
        "availableUSDC": 750,
        "adType": "buy",
      },
      {
        "id": "trader_007",
        "name": "Deepika Nair",
        "avatar":
            "https://images.unsplash.com/photo-1494790108755-2616b612b786?w=150&h=150&fit=crop&crop=face",
        "isOnline": false,
        "isActive": true,
        "distance": "6.1 km",
        "rating": 4.5,
        "completedTrades": 98,
        "specialization": "Bank Transfer",
        "responseTime": "15 min",
        "lastSeen": "1 hour ago",
        "availableAmount": "₹20,000 - ₹2,00,000",
        "verificationLevel": "Verified",
        "availableUSDC": 200,
        "adType": "sell",
      },
    ],
  };

  @override
  void initState() {
    super.initState();
    _refreshController = AnimationController(
      duration: const Duration(seconds: 1),
      vsync: this,
    );
    _startRealTimeUpdates();
  }

  @override
  void dispose() {
    _refreshController.dispose();
    super.dispose();
  }

  void _startRealTimeUpdates() {
    // Simulate real-time trader status updates
    Future.delayed(const Duration(seconds: 10), () {
      if (mounted) {
        setState(() {
          // Randomly update online status for demo
          final traders = _getFilteredTraders();
          for (var trader in traders) {
            if (DateTime.now().millisecond % 3 == 0) {
              trader['isOnline'] = !trader['isOnline'];
              trader['lastSeen'] = trader['isOnline']
                  ? 'Online now'
                  : '${DateTime.now().minute % 60} min ago';
            }
          }
        });
        _startRealTimeUpdates();
      }
    });
  }

  List<Map<String, dynamic>> _getFilteredTraders() {
    final traders = _tradersByCity[widget.selectedCity] ?? [];
    final nearbyCity = _getNearbyCity(widget.selectedCity);
    if (nearbyCity != null) {
      traders.addAll(_tradersByCity[nearbyCity] ?? []);
    }

    switch (_selectedFilter) {
      case 'Online':
        return traders.where((t) => t['isOnline'] == true).toList();
      case 'Active':
        return traders.where((t) => t['isActive'] == true).toList();
      case 'Verified':
        return traders.where((t) => t['verificationLevel'] != 'Basic').toList();
      default:
        return traders;
    }
  }

  String? _getNearbyCity(String city) {
    // Simple logic for nearby cities
    switch (city) {
      case 'Mumbai':
        return 'Pune';
      case 'Delhi':
        return null;
      case 'Bangalore':
        return 'Chennai';
      default:
        return null;
    }
  }

  Future<void> _handleRefresh() async {
    setState(() {
      _isLoading = true;
    });

    _refreshController.forward();
    await Future.delayed(const Duration(seconds: 2));

    setState(() {
      _isLoading = false;
    });
    _refreshController.reset();
  }

  Widget _buildTraderCard(Map<String, dynamic> trader) {
    final bool isOnline = trader['isOnline'] as bool;
    final bool isActive = trader['isActive'] as bool;
    final double rating = (trader['rating'] as num).toDouble();
    final int availableUSDC = trader['availableUSDC'] as int;
    final String adType = trader['adType'] as String;

    return Container(
      margin: EdgeInsets.symmetric(horizontal: 4.w, vertical: 1.h),
      child: Material(
        elevation: 2,
        borderRadius: BorderRadius.circular(12),
        color: AppTheme.lightTheme.cardColor,
        child: InkWell(
          onTap: () => widget.onTraderTap(trader['id'] as String),
          borderRadius: BorderRadius.circular(12),
          child: Padding(
            padding: EdgeInsets.all(4.w),
            child: Column(
              children: [
                Row(
                  children: [
                    // Avatar with online indicator
                    Stack(
                      children: [
                        Container(
                          width: 12.w,
                          height: 12.w,
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            color: AppTheme
                                .lightTheme.colorScheme.primaryContainer,
                          ),
                          child: CustomImageWidget(
                            imageUrl: trader['avatar'] as String,
                            width: 12.w,
                            height: 12.w,
                            fit: BoxFit.cover,
                          ),
                        ),
                        Positioned(
                          bottom: 0,
                          right: 0,
                          child: Container(
                            width: 3.w,
                            height: 3.w,
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              color: isOnline
                                  ? AppTheme.getSuccessColor(true)
                                  : AppTheme.getNeutralColor(true),
                              border: Border.all(
                                color: Colors.white,
                                width: 2,
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                    SizedBox(width: 3.w),

                    // Trader Info
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              Expanded(
                                child: Text(
                                  trader['name'] as String,
                                  style: AppTheme
                                      .lightTheme.textTheme.titleMedium
                                      ?.copyWith(
                                    fontWeight: FontWeight.w600,
                                  ),
                                  overflow: TextOverflow.ellipsis,
                                ),
                              ),
                              if (isActive)
                                Container(
                                  padding: EdgeInsets.symmetric(
                                      horizontal: 2.w, vertical: 0.5.h),
                                  decoration: BoxDecoration(
                                    color: AppTheme.getSuccessColor(true)
                                        .withValues(alpha: 0.1),
                                    borderRadius: BorderRadius.circular(12),
                                  ),
                                  child: Text(
                                    'ACTIVE',
                                    style: AppTheme
                                        .lightTheme.textTheme.labelSmall
                                        ?.copyWith(
                                      color: AppTheme.getSuccessColor(true),
                                      fontWeight: FontWeight.w600,
                                      fontSize: 8.sp,
                                    ),
                                  ),
                                ),
                            ],
                          ),
                          SizedBox(height: 0.5.h),
                          Row(
                            children: [
                              CustomIconWidget(
                                iconName: 'location_on',
                                color: AppTheme
                                    .lightTheme.colorScheme.onSurfaceVariant,
                                size: 14,
                              ),
                              SizedBox(width: 1.w),
                              Text(
                                trader['distance'] as String,
                                style: AppTheme.lightTheme.textTheme.bodySmall,
                              ),
                              SizedBox(width: 3.w),
                              Text(
                                trader['lastSeen'] as String,
                                style: AppTheme.lightTheme.textTheme.bodySmall
                                    ?.copyWith(
                                  color: isOnline
                                      ? AppTheme.getSuccessColor(true)
                                      : AppTheme.lightTheme.colorScheme
                                          .onSurfaceVariant,
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),

                    // Ad Type Badge
                    Container(
                      padding: EdgeInsets.symmetric(
                          horizontal: 2.w, vertical: 0.5.h),
                      decoration: BoxDecoration(
                        color: adType == 'buy'
                            ? AppTheme.getSuccessColor(true)
                                .withValues(alpha: 0.1)
                            : AppTheme.lightTheme.colorScheme.errorContainer,
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: Text(
                        '${adType.toUpperCase()} AD',
                        style:
                            AppTheme.lightTheme.textTheme.labelSmall?.copyWith(
                          color: adType == 'buy'
                              ? AppTheme.getSuccessColor(true)
                              : AppTheme
                                  .lightTheme.colorScheme.onErrorContainer,
                          fontWeight: FontWeight.w600,
                          fontSize: 8.sp,
                        ),
                      ),
                    ),
                  ],
                ),

                SizedBox(height: 2.h),

                // Rating and Stats Row
                Row(
                  children: [
                    Row(
                      children: List.generate(5, (index) {
                        return CustomIconWidget(
                          iconName:
                              index < rating.floor() ? 'star' : 'star_border',
                          color: index < rating.floor()
                              ? AppTheme.getWarningColor(true)
                              : AppTheme.getNeutralColor(true),
                          size: 16,
                        );
                      }),
                    ),
                    SizedBox(width: 2.w),
                    Text(
                      rating.toStringAsFixed(1),
                      style: AppTheme.lightTheme.textTheme.bodySmall?.copyWith(
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                    SizedBox(width: 4.w),
                    Text(
                      '${trader['completedTrades']} trades',
                      style: AppTheme.lightTheme.textTheme.bodySmall,
                    ),
                    const Spacer(),
                    Text(
                      trader['responseTime'] as String,
                      style: AppTheme.lightTheme.textTheme.bodySmall?.copyWith(
                        color: AppTheme.lightTheme.colorScheme.onSurfaceVariant,
                      ),
                    ),
                  ],
                ),

                SizedBox(height: 1.5.h),

                // Available USDC and INR Limits
                Container(
                  padding: EdgeInsets.all(3.w),
                  decoration: BoxDecoration(
                    color: AppTheme
                        .lightTheme.colorScheme.surfaceContainerHighest
                        .withValues(alpha: 0.3),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Column(
                    children: [
                      Row(
                        children: [
                          Text(
                            'INR Limit:',
                            style: AppTheme.lightTheme.textTheme.bodySmall
                                ?.copyWith(
                              color: AppTheme
                                  .lightTheme.colorScheme.onSurfaceVariant,
                              fontWeight: FontWeight.w500,
                            ),
                          ),
                          const Spacer(),
                          Text(
                            trader['availableAmount'] as String,
                            style: AppTheme.lightTheme.textTheme.bodySmall
                                ?.copyWith(
                              color: AppTheme.lightTheme.colorScheme.onSurface,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                        ],
                      ),
                      SizedBox(height: 1.h),
                      Row(
                        children: [
                          Text(
                            'Available USDC:',
                            style: AppTheme.lightTheme.textTheme.bodySmall
                                ?.copyWith(
                              color: AppTheme
                                  .lightTheme.colorScheme.onSurfaceVariant,
                              fontWeight: FontWeight.w500,
                            ),
                          ),
                          const Spacer(),
                          Text(
                            '$availableUSDC USDC',
                            style: AppTheme.lightTheme.textTheme.bodySmall
                                ?.copyWith(
                              color: AppTheme.lightTheme.primaryColor,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),

                SizedBox(height: 2.h),

                // Action Buttons Row
                Row(
                  children: [
                    // Specialization chip
                    Container(
                      padding: EdgeInsets.symmetric(
                          horizontal: 2.w, vertical: 0.5.h),
                      decoration: BoxDecoration(
                        color:
                            AppTheme.lightTheme.colorScheme.secondaryContainer,
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: Text(
                        trader['specialization'] as String,
                        style:
                            AppTheme.lightTheme.textTheme.labelSmall?.copyWith(
                          color: AppTheme
                              .lightTheme.colorScheme.onSecondaryContainer,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                    ),
                    const Spacer(),

                    // Message Button
                    GestureDetector(
                      onTap: () =>
                          widget.onMessageTrader(trader['id'] as String),
                      child: Container(
                        padding: EdgeInsets.symmetric(
                            horizontal: 3.w, vertical: 1.h),
                        decoration: BoxDecoration(
                          color: AppTheme.lightTheme.colorScheme.outline
                              .withValues(alpha: 0.1),
                          borderRadius: BorderRadius.circular(8),
                          border: Border.all(
                            color: AppTheme.lightTheme.colorScheme.outline
                                .withValues(alpha: 0.3),
                          ),
                        ),
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            CustomIconWidget(
                              iconName: 'message',
                              color: AppTheme.lightTheme.colorScheme.onSurface,
                              size: 16,
                            ),
                            SizedBox(width: 1.w),
                            Text(
                              'Message',
                              style: AppTheme.lightTheme.textTheme.bodySmall
                                  ?.copyWith(
                                color:
                                    AppTheme.lightTheme.colorScheme.onSurface,
                                fontWeight: FontWeight.w500,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),

                    SizedBox(width: 2.w),

                    // Buy/Sell Button based on ad type
                    GestureDetector(
                      onTap: () {
                        if (adType == 'buy' &&
                            trader['name'] == 'Priya Sharma') {
                          // Show buy modal for Priya Sharma
                          showDialog(
                            context: context,
                            barrierDismissible: false,
                            builder: (context) => BuyModalWidget(
                              trader: trader,
                              onTradeCreated: () {
                                // Optional: Refresh traders list or show success message
                                ScaffoldMessenger.of(context).showSnackBar(
                                  SnackBar(
                                    content: Text(
                                        'Trade initiated with ${trader['name']}'),
                                    backgroundColor:
                                        AppTheme.getSuccessColor(true),
                                    duration: const Duration(seconds: 2),
                                  ),
                                );
                              },
                            ),
                          );
                        } else if (adType == 'sell' &&
                            trader['name'] == 'Amit Patel') {
                          // Show sell modal for Amit Patel
                          showDialog(
                            context: context,
                            barrierDismissible: false,
                            builder: (context) => SellModalWidget(
                              trader: trader,
                              onTradeCreated: () {
                                // Optional: Refresh traders list or show success message
                                ScaffoldMessenger.of(context).showSnackBar(
                                  SnackBar(
                                    content: Text(
                                        'Sell order created with ${trader['name']}'),
                                    backgroundColor:
                                        AppTheme.getSuccessColor(true),
                                    duration: const Duration(seconds: 2),
                                  ),
                                );
                              },
                            ),
                          );
                        } else {
                          ScaffoldMessenger.of(context).showSnackBar(
                            SnackBar(
                              content: Text(
                                  '${adType == 'buy' ? 'Buying' : 'Selling'} from ${trader['name']}'),
                              backgroundColor: AppTheme.lightTheme.primaryColor,
                              duration: const Duration(seconds: 2),
                            ),
                          );
                        }
                      },
                      child: Container(
                        padding: EdgeInsets.symmetric(
                            horizontal: 4.w, vertical: 1.h),
                        decoration: BoxDecoration(
                          color: adType == 'buy'
                              ? AppTheme.getSuccessColor(true)
                              : AppTheme.lightTheme.colorScheme.error,
                          borderRadius: BorderRadius.circular(8),
                        ),
                        child: Text(
                          adType == 'buy' ? 'BUY' : 'SELL',
                          style: AppTheme.lightTheme.textTheme.bodyMedium
                              ?.copyWith(
                            color: Colors.white,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildFilterChips() {
    final filters = ['All', 'Online', 'Active', 'Verified'];

    return Container(
      height: 6.h,
      margin: EdgeInsets.symmetric(vertical: 1.h),
      child: ListView.builder(
        scrollDirection: Axis.horizontal,
        padding: EdgeInsets.symmetric(horizontal: 4.w),
        itemCount: filters.length,
        itemBuilder: (context, index) {
          final filter = filters[index];
          final isSelected = filter == _selectedFilter;

          return Container(
            margin: EdgeInsets.only(right: 2.w),
            child: FilterChip(
              selected: isSelected,
              label: Text(
                filter,
                style: AppTheme.lightTheme.textTheme.bodyMedium?.copyWith(
                  color: isSelected
                      ? Colors.white
                      : AppTheme.lightTheme.colorScheme.onSurface,
                  fontWeight: FontWeight.w500,
                ),
              ),
              backgroundColor: AppTheme.lightTheme.colorScheme.surface,
              selectedColor: AppTheme.lightTheme.primaryColor,
              onSelected: (selected) {
                setState(() {
                  _selectedFilter = filter;
                });
              },
            ),
          );
        },
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final traders = _getFilteredTraders();

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // Header with refresh
        Padding(
          padding: EdgeInsets.symmetric(horizontal: 4.w, vertical: 1.h),
          child: Row(
            children: [
              Text(
                'Nearby Active Traders',
                style: AppTheme.lightTheme.textTheme.titleLarge?.copyWith(
                  fontWeight: FontWeight.w600,
                ),
              ),
              const Spacer(),
              GestureDetector(
                onTap: _handleRefresh,
                child: AnimatedBuilder(
                  animation: _refreshController,
                  builder: (context, child) {
                    return Transform.rotate(
                      angle: _refreshController.value * 2 * 3.14159,
                      child: CustomIconWidget(
                        iconName: 'refresh',
                        color: _isLoading
                            ? AppTheme.lightTheme.primaryColor
                            : AppTheme.lightTheme.colorScheme.onSurfaceVariant,
                        size: 24,
                      ),
                    );
                  },
                ),
              ),
            ],
          ),
        ),

        // Filter Chips
        _buildFilterChips(),

        // Traders List
        if (_isLoading)
          _buildLoadingState()
        else if (traders.isEmpty)
          _buildEmptyState()
        else
          Column(
            children:
                traders.map((trader) => _buildTraderCard(trader)).toList(),
          ),
      ],
    );
  }

  Widget _buildLoadingState() {
    return Column(
      children: List.generate(3, (index) {
        return Container(
          margin: EdgeInsets.symmetric(horizontal: 4.w, vertical: 1.h),
          padding: EdgeInsets.all(4.w),
          decoration: BoxDecoration(
            color: AppTheme.lightTheme.cardColor,
            borderRadius: BorderRadius.circular(12),
          ),
          child: Column(
            children: [
              Row(
                children: [
                  Container(
                    width: 12.w,
                    height: 12.w,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: AppTheme.lightTheme.colorScheme.outline
                          .withValues(alpha: 0.3),
                    ),
                  ),
                  SizedBox(width: 3.w),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Container(
                          height: 16,
                          width: 40.w,
                          decoration: BoxDecoration(
                            color: AppTheme.lightTheme.colorScheme.outline
                                .withValues(alpha: 0.3),
                            borderRadius: BorderRadius.circular(4),
                          ),
                        ),
                        SizedBox(height: 1.h),
                        Container(
                          height: 12,
                          width: 25.w,
                          decoration: BoxDecoration(
                            color: AppTheme.lightTheme.colorScheme.outline
                                .withValues(alpha: 0.3),
                            borderRadius: BorderRadius.circular(4),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ],
          ),
        );
      }),
    );
  }

  Widget _buildEmptyState() {
    return Container(
      padding: EdgeInsets.all(8.w),
      child: Column(
        children: [
          CustomIconWidget(
            iconName: 'people_outline',
            color: AppTheme.lightTheme.colorScheme.onSurfaceVariant,
            size: 64,
          ),
          SizedBox(height: 2.h),
          Text(
            'No Active Traders Found',
            style: AppTheme.lightTheme.textTheme.titleLarge?.copyWith(
              color: AppTheme.lightTheme.colorScheme.onSurfaceVariant,
            ),
          ),
          SizedBox(height: 1.h),
          Text(
            'There are currently no active traders in ${widget.selectedCity}. Try refreshing or check back later.',
            style: AppTheme.lightTheme.textTheme.bodyMedium?.copyWith(
              color: AppTheme.lightTheme.colorScheme.onSurfaceVariant,
            ),
            textAlign: TextAlign.center,
          ),
          SizedBox(height: 3.h),
          ElevatedButton(
            onPressed: _handleRefresh,
            child: Text('Refresh'),
          ),
        ],
      ),
    );
  }
}
