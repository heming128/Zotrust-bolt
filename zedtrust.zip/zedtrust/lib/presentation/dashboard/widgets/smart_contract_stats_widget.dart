import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';
import 'package:google_fonts/google_fonts.dart';
import '../../../core/services/web3_escrow_service.dart';

class SmartContractStatsWidget extends StatefulWidget {
  const SmartContractStatsWidget({Key? key}) : super(key: key);

  @override
  State<SmartContractStatsWidget> createState() =>
      _SmartContractStatsWidgetState();
}

class _SmartContractStatsWidgetState extends State<SmartContractStatsWidget> {
  final Web3EscrowService _web3Service = Web3EscrowService.instance;

  bool _isLoading = true;
  Map<String, dynamic> _contractStats = {};
  String _errorMessage = '';

  @override
  void initState() {
    super.initState();
    _loadContractStats();
  }

  Future<void> _loadContractStats() async {
    try {
      setState(() {
        _isLoading = true;
        _errorMessage = '';
      });

      await _web3Service.initialize();

      final tradeCounter = await _web3Service.getTradeCounter();
      final adminAddress = await _web3Service.getAdminAddress();

      // Check some common tokens
      final usdtAllowed = await _web3Service
          .isTokenAllowed('0xc2132D05D31c914a87C6611C10748AEb04B58e8F');
      final usdcAllowed = await _web3Service
          .isTokenAllowed('0x2791Bca1f2de4661ED88A30C99A7a9449Aa84174');
      final maticAllowed = await _web3Service
          .isTokenAllowed('0x0000000000000000000000000000000000000000');

      setState(() {
        _contractStats = {
          'totalTrades': tradeCounter.toString(),
          'adminAddress': adminAddress,
          'allowedTokens': {
            'MATIC': maticAllowed,
            'USDT': usdtAllowed,
            'USDC': usdcAllowed,
          },
          'contractAddress': '0xf3fcdaaE3320D32e2386B795FA4e3F93e22634f5',
          'network': 'Polygon Amoy Testnet',
          'chainId': '80002',
        };
        _isLoading = false;
      });
    } catch (e) {
      setState(() {
        _errorMessage = 'Failed to load contract stats: ${e.toString()}';
        _isLoading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.maxFinite,
      padding: EdgeInsets.all(4.w),
      margin: EdgeInsets.symmetric(horizontal: 4.w, vertical: 1.h),
      decoration: BoxDecoration(
        color: Theme.of(context).cardColor,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: Colors.blue.withAlpha(51),
          width: 1,
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withAlpha(13),
            blurRadius: 8,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _buildHeader(),
          SizedBox(height: 3.h),
          if (_isLoading) _buildLoadingContent(),
          if (!_isLoading && _errorMessage.isEmpty) _buildStatsContent(),
          if (!_isLoading && _errorMessage.isNotEmpty) _buildErrorContent(),
        ],
      ),
    );
  }

  Widget _buildHeader() {
    return Row(
      children: [
        Container(
          padding: EdgeInsets.all(2.w),
          decoration: BoxDecoration(
            color: Colors.blue.withAlpha(26),
            borderRadius: BorderRadius.circular(8),
          ),
          child: Icon(
            Icons.account_balance,
            color: Colors.blue,
            size: 6.w,
          ),
        ),
        SizedBox(width: 3.w),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'Smart Contract Stats',
                style: GoogleFonts.inter(
                  fontSize: 16.sp,
                  fontWeight: FontWeight.w600,
                  color: Theme.of(context).textTheme.headlineSmall?.color,
                ),
              ),
              SizedBox(height: 0.5.h),
              Text(
                'Real-time blockchain data',
                style: GoogleFonts.inter(
                  fontSize: 11.sp,
                  fontWeight: FontWeight.w400,
                  color: Theme.of(context).textTheme.bodyMedium?.color,
                ),
              ),
            ],
          ),
        ),
        GestureDetector(
          onTap: _loadContractStats,
          child: Container(
            padding: EdgeInsets.all(2.w),
            decoration: BoxDecoration(
              color: Colors.grey.withAlpha(26),
              borderRadius: BorderRadius.circular(6),
            ),
            child: Icon(
              Icons.refresh,
              color: Theme.of(context).primaryColor,
              size: 4.w,
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildLoadingContent() {
    return Center(
      child: Column(
        children: [
          SizedBox(
            width: 8.w,
            height: 8.w,
            child: const CircularProgressIndicator(strokeWidth: 2),
          ),
          SizedBox(height: 2.h),
          Text(
            'Loading contract data...',
            style: GoogleFonts.inter(
              fontSize: 12.sp,
              fontWeight: FontWeight.w400,
              color: Theme.of(context).textTheme.bodyMedium?.color,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildStatsContent() {
    return Column(
      children: [
        // Key Stats Row
        Row(
          children: [
            _buildStatCard(
              'Total Trades',
              _contractStats['totalTrades'] ?? '0',
              Icons.swap_horiz,
              Colors.green,
            ),
            SizedBox(width: 3.w),
            _buildStatCard(
              'Network',
              'Polygon',
              Icons.hub,
              Colors.purple,
            ),
          ],
        ),
        SizedBox(height: 2.h),

        // Contract Details
        _buildSectionHeader('Contract Details'),
        SizedBox(height: 1.h),
        _buildDetailItem(
          'Contract Address',
          _contractStats['contractAddress'] ?? '',
          Icons.code,
        ),
        _buildDetailItem(
          'Admin Address',
          _contractStats['adminAddress'] ?? '',
          Icons.admin_panel_settings,
        ),
        _buildDetailItem(
          'Chain ID',
          _contractStats['chainId'] ?? '',
          Icons.link,
        ),

        SizedBox(height: 2.h),

        // Allowed Tokens
        _buildSectionHeader('Allowed Tokens'),
        SizedBox(height: 1.h),
        _buildAllowedTokens(),
      ],
    );
  }

  Widget _buildStatCard(
      String label, String value, IconData icon, Color color) {
    return Expanded(
      child: Container(
        padding: EdgeInsets.all(3.w),
        decoration: BoxDecoration(
          color: color.withAlpha(26),
          borderRadius: BorderRadius.circular(8),
          border: Border.all(color: color.withAlpha(51)),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(
                  icon,
                  color: color,
                  size: 4.w,
                ),
                const Spacer(),
                Text(
                  value,
                  style: GoogleFonts.inter(
                    fontSize: 16.sp,
                    fontWeight: FontWeight.w700,
                    color: color,
                  ),
                ),
              ],
            ),
            SizedBox(height: 1.h),
            Text(
              label,
              style: GoogleFonts.inter(
                fontSize: 11.sp,
                fontWeight: FontWeight.w500,
                color: Theme.of(context).textTheme.bodyMedium?.color,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildSectionHeader(String title) {
    return Row(
      children: [
        Container(
          width: 3,
          height: 4.w,
          decoration: BoxDecoration(
            color: Theme.of(context).primaryColor,
            borderRadius: BorderRadius.circular(2),
          ),
        ),
        SizedBox(width: 2.w),
        Text(
          title,
          style: GoogleFonts.inter(
            fontSize: 14.sp,
            fontWeight: FontWeight.w600,
            color: Theme.of(context).textTheme.headlineSmall?.color,
          ),
        ),
      ],
    );
  }

  Widget _buildDetailItem(String label, String value, IconData icon) {
    return Padding(
      padding: EdgeInsets.symmetric(vertical: 0.8.h),
      child: Row(
        children: [
          Icon(
            icon,
            color: Theme.of(context).textTheme.bodyMedium?.color,
            size: 4.w,
          ),
          SizedBox(width: 3.w),
          Text(
            label,
            style: GoogleFonts.inter(
              fontSize: 12.sp,
              fontWeight: FontWeight.w500,
              color: Theme.of(context).textTheme.bodyMedium?.color,
            ),
          ),
          const Spacer(),
          Text(
            value.length > 20
                ? '${value.substring(0, 6)}...${value.substring(value.length - 4)}'
                : value,
            style: GoogleFonts.inter(
              fontSize: 11.sp,
              fontWeight: FontWeight.w400,
              color: Theme.of(context).textTheme.headlineSmall?.color,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildAllowedTokens() {
    final allowedTokens =
        _contractStats['allowedTokens'] as Map<String, dynamic>? ?? {};

    return Column(
      children: allowedTokens.entries.map((entry) {
        final isAllowed = entry.value as bool;
        return Container(
          margin: EdgeInsets.only(bottom: 1.h),
          padding: EdgeInsets.symmetric(horizontal: 3.w, vertical: 1.5.h),
          decoration: BoxDecoration(
            color: isAllowed
                ? Colors.green.withAlpha(26)
                : Colors.red.withAlpha(26),
            borderRadius: BorderRadius.circular(8),
            border: Border.all(
              color: isAllowed
                  ? Colors.green.withAlpha(77)
                  : Colors.red.withAlpha(77),
            ),
          ),
          child: Row(
            children: [
              Container(
                width: 8.w,
                height: 8.w,
                decoration: BoxDecoration(
                  color: isAllowed ? Colors.green : Colors.red,
                  shape: BoxShape.circle,
                ),
                child: Icon(
                  isAllowed ? Icons.check : Icons.close,
                  color: Colors.white,
                  size: 4.w,
                ),
              ),
              SizedBox(width: 3.w),
              Text(
                entry.key,
                style: GoogleFonts.inter(
                  fontSize: 13.sp,
                  fontWeight: FontWeight.w600,
                  color: Theme.of(context).textTheme.headlineSmall?.color,
                ),
              ),
              const Spacer(),
              Text(
                isAllowed ? 'Allowed' : 'Not Allowed',
                style: GoogleFonts.inter(
                  fontSize: 11.sp,
                  fontWeight: FontWeight.w500,
                  color: isAllowed ? Colors.green : Colors.red,
                ),
              ),
            ],
          ),
        );
      }).toList(),
    );
  }

  Widget _buildErrorContent() {
    return Container(
      width: double.maxFinite,
      padding: EdgeInsets.all(4.w),
      decoration: BoxDecoration(
        color: Colors.red.withAlpha(26),
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: Colors.red.withAlpha(77)),
      ),
      child: Column(
        children: [
          Icon(
            Icons.error_outline,
            color: Colors.red,
            size: 8.w,
          ),
          SizedBox(height: 1.h),
          Text(
            'Failed to Load Contract Data',
            style: GoogleFonts.inter(
              fontSize: 14.sp,
              fontWeight: FontWeight.w600,
              color: Colors.red,
            ),
          ),
          SizedBox(height: 1.h),
          Text(
            _errorMessage,
            textAlign: TextAlign.center,
            style: GoogleFonts.inter(
              fontSize: 11.sp,
              fontWeight: FontWeight.w400,
              color: Colors.red.shade700,
            ),
          ),
          SizedBox(height: 2.h),
          ElevatedButton(
            onPressed: _loadContractStats,
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.red,
              padding: EdgeInsets.symmetric(horizontal: 6.w, vertical: 1.h),
            ),
            child: Text(
              'Retry',
              style: GoogleFonts.inter(
                fontSize: 12.sp,
                fontWeight: FontWeight.w500,
                color: Colors.white,
              ),
            ),
          ),
        ],
      ),
    );
  }
}
