import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

import '../../../core/services/auth_service.dart';
import '../../../core/services/backend_api_service.dart';

class AuthStatusWidget extends StatefulWidget {
  const AuthStatusWidget({super.key});

  @override
  State<AuthStatusWidget> createState() => _AuthStatusWidgetState();
}

class _AuthStatusWidgetState extends State<AuthStatusWidget> {
  final AuthService _authService = AuthService.instance;
  final BackendApiService _backendService = BackendApiService.instance;

  Map<String, dynamic>? _userProfile;
  Map<String, dynamic>? _userStats;
  bool _isLoading = true;
  String _connectionStatus = 'Checking...';

  @override
  void initState() {
    super.initState();
    _initializeAuthStatus();
  }

  Future<void> _initializeAuthStatus() async {
    await _checkAuthStatus();
    await _loadUserData();
    await _checkBackendConnection();
  }

  Future<void> _checkAuthStatus() async {
    try {
      if (_authService.isAuthenticated) {
        final profile = await _authService.getCurrentUserProfile();
        if (mounted) {
          setState(() {
            _userProfile = profile;
          });
        }
      }
    } catch (e) {
      if (mounted) {
        setState(() {
          _connectionStatus = 'Auth Error: ${e.toString()}';
        });
      }
    }
  }

  Future<void> _loadUserData() async {
    try {
      if (_authService.isAuthenticated) {
        final stats = await _backendService.getUserStatistics();
        if (mounted) {
          setState(() {
            _userStats = stats;
          });
        }
      }
    } catch (e) {
      debugPrint('Error loading user stats: $e');
    }
  }

  Future<void> _checkBackendConnection() async {
    try {
      final isConnected = await _backendService.checkConnection();
      if (mounted) {
        setState(() {
          _connectionStatus = isConnected ? 'Connected' : 'Disconnected';
          _isLoading = false;
        });
      }
    } catch (e) {
      if (mounted) {
        setState(() {
          _connectionStatus = 'Connection Error';
          _isLoading = false;
        });
      }
    }
  }

  Future<void> _handleSignOut() async {
    try {
      final result = await _authService.signOut();
      if (result['success'] == true && mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(result['message'] ?? 'Signed out successfully'),
            backgroundColor: Colors.green,
          ),
        );
        // Navigate to login screen or refresh app state
        if (mounted) {
          setState(() {
            _userProfile = null;
            _userStats = null;
          });
        }
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Sign out failed: $e'),
            backgroundColor: Colors.red,
          ),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.all(16),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        boxShadow: [
          BoxShadow(
            color: Colors.grey.withAlpha(26),
            blurRadius: 8,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(
                Icons.account_circle,
                color:
                    _authService.isAuthenticated ? Colors.green : Colors.grey,
                size: 24,
              ),
              const SizedBox(width: 8),
              Text(
                'Authentication Status',
                style: GoogleFonts.inter(
                  fontSize: 18,
                  fontWeight: FontWeight.w600,
                  color: Colors.black87,
                ),
              ),
              const Spacer(),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                decoration: BoxDecoration(
                  color:
                      _connectionStatus == 'Connected'
                          ? Colors.green
                          : Colors.red,
                  borderRadius: BorderRadius.circular(6),
                ),
                child: Text(
                  _connectionStatus,
                  style: GoogleFonts.inter(
                    fontSize: 12,
                    color: Colors.white,
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),

          if (_isLoading)
            const Center(child: CircularProgressIndicator())
          else if (!_authService.isAuthenticated)
            _buildUnauthenticatedState()
          else
            _buildAuthenticatedState(),
        ],
      ),
    );
  }

  Widget _buildUnauthenticatedState() {
    return Column(
      children: [
        const Icon(Icons.login, size: 48, color: Colors.grey),
        const SizedBox(height: 16),
        Text(
          'Not authenticated',
          style: GoogleFonts.inter(
            fontSize: 16,
            fontWeight: FontWeight.w500,
            color: Colors.grey[600],
          ),
        ),
        const SizedBox(height: 8),
        Text(
          'Please sign in to access your account',
          style: GoogleFonts.inter(fontSize: 14, color: Colors.grey[500]),
          textAlign: TextAlign.center,
        ),
        const SizedBox(height: 16),
        ElevatedButton.icon(
          onPressed: () {
            // Navigate to auth screen
            // Navigator.pushNamed(context, AppRoutes.auth);
          },
          icon: const Icon(Icons.login),
          label: const Text('Sign In'),
          style: ElevatedButton.styleFrom(
            backgroundColor: Colors.blue,
            foregroundColor: Colors.white,
            padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(8),
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildAuthenticatedState() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // User Profile Section
        Row(
          children: [
            CircleAvatar(
              radius: 24,
              backgroundColor: Colors.blue,
              backgroundImage:
                  _userProfile?['avatar_url'] != null
                      ? NetworkImage(_userProfile!['avatar_url'])
                      : null,
              child:
                  _userProfile?['avatar_url'] == null
                      ? Text(
                        (_userProfile?['display_name']
                                ?.toString()
                                .substring(0, 1)
                                .toUpperCase() ??
                            'U'),
                        style: GoogleFonts.inter(
                          fontSize: 18,
                          fontWeight: FontWeight.w600,
                          color: Colors.white,
                        ),
                      )
                      : null,
            ),
            const SizedBox(width: 16),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    _userProfile?['display_name'] ??
                        _userProfile?['full_name'] ??
                        'User',
                    style: GoogleFonts.inter(
                      fontSize: 16,
                      fontWeight: FontWeight.w600,
                      color: Colors.black87,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    _userProfile?['email'] ??
                        _authService.currentUser?.email ??
                        '',
                    style: GoogleFonts.inter(
                      fontSize: 14,
                      color: Colors.grey[600],
                    ),
                  ),
                  if (_userProfile?['role'] != null) ...[
                    const SizedBox(height: 4),
                    Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 8,
                        vertical: 2,
                      ),
                      decoration: BoxDecoration(
                        color: _getRoleColor(
                          _userProfile!['role'],
                        ).withAlpha(26),
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(
                          color: _getRoleColor(_userProfile!['role']),
                          width: 1,
                        ),
                      ),
                      child: Text(
                        _userProfile!['role'].toString().toUpperCase(),
                        style: GoogleFonts.inter(
                          fontSize: 12,
                          fontWeight: FontWeight.w500,
                          color: _getRoleColor(_userProfile!['role']),
                        ),
                      ),
                    ),
                  ],
                ],
              ),
            ),
            IconButton(
              onPressed: _handleSignOut,
              icon: const Icon(Icons.logout),
              color: Colors.red,
              tooltip: 'Sign Out',
            ),
          ],
        ),

        const SizedBox(height: 16),
        const Divider(),
        const SizedBox(height: 16),

        // User Statistics Section
        if (_userStats != null) ...[
          Text(
            'Account Statistics',
            style: GoogleFonts.inter(
              fontSize: 16,
              fontWeight: FontWeight.w600,
              color: Colors.black87,
            ),
          ),
          const SizedBox(height: 12),
          Row(
            children: [
              Expanded(
                child: _buildStatCard(
                  'Total Trades',
                  _userStats!['total_trades']?.toString() ?? '0',
                  Icons.swap_horiz,
                  Colors.blue,
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: _buildStatCard(
                  'Completed',
                  _userStats!['completed_trades']?.toString() ?? '0',
                  Icons.check_circle,
                  Colors.green,
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          Row(
            children: [
              Expanded(
                child: _buildStatCard(
                  'Active',
                  _userStats!['active_trades']?.toString() ?? '0',
                  Icons.pending,
                  Colors.orange,
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: _buildStatCard(
                  'Success Rate',
                  '${_userStats!['success_rate']?.toString() ?? '0'}%',
                  Icons.trending_up,
                  Colors.purple,
                ),
              ),
            ],
          ),
        ],

        const SizedBox(height: 16),

        // Verification Status
        if (_userProfile != null) ...[
          Row(
            children: [
              Icon(
                _userProfile!['is_verified'] == true
                    ? Icons.verified
                    : Icons.warning,
                color:
                    _userProfile!['is_verified'] == true
                        ? Colors.green
                        : Colors.orange,
                size: 20,
              ),
              const SizedBox(width: 8),
              Text(
                _userProfile!['is_verified'] == true
                    ? 'Verified Account'
                    : 'Verification Pending',
                style: GoogleFonts.inter(
                  fontSize: 14,
                  fontWeight: FontWeight.w500,
                  color:
                      _userProfile!['is_verified'] == true
                          ? Colors.green
                          : Colors.orange,
                ),
              ),
            ],
          ),
        ],
      ],
    );
  }

  Widget _buildStatCard(
    String title,
    String value,
    IconData icon,
    Color color,
  ) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: color.withAlpha(26),
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: color.withAlpha(77)),
      ),
      child: Column(
        children: [
          Icon(icon, color: color, size: 20),
          const SizedBox(height: 8),
          Text(
            value,
            style: GoogleFonts.inter(
              fontSize: 18,
              fontWeight: FontWeight.w700,
              color: color,
            ),
          ),
          const SizedBox(height: 4),
          Text(
            title,
            style: GoogleFonts.inter(
              fontSize: 12,
              fontWeight: FontWeight.w500,
              color: Colors.grey[600],
            ),
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }

  Color _getRoleColor(String role) {
    switch (role.toLowerCase()) {
      case 'admin':
        return Colors.red;
      case 'manager':
        return Colors.purple;
      case 'agent':
        return Colors.blue;
      default:
        return Colors.grey;
    }
  }
}
