import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';

class NetworkStatusWidget extends StatelessWidget {
  final bool isConnected;
  final String networkName;
  final int blockNumber;

  const NetworkStatusWidget({
    Key? key,
    required this.isConnected,
    required this.networkName,
    required this.blockNumber,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: EdgeInsets.symmetric(horizontal: 4.w, vertical: 1.h),
      padding: EdgeInsets.symmetric(horizontal: 4.w, vertical: 2.h),
      decoration: BoxDecoration(
        color: isConnected
            ? AppTheme.getSuccessColor(true).withValues(alpha: 0.1)
            : AppTheme.lightTheme.colorScheme.error.withValues(alpha: 0.1),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: isConnected
              ? AppTheme.getSuccessColor(true).withValues(alpha: 0.3)
              : AppTheme.lightTheme.colorScheme.error.withValues(alpha: 0.3),
        ),
      ),
      child: Row(
        children: [
          Container(
            width: 3.w,
            height: 3.w,
            decoration: BoxDecoration(
              color: isConnected
                  ? AppTheme.getSuccessColor(true)
                  : AppTheme.lightTheme.colorScheme.error,
              shape: BoxShape.circle,
            ),
          ),
          SizedBox(width: 3.w),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  isConnected
                      ? 'Connected to $networkName'
                      : 'Network Disconnected',
                  style: AppTheme.lightTheme.textTheme.titleMedium?.copyWith(
                    color: isConnected
                        ? AppTheme.getSuccessColor(true)
                        : AppTheme.lightTheme.colorScheme.error,
                    fontWeight: FontWeight.w600,
                  ),
                ),
                if (isConnected) ...[
                  SizedBox(height: 0.5.h),
                  Text(
                    'Block #$blockNumber',
                    style: AppTheme.lightTheme.textTheme.bodySmall?.copyWith(
                      color: AppTheme.lightTheme.colorScheme.onSurfaceVariant,
                    ),
                  ),
                ],
              ],
            ),
          ),
          CustomIconWidget(
            iconName: isConnected ? 'wifi' : 'wifi_off',
            color: isConnected
                ? AppTheme.getSuccessColor(true)
                : AppTheme.lightTheme.colorScheme.error,
            size: 20,
          ),
        ],
      ),
    );
  }
}
