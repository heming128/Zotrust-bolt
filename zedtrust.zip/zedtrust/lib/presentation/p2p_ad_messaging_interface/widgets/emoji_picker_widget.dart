import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';
import '../../../theme/app_theme.dart';

class EmojiPickerWidget extends StatelessWidget {
  final Function(String) onEmojiSelected;

  const EmojiPickerWidget({
    Key? key,
    required this.onEmojiSelected,
  }) : super(key: key);

  static const List<List<String>> _emojiCategories = [
    // Faces & People
    [
      '😀',
      '😃',
      '😄',
      '😁',
      '😅',
      '😂',
      '🤣',
      '😊',
      '😇',
      '🙂',
      '🙃',
      '😉',
      '😌',
      '😍',
      '🥰',
      '😘'
    ],
    // Hand Gestures & Symbols
    [
      '👍',
      '👎',
      '👌',
      '✌️',
      '🤞',
      '🤝',
      '👏',
      '🙏',
      '✋',
      '👋',
      '🤚',
      '💪',
      '👊',
      '✊',
      '🤛',
      '🤜'
    ],
    // Hearts & Emotions
    [
      '❤️',
      '💛',
      '💚',
      '💙',
      '💜',
      '🧡',
      '🖤',
      '🤍',
      '🤎',
      '💯',
      '💢',
      '💥',
      '💫',
      '⭐',
      '🌟',
      '✨'
    ],
    // Objects & Symbols
    [
      '💰',
      '💎',
      '🔥',
      '⚡',
      '🎯',
      '🎉',
      '🎊',
      '🔔',
      '🔕',
      '📱',
      '💻',
      '⌚',
      '💡',
      '🔋',
      '🔌',
      '🔧'
    ],
  ];

  static const List<String> _categoryNames = [
    'Faces',
    'Gestures',
    'Hearts',
    'Objects',
  ];

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 25.h,
      decoration: BoxDecoration(
        color: AppTheme.lightTheme.cardColor,
        border: Border(
          top: BorderSide(
            color:
                AppTheme.lightTheme.colorScheme.outline.withValues(alpha: 0.2),
          ),
        ),
      ),
      child: DefaultTabController(
        length: _emojiCategories.length,
        child: Column(
          children: [
            // Tab bar for emoji categories
            Container(
              height: 6.h,
              decoration: BoxDecoration(
                color: AppTheme.lightTheme.colorScheme.surfaceContainerHighest
                    .withValues(alpha: 0.5),
                border: Border(
                  bottom: BorderSide(
                    color: AppTheme.lightTheme.colorScheme.outline
                        .withValues(alpha: 0.1),
                  ),
                ),
              ),
              child: TabBar(
                isScrollable: true,
                labelColor: AppTheme.lightTheme.primaryColor,
                unselectedLabelColor:
                    AppTheme.lightTheme.colorScheme.onSurfaceVariant,
                indicatorColor: AppTheme.lightTheme.primaryColor,
                indicatorWeight: 2,
                tabs: _categoryNames
                    .map((name) => Tab(
                          child: Text(
                            name,
                            style: AppTheme.lightTheme.textTheme.bodySmall
                                ?.copyWith(
                              fontWeight: FontWeight.w500,
                            ),
                          ),
                        ))
                    .toList(),
              ),
            ),

            // Emoji grid views
            Expanded(
              child: TabBarView(
                children: _emojiCategories
                    .map((emojis) => _buildEmojiGrid(emojis))
                    .toList(),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildEmojiGrid(List<String> emojis) {
    return Container(
      padding: EdgeInsets.all(2.w),
      child: GridView.builder(
        gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 8,
          crossAxisSpacing: 1.w,
          mainAxisSpacing: 1.w,
        ),
        itemCount: emojis.length,
        itemBuilder: (context, index) {
          final emoji = emojis[index];
          return GestureDetector(
            onTap: () => onEmojiSelected(emoji),
            child: Container(
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(2.w),
                color: Colors.transparent,
              ),
              child: Center(
                child: Text(
                  emoji,
                  style: TextStyle(fontSize: 24.sp),
                ),
              ),
            ),
          );
        },
      ),
    );
  }
}
