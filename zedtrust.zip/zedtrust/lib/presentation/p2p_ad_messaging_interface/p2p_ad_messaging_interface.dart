import 'dart:async';

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:sizer/sizer.dart';
import 'package:socket_io_client/socket_io_client.dart' as IO;
import 'package:uuid/uuid.dart';

import '../../core/app_export.dart';
import '../web_rtc_voice_call_interface/web_rtc_voice_call_interface.dart';
import './widgets/emoji_picker_widget.dart';
import './widgets/message_bubble_widget.dart';
import './widgets/quick_response_templates_widget.dart';
import './widgets/typing_indicator_widget.dart';

class P2PAdMessagingInterface extends StatefulWidget {
  const P2PAdMessagingInterface({Key? key}) : super(key: key);

  @override
  State<P2PAdMessagingInterface> createState() =>
      _P2PAdMessagingInterfaceState();
}

class _P2PAdMessagingInterfaceState extends State<P2PAdMessagingInterface>
    with WidgetsBindingObserver {
  final TextEditingController _messageController = TextEditingController();
  final ScrollController _scrollController = ScrollController();
  final FocusNode _messageFocusNode = FocusNode();

  // Socket connection
  IO.Socket? _socket;
  bool _isConnected = false;
  bool _isTyping = false;
  bool _counterpartyTyping = false;
  Timer? _typingTimer;

  // Message management
  List<Map<String, dynamic>> _messages = [];
  Set<String> _readMessages = <String>{};

  // Chat data
  Map<String, dynamic> _chatData = {};
  String _conversationId = '';

  // UI states
  bool _showEmojiPicker = false;
  bool _showQuickResponses = false;
  String _connectionStatus = 'Connecting...';

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _initializeChat();
    _connectSocket();
  }

  @override
  void dispose() {
    _socket?.disconnect();
    _socket?.dispose();
    _typingTimer?.cancel();
    _messageController.dispose();
    _scrollController.dispose();
    _messageFocusNode.dispose();
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) {
      _connectSocket();
    } else if (state == AppLifecycleState.paused) {
      _socket?.disconnect();
    }
  }

  void _initializeChat() {
    final args =
        ModalRoute.of(context)?.settings.arguments as Map<String, dynamic>? ??
            {};
    _chatData = args;

    // Generate conversation ID
    final uuid = const Uuid();
    final currentUserId = 'user_${DateTime.now().millisecondsSinceEpoch}';
    final counterpartyId = _chatData['counterpartyId'] ?? 'unknown';
    _conversationId =
        uuid.v5(Uuid.NAMESPACE_URL, '$currentUserId:$counterpartyId');

    _loadChatHistory();
  }

  void _connectSocket() {
    try {
      _socket = IO.io('ws://localhost:3000', <String, dynamic>{
        'transports': ['websocket'],
        'autoConnect': false,
      });

      _socket?.connect();

      _socket?.onConnect((_) {
        setState(() {
          _isConnected = true;
          _connectionStatus = 'Connected';
        });
        _socket?.emit('join_conversation', _conversationId);
      });

      _socket?.onDisconnect((_) {
        setState(() {
          _isConnected = false;
          _connectionStatus = 'Disconnected';
        });
      });

      _socket?.on('message', (data) => _handleIncomingMessage(data));
      _socket?.on('typing', (data) => _handleTypingIndicator(data, true));
      _socket?.on('stop_typing', (data) => _handleTypingIndicator(data, false));
      _socket?.on('message_read', (data) => _handleMessageRead(data));
    } catch (e) {
      setState(() {
        _connectionStatus = 'Connection failed';
      });
    }
  }

  void _loadChatHistory() {
    // Mock chat history for demo
    setState(() {
      _messages = [
        {
          'id': const Uuid().v4(),
          'text':
              'Hi! I\'m interested in your ${_chatData['adReference']} offer.',
          'timestamp': DateTime.now().subtract(const Duration(minutes: 5)),
          'isMe': true,
          'isRead': true,
          'type': 'text',
        },
        {
          'id': const Uuid().v4(),
          'text':
              'Hello! Sure, I can help you with that. What amount are you looking for?',
          'timestamp': DateTime.now().subtract(const Duration(minutes: 4)),
          'isMe': false,
          'isRead': true,
          'type': 'text',
        },
      ];
    });
    _scrollToBottom();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black.withValues(alpha: 0.5),
      body: GestureDetector(
        onTap: () => Navigator.pop(context),
        child: SafeArea(
          child: Center(
            child: Container(
              margin: EdgeInsets.symmetric(horizontal: 4.w, vertical: 8.h),
              decoration: BoxDecoration(
                color: AppTheme.lightTheme.scaffoldBackgroundColor,
                borderRadius: BorderRadius.circular(4.w),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withValues(alpha: 0.3),
                    blurRadius: 20,
                    offset: const Offset(0, 10),
                  ),
                ],
              ),
              child: GestureDetector(
                onTap: () {}, // Prevent closing when tapping inside
                child: Column(
                  children: [
                    _buildChatHeader(),
                    Expanded(child: _buildMessagesList()),
                    if (_counterpartyTyping) _buildTypingIndicator(),
                    if (_showQuickResponses) _buildQuickResponses(),
                    if (_showEmojiPicker) _buildEmojiPicker(),
                    _buildMessageInput(),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildChatHeader() {
    return Container(
      padding: EdgeInsets.all(4.w),
      decoration: BoxDecoration(
        color: AppTheme.lightTheme.primaryColor,
        borderRadius: BorderRadius.vertical(top: Radius.circular(4.w)),
      ),
      child: Column(
        children: [
          // Close indicator
          Container(
            width: 12.w,
            height: 0.5.h,
            decoration: BoxDecoration(
              color: Colors.white.withValues(alpha: 0.5),
              borderRadius: BorderRadius.circular(4),
            ),
          ),
          SizedBox(height: 3.h),

          Row(
            children: [
              // Counterparty info
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Text(
                          _chatData['counterparty'] ?? 'Unknown Trader',
                          style: AppTheme.lightTheme.textTheme.titleLarge
                              ?.copyWith(
                            color: Colors.white,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                        if (_chatData['isVerified'] == true) ...[
                          SizedBox(width: 2.w),
                          CustomIconWidget(
                            iconName: 'verified',
                            color: Colors.white,
                            size: 5.w,
                          ),
                        ],
                      ],
                    ),
                    Text(
                      _chatData['adReference'] ?? 'P2P Trade',
                      style: AppTheme.lightTheme.textTheme.bodyMedium?.copyWith(
                        color: Colors.white.withValues(alpha: 0.8),
                      ),
                    ),
                    Text(
                      _connectionStatus,
                      style: AppTheme.lightTheme.textTheme.bodySmall?.copyWith(
                        color: Colors.white.withValues(alpha: 0.7),
                      ),
                    ),
                  ],
                ),
              ),

              // Call button
              Container(
                decoration: BoxDecoration(
                  color: Colors.white.withValues(alpha: 0.2),
                  borderRadius: BorderRadius.circular(3.w),
                ),
                child: IconButton(
                  onPressed: _initiateVoIPCall,
                  icon: CustomIconWidget(
                    iconName: 'phone',
                    color: Colors.white,
                    size: 6.w,
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildMessagesList() {
    return ListView.builder(
      controller: _scrollController,
      padding: EdgeInsets.all(4.w),
      itemCount: _messages.length,
      itemBuilder: (context, index) {
        final message = _messages[index];
        return MessageBubbleWidget(
          message: message,
          onLongPress: () => _showMessageOptions(message),
        );
      },
    );
  }

  Widget _buildTypingIndicator() {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 4.w, vertical: 1.h),
      child: Row(
        children: [
          const TypingIndicatorWidget(),
          SizedBox(width: 2.w),
          Text(
            '${_chatData['counterparty']} is typing...',
            style: AppTheme.lightTheme.textTheme.bodySmall?.copyWith(
              color: AppTheme.lightTheme.colorScheme.onSurfaceVariant,
              fontStyle: FontStyle.italic,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildQuickResponses() {
    return QuickResponseTemplatesWidget(
      onResponseSelected: (response) {
        _messageController.text = response;
        setState(() {
          _showQuickResponses = false;
        });
      },
    );
  }

  Widget _buildEmojiPicker() {
    return EmojiPickerWidget(
      onEmojiSelected: (emoji) {
        final text = _messageController.text;
        final selection = _messageController.selection;
        final newText =
            text.replaceRange(selection.start, selection.end, emoji);
        _messageController.text = newText;
        _messageController.selection = TextSelection.fromPosition(
          TextPosition(offset: selection.start + emoji.length),
        );
      },
    );
  }

  Widget _buildMessageInput() {
    return Container(
      padding: EdgeInsets.all(4.w),
      decoration: BoxDecoration(
        color: AppTheme.lightTheme.cardColor,
        border: Border(
          top: BorderSide(
            color:
                AppTheme.lightTheme.colorScheme.outline.withValues(alpha: 0.2),
          ),
        ),
      ),
      child: Column(
        children: [
          // Connection quality indicator
          if (!_isConnected) _buildConnectionIndicator(),

          SizedBox(height: 1.h),

          Row(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              // Emoji button
              IconButton(
                onPressed: () {
                  setState(() {
                    _showEmojiPicker = !_showEmojiPicker;
                    _showQuickResponses = false;
                  });
                  if (_showEmojiPicker) {
                    FocusScope.of(context).unfocus();
                  }
                },
                icon: CustomIconWidget(
                  iconName: 'emoji_emotions',
                  color: AppTheme.lightTheme.primaryColor,
                  size: 6.w,
                ),
              ),

              // Text input
              Expanded(
                child: Container(
                  constraints: BoxConstraints(maxHeight: 20.h),
                  padding: EdgeInsets.symmetric(horizontal: 3.w, vertical: 1.h),
                  decoration: BoxDecoration(
                    color:
                        AppTheme.lightTheme.colorScheme.surfaceContainerHighest,
                    borderRadius: BorderRadius.circular(6.w),
                  ),
                  child: TextField(
                    controller: _messageController,
                    focusNode: _messageFocusNode,
                    maxLines: null,
                    textInputAction: TextInputAction.newline,
                    onChanged: _handleTextChanged,
                    onTap: () {
                      setState(() {
                        _showEmojiPicker = false;
                        _showQuickResponses = false;
                      });
                    },
                    decoration: InputDecoration(
                      hintText: 'Type a message...',
                      border: InputBorder.none,
                      hintStyle:
                          AppTheme.lightTheme.textTheme.bodyMedium?.copyWith(
                        color: AppTheme.lightTheme.colorScheme.onSurfaceVariant,
                      ),
                    ),
                  ),
                ),
              ),

              SizedBox(width: 2.w),

              // Quick responses button
              IconButton(
                onPressed: () {
                  setState(() {
                    _showQuickResponses = !_showQuickResponses;
                    _showEmojiPicker = false;
                  });
                  if (_showQuickResponses) {
                    FocusScope.of(context).unfocus();
                  }
                },
                icon: CustomIconWidget(
                  iconName: 'quick_phrases',
                  color: AppTheme.lightTheme.colorScheme.onSurfaceVariant,
                  size: 5.w,
                ),
              ),

              // Send button
              Container(
                decoration: BoxDecoration(
                  color: _messageController.text.trim().isNotEmpty
                      ? AppTheme.lightTheme.primaryColor
                      : AppTheme.lightTheme.colorScheme.onSurfaceVariant
                          .withValues(alpha: 0.3),
                  shape: BoxShape.circle,
                ),
                child: IconButton(
                  onPressed: _messageController.text.trim().isNotEmpty
                      ? _sendMessage
                      : null,
                  icon: CustomIconWidget(
                    iconName: 'send',
                    color: Colors.white,
                    size: 5.w,
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildConnectionIndicator() {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 3.w, vertical: 1.h),
      decoration: BoxDecoration(
        color: AppTheme.lightTheme.colorScheme.errorContainer,
        borderRadius: BorderRadius.circular(2.w),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          CustomIconWidget(
            iconName: 'signal_wifi_off',
            color: AppTheme.lightTheme.colorScheme.error,
            size: 4.w,
          ),
          SizedBox(width: 2.w),
          Text(
            'Poor connection - messages may be delayed',
            style: AppTheme.lightTheme.textTheme.bodySmall?.copyWith(
              color: AppTheme.lightTheme.colorScheme.error,
            ),
          ),
        ],
      ),
    );
  }

  void _handleTextChanged(String text) {
    if (text.isNotEmpty && !_isTyping) {
      _isTyping = true;
      _socket?.emit('typing', {'conversationId': _conversationId});
    }

    _typingTimer?.cancel();
    _typingTimer = Timer(const Duration(seconds: 2), () {
      if (_isTyping) {
        _isTyping = false;
        _socket?.emit('stop_typing', {'conversationId': _conversationId});
      }
    });
  }

  void _sendMessage() {
    final text = _messageController.text.trim();
    if (text.isEmpty) return;

    final message = {
      'id': const Uuid().v4(),
      'text': text,
      'timestamp': DateTime.now(),
      'isMe': true,
      'isRead': false,
      'type': 'text',
      'conversationId': _conversationId,
    };

    setState(() {
      _messages.add(message);
    });

    _messageController.clear();
    _scrollToBottom();

    // Send via socket
    _socket?.emit('message', {
      'conversationId': _conversationId,
      'message': message,
    });

    // Add haptic feedback
    if (!kIsWeb) {
      HapticFeedback.lightImpact();
    }
  }

  void _handleIncomingMessage(dynamic data) {
    final message = data as Map<String, dynamic>;
    setState(() {
      _messages.add({
        ...message,
        'isMe': false,
        'timestamp': DateTime.parse(message['timestamp']),
      });
    });
    _scrollToBottom();
  }

  void _handleTypingIndicator(dynamic data, bool isTyping) {
    setState(() {
      _counterpartyTyping = isTyping;
    });
  }

  void _handleMessageRead(dynamic data) {
    final messageId = data['messageId'] as String;
    setState(() {
      _readMessages.add(messageId);
    });
  }

  void _scrollToBottom() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_scrollController.hasClients) {
        _scrollController.animateTo(
          _scrollController.position.maxScrollExtent,
          duration: const Duration(milliseconds: 300),
          curve: Curves.easeOut,
        );
      }
    });
  }

  void _initiateVoIPCall() {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => WebRTCVoiceCallInterface(
          counterparty: _chatData['counterparty'] ?? 'Unknown Trader',
          isVerified: _chatData['isVerified'] ?? false,
          conversationId: _conversationId,
        ),
      ),
    );
  }

  void _showMessageOptions(Map<String, dynamic> message) {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      builder: (context) => Container(
        decoration: BoxDecoration(
          color: AppTheme.lightTheme.cardColor,
          borderRadius: const BorderRadius.vertical(top: Radius.circular(20)),
        ),
        padding: EdgeInsets.all(6.w),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            _buildBottomSheetItem('Copy', 'content_copy', () {
              Clipboard.setData(ClipboardData(text: message['text']));
              Navigator.pop(context);
            }),
            _buildBottomSheetItem('Forward', 'forward', () {
              Navigator.pop(context);
            }),
            _buildBottomSheetItem('Report', 'report', () {
              Navigator.pop(context);
              _showReportDialog();
            }),
            _buildBottomSheetItem('Block User', 'block', () {
              Navigator.pop(context);
              _showBlockDialog();
            }),
          ],
        ),
      ),
    );
  }

  Widget _buildBottomSheetItem(
      String title, String iconName, VoidCallback onTap) {
    return ListTile(
      leading: CustomIconWidget(
        iconName: iconName,
        color: AppTheme.lightTheme.primaryColor,
        size: 24,
      ),
      title: Text(title),
      onTap: onTap,
    );
  }

  void _showReportDialog() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Report User'),
        content: const Text(
            'Are you sure you want to report this user for inappropriate behavior?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(context);
              // Handle report logic
            },
            child: const Text('Report'),
          ),
        ],
      ),
    );
  }

  void _showBlockDialog() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Block User'),
        content: const Text(
            'Are you sure you want to block this user? This will end the conversation.'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(context);
              Navigator.pop(context); // Close chat interface
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: AppTheme.lightTheme.colorScheme.error,
            ),
            child: const Text('Block'),
          ),
        ],
      ),
    );
  }
}
