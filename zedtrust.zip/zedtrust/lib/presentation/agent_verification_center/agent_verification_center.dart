import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:sizer/sizer.dart';

import '../../core/app_export.dart';
import '../../core/services/supabase_service.dart';
import './widgets/verification_queue_widget.dart';
import './widgets/document_viewer_modal.dart';
import './widgets/bulk_approval_widget.dart';
import './widgets/verification_filters_widget.dart';

class AgentVerificationCenter extends StatefulWidget {
  const AgentVerificationCenter({super.key});

  @override
  State<AgentVerificationCenter> createState() =>
      _AgentVerificationCenterState();
}

class _AgentVerificationCenterState extends State<AgentVerificationCenter>
    with TickerProviderStateMixin {
  final TextEditingController _searchController = TextEditingController();
  final SupabaseService _supabaseService = SupabaseService.instance;

  List<Map<String, dynamic>> _pendingApplications = [];
  List<Map<String, dynamic>> _filteredApplications = [];
  bool _isLoading = false;
  String _selectedFilter = 'all';
  String _selectedRegion = 'all';
  bool _showBulkActions = false;
  Set<String> _selectedApplicationIds = {};

  late AnimationController _fadeController;
  late Animation<double> _fadeAnimation;

  // Mock data for pending applications
  final List<Map<String, dynamic>> _mockApplications = [
    {
      'id': 'APP001',
      'agent_name': 'Rajesh Kumar',
      'application_date': '2025-08-20T10:30:00Z',
      'status': 'pending_review',
      'region': 'Mumbai',
      'verification_score': 85,
      'documents_count': 3,
      'identity_verified': true,
      'kyc_complete': false,
      'phone': '+91 9876543210',
      'email': 'rajesh.kumar@email.com',
      'documents': [
        {
          'type': 'id_card',
          'url':
              'https://images.unsplash.com/photo-1586953208448-b95a79798f07?w=400',
          'verified': true
        },
        {
          'type': 'business_license',
          'url':
              'https://images.unsplash.com/photo-1554224155-8d04cb21cd6c?w=400',
          'verified': false
        },
        {
          'type': 'address_proof',
          'url':
              'https://images.unsplash.com/photo-1586953208448-b95a79798f07?w=400',
          'verified': true
        },
      ],
    },
    {
      'id': 'APP002',
      'agent_name': 'Priya Sharma',
      'application_date': '2025-08-19T15:45:00Z',
      'status': 'pending_documents',
      'region': 'Delhi',
      'verification_score': 92,
      'documents_count': 4,
      'identity_verified': true,
      'kyc_complete': true,
      'phone': '+91 9876543211',
      'email': 'priya.sharma@email.com',
      'documents': [
        {
          'type': 'id_card',
          'url':
              'https://images.unsplash.com/photo-1586953208448-b95a79798f07?w=400',
          'verified': true
        },
        {
          'type': 'business_license',
          'url':
              'https://images.unsplash.com/photo-1554224155-8d04cb21cd6c?w=400',
          'verified': true
        },
        {
          'type': 'address_proof',
          'url':
              'https://images.unsplash.com/photo-1586953208448-b95a79798f07?w=400',
          'verified': true
        },
        {
          'type': 'bank_statement',
          'url':
              'https://images.unsplash.com/photo-1554224155-8d04cb21cd6c?w=400',
          'verified': true
        },
      ],
    },
    {
      'id': 'APP003',
      'agent_name': 'Arjun Patel',
      'application_date': '2025-08-18T09:15:00Z',
      'status': 'compliance_check',
      'region': 'Surat',
      'verification_score': 78,
      'documents_count': 3,
      'identity_verified': false,
      'kyc_complete': true,
      'phone': '+91 9876543212',
      'email': 'arjun.patel@email.com',
      'documents': [
        {
          'type': 'id_card',
          'url':
              'https://images.unsplash.com/photo-1586953208448-b95a79798f07?w=400',
          'verified': false
        },
        {
          'type': 'business_license',
          'url':
              'https://images.unsplash.com/photo-1554224155-8d04cb21cd6c?w=400',
          'verified': true
        },
        {
          'type': 'address_proof',
          'url':
              'https://images.unsplash.com/photo-1586953208448-b95a79798f07?w=400',
          'verified': true
        },
      ],
    },
  ];

  @override
  void initState() {
    super.initState();
    _fadeController = AnimationController(
      duration: const Duration(milliseconds: 800),
      vsync: this,
    );
    _fadeAnimation = CurvedAnimation(
      parent: _fadeController,
      curve: Curves.easeInOut,
    );
    _loadPendingApplications();
    _fadeController.forward();
  }

  @override
  void dispose() {
    _fadeController.dispose();
    _searchController.dispose();
    super.dispose();
  }

  Future<void> _loadPendingApplications() async {
    setState(() => _isLoading = true);

    try {
      // Simulate API call - replace with actual Supabase call
      await Future.delayed(const Duration(seconds: 1));
      setState(() {
        _pendingApplications = _mockApplications;
        _filteredApplications = _mockApplications;
        _isLoading = false;
      });
    } catch (e) {
      setState(() => _isLoading = false);
      _showErrorToast('Failed to load applications: $e');
    }
  }

  void _filterApplications() {
    setState(() {
      _filteredApplications = _pendingApplications.where((app) {
        final matchesSearch = app['agent_name']
            .toString()
            .toLowerCase()
            .contains(_searchController.text.toLowerCase());

        final matchesFilter = _selectedFilter == 'all' ||
            (_selectedFilter == 'pending_review' &&
                app['status'] == 'pending_review') ||
            (_selectedFilter == 'high_score' &&
                app['verification_score'] >= 90) ||
            (_selectedFilter == 'needs_attention' &&
                (app['identity_verified'] == false ||
                    app['kyc_complete'] == false));

        final matchesRegion =
            _selectedRegion == 'all' || app['region'] == _selectedRegion;

        return matchesSearch && matchesFilter && matchesRegion;
      }).toList();
    });
  }

  void _toggleBulkSelection(String applicationId) {
    setState(() {
      if (_selectedApplicationIds.contains(applicationId)) {
        _selectedApplicationIds.remove(applicationId);
      } else {
        _selectedApplicationIds.add(applicationId);
      }
      _showBulkActions = _selectedApplicationIds.isNotEmpty;
    });
  }

  Future<void> _approveApplication(String applicationId) async {
    try {
      // Simulate approval process
      await Future.delayed(const Duration(milliseconds: 500));

      setState(() {
        _pendingApplications.removeWhere((app) => app['id'] == applicationId);
        _filteredApplications.removeWhere((app) => app['id'] == applicationId);
      });

      _showSuccessToast('Application approved successfully');
    } catch (e) {
      _showErrorToast('Failed to approve application: $e');
    }
  }

  Future<void> _rejectApplication(String applicationId, String reason) async {
    try {
      // Simulate rejection process
      await Future.delayed(const Duration(milliseconds: 500));

      setState(() {
        _pendingApplications.removeWhere((app) => app['id'] == applicationId);
        _filteredApplications.removeWhere((app) => app['id'] == applicationId);
      });

      _showSuccessToast('Application rejected');
    } catch (e) {
      _showErrorToast('Failed to reject application: $e');
    }
  }

  Future<void> _bulkApproveApplications() async {
    try {
      for (final appId in _selectedApplicationIds) {
        await Future.delayed(const Duration(milliseconds: 100));
        _pendingApplications.removeWhere((app) => app['id'] == appId);
        _filteredApplications.removeWhere((app) => app['id'] == appId);
      }

      _showSuccessToast(
          '${_selectedApplicationIds.length} applications approved');
      setState(() {
        _selectedApplicationIds.clear();
        _showBulkActions = false;
      });
    } catch (e) {
      _showErrorToast('Failed to bulk approve: $e');
    }
  }

  void _showErrorToast(String message) {
    Fluttertoast.showToast(
      msg: message,
      toastLength: Toast.LENGTH_LONG,
      backgroundColor: AppTheme.errorLight,
      textColor: Colors.white,
    );
  }

  void _showSuccessToast(String message) {
    Fluttertoast.showToast(
      msg: message,
      toastLength: Toast.LENGTH_SHORT,
      backgroundColor: AppTheme.successLight,
      textColor: Colors.white,
    );
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;

    return Scaffold(
      backgroundColor: Theme.of(context).scaffoldBackgroundColor,
      appBar: AppBar(
        title: Text(
          'Verification Center',
          style: GoogleFonts.inter(
            fontSize: 18.sp,
            fontWeight: FontWeight.w600,
            color: Theme.of(context).textTheme.titleLarge?.color,
          ),
        ),
        centerTitle: true,
        elevation: 0,
        backgroundColor: Theme.of(context).scaffoldBackgroundColor,
        leading: IconButton(
          onPressed: () => Navigator.pop(context),
          icon: Icon(
            Icons.arrow_back_ios,
            color: Theme.of(context).iconTheme.color,
            size: 20.sp,
          ),
        ),
        actions: [
          IconButton(
            onPressed: _loadPendingApplications,
            icon: CustomIconWidget(
              iconName: 'refresh',
              color: Theme.of(context).iconTheme.color,
              size: 24,
            ),
          ),
          SizedBox(width: 16.w),
        ],
      ),
      body: FadeTransition(
        opacity: _fadeAnimation,
        child: SafeArea(
          child: Column(
            children: [
              // Statistics Header
              Container(
                padding: EdgeInsets.all(16.sp),
                decoration: BoxDecoration(
                  color: AppTheme.primaryLight.withAlpha(26),
                  border: Border(
                    bottom: BorderSide(
                      color: AppTheme.getNeutralColor(!isDark),
                      width: 0.5,
                    ),
                  ),
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                  children: [
                    _buildStatItem('Pending', '${_pendingApplications.length}',
                        AppTheme.warningLight),
                    _buildStatItem(
                        'High Score',
                        '${_pendingApplications.where((app) => app['verification_score'] >= 90).length}',
                        AppTheme.successLight),
                    _buildStatItem(
                        'Need Review',
                        '${_pendingApplications.where((app) => app['identity_verified'] == false).length}',
                        AppTheme.errorLight),
                  ],
                ),
              ),

              // Search and Filter Bar
              Container(
                padding: EdgeInsets.all(16.sp),
                decoration: BoxDecoration(
                  color: Theme.of(context).cardColor,
                  boxShadow: [
                    BoxShadow(
                      color: AppTheme.shadowLight,
                      blurRadius: 4,
                      offset: const Offset(0, 1),
                    ),
                  ],
                ),
                child: Column(
                  children: [
                    // Search Bar
                    Container(
                      decoration: BoxDecoration(
                        color:
                            isDark ? AppTheme.cardDark : AppTheme.surfaceLight,
                        borderRadius: BorderRadius.circular(12.sp),
                        border: Border.all(
                          color: AppTheme.getNeutralColor(!isDark),
                        ),
                      ),
                      child: TextField(
                        controller: _searchController,
                        onChanged: (_) => _filterApplications(),
                        decoration: InputDecoration(
                          hintText: 'Search applications by agent name...',
                          prefixIcon: Icon(
                            Icons.search,
                            color: AppTheme.textSecondaryLight,
                            size: 20.sp,
                          ),
                          border: InputBorder.none,
                          contentPadding: EdgeInsets.symmetric(
                            horizontal: 16.w,
                            vertical: 12.h,
                          ),
                        ),
                      ),
                    ),

                    SizedBox(height: 12.h),

                    // Filter Chips
                    VerificationFiltersWidget(
                      selectedFilter: _selectedFilter,
                      selectedRegion: _selectedRegion,
                      onFilterChanged: (filter) {
                        setState(() => _selectedFilter = filter);
                        _filterApplications();
                      },
                      onRegionChanged: (region) {
                        setState(() => _selectedRegion = region);
                        _filterApplications();
                      },
                    ),
                  ],
                ),
              ),

              // Bulk Actions
              if (_showBulkActions)
                BulkApprovalWidget(
                  selectedCount: _selectedApplicationIds.length,
                  onApproveAll: _bulkApproveApplications,
                  onClearSelection: () {
                    setState(() {
                      _selectedApplicationIds.clear();
                      _showBulkActions = false;
                    });
                  },
                ),

              // Applications Queue
              Expanded(
                child: _isLoading
                    ? const Center(child: CircularProgressIndicator())
                    : _filteredApplications.isEmpty
                        ? _buildEmptyState()
                        : RefreshIndicator(
                            onRefresh: _loadPendingApplications,
                            child: VerificationQueueWidget(
                              applications: _filteredApplications,
                              selectedIds: _selectedApplicationIds,
                              onApplicationTap: _showApplicationDetails,
                              onLongPress: _toggleBulkSelection,
                              onApprove: _approveApplication,
                              onReject: _rejectApplication,
                            ),
                          ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildStatItem(String label, String value, Color color) {
    return Column(
      children: [
        Container(
          padding: EdgeInsets.all(8.sp),
          decoration: BoxDecoration(
            color: color.withAlpha(26),
            borderRadius: BorderRadius.circular(8.sp),
          ),
          child: Text(
            value,
            style: GoogleFonts.inter(
              fontSize: 18.sp,
              fontWeight: FontWeight.w700,
              color: color,
            ),
          ),
        ),
        SizedBox(height: 4.h),
        Text(
          label,
          style: GoogleFonts.inter(
            fontSize: 12.sp,
            color: AppTheme.textSecondaryLight,
          ),
        ),
      ],
    );
  }

  Widget _buildEmptyState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          CustomIconWidget(
            iconName: 'verified_user',
            color: AppTheme.textSecondaryLight,
            size: 64,
          ),
          SizedBox(height: 24.h),
          Text(
            'No Pending Applications',
            style: GoogleFonts.inter(
              fontSize: 18.sp,
              fontWeight: FontWeight.w600,
              color: AppTheme.textPrimaryLight,
            ),
          ),
          SizedBox(height: 8.h),
          Text(
            'All applications have been processed',
            style: GoogleFonts.inter(
              fontSize: 14.sp,
              color: AppTheme.textSecondaryLight,
            ),
          ),
        ],
      ),
    );
  }

  void _showApplicationDetails(Map<String, dynamic> application) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) => DocumentViewerModal(
        application: application,
        onApprove: () {
          Navigator.pop(context);
          _approveApplication(application['id']);
        },
        onReject: (reason) {
          Navigator.pop(context);
          _rejectApplication(application['id'], reason);
        },
        onRequestDocuments: () {
          Navigator.pop(context);
          _requestAdditionalDocuments(application['id']);
        },
      ),
    );
  }

  void _requestAdditionalDocuments(String applicationId) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(
          'Request Additional Documents',
          style: GoogleFonts.inter(
            fontWeight: FontWeight.w600,
          ),
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              'Send a message to the applicant requesting additional documentation.',
              style: GoogleFonts.inter(fontSize: 14.sp),
            ),
            SizedBox(height: 16.h),
            TextField(
              maxLines: 3,
              decoration: InputDecoration(
                hintText: 'Enter your message...',
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(8.sp),
                ),
              ),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(context);
              _showSuccessToast('Document request sent');
            },
            child: Text('Send Request'),
          ),
        ],
      ),
    );
  }
}
