import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';
import 'package:google_fonts/google_fonts.dart'; // Add this import
import '../../../core/services/zotrust_smart_contract_service.dart';

class NetworkStatusWidget extends StatefulWidget {
  final Map<String, dynamic>? contractStats;

  const NetworkStatusWidget({
    super.key,
    this.contractStats,
  });

  @override
  State<NetworkStatusWidget> createState() => _NetworkStatusWidgetState();
}

class _NetworkStatusWidgetState extends State<NetworkStatusWidget>
    with SingleTickerProviderStateMixin {
  late AnimationController _pulseController;
  Map<String, dynamic>? _connectionTest;
  bool _isTestingConnection = false;

  @override
  void initState() {
    super.initState();
    _pulseController = AnimationController(
      duration: const Duration(seconds: 2),
      vsync: this,
    );
    _pulseController.repeat();
    _testConnection();
  }

  @override
  void dispose() {
    _pulseController.dispose();
    super.dispose();
  }

  Future<void> _testConnection() async {
    setState(() => _isTestingConnection = true);

    try {
      final test = await ZoTrustSmartContractService.instance.testConnection();
      setState(() {
        _connectionTest = test;
        _isTestingConnection = false;
      });
    } catch (e) {
      setState(() {
        _connectionTest = {
          'success': false,
          'error': e.toString(),
          'fallbackMode': true,
        };
        _isTestingConnection = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: EdgeInsets.symmetric(horizontal: 4.w, vertical: 1.w),
      padding: EdgeInsets.all(3.w),
      decoration: BoxDecoration(
        color: Colors.grey.shade900.withAlpha(128),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: _getStatusColor().withAlpha(77),
          width: 1,
        ),
      ),
      child: Row(
        children: [
          _buildStatusIndicator(),
          SizedBox(width: 3.w),
          Expanded(
            child: _buildStatusInfo(),
          ),
          _buildRefreshButton(),
        ],
      ),
    );
  }

  Widget _buildStatusIndicator() {
    return AnimatedBuilder(
      animation: _pulseController,
      builder: (context, child) {
        return Container(
          width: 3.w,
          height: 3.w,
          decoration: BoxDecoration(
            color: _getStatusColor(),
            shape: BoxShape.circle,
            boxShadow: [
              BoxShadow(
                color:
                    _getStatusColor().withOpacity(0.6 * _pulseController.value),
                blurRadius: 8 * _pulseController.value,
                spreadRadius: 2 * _pulseController.value,
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _buildStatusInfo() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          _getStatusText(),
          style: GoogleFonts.inter(
            fontSize: 11.sp,
            fontWeight: FontWeight.w600,
            color: Colors.white,
          ),
        ),
        if (_connectionTest != null) ...[
          Text(
            _getSubStatusText(),
            style: GoogleFonts.inter(
              fontSize: 9.sp,
              color: Colors.grey.shade400,
            ),
          ),
        ],
      ],
    );
  }

  Widget _buildRefreshButton() {
    if (_isTestingConnection) {
      return SizedBox(
        width: 4.w,
        height: 4.w,
        child: CircularProgressIndicator(
          strokeWidth: 2,
          valueColor: AlwaysStoppedAnimation<Color>(Colors.cyan.shade400),
        ),
      );
    }

    return GestureDetector(
      onTap: _testConnection,
      child: Icon(
        Icons.refresh,
        color: Colors.grey.shade400,
        size: 4.w,
      ),
    );
  }

  Color _getStatusColor() {
    if (_isTestingConnection) {
      return Colors.yellow.shade400;
    }

    if (_connectionTest == null) {
      return Colors.grey.shade400;
    }

    if (_connectionTest!['success'] == true) {
      return Colors.green.shade400;
    } else if (_connectionTest!['fallbackMode'] == true) {
      return Colors.orange.shade400;
    } else {
      return Colors.red.shade400;
    }
  }

  String _getStatusText() {
    if (_isTestingConnection) {
      return 'Testing Network...';
    }

    if (_connectionTest == null) {
      return 'Network Status Unknown';
    }

    if (_connectionTest!['success'] == true) {
      return 'Polygon Amoy Connected';
    } else if (_connectionTest!['fallbackMode'] == true) {
      return 'Demo Mode Active';
    } else {
      return 'Network Connection Failed';
    }
  }

  String _getSubStatusText() {
    if (_connectionTest == null || _isTestingConnection) {
      return 'Checking blockchain connectivity...';
    }

    if (_connectionTest!['success'] == true) {
      final blockNumber = _connectionTest!['blockNumber'];
      final gasPrice = _connectionTest!['gasPrice'];
      return 'Block $blockNumber • Gas: $gasPrice';
    } else if (_connectionTest!['fallbackMode'] == true) {
      return 'Using mock data • Real blockchain unavailable';
    } else {
      return 'Unable to connect to blockchain network';
    }
  }
}