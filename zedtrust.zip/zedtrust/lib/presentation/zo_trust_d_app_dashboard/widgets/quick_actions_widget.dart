import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';
import 'package:google_fonts/google_fonts.dart'; // Add this import

class QuickActionsWidget extends StatelessWidget {
  final VoidCallback onNewTrade;

  const QuickActionsWidget({
    super.key,
    required this.onNewTrade,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _buildHeader(),
        SizedBox(height: 3.w),
        _buildActionsGrid(),
      ],
    );
  }

  Widget _buildHeader() {
    return Text(
      'Quick Actions',
      style: GoogleFonts.inter(
        fontSize: 18.sp,
        fontWeight: FontWeight.bold,
        color: Colors.white,
      ),
    );
  }

  Widget _buildActionsGrid() {
    return Row(
      children: [
        Expanded(
          child: _buildActionCard(
            'New Trade',
            'Start escrow trade',
            Icons.add_circle,
            Colors.cyan.shade400,
            onNewTrade,
          ),
        ),
        SizedBox(width: 3.w),
        Expanded(
          child: _buildActionCard(
            'Buy Crypto',
            'Purchase tokens',
            Icons.shopping_cart,
            Colors.green.shade400,
            () => _showComingSoon(),
          ),
        ),
        SizedBox(width: 3.w),
        Expanded(
          child: _buildActionCard(
            'Sell Crypto',
            'Sell tokens',
            Icons.sell,
            Colors.orange.shade400,
            () => _showComingSoon(),
          ),
        ),
      ],
    );
  }

  Widget _buildActionCard(
    String title,
    String subtitle,
    IconData icon,
    Color color,
    VoidCallback onTap,
  ) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: EdgeInsets.all(4.w),
        decoration: BoxDecoration(
          color: Colors.grey.shade900,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(
            color: color.withAlpha(77),
            width: 1,
          ),
          boxShadow: [
            BoxShadow(
              color: color.withAlpha(26),
              blurRadius: 10,
              offset: const Offset(0, 5),
            ),
          ],
        ),
        child: Column(
          children: [
            Container(
              padding: EdgeInsets.all(3.w),
              decoration: BoxDecoration(
                color: color.withAlpha(26),
                borderRadius: BorderRadius.circular(12),
              ),
              child: Icon(
                icon,
                color: color,
                size: 6.w,
              ),
            ),
            SizedBox(height: 3.w),
            Text(
              title,
              style: GoogleFonts.inter(
                fontSize: 12.sp,
                fontWeight: FontWeight.w600,
                color: Colors.white,
              ),
              textAlign: TextAlign.center,
            ),
            SizedBox(height: 1.w),
            Text(
              subtitle,
              style: GoogleFonts.inter(
                fontSize: 9.sp,
                color: Colors.grey.shade400,
              ),
              textAlign: TextAlign.center,
            ),
          ],
        ),
      ),
    );
  }

  void _showComingSoon() {
    // Method implementation will need context to be passed when called
    // This is a placeholder that won't be called without proper context
  }
}