import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';
import 'package:google_fonts/google_fonts.dart';
import '../../../core/services/web3_wallet_service.dart';

class BalanceOverviewWidget extends StatefulWidget {
  final Map<String, dynamic>? contractStats;

  const BalanceOverviewWidget({
    super.key,
    this.contractStats,
  });

  @override
  State<BalanceOverviewWidget> createState() => _BalanceOverviewWidgetState();
}

class _BalanceOverviewWidgetState extends State<BalanceOverviewWidget> {
  WalletBalance? _balance;

  @override
  void initState() {
    super.initState();
    _setupBalanceListener();
  }

  void _setupBalanceListener() {
    Web3WalletService.instance.balanceStream.listen((balance) {
      if (mounted) {
        setState(() => _balance = balance);
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.all(6.w),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [Colors.indigo.shade800, Colors.purple.shade600],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(20),
        boxShadow: [
          BoxShadow(
            color: Colors.indigo.shade600.withAlpha(77),
            blurRadius: 20,
            offset: const Offset(0, 10),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _buildHeader(),
          SizedBox(height: 4.w),
          _buildMainBalance(),
          SizedBox(height: 4.w),
          _buildStatsGrid(),
        ],
      ),
    );
  }

  Widget _buildHeader() {
    return Row(
      children: [
        Container(
          padding: EdgeInsets.all(3.w),
          decoration: BoxDecoration(
            color: Colors.white.withAlpha(51),
            borderRadius: BorderRadius.circular(12),
          ),
          child: Icon(
            Icons.account_balance,
            color: Colors.white,
            size: 6.w,
          ),
        ),
        SizedBox(width: 4.w),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'Portfolio Balance',
                style: GoogleFonts.inter(
                  fontSize: 16.sp,
                  fontWeight: FontWeight.w600,
                  color: Colors.white,
                ),
              ),
              Text(
                'Real-time blockchain sync',
                style: GoogleFonts.inter(
                  fontSize: 11.sp,
                  color: Colors.white70,
                ),
              ),
            ],
          ),
        ),
        GestureDetector(
          onTap: () => Web3WalletService.instance.refreshBalance(),
          child: Container(
            padding: EdgeInsets.all(2.w),
            decoration: BoxDecoration(
              color: Colors.white.withAlpha(26),
              borderRadius: BorderRadius.circular(8),
            ),
            child: Icon(
              Icons.refresh,
              color: Colors.white,
              size: 5.w,
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildMainBalance() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        if (_balance != null) ...[
          Text(
            '${_balance!.formatted} ${_balance!.symbol}',
            style: GoogleFonts.inter(
              fontSize: 32.sp,
              fontWeight: FontWeight.bold,
              color: Colors.white,
              height: 1.0,
            ),
          ),
          SizedBox(height: 2.w),
          Row(
            children: [
              Icon(
                Icons.trending_up,
                color: Colors.green.shade300,
                size: 4.w,
              ),
              SizedBox(width: 2.w),
              Text(
                '\$${(_balance!.asDouble * 0.65).toStringAsFixed(2)} USD',
                style: GoogleFonts.inter(
                  fontSize: 16.sp,
                  fontWeight: FontWeight.w600,
                  color: Colors.green.shade300,
                ),
              ),
              SizedBox(width: 2.w),
              Container(
                padding: EdgeInsets.symmetric(horizontal: 2.w, vertical: 1.w),
                decoration: BoxDecoration(
                  color: Colors.green.shade400.withAlpha(51),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Text(
                  '+2.5%',
                  style: GoogleFonts.inter(
                    fontSize: 10.sp,
                    fontWeight: FontWeight.w600,
                    color: Colors.green.shade300,
                  ),
                ),
              ),
            ],
          ),
        ] else ...[
          Container(
            height: 8.w,
            width: 60.w,
            decoration: BoxDecoration(
              color: Colors.white.withAlpha(26),
              borderRadius: BorderRadius.circular(8),
            ),
          ),
          SizedBox(height: 2.w),
          Container(
            height: 4.w,
            width: 40.w,
            decoration: BoxDecoration(
              color: Colors.white.withAlpha(26),
              borderRadius: BorderRadius.circular(6),
            ),
          ),
        ],
      ],
    );
  }

  Widget _buildStatsGrid() {
    return Row(
      children: [
        Expanded(
          child: _buildStatCard(
            'Total Trades',
            widget.contractStats?['totalTrades'] ?? '-',
            Icons.swap_horiz,
            Colors.cyan.shade400,
          ),
        ),
        SizedBox(width: 3.w),
        Expanded(
          child: _buildStatCard(
            'Active',
            widget.contractStats?['activeTrades']?.toString() ?? '-',
            Icons.access_time,
            Colors.orange.shade400,
          ),
        ),
        SizedBox(width: 3.w),
        Expanded(
          child: _buildStatCard(
            'Volume',
            widget.contractStats?['totalVolume'] != null
                ? '\$${widget.contractStats!['totalVolume']}'
                : '-',
            Icons.bar_chart,
            Colors.green.shade400,
          ),
        ),
      ],
    );
  }

  Widget _buildStatCard(
      String label, String value, IconData icon, Color color) {
    return Container(
      padding: EdgeInsets.all(3.w),
      decoration: BoxDecoration(
        color: Colors.white.withAlpha(26),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: color.withAlpha(77),
          width: 1,
        ),
      ),
      child: Column(
        children: [
          Icon(
            icon,
            color: color,
            size: 5.w,
          ),
          SizedBox(height: 2.w),
          Text(
            value,
            style: GoogleFonts.inter(
              fontSize: 14.sp,
              fontWeight: FontWeight.bold,
              color: Colors.white,
            ),
          ),
          SizedBox(height: 1.w),
          Text(
            label,
            style: GoogleFonts.inter(
              fontSize: 10.sp,
              color: Colors.white70,
            ),
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }
}