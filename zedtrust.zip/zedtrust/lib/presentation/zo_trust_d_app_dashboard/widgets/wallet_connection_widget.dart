import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';
import 'package:google_fonts/google_fonts.dart'; // Add this import
import '../../../core/services/web3_wallet_service.dart';

class WalletConnectionWidget extends StatefulWidget {
  final VoidCallback? onRefresh;

  const WalletConnectionWidget({
    super.key,
    this.onRefresh,
  });

  @override
  State<WalletConnectionWidget> createState() => _WalletConnectionWidgetState();
}

class _WalletConnectionWidgetState extends State<WalletConnectionWidget>
    with SingleTickerProviderStateMixin {
  late AnimationController _animationController;
  WalletConnectionStatus _status = WalletConnectionStatus.disconnected;
  ConnectedWallet? _wallet;
  WalletBalance? _balance;

  @override
  void initState() {
    super.initState();
    _animationController = AnimationController(
      duration: const Duration(milliseconds: 1500),
      vsync: this,
    );

    _setupListeners();
    _loadInitialState();
  }

  @override
  void dispose() {
    _animationController.dispose();
    super.dispose();
  }

  void _setupListeners() {
    Web3WalletService.instance.statusStream.listen((status) {
      if (mounted) {
        setState(() => _status = status);
        if (status == WalletConnectionStatus.connecting) {
          _animationController.repeat();
        } else {
          _animationController.stop();
        }
      }
    });

    Web3WalletService.instance.walletStream.listen((wallet) {
      if (mounted) {
        setState(() => _wallet = wallet);
      }
    });

    Web3WalletService.instance.balanceStream.listen((balance) {
      if (mounted) {
        setState(() => _balance = balance);
      }
    });
  }

  void _loadInitialState() {
    setState(() {
      _status = Web3WalletService.instance.connectionStatus;
      _wallet = Web3WalletService.instance.connectedWallet;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: EdgeInsets.symmetric(horizontal: 4.w, vertical: 2.w),
      padding: EdgeInsets.all(4.w),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [Colors.grey.shade900, Colors.grey.shade800],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: _getStatusColor().withAlpha(77),
          width: 1,
        ),
      ),
      child: _buildContent(),
    );
  }

  Widget _buildContent() {
    switch (_status) {
      case WalletConnectionStatus.disconnected:
        return _buildDisconnectedState();
      case WalletConnectionStatus.connecting:
        return _buildConnectingState();
      case WalletConnectionStatus.connected:
        return _buildConnectedState();
      case WalletConnectionStatus.failed:
        return _buildFailedState();
    }
  }

  Widget _buildDisconnectedState() {
    return Column(
      children: [
        Row(
          children: [
            Icon(
              Icons.account_balance_wallet_outlined,
              color: Colors.grey.shade400,
              size: 6.w,
            ),
            SizedBox(width: 3.w),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Connect Wallet',
                    style: GoogleFonts.inter(
                      fontSize: 16.sp,
                      fontWeight: FontWeight.w600,
                      color: Colors.white,
                    ),
                  ),
                  Text(
                    'Connect MetaMask or Trust Wallet to start trading',
                    style: GoogleFonts.inter(
                      fontSize: 11.sp,
                      color: Colors.grey.shade400,
                    ),
                  ),
                ],
              ),
            ),
            Container(
              width: 10.w,
              height: 10.w,
              decoration: BoxDecoration(
                color: Colors.grey.shade700,
                shape: BoxShape.circle,
              ),
              child: Icon(
                Icons.power_settings_new,
                color: Colors.grey.shade400,
                size: 5.w,
              ),
            ),
          ],
        ),
        SizedBox(height: 4.w),
        _buildWalletButtons(),
      ],
    );
  }

  Widget _buildConnectingState() {
    return Row(
      children: [
        RotationTransition(
          turns: _animationController,
          child: Icon(
            Icons.sync,
            color: Colors.cyan.shade400,
            size: 6.w,
          ),
        ),
        SizedBox(width: 3.w),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'Connecting Wallet...',
                style: GoogleFonts.inter(
                  fontSize: 16.sp,
                  fontWeight: FontWeight.w600,
                  color: Colors.white,
                ),
              ),
              Text(
                'Please check your wallet app',
                style: GoogleFonts.inter(
                  fontSize: 11.sp,
                  color: Colors.cyan.shade300,
                ),
              ),
            ],
          ),
        ),
        Container(
          width: 10.w,
          height: 10.w,
          decoration: BoxDecoration(
            color: Colors.cyan.shade400.withAlpha(51),
            shape: BoxShape.circle,
          ),
          child: Center(
            child: SizedBox(
              width: 5.w,
              height: 5.w,
              child: CircularProgressIndicator(
                valueColor: AlwaysStoppedAnimation<Color>(Colors.cyan.shade400),
                strokeWidth: 2,
              ),
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildConnectedState() {
    return Column(
      children: [
        Row(
          children: [
            Container(
              padding: EdgeInsets.all(2.w),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [Colors.green.shade400, Colors.cyan.shade400],
                ),
                shape: BoxShape.circle,
              ),
              child: Icon(
                _wallet?.type == WalletType.metamask
                    ? Icons.account_balance_wallet
                    : Icons.security,
                color: Colors.white,
                size: 4.w,
              ),
            ),
            SizedBox(width: 3.w),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    '${_wallet?.type.name.toUpperCase()} Connected',
                    style: GoogleFonts.inter(
                      fontSize: 14.sp,
                      fontWeight: FontWeight.w600,
                      color: Colors.white,
                    ),
                  ),
                  GestureDetector(
                    onTap: _copyAddress,
                    child: Row(
                      children: [
                        Text(
                          Web3WalletService.instance.truncatedAddress,
                          style: GoogleFonts.inter(
                            fontSize: 11.sp,
                            color: Colors.cyan.shade400,
                          ),
                        ),
                        SizedBox(width: 2.w),
                        Icon(
                          Icons.copy,
                          size: 3.w,
                          color: Colors.cyan.shade400,
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            GestureDetector(
              onTap: _refreshBalance,
              child: Container(
                width: 10.w,
                height: 10.w,
                decoration: BoxDecoration(
                  color: Colors.green.shade400.withAlpha(51),
                  shape: BoxShape.circle,
                ),
                child: Icon(
                  Icons.refresh,
                  color: Colors.green.shade400,
                  size: 5.w,
                ),
              ),
            ),
          ],
        ),
        if (_balance != null) ...[
          SizedBox(height: 3.w),
          _buildBalanceDisplay(),
        ],
        SizedBox(height: 3.w),
        _buildConnectedActions(),
      ],
    );
  }

  Widget _buildFailedState() {
    return Row(
      children: [
        Icon(
          Icons.error_outline,
          color: Colors.red.shade400,
          size: 6.w,
        ),
        SizedBox(width: 3.w),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'Connection Failed',
                style: GoogleFonts.inter(
                  fontSize: 16.sp,
                  fontWeight: FontWeight.w600,
                  color: Colors.white,
                ),
              ),
              Text(
                'Please try connecting again',
                style: GoogleFonts.inter(
                  fontSize: 11.sp,
                  color: Colors.red.shade300,
                ),
              ),
            ],
          ),
        ),
        TextButton(
          onPressed: () => _connectWallet(WalletType.metamask),
          child: Text(
            'Retry',
            style: GoogleFonts.inter(
              color: Colors.red.shade400,
              fontWeight: FontWeight.w600,
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildWalletButtons() {
    return Row(
      children: [
        Expanded(
          child: _buildWalletButton(
            'MetaMask',
            Icons.account_balance_wallet,
            Colors.orange.shade600,
            () => _connectWallet(WalletType.metamask),
          ),
        ),
        SizedBox(width: 3.w),
        Expanded(
          child: _buildWalletButton(
            'Trust',
            Icons.security,
            Colors.blue.shade600,
            () => _connectWallet(WalletType.trustWallet),
          ),
        ),
      ],
    );
  }

  Widget _buildWalletButton(
      String name, IconData icon, Color color, VoidCallback onTap) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: EdgeInsets.symmetric(vertical: 3.w, horizontal: 4.w),
        decoration: BoxDecoration(
          color: color.withAlpha(26),
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: color.withAlpha(77)),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, color: color, size: 5.w),
            SizedBox(width: 2.w),
            Text(
              name,
              style: GoogleFonts.inter(
                fontSize: 12.sp,
                fontWeight: FontWeight.w600,
                color: color,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildBalanceDisplay() {
    return Container(
      padding: EdgeInsets.all(3.w),
      decoration: BoxDecoration(
        color: Colors.black.withAlpha(77),
        borderRadius: BorderRadius.circular(12),
      ),
      child: Row(
        children: [
          Icon(
            Icons.account_balance,
            color: Colors.cyan.shade400,
            size: 5.w,
          ),
          SizedBox(width: 3.w),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  '${_balance!.formatted} ${_balance!.symbol}',
                  style: GoogleFonts.inter(
                    fontSize: 16.sp,
                    fontWeight: FontWeight.bold,
                    color: Colors.white,
                  ),
                ),
                Text(
                  'Available Balance',
                  style: GoogleFonts.inter(
                    fontSize: 10.sp,
                    color: Colors.grey.shade400,
                  ),
                ),
              ],
            ),
          ),
          Text(
            '\$${(_balance!.asDouble * 0.65).toStringAsFixed(2)}', // Mock USD value
            style: GoogleFonts.inter(
              fontSize: 14.sp,
              fontWeight: FontWeight.w600,
              color: Colors.green.shade400,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildConnectedActions() {
    return Row(
      children: [
        Expanded(
          child: _buildActionButton(
            'Disconnect',
            Icons.power_settings_new,
            Colors.red.shade400,
            _disconnect,
          ),
        ),
        SizedBox(width: 3.w),
        Expanded(
          child: _buildActionButton(
            'Refresh',
            Icons.refresh,
            Colors.cyan.shade400,
            _refreshBalance,
          ),
        ),
      ],
    );
  }

  Widget _buildActionButton(
      String label, IconData icon, Color color, VoidCallback onTap) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: EdgeInsets.symmetric(vertical: 2.w),
        decoration: BoxDecoration(
          color: color.withAlpha(26),
          borderRadius: BorderRadius.circular(8),
          border: Border.all(color: color.withAlpha(77)),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, color: color, size: 4.w),
            SizedBox(width: 2.w),
            Text(
              label,
              style: GoogleFonts.inter(
                fontSize: 11.sp,
                fontWeight: FontWeight.w500,
                color: color,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Color _getStatusColor() {
    switch (_status) {
      case WalletConnectionStatus.disconnected:
        return Colors.grey;
      case WalletConnectionStatus.connecting:
        return Colors.cyan;
      case WalletConnectionStatus.connected:
        return Colors.green;
      case WalletConnectionStatus.failed:
        return Colors.red;
    }
  }

  Future<void> _connectWallet(WalletType walletType) async {
    bool success = false;

    if (walletType == WalletType.metamask) {
      success = await Web3WalletService.instance.connectToMetaMask();
    } else if (walletType == WalletType.trustWallet) {
      success = await Web3WalletService.instance.connectToTrustWallet();
    }

    if (success && widget.onRefresh != null) {
      widget.onRefresh!();
    }
  }

  Future<void> _disconnect() async {
    await Web3WalletService.instance.disconnect();
    if (widget.onRefresh != null) {
      widget.onRefresh!();
    }
  }

  Future<void> _refreshBalance() async {
    await Web3WalletService.instance.refreshBalance();
    if (widget.onRefresh != null) {
      widget.onRefresh!();
    }
  }

  Future<void> _copyAddress() async {
    await Web3WalletService.instance.copyAddressToClipboard();

    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            'Wallet address copied to clipboard',
            style: GoogleFonts.inter(color: Colors.white),
          ),
          backgroundColor: Colors.green.shade600,
          duration: const Duration(seconds: 2),
        ),
      );
    }
  }
}