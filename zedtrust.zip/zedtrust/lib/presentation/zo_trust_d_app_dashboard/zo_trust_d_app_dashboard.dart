import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';
import 'package:google_fonts/google_fonts.dart'; // Add this import

import '../../core/app_export.dart';
import '../../core/services/supabase_service.dart';
import '../../core/services/web3_wallet_service.dart';
import '../../core/services/zotrust_smart_contract_service.dart';
import '../../routes/app_routes.dart';
import './widgets/balance_overview_widget.dart';
import './widgets/network_status_widget.dart';
import './widgets/quick_actions_widget.dart';
import './widgets/trades_list_widget.dart';
import './widgets/wallet_connection_widget.dart';

class ZoTrustDAppDashboard extends StatefulWidget {
  const ZoTrustDAppDashboard({super.key});

  @override
  State<ZoTrustDAppDashboard> createState() => _ZoTrustDAppDashboardState();
}

class _ZoTrustDAppDashboardState extends State<ZoTrustDAppDashboard>
    with TickerProviderStateMixin {
  late TabController _tabController;
  bool _isLoading = true;
  Map<String, dynamic>? _contractStats;
  List<TradeData> _activeTrades = [];
  List<TradeData> _pastTrades = [];
  String? _userCity;
  bool _hasCheckedOnboarding = false;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 4, vsync: this);
    _initializeDashboard();
    _checkCityOnboarding();
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  Future<void> _initializeDashboard() async {
    try {
      setState(() => _isLoading = true);

      // Initialize services
      await Web3WalletService.instance.initialize();
      await ZoTrustSmartContractService.instance.initialize();

      // Load contract stats
      await _loadContractStats();

      // Load trades
      await _loadTrades();

      setState(() => _isLoading = false);
    } catch (e) {
      if (kDebugMode) {
        print('❌ Dashboard initialization error: $e');
      }
      setState(() => _isLoading = false);
    }
  }

  Future<void> _checkCityOnboarding() async {
    if (_hasCheckedOnboarding) return;

    try {
      final client = SupabaseService.instance.client;
      final user = client.auth.currentUser;

      if (user != null) {
        final userProfile = await client
            .from('users')
            .select('city')
            .eq('id', user.id)
            .maybeSingle();

        if (userProfile != null) {
          _userCity = userProfile['city'];
        }

        // Show onboarding modal if city is not set
        if (_userCity == null || _userCity!.isEmpty) {
          WidgetsBinding.instance.addPostFrameCallback((_) {
            _showCityOnboardingModal();
          });
        }
      }

      _hasCheckedOnboarding = true;
    } catch (e) {
      if (kDebugMode) {
        print('❌ City onboarding check error: $e');
      }
    }
  }

  void _showCityOnboardingModal() {
    Navigator.pushNamed(context, AppRoutes.cityBasedOnboardingModal).then((_) {
      // Refresh user data after onboarding
      _checkCityOnboarding();
    });
  }

  Future<void> _loadContractStats() async {
    try {
      final stats =
          await ZoTrustSmartContractService.instance.getContractStats();
      setState(() {
        _contractStats = stats;
      });
    } catch (e) {
      if (kDebugMode) {
        print('❌ Failed to load contract stats: $e');
      }
    }
  }

  Future<void> _loadTrades() async {
    try {
      final connectedWallet = Web3WalletService.instance.connectedWallet;
      List<TradeData> allTrades;

      if (connectedWallet != null) {
        // Load user-specific trades
        allTrades = await ZoTrustSmartContractService.instance
            .getTradesByUser(connectedWallet.address);
      } else {
        // Load general trades for demo
        allTrades =
            await ZoTrustSmartContractService.instance.getAllTrades(limit: 20);
      }

      // Filter trades by city if user has set their city
      if (_userCity != null && _userCity!.isNotEmpty) {
        // In a real implementation, this would filter by agent locations
        // For now, we'll show all trades but indicate they're city-filtered
      }

      // Separate active and past trades
      final active = allTrades
          .where((t) => ['Created', 'Funded', 'In Progress'].contains(t.status))
          .toList();

      final past = allTrades
          .where((t) => ['Completed', 'Cancelled'].contains(t.status))
          .toList();

      setState(() {
        _activeTrades = active;
        _pastTrades = past;
      });
    } catch (e) {
      if (kDebugMode) {
        print('❌ Failed to load trades: $e');
      }
    }
  }

  Future<void> _refreshData() async {
    await Future.wait([
      _loadContractStats(),
      _loadTrades(),
      Web3WalletService.instance.refreshBalance(),
    ]);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: SafeArea(
        child: Column(
          children: [
            _buildAppBar(),
            _buildNetworkStatus(),
            _buildWalletConnection(),
            if (_isLoading)
              _buildLoadingIndicator()
            else
              Expanded(child: _buildTabContent()),
          ],
        ),
      ),
      floatingActionButton: _buildFloatingActionButton(),
    );
  }

  Widget _buildAppBar() {
    return Container(
      padding: EdgeInsets.all(4.w),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [Colors.deepPurple.shade900, Colors.indigo.shade800],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
      ),
      child: Row(
        children: [
          Container(
            padding: EdgeInsets.all(2.w),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(12),
              gradient: LinearGradient(
                colors: [Colors.cyan.shade400, Colors.blue.shade600],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
            ),
            child: Icon(
              Icons.account_balance_wallet,
              color: Colors.white,
              size: 6.w,
            ),
          ),
          SizedBox(width: 3.w),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'ZoTrust',
                  style: GoogleFonts.inter(
                    fontSize: 18.sp,
                    fontWeight: FontWeight.bold,
                    color: Colors.white,
                  ),
                ),
                Text(
                  'Decentralized P2P Trading',
                  style: GoogleFonts.inter(
                    fontSize: 11.sp,
                    color: Colors.white70,
                  ),
                ),
              ],
            ),
          ),
          if (_userCity != null)
            Container(
              padding: EdgeInsets.symmetric(horizontal: 3.w, vertical: 1.w),
              decoration: BoxDecoration(
                color: Colors.white.withAlpha(51),
                borderRadius: BorderRadius.circular(20),
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(
                    Icons.location_on,
                    color: Colors.white,
                    size: 4.w,
                  ),
                  SizedBox(width: 1.w),
                  Text(
                    _userCity!,
                    style: GoogleFonts.inter(
                      fontSize: 10.sp,
                      color: Colors.white,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                ],
              ),
            ),
        ],
      ),
    );
  }

  Widget _buildNetworkStatus() {
    return NetworkStatusWidget(contractStats: _contractStats);
  }

  Widget _buildWalletConnection() {
    return WalletConnectionWidget(onRefresh: _refreshData);
  }

  Widget _buildLoadingIndicator() {
    return Expanded(
      child: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            CircularProgressIndicator(
              valueColor: AlwaysStoppedAnimation<Color>(Colors.cyan.shade400),
            ),
            SizedBox(height: 4.w),
            Text(
              'Loading ZoTrust Dashboard...',
              style: GoogleFonts.inter(
                fontSize: 14.sp,
                color: Colors.white70,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildTabContent() {
    return Column(
      children: [
        _buildTabBar(),
        Expanded(
          child: TabBarView(
            controller: _tabController,
            children: [
              _buildDashboardTab(),
              _buildP2PTab(),
              _buildAgentsTab(),
              _buildProfileTab(),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildTabBar() {
    return Container(
      margin: EdgeInsets.symmetric(horizontal: 4.w, vertical: 2.w),
      decoration: BoxDecoration(
        color: Colors.grey.shade900,
        borderRadius: BorderRadius.circular(25),
      ),
      child: TabBar(
        controller: _tabController,
        indicator: BoxDecoration(
          borderRadius: BorderRadius.circular(25),
          gradient: LinearGradient(
            colors: [Colors.cyan.shade400, Colors.blue.shade600],
          ),
        ),
        labelColor: Colors.white,
        unselectedLabelColor: Colors.grey.shade400,
        labelStyle: GoogleFonts.inter(
          fontSize: 12.sp,
          fontWeight: FontWeight.w600,
        ),
        tabs: const [
          Tab(text: 'Trades'),
          Tab(text: 'P2P'),
          Tab(text: 'Agents'),
          Tab(text: 'Profile'),
        ],
      ),
    );
  }

  Widget _buildDashboardTab() {
    return RefreshIndicator(
      onRefresh: _refreshData,
      color: Colors.cyan.shade400,
      backgroundColor: Colors.grey.shade900,
      child: SingleChildScrollView(
        physics: const AlwaysScrollableScrollPhysics(),
        padding: EdgeInsets.all(4.w),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            BalanceOverviewWidget(contractStats: _contractStats),
            SizedBox(height: 4.w),
            QuickActionsWidget(onNewTrade: _navigateToCreateTrade),
            SizedBox(height: 4.w),
            TradesListWidget(
              activeTrades: _activeTrades,
              pastTrades: _pastTrades,
              userCity: _userCity,
              onTradeSelected: _navigateToTradeDetails,
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildP2PTab() {
    return Center(
      child: Padding(
        padding: EdgeInsets.all(4.w),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              Icons.swap_horiz,
              size: 20.w,
              color: Colors.grey.shade600,
            ),
            SizedBox(height: 4.w),
            Text(
              'P2P Trading',
              style: GoogleFonts.inter(
                fontSize: 18.sp,
                fontWeight: FontWeight.bold,
                color: Colors.white,
              ),
            ),
            SizedBox(height: 2.w),
            Text(
              'Direct peer-to-peer trading features coming soon!',
              textAlign: TextAlign.center,
              style: GoogleFonts.inter(
                fontSize: 12.sp,
                color: Colors.grey.shade400,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildAgentsTab() {
    return Center(
      child: Padding(
        padding: EdgeInsets.all(4.w),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              Icons.people,
              size: 20.w,
              color: Colors.grey.shade600,
            ),
            SizedBox(height: 4.w),
            Text(
              'Trusted Agents',
              style: GoogleFonts.inter(
                fontSize: 18.sp,
                fontWeight: FontWeight.bold,
                color: Colors.white,
              ),
            ),
            SizedBox(height: 2.w),
            Text(
              _userCity != null
                  ? 'Find trusted agents in $_userCity'
                  : 'Find trusted agents near you',
              textAlign: TextAlign.center,
              style: GoogleFonts.inter(
                fontSize: 12.sp,
                color: Colors.grey.shade400,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildProfileTab() {
    return Center(
      child: Padding(
        padding: EdgeInsets.all(4.w),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              Icons.account_circle,
              size: 20.w,
              color: Colors.grey.shade600,
            ),
            SizedBox(height: 4.w),
            Text(
              'Profile Settings',
              style: GoogleFonts.inter(
                fontSize: 18.sp,
                fontWeight: FontWeight.bold,
                color: Colors.white,
              ),
            ),
            SizedBox(height: 2.w),
            if (_userCity != null)
              Text(
                'Location: $_userCity',
                style: GoogleFonts.inter(
                  fontSize: 12.sp,
                  color: Colors.cyan.shade400,
                ),
              ),
          ],
        ),
      ),
    );
  }

  Widget _buildFloatingActionButton() {
    return FloatingActionButton.extended(
      onPressed: _navigateToCreateTrade,
      backgroundColor: Colors.cyan.shade400,
      foregroundColor: Colors.white,
      label: Text(
        'New Trade',
        style: GoogleFonts.inter(
          fontWeight: FontWeight.w600,
        ),
      ),
      icon: const Icon(Icons.add),
    );
  }

  void _navigateToCreateTrade() {
    Navigator.pushNamed(context, AppRoutes.createTrade);
  }

  void _navigateToTradeDetails(TradeData trade) {
    Navigator.pushNamed(
      context,
      AppRoutes.tradeDetails,
      arguments: {'tradeId': trade.tradeId.toString()},
    );
  }
}