import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:sizer/sizer.dart';

import '../../core/app_export.dart';
import '../../core/services/secure_wallet_service.dart';
import '../../core/services/web3_escrow_service.dart';
import '../../core/services/web3_wallet_service.dart';
import './widgets/qr_scan_button_widget.dart';
import './widgets/security_badge_widget.dart';
import './widgets/smart_contract_integration_widget.dart';
import './widgets/wallet_card_widget.dart';
import './widgets/why_connect_widget.dart';

class WalletConnection extends StatefulWidget {
  const WalletConnection({Key? key}) : super(key: key);

  @override
  State<WalletConnection> createState() => _WalletConnectionState();
}

class _WalletConnectionState extends State<WalletConnection> {
  bool _isConnecting = false;
  String? _connectingWallet;
  bool _isQrScanning = false;
  bool _isWalletSetup = false;
  String? _walletAddress;

  // Mock wallet data with Web3 integration
  final List<Map<String, dynamic>> _supportedWallets = [
    {
      "id": "metamask",
      "name": "MetaMask",
      "logo":
          "https://upload.wikimedia.org/wikipedia/commons/3/36/MetaMask_Fox.svg",
      "isConnected": false,
      "lastConnected": null,
      "deepLink": "metamask://",
      "universalLink": "https://metamask.app.link/",
      "supportsWeb3": true,
      "description": "Connect with MetaMask wallet",
    },
    {
      "id": "trust_wallet",
      "name": "Trust Wallet",
      "logo":
          "https://trustwallet.com/assets/images/media/assets/trust_platform.png",
      "isConnected": false,
      "lastConnected": null,
      "deepLink": "trust://",
      "universalLink": "https://link.trustwallet.com/",
      "supportsWeb3": true,
      "description": "Connect with Trust Wallet",
    },
    {
      "id": "wallet_connect",
      "name": "WalletConnect",
      "logo": "https://walletconnect.com/walletconnect-logo.svg",
      "isConnected": false,
      "lastConnected": null,
      "deepLink": "",
      "universalLink": "",
      "supportsWeb3": true,
      "description": "Connect any WalletConnect compatible wallet",
    },
    {
      "id": "create_new",
      "name": "Create New Wallet",
      "logo":
          "https://images.unsplash.com/photo-1614064641938-3bbee52942c7?w=100&h=100&fit=crop&crop=center",
      "isConnected": false,
      "lastConnected": null,
      "deepLink": "",
      "universalLink": "",
      "supportsWeb3": true,
      "description": "Generate a new secure wallet",
    },
  ];

  @override
  void initState() {
    super.initState();
    _checkWalletStatus();
  }

  Future<void> _checkWalletStatus() async {
    try {
      final address = await SecureWalletService.instance.getWalletAddress();
      final hasWallet = await SecureWalletService.instance.hasWallet();
      setState(() {
        _isWalletSetup = hasWallet;
        _walletAddress = address;

        // Update wallet connection status
        if (_isWalletSetup && _walletAddress != null) {
          final internalWalletIndex = _supportedWallets.indexWhere(
            (w) => w["id"] == "create_new" || w["id"] == "import_wallet",
          );
          if (internalWalletIndex != -1) {
            _supportedWallets[internalWalletIndex]["isConnected"] = true;
            _supportedWallets[internalWalletIndex]["lastConnected"] =
                DateTime.now();
          }
        }
      });
    } catch (e) {
      if (kDebugMode) {
        print('❌ Error checking wallet status: $e');
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Theme.of(context).scaffoldBackgroundColor,
      body: SafeArea(
        child: Column(
          children: [
            // Header
            _buildHeader(context),

            // Content
            Expanded(
              child: SingleChildScrollView(
                physics: const BouncingScrollPhysics(),
                child: Column(
                  children: [
                    SizedBox(height: 2.h),

                    // Security Badge
                    const SecurityBadgeWidget(),

                    SizedBox(height: 3.h),

                    // Smart Contract Integration Status
                    const SmartContractIntegrationWidget(),

                    SizedBox(height: 2.h),

                    // Wallet List Title
                    Padding(
                      padding: EdgeInsets.symmetric(horizontal: 6.w),
                      child: Align(
                        alignment: Alignment.centerLeft,
                        child: Text(
                          _isWalletSetup
                              ? 'Manage Wallet'
                              : 'Choose Your Wallet',
                          style: Theme.of(context)
                              .textTheme
                              .titleLarge
                              ?.copyWith(fontWeight: FontWeight.w700),
                        ),
                      ),
                    ),

                    if (_isWalletSetup && _walletAddress != null) ...[
                      SizedBox(height: 2.h),
                      _buildCurrentWalletCard(),
                      SizedBox(height: 2.h),
                      _buildWalletActions(),
                    ],

                    SizedBox(height: 2.h),

                    // Wallet Cards
                    ..._supportedWallets.map(
                      (wallet) => WalletCardWidget(
                        walletName: wallet["name"] as String,
                        walletLogo: wallet["logo"] as String,
                        isConnected: wallet["isConnected"] as bool,
                        lastConnected: wallet["lastConnected"] as DateTime?,
                        onConnect: () => _connectWallet(wallet),
                        isLoading:
                            _isConnecting && _connectingWallet == wallet["id"],
                      ),
                    ),

                    SizedBox(height: 3.h),

                    // QR Scan Button
                    QrScanButtonWidget(
                      onPressed: _scanQrCode,
                      isLoading: _isQrScanning,
                    ),

                    SizedBox(height: 2.h),

                    // Why Connect Section
                    const WhyConnectWidget(),

                    SizedBox(height: 4.h),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildHeader(BuildContext context) {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 4.w, vertical: 2.h),
      decoration: BoxDecoration(
        color: Theme.of(context).cardColor,
        boxShadow: [
          BoxShadow(
            color: Theme.of(context).shadowColor.withValues(alpha: 0.1),
            blurRadius: 8,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Row(
        children: [
          // Close Button
          IconButton(
            onPressed: () => Navigator.pop(context),
            icon: CustomIconWidget(
              iconName: 'close',
              color: Theme.of(context).colorScheme.onSurface,
              size: 6.w,
            ),
            style: IconButton.styleFrom(
              backgroundColor: Theme.of(context).colorScheme.surface,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12),
              ),
            ),
          ),

          SizedBox(width: 4.w),

          // Title
          Expanded(
            child: Text(
              'Web3 Wallet Connection',
              style: Theme.of(
                context,
              ).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.w700),
              textAlign: TextAlign.center,
            ),
          ),

          SizedBox(width: 4.w),

          // Network Status
          Container(
            padding: EdgeInsets.symmetric(horizontal: 3.w, vertical: 1.h),
            decoration: BoxDecoration(
              color: AppTheme.lightTheme.colorScheme.secondary.withValues(
                alpha: 0.1,
              ),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(
                  width: 2.w,
                  height: 2.w,
                  decoration: BoxDecoration(
                    color: AppTheme.lightTheme.colorScheme.secondary,
                    borderRadius: BorderRadius.circular(1.w),
                  ),
                ),
                SizedBox(width: 2.w),
                Text(
                  'Polygon',
                  style: Theme.of(context).textTheme.labelSmall?.copyWith(
                        color: AppTheme.lightTheme.colorScheme.secondary,
                        fontWeight: FontWeight.w600,
                      ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildCurrentWalletCard() {
    return Container(
      margin: EdgeInsets.symmetric(horizontal: 6.w),
      padding: EdgeInsets.all(4.w),
      decoration: BoxDecoration(
        color: AppTheme.lightTheme.colorScheme.secondary.withValues(alpha: 0.1),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: AppTheme.lightTheme.colorScheme.secondary,
          width: 1,
        ),
      ),
      child: Row(
        children: [
          Container(
            padding: EdgeInsets.all(3.w),
            decoration: BoxDecoration(
              color: AppTheme.lightTheme.colorScheme.secondary,
              borderRadius: BorderRadius.circular(12),
            ),
            child: CustomIconWidget(
              iconName: 'account_balance_wallet',
              color: Colors.white,
              size: 6.w,
            ),
          ),
          SizedBox(width: 4.w),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Connected Wallet',
                  style: Theme.of(context).textTheme.titleSmall?.copyWith(
                        fontWeight: FontWeight.w600,
                        color: AppTheme.lightTheme.colorScheme.secondary,
                      ),
                ),
                SizedBox(height: 0.5.h),
                Text(
                  '${_walletAddress!.substring(0, 6)}...${_walletAddress!.substring(_walletAddress!.length - 4)}',
                  style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                        fontFamily: 'monospace',
                        fontWeight: FontWeight.w500,
                      ),
                ),
              ],
            ),
          ),
          IconButton(
            onPressed: () => _copyAddress(_walletAddress!),
            icon: CustomIconWidget(
              iconName: 'copy',
              color: AppTheme.lightTheme.colorScheme.secondary,
              size: 5.w,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildWalletActions() {
    return Padding(
      padding: EdgeInsets.symmetric(horizontal: 6.w),
      child: Row(
        children: [
          Expanded(
            child: OutlinedButton.icon(
              onPressed: _showBackupWallet,
              icon: CustomIconWidget(
                iconName: 'backup',
                color: AppTheme.lightTheme.colorScheme.primary,
                size: 4.w,
              ),
              label: const Text('Backup'),
              style: OutlinedButton.styleFrom(
                foregroundColor: AppTheme.lightTheme.colorScheme.primary,
                side: BorderSide(
                  color: AppTheme.lightTheme.colorScheme.primary,
                ),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
                padding: EdgeInsets.symmetric(vertical: 1.5.h),
              ),
            ),
          ),
          SizedBox(width: 3.w),
          Expanded(
            child: ElevatedButton.icon(
              onPressed: _disconnectWallet,
              icon: CustomIconWidget(
                iconName: 'logout',
                color: Colors.white,
                size: 4.w,
              ),
              label: const Text('Disconnect'),
              style: ElevatedButton.styleFrom(
                backgroundColor: AppTheme.lightTheme.colorScheme.error,
                foregroundColor: Colors.white,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
                padding: EdgeInsets.symmetric(vertical: 1.5.h),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Future<void> _connectWallet(Map<String, dynamic> wallet) async {
    if (_isConnecting) return;

    setState(() {
      _isConnecting = true;
      _connectingWallet = wallet["id"] as String;
    });

    try {
      HapticFeedback.lightImpact();

      final walletId = wallet["id"] as String;
      bool connected = false;

      switch (walletId) {
        case "metamask":
          connected = await Web3WalletService.instance.connectToMetaMask();
          break;
        case "trust_wallet":
          connected = await Web3WalletService.instance.connectToTrustWallet();
          break;
        case "wallet_connect":
          connected =
              await Web3WalletService.instance.connectViaWalletConnect();
          break;
        case "create_new":
          await _handleCreateNewWallet();
          return;
        default:
          throw Exception('Unsupported wallet: $walletId');
      }

      if (connected) {
        await _handleSuccessfulConnection(wallet);
      } else {
        throw Exception('Connection failed or was rejected');
      }
    } catch (e) {
      if (mounted) {
        _showDetailedConnectionError(wallet["name"] as String, e.toString());
      }
    } finally {
      if (mounted) {
        setState(() {
          _isConnecting = false;
          _connectingWallet = null;
        });
      }
    }
  }

  Future<void> _handleSuccessfulConnection(Map<String, dynamic> wallet) async {
    setState(() {
      final walletIndex = _supportedWallets.indexWhere(
        (w) => w["id"] == wallet["id"],
      );
      if (walletIndex != -1) {
        // Disconnect other wallets
        for (var w in _supportedWallets) {
          w["isConnected"] = false;
        }
        // Connect selected wallet
        _supportedWallets[walletIndex]["isConnected"] = true;
        _supportedWallets[walletIndex]["lastConnected"] = DateTime.now();
      }
    });

    _showConnectionSuccess(wallet["name"] as String);

    // Navigate to dashboard after success
    await Future.delayed(const Duration(seconds: 2));
    if (mounted) {
      Navigator.pushReplacementNamed(context, '/dashboard');
    }
  }

  void _showDetailedConnectionError(String walletName, String error) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Failed to connect to $walletName',
              style: const TextStyle(fontWeight: FontWeight.w600),
            ),
            const SizedBox(height: 4),
            Text(
              'Error: ${error.length > 50 ? error.substring(0, 50) + '...' : error}',
              style: TextStyle(
                fontSize: 12,
                color: Colors.white.withAlpha(204),
              ),
            ),
            const SizedBox(height: 4),
            Text(
              'Please ensure the wallet app is installed and try again.',
              style: TextStyle(
                fontSize: 12,
                color: Colors.white.withAlpha(204),
              ),
            ),
          ],
        ),
        backgroundColor: AppTheme.lightTheme.colorScheme.error,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        duration: const Duration(seconds: 4),
        action: SnackBarAction(
          label: 'Retry',
          textColor: Colors.white,
          onPressed: () {
            final wallet = _supportedWallets.firstWhere(
              (w) => w['name'] == walletName,
            );
            _connectWallet(wallet);
          },
        ),
      ),
    );
  }

  void _showConnectionError(String walletName) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Row(
          children: [
            CustomIconWidget(iconName: 'error', color: Colors.white, size: 5.w),
            SizedBox(width: 3.w),
            const Expanded(child: Text('Failed to connect. Please try again.')),
          ],
        ),
        backgroundColor: AppTheme.lightTheme.colorScheme.error,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        duration: const Duration(seconds: 3),
      ),
    );
  }

  Future<void> _handleCreateNewWallet() async {
    // Show generating dialog
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => AlertDialog(
        backgroundColor: Theme.of(context).cardColor,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(16),
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            SizedBox(
              width: 15.w,
              height: 15.w,
              child: CircularProgressIndicator(
                strokeWidth: 3,
                valueColor: AlwaysStoppedAnimation<Color>(
                  AppTheme.lightTheme.colorScheme.primary,
                ),
              ),
            ),
            SizedBox(height: 3.h),
            Text(
              'Generating New Wallet',
              style: Theme.of(context).textTheme.titleMedium?.copyWith(
                    fontWeight: FontWeight.w600,
                  ),
              textAlign: TextAlign.center,
            ),
            SizedBox(height: 1.h),
            Text(
              'Creating secure wallet with private key...',
              style: Theme.of(context).textTheme.bodySmall?.copyWith(
                    color: Theme.of(context).colorScheme.onSurfaceVariant,
                  ),
              textAlign: TextAlign.center,
            ),
          ],
        ),
      ),
    );

    try {
      // Generate new wallet
      final result = await SecureWalletService.instance.createWallet();

      if (mounted) Navigator.pop(context); // Close dialog

      if (result['success']) {
        await _initializeWeb3Service();
        await _checkWalletStatus();
        _showWalletCreatedSuccess(result);
      } else {
        throw Exception(result['message']);
      }
    } catch (e) {
      if (mounted) {
        Navigator.pop(context); // Close dialog
        _showError('Failed to create wallet: $e');
      }
    }
  }

  Future<void> _handleImportWallet() async {
    // Show import dialog
    final privateKeyController = TextEditingController();

    final result = await showDialog<String>(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: Theme.of(context).cardColor,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(16),
        ),
        title: Text(
          'Import Private Key',
          style: Theme.of(
            context,
          ).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w600),
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
              controller: privateKeyController,
              decoration: InputDecoration(
                labelText: 'Private Key (without 0x prefix)',
                hintText: 'Enter your 64-character private key',
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
                prefixIcon: Icon(
                  Icons.vpn_key,
                  color: AppTheme.lightTheme.colorScheme.primary,
                ),
              ),
              obscureText: true,
              maxLength: 64,
            ),
            SizedBox(height: 2.h),
            Text(
              '⚠️ Never share your private key with anyone!',
              style: Theme.of(context).textTheme.bodySmall?.copyWith(
                    color: AppTheme.lightTheme.colorScheme.error,
                    fontWeight: FontWeight.w500,
                  ),
              textAlign: TextAlign.center,
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () => Navigator.pop(context, privateKeyController.text),
            child: const Text('Import'),
          ),
        ],
      ),
    );

    if (result != null && result.isNotEmpty) {
      try {
        final importResult = await SecureWalletService.instance.storeWallet(
          address:
              '0x${result.substring(result.length >= 40 ? result.length - 40 : 0)}',
          privateKey: result,
        );

        if (importResult['success']) {
          await _initializeWeb3Service();
          await _checkWalletStatus();
          _showConnectionSuccess('Imported Wallet');
        } else {
          throw Exception(importResult['message']);
        }
      } catch (e) {
        _showError('Failed to import wallet: $e');
      }
    }
  }

  Future<void> _handleExternalWallet(Map<String, dynamic> wallet) async {
    // Show connecting dialog
    _showConnectingDialog(wallet["name"] as String);

    // Simulate WalletConnect v2 connection process
    await Future.delayed(const Duration(seconds: 2));

    // Close dialog
    if (mounted) Navigator.pop(context);

    // Simulate connection success
    await Future.delayed(const Duration(milliseconds: 500));

    if (mounted) {
      // Update wallet connection status
      setState(() {
        final walletIndex = _supportedWallets.indexWhere(
          (w) => w["id"] == wallet["id"],
        );
        if (walletIndex != -1) {
          // Disconnect other wallets
          for (var w in _supportedWallets) {
            w["isConnected"] = false;
          }
          // Connect selected wallet
          _supportedWallets[walletIndex]["isConnected"] = true;
          _supportedWallets[walletIndex]["lastConnected"] = DateTime.now();
        }
      });

      // Show success feedback
      _showConnectionSuccess(wallet["name"] as String);

      // Navigate to dashboard after success animation
      await Future.delayed(const Duration(seconds: 1));
      if (mounted) {
        Navigator.pushReplacementNamed(context, '/dashboard');
      }
    }
  }

  Future<void> _initializeWeb3Service() async {
    try {
      await Web3EscrowService.instance.initialize();
    } catch (e) {
      if (kDebugMode) {
        print('❌ Failed to initialize Web3 service: $e');
      }
    }
  }

  void _showWalletCreatedSuccess(Map<String, dynamic> result) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: Theme.of(context).cardColor,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(16),
        ),
        title: Row(
          children: [
            CustomIconWidget(
              iconName: 'check_circle',
              color: AppTheme.lightTheme.colorScheme.secondary,
              size: 6.w,
            ),
            SizedBox(width: 3.w),
            Text(
              'Wallet Created!',
              style: Theme.of(context).textTheme.titleMedium?.copyWith(
                    fontWeight: FontWeight.w600,
                  ),
            ),
          ],
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Your new wallet has been created successfully.',
              style: Theme.of(context).textTheme.bodyMedium,
            ),
            SizedBox(height: 2.h),
            Text(
              'Address:',
              style: Theme.of(
                context,
              ).textTheme.bodySmall?.copyWith(fontWeight: FontWeight.w600),
            ),
            SizedBox(height: 0.5.h),
            Container(
              padding: EdgeInsets.all(2.w),
              decoration: BoxDecoration(
                color: Theme.of(context).colorScheme.surface,
                borderRadius: BorderRadius.circular(8),
              ),
              child: Text(
                result['address'] ?? '',
                style: Theme.of(
                  context,
                ).textTheme.bodySmall?.copyWith(fontFamily: 'monospace'),
              ),
            ),
            SizedBox(height: 2.h),
            Text(
              '⚠️ Make sure to backup your wallet!',
              style: Theme.of(context).textTheme.bodySmall?.copyWith(
                    color: AppTheme.lightTheme.colorScheme.error,
                    fontWeight: FontWeight.w500,
                  ),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.pop(context);
              _showBackupWallet();
            },
            child: const Text('Backup Now'),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(context);
              Navigator.pushReplacementNamed(context, '/dashboard');
            },
            child: const Text('Continue'),
          ),
        ],
      ),
    );
  }

  Future<void> _showBackupWallet() async {
    try {
      final address = await SecureWalletService.instance.getWalletAddress();

      if (address != null) {
        showDialog(
          context: context,
          builder: (context) => AlertDialog(
            backgroundColor: Theme.of(context).cardColor,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(16),
            ),
            title: Text(
              'Wallet Backup',
              style: Theme.of(context).textTheme.titleMedium?.copyWith(
                    fontWeight: FontWeight.w600,
                  ),
            ),
            content: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Save this information securely:',
                  style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                        fontWeight: FontWeight.w600,
                      ),
                ),
                SizedBox(height: 2.h),
                Text(
                  'Wallet Address:',
                  style: Theme.of(context).textTheme.bodySmall?.copyWith(
                        fontWeight: FontWeight.w600,
                      ),
                ),
                SizedBox(height: 0.5.h),
                Container(
                  padding: EdgeInsets.all(2.w),
                  decoration: BoxDecoration(
                    color: Theme.of(context).colorScheme.surface,
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Text(
                    address,
                    style: Theme.of(context).textTheme.bodySmall,
                  ),
                ),
                SizedBox(height: 2.h),
                Text(
                  '⚠️ Never share your backup with anyone!',
                  style: Theme.of(context).textTheme.bodySmall?.copyWith(
                        color: AppTheme.lightTheme.colorScheme.error,
                        fontWeight: FontWeight.w500,
                      ),
                ),
              ],
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(context),
                child: const Text('Close'),
              ),
            ],
          ),
        );
      }
    } catch (e) {
      _showError('Failed to create backup: $e');
    }
  }

  Future<void> _disconnectWallet() async {
    final confirm = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: Theme.of(context).cardColor,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(16),
        ),
        title: const Text('Disconnect Wallet'),
        content: const Text(
          'Are you sure you want to disconnect your wallet? Make sure you have backed up your wallet before disconnecting.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () => Navigator.pop(context, true),
            style: ElevatedButton.styleFrom(
              backgroundColor: AppTheme.lightTheme.colorScheme.error,
            ),
            child: const Text('Disconnect'),
          ),
        ],
      ),
    );

    if (confirm == true) {
      try {
        await SecureWalletService.instance.clearWallet();
        await _checkWalletStatus();

        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Wallet disconnected successfully'),
            backgroundColor: Colors.orange,
          ),
        );
      } catch (e) {
        _showError('Failed to disconnect wallet: $e');
      }
    }
  }

  void _copyAddress(String address) {
    Clipboard.setData(ClipboardData(text: address));
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('Address copied to clipboard'),
        behavior: SnackBarBehavior.floating,
        duration: Duration(seconds: 2),
      ),
    );
    HapticFeedback.lightImpact();
  }

  void _showError(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        backgroundColor: AppTheme.lightTheme.colorScheme.error,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      ),
    );
  }

  Future<void> _scanQrCode() async {
    if (_isQrScanning) return;

    setState(() {
      _isQrScanning = true;
    });

    try {
      // Haptic feedback
      HapticFeedback.lightImpact();

      // Simulate QR code scanning
      await Future.delayed(const Duration(seconds: 2));

      if (mounted) {
        // Show QR scan result
        _showQrScanResult();
      }
    } catch (e) {
      if (mounted) {
        _showQrScanError();
      }
    } finally {
      if (mounted) {
        setState(() {
          _isQrScanning = false;
        });
      }
    }
  }

  void _showConnectingDialog(String walletName) {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => AlertDialog(
        backgroundColor: Theme.of(context).cardColor,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(16),
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            SizedBox(
              width: 15.w,
              height: 15.w,
              child: CircularProgressIndicator(
                strokeWidth: 3,
                valueColor: AlwaysStoppedAnimation<Color>(
                  AppTheme.lightTheme.colorScheme.primary,
                ),
              ),
            ),
            SizedBox(height: 3.h),
            Text(
              'Connecting to $walletName',
              style: Theme.of(context).textTheme.titleMedium?.copyWith(
                    fontWeight: FontWeight.w600,
                  ),
              textAlign: TextAlign.center,
            ),
            SizedBox(height: 1.h),
            Text(
              'Please approve the connection in your wallet app',
              style: Theme.of(context).textTheme.bodySmall?.copyWith(
                    color: Theme.of(context).colorScheme.onSurfaceVariant,
                  ),
              textAlign: TextAlign.center,
            ),
          ],
        ),
      ),
    );
  }

  void _showConnectionSuccess(String walletName) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Row(
          children: [
            CustomIconWidget(
              iconName: 'check_circle',
              color: AppTheme.lightTheme.colorScheme.secondary,
              size: 5.w,
            ),
            SizedBox(width: 3.w),
            Expanded(
              child: Text(
                '$walletName connected successfully!',
                style: Theme.of(context).snackBarTheme.contentTextStyle,
              ),
            ),
          ],
        ),
        backgroundColor: AppTheme.lightTheme.colorScheme.secondary,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        duration: const Duration(seconds: 2),
      ),
    );

    // Haptic feedback for success
    HapticFeedback.mediumImpact();
  }

  void _showQrScanResult() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: Theme.of(context).cardColor,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(16),
        ),
        title: Row(
          children: [
            CustomIconWidget(
              iconName: 'qr_code_scanner',
              color: AppTheme.lightTheme.colorScheme.primary,
              size: 6.w,
            ),
            SizedBox(width: 3.w),
            Text(
              'QR Code Detected',
              style: Theme.of(context).textTheme.titleMedium?.copyWith(
                    fontWeight: FontWeight.w600,
                  ),
            ),
          ],
        ),
        content: Text(
          'WalletConnect session detected. Connecting to desktop wallet...',
          style: Theme.of(context).textTheme.bodyMedium,
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text(
              'Cancel',
              style: TextStyle(
                color: Theme.of(context).colorScheme.onSurfaceVariant,
              ),
            ),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(context);
              // Simulate desktop wallet connection
              _connectDesktopWallet();
            },
            child: const Text('Connect'),
          ),
        ],
      ),
    );
  }

  void _showQrScanError() {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Row(
          children: [
            CustomIconWidget(iconName: 'error', color: Colors.white, size: 5.w),
            SizedBox(width: 3.w),
            const Expanded(
              child: Text('Failed to scan QR code. Please try again.'),
            ),
          ],
        ),
        backgroundColor: AppTheme.lightTheme.colorScheme.error,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      ),
    );
  }

  Future<void> _connectDesktopWallet() async {
    // Show connecting to desktop wallet
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => AlertDialog(
        backgroundColor: Theme.of(context).cardColor,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(16),
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            SizedBox(
              width: 15.w,
              height: 15.w,
              child: CircularProgressIndicator(
                strokeWidth: 3,
                valueColor: AlwaysStoppedAnimation<Color>(
                  AppTheme.lightTheme.colorScheme.primary,
                ),
              ),
            ),
            SizedBox(height: 3.h),
            Text(
              'Connecting to Desktop Wallet',
              style: Theme.of(context).textTheme.titleMedium?.copyWith(
                    fontWeight: FontWeight.w600,
                  ),
              textAlign: TextAlign.center,
            ),
            SizedBox(height: 1.h),
            Text(
              'Please approve the connection in your desktop wallet',
              style: Theme.of(context).textTheme.bodySmall?.copyWith(
                    color: Theme.of(context).colorScheme.onSurfaceVariant,
                  ),
              textAlign: TextAlign.center,
            ),
          ],
        ),
      ),
    );

    // Simulate desktop connection
    await Future.delayed(const Duration(seconds: 3));

    if (mounted) {
      Navigator.pop(context); // Close dialog
      _showConnectionSuccess('Desktop Wallet');

      // Navigate to dashboard
      await Future.delayed(const Duration(seconds: 1));
      if (mounted) {
        Navigator.pushReplacementNamed(context, '/dashboard');
      }
    }
  }
}