import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import './core/services/realtime_service.dart';
import './core/services/supabase_service.dart';
import './core/services/testing_debug_service.dart';
import './presentation/admin_authentication_portal/admin_authentication_portal.dart'
    as admin_portal;
import './presentation/admin_control_center/admin_control_center.dart'
    as admin_center;
import './presentation/admin_dashboard/admin_dashboard.dart' as admin_dash;
import './presentation/admin_security_gateway/admin_security_gateway.dart'
    as admin_gateway;
import './presentation/splash_screen/splash_screen.dart';
import './presentation/wallet_connection/wallet_connection.dart';
import 'core/app_export.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // Initialize Supabase
  try {
    await SupabaseService.instance.initialize();
  } catch (e) {
    debugPrint('Failed to initialize Supabase: $e');
  }

  // Initialize services with bypass logic for Web3 primary mode
  final List<Map<String, dynamic>> initializationSteps = [];

  try {
    if (kDebugMode) {
      print('🚀 ZoTrust App Starting - Enhanced Debug Mode');
      print('⏰ Initialization Time: ${DateTime.now()}');
    }

    // Step 1: Analyze dependencies and determine bypass strategy
    final debugService = TestingDebugService.instance;
    final stopwatch = Stopwatch()..start();

    final dependencyAnalysis = await debugService.analyzeStartupDependencies();
    stopwatch.stop();

    initializationSteps.add({
      'name': 'Dependency Analysis',
      'success': true,
      'duration': stopwatch.elapsedMilliseconds,
      'bypassEnabled': dependencyAnalysis['can_bypass_auth'],
    });

    if (kDebugMode) {
      print('📊 Dependency Analysis Complete:');
      dependencyAnalysis.forEach((key, value) {
        print('   $key: $value');
      });
    }

    // Step 2: Conditional Supabase initialization (with bypass)
    if (dependencyAnalysis['supabase_required'] == true) {
      stopwatch.reset();
      stopwatch.start();

      try {
        await SupabaseService.instance.initialize();

        // Initialize realtime services after Supabase
        await RealtimeService.instance.initialize();

        stopwatch.stop();
        initializationSteps.add({
          'name': 'Supabase & Realtime Services',
          'success': true,
          'duration': stopwatch.elapsedMilliseconds,
        });

        if (kDebugMode) {
          print('✅ Supabase and Realtime services initialized successfully');
        }
      } catch (e) {
        stopwatch.stop();
        initializationSteps.add({
          'name': 'Supabase & Realtime Services',
          'success': false,
          'duration': stopwatch.elapsedMilliseconds,
          'error': e.toString(),
          'bypassEnabled': true,
        });

        if (kDebugMode) {
          print('❌ Failed to initialize services: $e');
          print('🚀 Bypass mode activated - continuing with Web3 primary mode');
        }
      }
    } else {
      initializationSteps.add({
        'name': 'Supabase Initialization',
        'success': true,
        'duration': 0,
        'bypassEnabled': true,
        'reason': 'Skipped - Web3 primary dependency detected',
      });

      if (kDebugMode) {
        print(
          '🚀 Supabase initialization skipped - Web3Dart is primary dependency',
        );
      }
    }

    // Step 3: Test Web3 connectivity (non-blocking)
    stopwatch.reset();
    stopwatch.start();

    final web3Test = await debugService.testWeb3SmartContractConnection();
    stopwatch.stop();

    initializationSteps.add({
      'name': 'Web3 Smart Contract Test',
      'success': web3Test['success'],
      'duration': stopwatch.elapsedMilliseconds,
      'tradeCounter': web3Test['tradeCounter'],
      'gasPrice': web3Test['gasPrice'],
    });

    // Step 4: Validate offline capabilities
    stopwatch.reset();
    stopwatch.start();

    final offlineTest = await debugService.validateOfflineCapabilities();
    stopwatch.stop();

    initializationSteps.add({
      'name': 'Offline Capabilities Validation',
      'success': offlineTest,
      'duration': stopwatch.elapsedMilliseconds,
    });

    // Log complete initialization sequence
    if (kDebugMode) {
      debugService.logInitializationSequence(initializationSteps);

      print('🎯 Initialization Summary:');
      print('   Total Steps: ${initializationSteps.length}');
      print(
        '   Successful: ${initializationSteps.where((s) => s['success']).length}',
      );
      print('   Bypass Mode: ${dependencyAnalysis['can_bypass_auth']}');
      print(
        '   Primary Dependency: ${dependencyAnalysis['primary_dependency']}',
      );

      final totalDuration = initializationSteps
          .map<int>((s) => s['duration'] ?? 0)
          .reduce((a, b) => a + b);
      print('   Total Duration: ${totalDuration}ms\n');
    }
  } catch (e) {
    if (kDebugMode) {
      print('❌ Critical initialization error: $e');
      print('🚀 Forcing bypass mode for emergency startup');
    }

    initializationSteps.add({
      'name': 'Emergency Startup',
      'success': false,
      'error': e.toString(),
      'bypassEnabled': true,
    });
  }

  runApp(MyApp(initializationSteps: initializationSteps));
}

class MyApp extends StatefulWidget {
  final List<Map<String, dynamic>> initializationSteps;

  const MyApp({super.key, required this.initializationSteps});

  @override
  State<MyApp> createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> with WidgetsBindingObserver {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _initializeRealtimeServices();
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _cleanupRealtimeServices();
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    super.didChangeAppLifecycleState(state);

    switch (state) {
      case AppLifecycleState.resumed:
        // App came to foreground - only if realtime services are available
        try {
          RealtimeService.instance.initializePresenceTracking();
        } catch (e) {
          if (kDebugMode) {
            print('⚠️ Realtime service unavailable in bypass mode: $e');
          }
        }
        break;
      case AppLifecycleState.paused:
      case AppLifecycleState.detached:
        // App went to background or closed
        try {
          RealtimeService.instance.setUserOffline();
        } catch (e) {
          if (kDebugMode) {
            print('⚠️ Realtime service cleanup skipped in bypass mode: $e');
          }
        }
        break;
      case AppLifecycleState.hidden:
        // App is hidden but still running
        break;
      case AppLifecycleState.inactive:
        // App is inactive
        break;
    }
  }

  void _initializeRealtimeServices() {
    // Initialize presence tracking when app starts (with error handling)
    try {
      RealtimeService.instance.initializePresenceTracking();
    } catch (e) {
      if (kDebugMode) {
        print('⚠️ Realtime services not available - continuing in bypass mode');
      }
    }
  }

  void _cleanupRealtimeServices() {
    // Clean up all realtime subscriptions (with error handling)
    try {
      RealtimeService.instance.stopAllListeners();
      RealtimeService.instance.setUserOffline();
    } catch (e) {
      if (kDebugMode) {
        print('⚠️ Realtime cleanup skipped - service not initialized');
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Sizer(
      builder: (context, orientation, deviceType) {
        return MediaQuery(
          data: MediaQuery.of(
            context,
          ).copyWith(textScaler: TextScaler.linear(1.0)),
          child: MaterialApp(
            title: 'ZedTrust',
            theme: AppTheme.lightTheme,
            darkTheme: AppTheme.darkTheme,
            themeMode: ThemeMode.system,
            debugShowCheckedModeBanner: false,
            initialRoute: AppRoutes.initial,
            routes: AppRoutes.routes,
            onGenerateRoute: (RouteSettings settings) {
              final routeName = settings.name ?? '/';

              // Handle wallet connection route
              if (routeName == '/wallet-connection') {
                return MaterialPageRoute(
                  builder: (context) => const WalletConnection(),
                  settings: settings,
                );
              }

              // Direct route matching first
              if (AppRoutes.routes.containsKey(routeName)) {
                final routeBuilder = AppRoutes.routes[routeName]!;
                return MaterialPageRoute(
                  builder: routeBuilder,
                  settings: settings,
                );
              }

              // Handle admin routes with proper web URL support
              if (routeName.startsWith('/admin')) {
                switch (routeName) {
                  case '/admin':
                  case '/admin/':
                  case '/admin-security-gateway':
                    return MaterialPageRoute(
                      builder: (context) =>
                          const admin_gateway.AdminSecurityGateway(),
                      settings: RouteSettings(name: AppRoutes.admin),
                    );
                  case '/admin-control-center':
                    return MaterialPageRoute(
                      builder: (context) =>
                          const admin_center.AdminControlCenter(),
                      settings: settings,
                    );
                  case '/admin-dashboard':
                    return MaterialPageRoute(
                      builder: (context) => const admin_dash.AdminDashboard(),
                      settings: settings,
                    );
                  case '/admin-authentication-portal':
                    return MaterialPageRoute(
                      builder: (context) =>
                          const admin_portal.AdminAuthenticationPortal(),
                      settings: settings,
                    );
                }
              }

              // Fallback to splash screen for unknown routes
              return MaterialPageRoute(
                builder: (context) => SplashScreen(
                  initializationSteps: widget.initializationSteps,
                ),
                settings: RouteSettings(name: AppRoutes.initial),
              );
            },
            // Handle completely unknown routes
            onUnknownRoute: (RouteSettings settings) {
              return MaterialPageRoute(
                builder: (context) => SplashScreen(
                  initializationSteps: widget.initializationSteps,
                ),
                settings: RouteSettings(name: AppRoutes.initial),
              );
            },
          ),
        );
      },
    );
  }
}
